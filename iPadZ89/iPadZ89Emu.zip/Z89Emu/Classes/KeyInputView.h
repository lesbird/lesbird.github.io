//
//  KeyInputView.h
//  Z89Emu
//
//  Created by Les Bird on 8/1/11.
//  Copyright 2011 Les Bird. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KeyInputView : UIView<UIKeyInput>
{
	UIView	*inputView;
}

@end
