//
//  RootViewController.h
//  Z89Emu
//
//  Created by Les Bird on 3/5/11.
//  Copyright Les Bird 2011. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController // <UIKeyInput>
{

}

@end
