// ----------------------------------------------------------------------------
// DoGameStuff.h
// ----------------------------------------------------------------------------

#ifndef DOGAMESTUFF_H
#define DOGAMESTUFF_H

#include "global.h"

extern int AnimationPosTable[SP_MAX_PLAYFIELD_SIZE];
extern byte AnimationSubTable[SP_MAX_PLAYFIELD_SIZE];

extern void subDoGameStuff();

#endif /* DOGAMESTUFF_H */
