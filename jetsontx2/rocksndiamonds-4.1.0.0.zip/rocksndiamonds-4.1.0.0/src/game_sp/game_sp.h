// ============================================================================
// Rocks'n'Diamonds - McDuffin Strikes Back!
// ----------------------------------------------------------------------------
// (c) 1995-2014 by Artsoft Entertainment
//     		    Holger Schemel
//		    info@artsoft.org
//		    http://www.artsoft.org/
// ----------------------------------------------------------------------------
// game_sp.h
// ============================================================================

#ifndef GAME_SP_H
#define GAME_SP_H

#define GAME_SP_VERSION_1_0_0

#include "export.h"

#endif	/* GAME_SP_H */
