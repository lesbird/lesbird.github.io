// ----------------------------------------------------------------------------
// vb_lib.h
// ----------------------------------------------------------------------------

#ifndef VB_LIB_H
#define VB_LIB_H

#define Abs(x)	ABS(x)
#define Sqr(x)	sqrt(x)


/* helper functions for constructs not supported by C */

extern int MyGetTickCount();

#endif /* VB_LIB_H */
