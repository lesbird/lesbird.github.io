// ----------------------------------------------------------------------------
// Zonk.h
// ----------------------------------------------------------------------------

#ifndef ZONK_H
#define ZONK_H

#include "global.h"

extern void subAnimateZonks(int si);

#endif /* ZONK_H */
