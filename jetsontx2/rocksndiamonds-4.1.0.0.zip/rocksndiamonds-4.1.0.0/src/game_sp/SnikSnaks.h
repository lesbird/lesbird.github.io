// ----------------------------------------------------------------------------
// SnikSnaks.h
// ----------------------------------------------------------------------------

#ifndef SNIKSNAKS_H
#define SNIKSNAKS_H

#include "global.h"


extern void subAnimateSnikSnaks(int);
extern void subDrawAnimatedSnikSnaks(int);

#endif /* SNIKSNAKS_H */
