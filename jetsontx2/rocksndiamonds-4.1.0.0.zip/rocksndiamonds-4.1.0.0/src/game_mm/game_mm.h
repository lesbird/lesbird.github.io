// ============================================================================
// Mirror Magic -- McDuffin's Revenge
// ----------------------------------------------------------------------------
// (c) 1994-2017 by Artsoft Entertainment
//     		    Holger Schemel
//		    info@artsoft.org
//		    http://www.artsoft.org/
// ----------------------------------------------------------------------------
// game_mm.h
// ============================================================================

#ifndef GAME_MM_H
#define GAME_MM_H

#define GAME_MM_VERSION_1_0_0

#include "export.h"

#endif	/* GAME_MM_H */
