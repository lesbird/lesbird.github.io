/* 2000-08-10T04:29:10Z
 *
 * generate ulaw<->linear conversion tables to be included
 * directly in emerald mine source
 */

#include "main_em.h"
