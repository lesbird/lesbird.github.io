/* 2000-08-10T17:39:15Z
 *
 * handle sounds in emerald mine
 */

#include "main_em.h"
