/* Emerald Mine
 * 
 * David Tritscher
 * 
 * v0.0 2000-01-06T06:43:39Z
 *
 * set everything up and close everything down
 */
