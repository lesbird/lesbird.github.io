// ============================================================================
// Artsoft Retro-Game Library
// ----------------------------------------------------------------------------
// (c) 1995-2014 by Artsoft Entertainment
//     		    Holger Schemel
//		    info@artsoft.org
//		    http://www.artsoft.org/
// ----------------------------------------------------------------------------
// android.h
// ============================================================================

#ifndef ANDROID_H
#define ANDROID_H

#include <android/log.h>


#endif /* ANDROID_H */
