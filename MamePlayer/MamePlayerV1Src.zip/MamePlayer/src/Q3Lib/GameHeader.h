//
//	GameHeader.h - precompiled header file
//

#define	WIN32_LEAN_AND_MEAN

#include "Windows.h"

#include "GameApp.h"
#include "GameEditor.h"
#include "GameFile.h"
#include "GameGfx.h"
#include "GameInput.h"
#include "GameLight.h"
#include "GameLine.h"
#include "GameMath.h"
#include "GameMesh.h"
#include "GameParticles.h"
#include "GamePhysics.h"
#include "GameScript.h"
#include "GameSound.h"
#include "GameWin32.h"

#include <math.h>
#include <stdio.h>
#include <stdarg.h>

#ifdef _DEBUG
#pragma comment(lib,"Q3Lib-dbg.lib")
#else
#pragma comment(lib,"Q3Lib.lib")
#endif
