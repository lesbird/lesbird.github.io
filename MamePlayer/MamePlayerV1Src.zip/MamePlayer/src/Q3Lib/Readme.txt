Quantum 3 Game Engine
=====================

LUA SCRIPT COMMANDS
(all .X files can have an associated .lua script file in the same folder which will be executed at every tick)

Default script files in order of execution (used if they exist):

appinit.lua		- executes after all devices are created
gameinit.lua	- executes in InitGame() (can be used to load level objects)
gametick.lua	- executes at every game app tick
gameuninit.lua	- executes in UnInitGame() (can be used to free level objects)
appuninit.lua	- executes before all devices are released


GAME FUNCTIONS
==============
gam.adddirlight(dx,dy,dz)		- Creates and returns pointer to a directional light with direction dx,dy,dz
gam.addpointlight(x,y,z)		- Creates and returns pointer to a point light at position x,y,z
gam.fadein(t,r,g,b,a)			- Fade-in with t=fade rate in seconds, r,g,b,a=fade-to color
gam.fadeout(t,r,g,b,a)			- Fade-out with t=fade rate in seconds, r,g,b,a=fade-from color
gam.findobj(tag)				- Find object by it's tag
gam.findnextobj(tag,obj)		- Find next object by it's tag after obj
gam.freetexture(tex)			- Free texture using texture pointer
gam.freetexturename(name)		- Free texture using texture name
gam.freetextures()				- Free all textures
gam.getgametime()				- Get elapsed game time in seconds
gam.getprojection()				- Gets the projection matrix parameters (fov,aspect,near clip,far clip)
gam.getscreensize()				- Returns screen size (x,y)
gam.getview()					- Returns x,y,z,rx,ry,rz of view position and rotation
gam.getviewmatrix()				- Returns pointer to the view matrix
gam.getviewmatrixinv()			- Returns pointer to the inverse view matrix
gam.getviewpos()				- Returns x,y,z of view position
gam.getviewfwd()				- Returns view forward vector (x,y,z)
gam.getviewrgt()				- Returns view right vector (x,y,z)
gam.getviewup()					- Returns view up vector (x,y,z)
gam.isfadedone()				- Returns true if screen fading is completed
gam.killapp()					- Shuts down the application
gam.loadfont(f,name,s,w)		- Loads a font at index (f), name, size (s) and weight (w)
gam.loadtexture(file)			- Loads a texture into cache and returns a pointer to it
gam.log(string)					- Outputs a string to the log file
gam.lookat(x,y,z,lx,ly,lz)		- Set camera at x,y,z and look at world position lx,ly,lz
gam.makeargb(a,r,g,b)			- Returns unsigned integer of packed color (a,r,g,b=0 thru 255)
gam.printtext(f,x,y,r,g,b,a,s)	- Prints text (s) using font (f) at screen position (x,y) in color (r,g,b,a)
gam.printtextlen(f,s)			- Get length in pixels of string (s) using font (f)
gam.printtextworld(f,x,y,z,r,g,b,a,s)
								- Print text (s) using font (f) at world coordinates (x,y,z) using color (r,g,b,a)
gam.ptriseq(ptr1,ptr2)			- Retruns true if ptr1 == ptr2
gam.ptrisnil(ptr)				- Returns true if ptr is nil (NULL)
gam.ptrisvalid(ptr)				- Returns true if ptr is not nil (a valid pointer)
gam.screentoworldray(sx,sy)		- Returns a normalized ray (x,y,z) from screen coordinates (sx,sy)
gam.setdisplaymode(w,h,win)		- Set display mode width (w), height (h) and true or false (win) for windowed mode
gam.setfog(r,g,b,a,s,e)			- Set fog color (r,g,b,a), start position (s) and end position (e). Set s and e to 0 to turn fog off
gam.setlightcolor(l,r,g,b)		- Set color (r,g,b) of light (l)
gam.setlightdir(l,x,y,z)		- Set direction (x,y,z) of directional light (l)
gam.setlightpos(l,x,y,z)		- Set position (x,y,z) of point light (l)
gam.setlightprop(l,r,a1,a2,a3)	- Set properties, range (r), atten1 (a1), atten2 (a2), atten3 (a3) of point light (l)
gam.setlightrot(l,dx,dy,dz)		- Set rotation in degrees (dx,dy,dz) of light (l)
gam.setprojection(v,a,n,f)		- Set projection matrix parameters (v=fov, a=aspect, n=near clip, f=far clip)
gam.setshadowlightpos(x,y,z)	- Set shadow light position (x,y,z)
gam.setview(x,y,z,rx,ry,rz)		- Set view position (x,y,z) and rotation in degrees (rx,ry,rz)
gam.setviewpos(x,y,z)			- Set view position (x,y,z)
gam.worldtoscreen(x,y,z)		- Returns screen coordinates (sx,sy) from world coordinates (x,y,z)


INPUT FUNCTIONS
===============
joystick button table:

 0=Right-side down button
 1=Right-side left button
 2=Right-side right button
 3=Right-side top button
 4=Left rear top button
 5=Left rear bottom button
 6=Right rear top button
 7=Right rear bottom button
 8=Select button
 9=Start button
10=Left joystick button
11=Right joystick button
12=Left-side down button
13=Left-side left button
14=Left-side right button
15=Left-side top button

inp.getjoybutton(j,n)			- Returns true if button #n (see button table) is down on joystick #j and resets the button state
inp.getkey(k)					- Returns true if key (k) was pressed
inp.getmousebutton(n)			- Returns true if mouse button (1=left, 2=right, 3=middle) is down and resets the button state
inp.peekjoybutton(j,n)			- Returns true if button #n (see button table) is down on joystick #j
inp.peekkey(k)					- Returns true if key (k) is pressed
inp.peekmousebutton(n)			- Returns true if mouse button (1=left, 2=right, 3=middle) is down
inp.getjoyaxis(j,s)				- Gets the (x,y) position (-1.0 thru 1.0) of stick #s (0 for left stick, 1 for right stick) on joystick #j
								  (note: mouse input is merged with joystick input - x=mouse left/right, y=mouse up/down)


MESH FUNCTIONS
==============
NOTE: Texture Transforms - the transform type is application specific and is defined in the GameAppTextureTransform callback.
For Levitar they are as follows:

1 = scale the texture about the z axis
2 = scale the texture about the y axis
3 = scale the texture about the yz axis
4 = scale the texture about the x axis
5 = scale the texture about the xz axis
6 = scale the texture about the xy axis
7 = scale the texture about the xyz axis

msh.boxcollision(obj,is_static)	- Add box collision with physics making it non-moveable if is_static=true
msh.delcollision(obj)			- Delete any collision and physics data associated with the mesh
msh.getcolor(obj)				- Returns (r,g,b) color of mesh object diffuse material
msh.initshadowvolume(obj)		- Creates a stencil shadow volume for the mesh
msh.load(file)					- Creates and loads a .X file mesh and returns pointer to CGameMesh object
msh.loadeffect(obj,f,t)			- Loads an effects file (f) and assigns the name (t) as the active technique
msh.makebox(x,y,z,file)			- Creates and builds a cube with size (x,y,z) and texture and returns pointer to CGameMesh object
msh.setcolor(obj,r,g,b)			- Sets mesh material color properties (r,g,b = 0 thru 1)
msh.settechnique(obj,t)			- Sets the technique name (t) to be the active rendered technique for the current effect
msh.settexturexform(obj,s,t,r)	- Sets texture stage (s) transform type (t) with a time rate of (r) (see notes above)
msh.spherecollision(obj,is_static)
								- Add sphere collision with physics making it non-moveable if is_static=true
msh.trimeshcollision(obj)		- Make object a solid polygon-based collision mesh (no rigid-body physics)


OBJECT FUNCTIONS
================
obj.getbool(gobj,var)			- Get boolean value from a variable
obj.getcategory(gobj)			- Get objects game-defined category
obj.getfloat(gobj,var)			- Get float value from a variable
obj.getindex(gobj)				- Get the object index number
obj.getint(gobj,var)			- Get integer value from a variable
obj.getkilltime(gobj)			- Get objects time since killed (is_alive=false)
obj.getlifetime(gobj)			- Get objects life time
obj.getname(gobj)				- Get name string of object
obj.getpos(gobj)				- Get objects position (x,y,z)
obj.getptr(gobj,var)			- Get object pointer variable
obj.getquat(gobj)				- Get objects rotation in quaternions (x,y,z,w)
obj.getradius(gobj)				- Get objects radius
obj.getrot(gobj)				- Get objects rotation in degrees (x,y,z)
obj.getscale(gobj)				- Get objects scale (x,y,z)
obj.getstate(gobj)				- Get objects state
obj.gettag(gobj)				- Get tag string of object
obj.gettype(gobj)				- Get type value of object
obj.getvar(gobj,var)			- Get a string value from a variable
obj.getvec(gobj,var)			- Get a 3-element vector (x,y,z) from a variable
obj.getworldmatrix(gobj)		- Returns pointer to the objects world matrix
obj.hide(gobj)					- Hide object
obj.isactive(gobj)				- Returns true if object is active
obj.isalive(gobj)				- Returns true if object is alive
obj.istag(gobj,s)				- Returns true if object's tag equal string (s)
obj.isvisible(gobj)				- Returns true if object is visible
obj.kill(gobj)					- Kill object (sets it's is_alive flag to false)
obj.setactive(gobj,b)			- Set is_active to b (true or false)
obj.setalive(gobj)				- Set is_alive to true
obj.setbool(gobj,var,b)			- Set boolean (true or false) value to a variable
obj.setcategory(gobj,cat)		- Set objects category
obj.setfloat(gobj,var,f)		- Set float value to a variable
obj.setint(gobj,var,i)			- Set integer value to a variable
obj.setortho(gobj,b)			- Set orthographic render mode
obj.setoutline(gobj,var)		- Set mesh outlining to true or false (experimental)
obj.setoutlineparams(gobj,r,g,b,a,t)
								- Set outlining parameters (color=r,g,b,a - 0 thru 1.0), thickness=t (default=1.1)
obj.setpos(gobj,x,y,z)			- Set objects position
obj.setptr(gobj,var,val)		- Set object pointer variable
obj.setquat(gobj,x,y,z,w)		- Set objects rotation in quaternions
obj.setrot(gobj,x,y,z)			- Set objects rotation in degrees
obj.setscale(gobj,x,y,z)		- Set objects scale (x,y,z)
obj.setstate(gobj,state)		- Set objects state (application dependent)
obj.settag(gobj,tag)			- Set objects tag
obj.setvar(gobj,var,s)			- Set string value to a variable
obj.setvec(gobj,var,x,y,z)		- Set a 3-element vector to a variable
obj.show(gobj)					- Show object


PARTICLE FUNCTIONS
==================
par.addparticle(emitter,x,y,z,vx,vy,vz,ax,ay,az,life,argb)
								- Add particle at pos(x,y,z), vel(vx,vy,vz), acceleration(ax,ay,az),
								  life span (life) and 32-bit integer color (argb)
par.createemitter(name,n,f,s,is_s,is_w)
								- Creates a particle emitter with (name), max particles (n), texture file (f),
								  particle size (s), static if (is_s) is true, world space if (is_w) is true
par.deleteemitter(name)			- Delete a particle emitter with (name)
par.findemitter(name)			- Returns pointer to emitter with (name)
par.resetemitter(name)			- Resets all particles (turns them off) in emitter with (name)


PHYSICS FUNCTIONS
=================
phy.addforce(gobj,x,y,z)		- Add a force (x,y,z) to an object
phy.addforcerel(gobj,x,y,z)		- Add a relative force (x,y,z) to an object
phy.addtorque(gobj,x,y,z)		- Add a torque (x,y,z) to an object
phy.disable(gobj)				- Disable physics object
phy.enable(gobj)				- Enable physics object
phy.enableall()					- Enable all physics objects
phy.getforce(gobj)				- Get x,y,z force of an object
phy.getgravity()				- Get x,y,z world gravity
phy.gettorque(gobj)				- Get x,y,z torque of an object
phy.getvelocity(gobj)			- Get x,y,z velocity of an object
phy.getvelocityang(gobj)		- Get x,y,z angular velocity of an object
phy.hitray(gobj,x,y,z,dir_x,dir_y,dir_z,len)
								- Shoot ray from x,y,z in direction dir_x,dir_y,dir_z with length len
								  and returns (hit_obj,hit_x,hit_y,hit_z,nor_x,nor_y,nor_z,len)
phy.lineofsight(x,y,z,dx,dy,dz)	- Shoots a ray from x,y,z to dx,dy,dz and returns true if no hits
phy.setbits(gobj,cat,col)		- Set the category bits (cat) and collision bits (col) of an object
phy.setforce(gobj,x,y,z)		- Set force (x,y,z) of an object
phy.setgravity(x,y,z)			- Set world gravity (x,y,z)
phy.settorque(gobj,x,y,z)		- Set torque (x,y,z) of an object
phy.setvelocity(gobj,x,y,z)		- Set velocity (x,y,z) of an object
phy.setvelocityang(gobj,x,y,z)	- Set angular velocity (x,y,z) of an object
phy.zeroforces(gobj)			- Zero all physics forces of an object


SOUND FUNCTIONS
===============
snd.isname(handle,name)			- Returns true if (name) matches any part of sound file
snd.isplaying(file)				- Returns true if sound file is playing
snd.isplayinghandle(handle)		- Returns true if sound handle is playing
snd.loop(file,gobj)				- Loops a sound file and attaches it to gobj (gobj can be 'nil') and returns a handle
snd.loophandle(handle,gobj)		- Loops a sound handle and attaches it to gobj (gobj can be 'nil')
snd.play(file,gobj)				- Plays a sound file and attaches it to gobj (gobj can be 'nil') and returns a handle
snd.playhandle(handle,gobj)		- Plays a sound handle and attaches it to gobj (gobj can be 'nil')
snd.playpos(file,x,y,z,loop)	- Plays a sound at a position and loops if loop=true and returns a handle
snd.precache(file)				- Preloads sound data into sound cache for playing later and returns a handle
snd.setlistener(x,y,z,vx,vy,vz)	- Sets the listeners position (x,y,z) and velocity (vx,vy,vz)
snd.stop(handle)				- Stops a sound handle from playing


SPRITE FUNCTIONS
================
spr.create(file)				- Creates a screen sprite using the texture file supplied
spr.createworld(file)			- Creates a world sprite using the texture file supplied
spr.delete(spr)					- Deletes a sprite
spr.freesprites()				- Delete all sprites
spr.getcolor(spr)				- Returns r,g,b,a color of the sprite
spr.getpos(spr)					- Returns x,y,z position of the sprite
spr.getrot(spr)					- Returns x,y,z rotation of the sprite
spr.getscale(spr)				- Returns x,y scale (size in pixels) of the sprite
spr.gettexture(spr)				- Returns pointer to the texture used by the sprite
spr.hide(spr)					- Hides the sprite
spr.isvisible(spr)				- Returns true if sprite is visible (not hidden)
spr.setcolor(spr,r,g,b,a)		- Sets the color of the sprite
spr.setpos(spr,x,y,z)			- Sets the position of the sprite
spr.setrot(spr,deg)				- Sets the rotation (around the z) of the sprite
spr.setscale(spr,x,y)			- Sets the scale (size in pixels) of the sprite
spr.settexture(spr,file)		- Sets the texture of the sprite
spr.show(spr)					- Shows the sprite


VECTOR FUNCTIONS
================
vec.cross(x1,y1,z1,x2,y2,z2)	- Returns x,y,z cross product of x1,y1,z1 and x2,y2,z2
vec.dir(x1,y1,z1,x2,y2,z2)		- Returns x,y,z directional vector from x1,y1,z1 to x2,y2,z2
vec.dot(x1,y1,z1,x2,y2,z2)		- Returns dot product of x1,y1,z1 and x2,y2,z2
vec.len(x1,y1,z1)				- Returns the length of x1,y1,z1
vec.lensq(x1,y1,z1)				- Returns the length squared of x1,y1,z1
vec.mul(x1,y1,z1,x2,y2,z2)		- Returns x,y,z result of x1,y1,z1 times x2,y2,z2
vec.norm(x1,y1,z1)				- Returns x,y,z normalized vector of x1,y1,z1
vec.scale(x1,y1,z1,s)			- Returns x,y,z scaled by s
vec.todeg(x1,y1,z1,x2,y2,z2)	- Returns angle in degrees (x,y,z) from vector (x1,y1,z1) to (x2,y2,z2)
vec.torad(x1,y1,z1,x2,y2,z2)	- Returns angle in radians (x,y,z) from vector (x1,y1,z1) to (x2,y2,z2)
vec.xform(x1,y1,z1,m)			- Returns x,y,z transformed vector of x1,y1,z1 by matrix m
								  (to get m use gam.getviewmat, gam.getviewmatinv or obj.getworldmat)
