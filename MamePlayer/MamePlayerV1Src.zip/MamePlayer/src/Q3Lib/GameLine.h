// GameLine.h: interface for the CGameLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMELINE_H__1C4CCFC6_D82F_4D4F_8C06_CEFD9F1594CC__INCLUDED_)
#define AFX_GAMELINE_H__1C4CCFC6_D82F_4D4F_8C06_CEFD9F1594CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

class CGameLine : public CGameObject  
{
public:
	CGameLine();
	virtual ~CGameLine();

	virtual void			SetEndPoints(D3DXVECTOR3 start,D3DXVECTOR3 end,float thickness);
	virtual void			SetColor(D3DXCOLOR color_rgba);
	virtual void			LoadFile(const char *texture_file);
	virtual void			RenderObject();

public:
	float					m_Thickness;
	float					m_Translucency;

	D3DXVECTOR3				m_BegPoint;
	D3DXVECTOR3				m_EndPoint;

	D3DXMATRIX				m_WorldMatrix;

	D3DMATERIAL8			m_Material;

	LPDIRECT3DTEXTURE8		m_Texture;

	LPDIRECT3DINDEXBUFFER8	m_IndexBuffer;
	LPDIRECT3DVERTEXBUFFER8	m_VertexBuffer;
};

#endif // !defined(AFX_GAMELINE_H__1C4CCFC6_D82F_4D4F_8C06_CEFD9F1594CC__INCLUDED_)
