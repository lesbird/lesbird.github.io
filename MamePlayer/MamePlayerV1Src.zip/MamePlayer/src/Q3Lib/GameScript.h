// GameScript.h: interface for the CGameScript class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMESCRIPT_H__B3CC7F72_6797_43F8_9DDE_0D8FC3AF77FF__INCLUDED_)
#define AFX_GAMESCRIPT_H__B3CC7F72_6797_43F8_9DDE_0D8FC3AF77FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameSound.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "lualib.h"
#include "lauxlib.h"

#ifdef __cplusplus
}
#endif

#ifdef _DEBUG
#pragma comment(lib,"lua-dbg.lib")
#else
#pragma comment(lib,"lua.lib")
#endif
/*
typedef struct Script
{
	char *			Code;
	int				Size;
	char			File[VAR_VALUE_SIZE];
} Script_t;
*/
class CGameObject;

class CGameScript  
{
public:
	CGameScript();
	virtual ~CGameScript();

	void			Init();
	char *			LoadFile(const char *file_name,int &size);
	void			FreeScript(char *script_code,int size);
	void			Update(float delta_time);
	int				Exec(char *script_code,int script_size);
	int				ExecCollisionCallback(char *script_code,int script_size,CGameObject *gobj1,CGameObject *gobj2,float x,float y,float z,float nor_x,float nor_y,float nor_z,float pen);
	int				ExecDelta(char *script_code,int script_size,float delta_time);
	int				ExecParam(char *script_code,int script_size,const char *param);
	int				ExecSoundCallback(char *script_code,int script_size,SND_HANDLE buffer);
	int				ExecTick(char *script_code,int script_size,CGameObject *gobj,float delta_time);

public:
	lua_State *		m_luaState;
};

extern
CGameScript *		g_GameScript;

extern
int					ScriptMem;

extern
void				InitScript();
extern
void				UnInitScript();

#endif // !defined(AFX_GAMESCRIPT_H__B3CC7F72_6797_43F8_9DDE_0D8FC3AF77FF__INCLUDED_)
