// GameLight.h: interface for the GameLight class.
//
// 10/21/04	Les Bird
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DLIGHT_H__452D8B71_D089_46B5_A065_0F63A3C21E65__INCLUDED_)
#define AFX_3DLIGHT_H__452D8B71_D089_46B5_A065_0F63A3C21E65__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	VAR_LIGHT		'LIGH'
#define	VAR_LIGHT_IDX	'LIDX'

class CGameLight : public CGameObject
{
public:
	CGameLight();
	virtual ~CGameLight();

	virtual void	SetGlobalDirectionalLight();
	virtual void	SetGlobalDynamicLight();

	virtual void	SetColor(float r,float g,float b);
	virtual void	SetSpecular(float r,float g,float b);

	virtual void	SetProperties(float range,float atten1,float atten2,float atten3);

	virtual void	SetDirection(float x,float y,float z);
	virtual void	SetRotation(float deg_x,float deg_y,float deg_z);
	virtual void	SetPosition(float x,float y,float z);

	virtual void	RenderObject();
};

extern
GameObjectList_t	LightObjectList;

extern
CGameLight *		DirectionalLight;
extern
CGameLight *		DynamicLight;

extern
D3DXVECTOR3			DirectionalLightDir;
extern
D3DXVECTOR3			DynamicLightPos;
extern
float				DynamicLightRange;
extern
float				DynamicLightAtten1;
extern
float				DynamicLightAtten2;
extern
float				DynamicLightAtten3;

#endif // !defined(AFX_3DLIGHT_H__452D8B71_D089_46B5_A065_0F63A3C21E65__INCLUDED_)
