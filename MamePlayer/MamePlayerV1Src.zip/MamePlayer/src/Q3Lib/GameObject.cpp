// GameObject.cpp: implementation of the CGameObject class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

GameObjectList_t	GameObjectList;
GameObjectList_t	RenderObjectList;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameObject::CGameObject()
{
	m_Sort=-1;
	m_State=0;

	m_bCanCull=false;
	m_bHasShadow=false;
	m_bIsActive=false;
	m_bIsAlive=true;
	m_bIsClipped=false;
	m_bIsOrtho=false;
	m_bIsStatic=false;
	m_bIsTransparent=false;
	m_bIsUnlit=false;
	m_bVisible=false;

	m_Category=0;
	m_Type=0;

	m_KillTime=0;
	m_LifeTime=0;
	m_Translucency=1;

	m_Tag[0]=0;

	m_ScriptCode=NULL;
	m_ScriptSize=0;
	m_ScriptStatus=0;

	m_VarCache=NULL;
	m_VarList.clear();
//	add vars here
	AddBool(this,VAR_CAN_CULL,true);
	AddBool(this,VAR_CAN_DELETE,true);
	AddInt(this,VAR_TYPE,'GOBJ');
	AddFloat(this,VAR_MASS,1);
	SetQuaternion(0,0,0,1);
	InsertGameObject(this);
}

CGameObject::~CGameObject()
{
	if (m_ScriptCode != NULL) {
		g_GameScript->FreeScript(m_ScriptCode,m_ScriptSize);
		m_ScriptCode=NULL;
	}
	while (m_VarList.size() != 0) {
		Var_t *var=*m_VarList.begin();
		m_VarList.pop_front();
		delete var;
	}
}

CGameObject *
CreateGameObject()
{
	CGameObject *gobj=new CGameObject;
//	InsertGameObject(gobj);
	return(gobj);
}

void
InsertGameObject(CGameObject *gobj)
{
	gobj->SetPosition(0,0,0);
	gobj->SetRotation(0,0,0);
	gobj->SetScale(1,1,1);
	AddFloat(gobj,VAR_TRANSLUCENCY,1);
	gobj->m_ObjectIndex=GameObjectList.size();
	GameObjectList.push_back(gobj);
	Show(gobj);
}

void
DeleteGameObject(CGameObject *gobj)
{
	GameObjectList.remove(gobj);
	RenderObjectList.remove(gobj);
	delete gobj;
}

Var_t *
FindVar(CGameObject *gobj,unsigned int name)
{
	if (gobj->m_VarCache != NULL && gobj->m_VarCache->Name == name) {
		return(gobj->m_VarCache);
	}
	for (VarList_t::iterator v=gobj->m_VarList.begin() ; v != gobj->m_VarList.end() ; v++) {
		Var_t *var=(*v);
		if (var->Name == name) {
			gobj->m_VarCache=var;
			return(var);
		}
	}
	return(NULL);
}

unsigned int
StrToVar(const char *str)
{
	unsigned int v=(toupper(str[0])<<24)|(toupper(str[1])<<16)|(toupper(str[2])<<8)|(toupper(str[3]));
	return(v);
}

void
AddVar(CGameObject *gobj,unsigned int name,const char *val)
{
	Var_t *var=FindVar(gobj,name);
	if (var == NULL) {
		var=new Var_t;
		var->Name=name;
		gobj->m_VarList.push_back(var);
	}
	strcpy(var->Value,val);
	_strupr(var->Value);
}

const char *
GetVar(CGameObject *gobj,unsigned int name)
{
	Var_t *var=FindVar(gobj,name);
	if (var != NULL) {
		return(var->Value);
	}
	return(NULL);
}

void
AddBool(CGameObject *gobj,unsigned int name,bool val)
{
	switch (name) {
	case VAR_CAN_CULL:
		gobj->m_bCanCull=val;
		return;
	case VAR_HAS_SHADOW:
		gobj->m_bHasShadow=val;
		return;
	case VAR_IS_ACTIVE:
		gobj->m_bIsActive=val;
		return;
	case VAR_IS_ALIVE:
		gobj->m_bIsAlive=val;
		return;
	case VAR_IS_CLIPPED:
		gobj->m_bIsClipped=val;
		return;
	case VAR_IS_ORTHO:
		gobj->m_bIsOrtho=val;
		return;
	case VAR_IS_STATIC:
		gobj->m_bIsStatic=val;
		return;
	case VAR_IS_TRANSPARENT:
		gobj->m_bIsTransparent=val;
		return;
	case VAR_IS_UNLIT:
		gobj->m_bIsUnlit=val;
		return;
	case VAR_IS_VISIBLE:
		gobj->m_bVisible=val;
		return;
	}
	if (val) {
		AddVar(gobj,name,"T");
	}
	else {
		AddVar(gobj,name,"F");
	}
}

bool
GetBool(CGameObject *gobj,unsigned int name)
{
	switch (name) {
	case VAR_CAN_CULL:
		return(gobj->m_bCanCull);
	case VAR_HAS_SHADOW:
		return(gobj->m_bHasShadow);
	case VAR_IS_ACTIVE:
		return(gobj->m_bIsActive);
	case VAR_IS_ALIVE:
		return(gobj->m_bIsAlive);
	case VAR_IS_CLIPPED:
		return(gobj->m_bIsClipped);
	case VAR_IS_ORTHO:
		return(gobj->m_bIsOrtho);
	case VAR_IS_STATIC:
		return(gobj->m_bIsStatic);
	case VAR_IS_TRANSPARENT:
		return(gobj->m_bIsTransparent);
	case VAR_IS_UNLIT:
		return(gobj->m_bIsUnlit);
	case VAR_IS_VISIBLE:
		return(gobj->m_bVisible);
	}
	const char *val=GetVar(gobj,name);
	if (val != NULL) {
		if (val[0] == 'T') {
			return(true);
		}
	}
	return(false);
}

void
AddInt(CGameObject *gobj,unsigned int name,int val)
{
	char value[VAR_VALUE_SIZE];
	switch (name) {
	case VAR_CATEGORY:
		gobj->m_Category=val;
		return;
	case VAR_TYPE:
		gobj->m_Type=val;
		return;
	}
	sprintf(value,"%d",val);
	AddVar(gobj,name,value);
}

int
GetInt(CGameObject *gobj,unsigned int name)
{
	switch (name) {
	case VAR_CATEGORY:
		return(gobj->m_Category);
	case VAR_TYPE:
		return(gobj->m_Type);
	}
	const char *val=GetVar(gobj,name);
	if (val != NULL) {
		return(atoi(val));
	}
	return(0);
}

void
AddFloat(CGameObject *gobj,unsigned int name,float val)
{
	char value[VAR_VALUE_SIZE];
	switch (name) {
	case VAR_TRANSLUCENCY:
		gobj->m_Translucency=val;
		return;
	}
	sprintf(value,"%f",val);
	AddVar(gobj,name,value);
}

float
GetFloat(CGameObject *gobj,unsigned int name)
{
	switch (name) {
	case VAR_TRANSLUCENCY:
		return(gobj->m_Translucency);
	}
	const char *val=GetVar(gobj,name);
	if (val != NULL) {
		return(float(atof(val)));
	}
	return(0);
}

void
AddVec3(CGameObject *gobj,unsigned int name,float x,float y,float z)
{
	char value[VAR_VALUE_SIZE];
	sprintf(value,"%f,%f,%f",x,y,z);
	AddVar(gobj,name,value);
}

void
GetVec3(CGameObject *gobj,unsigned int name,float &x,float &y,float &z)
{
	const char *val=GetVar(gobj,name);
	if (val != NULL) {
		sscanf(val,"%f,%f,%f",&x,&y,&z);
	}
	else {
		x=y=z=0;
	}
}

void
AddVec4(CGameObject *gobj,unsigned int name,float x,float y,float z,float w)
{
	char value[VAR_VALUE_SIZE];
	sprintf(value,"%f,%f,%f,%f",x,y,z,w);
	AddVar(gobj,name,value);
}

void
GetVec4(CGameObject *gobj,unsigned int name,float &x,float &y,float &z,float &w)
{
	const char *val=GetVar(gobj,name);
	if (val != NULL) {
		sscanf(val,"%f,%f,%f,%f",&x,&y,&z,&w);
	}
	else {
		x=y=z=w=0;
	}
}

void
AddPtr(CGameObject *gobj,unsigned int name,void *ptr)
{
	AddInt(gobj,name,(unsigned int)ptr);
}

void *
GetPtr(CGameObject *gobj,unsigned int name)
{
	return((void *)GetInt(gobj,name));
}

CGameObject *
FindTag(const char *tag)
{
	for (GameObjectList_t::iterator g=GameObjectList.begin() ; g != GameObjectList.end() ; g++) {
		CGameObject *gobj=(*g);
		if (stricmp(gobj->m_Tag,tag) == 0) {
			return(gobj);
		}
	}
	return(NULL);
}

CGameObject *
FindNextTag(const char *tag,CGameObject *start_obj)
{
	bool found_first=false;
	for (GameObjectList_t::iterator g=GameObjectList.begin() ; g != GameObjectList.end() ; g++) {
		CGameObject *gobj=(*g);
		if (gobj == start_obj) {
			found_first=true;
		}
		else if (found_first) {
			if (stricmp(gobj->m_Tag,tag) == 0) {
				return(gobj);
			}
		}
	}
	return(NULL);
}

void
Hide(CGameObject *gobj)
{
	if (GetBool(gobj,VAR_IS_VISIBLE)) {
		AddBool(gobj,VAR_IS_VISIBLE,false);
		RenderObjectList.remove(gobj);
	}
}

void
Show(CGameObject *gobj)
{
	if (GetBool(gobj,VAR_IS_VISIBLE)) {
		return;
	}
	AddBool(gobj,VAR_IS_VISIBLE,true);
	RenderObjectList.push_back(gobj);
}

float
RotateFloatTo(float axis_angle,float rotate_to_angle)
{
	float rotate_delta;
	if (axis_angle-rotate_to_angle > 180) {
		rotate_delta=(rotate_to_angle+360)-axis_angle;
	}
	else if (axis_angle-rotate_to_angle < -180) {
		rotate_delta=rotate_to_angle-(axis_angle+360);
	}
	else {
		rotate_delta=rotate_to_angle-axis_angle;
	}
	return(rotate_delta);
}

bool
CGameObject::RotateTo(float x,float y,float z,float rotate_rate,float threshold,float delta_time)
{
	bool rotate_done=false;
	float rx,ry,rz;
	GetRotation(rx,ry,rz);
	rx+=RotateFloatTo(rx,x)*rotate_rate*delta_time;
	ry+=RotateFloatTo(ry,y)*rotate_rate*delta_time;
	rz+=RotateFloatTo(rz,z)*rotate_rate*delta_time;
	if (fabs(rx-x) < threshold && fabs(ry-y) < threshold && fabs(rz-z) < threshold) {
		rotate_done=true;
		rx=x;
		ry=y;
		rz=z;
	}
	SetRotation(rx,ry,rz);
	return(rotate_done);
}

void
CGameObject::SetPosition(float x,float y,float z)
{
	AddVec3(this,VAR_POS,x,y,z);
}

void
CGameObject::GetPosition(float &x,float &y,float &z)
{
	GetVec3(this,VAR_POS,x,y,z);
}

void
CGameObject::SetRotation(float x,float y,float z)
{
	AddVec3(this,VAR_ROT,CLAMP_360(x),CLAMP_360(y),CLAMP_360(z));
}

void
CGameObject::GetRotation(float &x,float &y,float &z)
{
	GetVec3(this,VAR_ROT,x,y,z);
}

void
CGameObject::SetQuaternion(float x,float y,float z,float w)
{
	AddVec4(this,VAR_QUAT,x,y,z,w);
}

void
CGameObject::GetQuaternion(float &x,float &y,float &z,float &w)
{
	GetVec4(this,VAR_QUAT,x,y,z,w);
}

void
CGameObject::SetScale(float x,float y,float z)
{
	AddVec3(this,VAR_SCALE,x,y,z);
}

void
CGameObject::GetScale(float &x,float &y,float &z)
{
	GetVec3(this,VAR_SCALE,x,y,z);
}

void
CGameObject::SetTag(const char *tag)
{
	AddVar(this,VAR_TAG,tag);
	strcpy(m_Tag,GetVar(this,VAR_TAG));
}

const char *
CGameObject::GetTag()
{
	return(m_Tag);
}

void
CGameObject::LoadScriptFile(const char *file_name)
{
	if (g_GameScript != NULL) {
		if (m_ScriptCode != NULL) {
			g_GameScript->FreeScript(m_ScriptCode,m_ScriptSize);
		}
		m_ScriptCode=g_GameScript->LoadFile(file_name,m_ScriptSize);
		if (m_ScriptCode != NULL) {
			AddBool(this,VAR_IS_ACTIVE,true);
			m_ScriptStatus=0;
		}
	}
}

//	copies string variables to in-memory variables
void
CGameObject::ApplyVars()
{
	const char *cat_val=GetVar(this,VAR_CATEGORY);
	if (cat_val != NULL) {
		m_Category=atoi(cat_val);
	}
	const char *shadow_val=GetVar(this,VAR_HAS_SHADOW);
	if (shadow_val != NULL) {
		m_bHasShadow=(shadow_val[0] == 'T' ? true : false);
	}
}

//	copies in-memory variables to string variables
void
CGameObject::UpdateVars()
{
	char buf[VAR_VALUE_SIZE];
	sprintf(buf,"%d",m_Category);
	AddVar(this,VAR_CATEGORY,buf);
	sprintf(buf,"%s",m_bHasShadow ? "T" : "F");
	AddVar(this,VAR_HAS_SHADOW,buf);
}

void
CGameObject::LostObject()
{
}

void
CGameObject::ResetObject()
{
}

void
CGameObject::UpdateObject(float delta_time)
{
	if (g_bUpdateObjects) {
		m_LifeTime+=delta_time;
		if (!GetBool(this,VAR_IS_ALIVE)) {
			m_KillTime+=delta_time;
		}
		if (m_ScriptCode != NULL) {
			if (m_ScriptStatus == 0) {
				m_ScriptStatus=g_GameScript->ExecTick(m_ScriptCode,m_ScriptSize,this,delta_time);
			}
		}
	}
}

void
CGameObject::PreRenderObject()
{
}

void
CGameObject::RenderObject()
{
}

void
CGameObject::PostRenderObject()
{
}
