// GameEditor.cpp: implementation of the CGameEditor class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameEditor::CGameEditor()
{
	SelectedObj=NULL;
	SelectedSpr=NULL;

	EditObjList.clear();
}

CGameEditor::~CGameEditor()
{

}

void
CGameEditor::Init()
{
}

void
CGameEditor::UnInit()
{
	while (EditObjList.size() != 0) {
		CGameObject *gobj=(*EditObjList.begin());
		EditObjList.pop_front();
		delete gobj;
	}
	SelectedObj=NULL;
	SelectedSpr=NULL;
}

void
CGameEditor::Update(float delta_time)
{
}
