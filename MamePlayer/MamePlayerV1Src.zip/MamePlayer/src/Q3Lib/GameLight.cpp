// GameLight.cpp: implementation of the GameLight class.
//
// 3/13/06	Les Bird
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

static
int	g_LightIndex;

#define	DYNL_RANGE	100000.0f

D3DXVECTOR3			DirectionalLightDir;
D3DXVECTOR3			DynamicLightPos;
float				DynamicLightRange=DYNL_RANGE;
float				DynamicLightAtten1=0;
float				DynamicLightAtten2=0.001f;
float				DynamicLightAtten3=0;

CGameLight *		DirectionalLight;
CGameLight *		DynamicLight;

GameObjectList_t	LightObjectList;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameLight::CGameLight()
{
	AddInt(this,VAR_TYPE,'LIGH');

	D3DLIGHT8 *light=new D3DLIGHT8;
	memset(light,0,sizeof(D3DLIGHT8));
	light->Type=D3DLIGHT_DIRECTIONAL;
	light->Ambient=D3DXCOLOR(0,0,0,0);
	light->Diffuse=D3DXCOLOR(1,1,1,1);
	light->Specular=D3DXCOLOR(1,1,1,1);
	light->Direction=D3DXVECTOR3(0,0,1);
	light->Range=10000;
	AddInt(this,VAR_LIGHT_IDX,g_LightIndex++);
	AddPtr(this,VAR_LIGHT,light);

	LightObjectList.push_back(this);
}

CGameLight::~CGameLight()
{
	LightObjectList.remove(this);

	if (DynamicLight == this) {
		DynamicLight=NULL;
	}
	else if (DirectionalLight == this) {
		DirectionalLight=NULL;
	}
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	int light_index=GetInt(this,VAR_LIGHT_IDX);
	g_D3DDevice->LightEnable(light_index,false);
	delete light;
}

void
CGameLight::SetGlobalDirectionalLight()
{
	DirectionalLight=this;
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Type=D3DLIGHT_DIRECTIONAL;
}

void
CGameLight::SetGlobalDynamicLight()
{
	DynamicLight=this;
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Type=D3DLIGHT_POINT;
}

void
CGameLight::SetColor(float r,float g,float b)
{
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Diffuse=D3DXCOLOR(r,g,b,1);
}

void
CGameLight::SetSpecular(float r,float g,float b)
{
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Specular=D3DXCOLOR(r,g,b,1);
}

void
CGameLight::SetProperties(float range,float atten1,float atten2,float atten3)
{
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Range=range;
	light->Attenuation0=atten1;
	light->Attenuation1=atten2;
	light->Attenuation2=atten3;
	light->Type=D3DLIGHT_POINT;
}

void
CGameLight::SetDirection(float x,float y,float z)
{
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Direction=D3DXVECTOR3(x,y,z);
	light->Type=D3DLIGHT_DIRECTIONAL;
}

void
CGameLight::SetRotation(float deg_x,float deg_y,float deg_z)
{
	CGameObject::SetRotation(deg_x,deg_y,deg_z);
	D3DXMATRIX rot_mat;
	D3DXMatrixRotationYawPitchRoll(&rot_mat,D3DXToRadian(deg_y),D3DXToRadian(deg_x),D3DXToRadian(deg_z));
	D3DXVECTOR3 dir(0,0,1);
	D3DXVec3TransformNormal(&dir,&dir,&rot_mat);
	SetDirection(dir.x,dir.y,dir.z);
}

void
CGameLight::SetPosition(float x,float y,float z)
{
	CGameObject::SetPosition(x,y,z);
	D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
	light->Position=D3DXVECTOR3(x,y,z);
}

void
CGameLight::RenderObject()
{
	int light_index=GetInt(this,VAR_LIGHT_IDX);
	if (GetBool(this,VAR_IS_VISIBLE)) {
		D3DLIGHT8 *light=(D3DLIGHT8 *)GetPtr(this,VAR_LIGHT);
		g_D3DDevice->SetLight(light_index,light);
		g_D3DDevice->LightEnable(light_index,TRUE);
		if (DirectionalLight == this) {
			DirectionalLightDir=light->Direction;
		}
		else if (DynamicLight == this) {
			DynamicLightPos=light->Position;
			DynamicLightRange=light->Range;
			DynamicLightAtten1=light->Attenuation0;
			DynamicLightAtten2=light->Attenuation1;
			DynamicLightAtten3=light->Attenuation2;
		}
	}
	else {
		g_D3DDevice->LightEnable(light_index,FALSE);
	}
}
