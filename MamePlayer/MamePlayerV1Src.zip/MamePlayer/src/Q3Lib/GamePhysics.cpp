// GamePhysics.cpp: implementation of the CGamePhysics class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

static
bool							bRayHit=false;

static
float							GravityX,GravityY,GravityZ;

static
HitRayCollision_t				HitRayCollision;

static
dGeomID							RayGeom;

int								g_BodiesEnabled;

PhysicsObjectList_t				PhysicsObjectList;

dWorldID						g_World;
dSpaceID						g_Space;
dJointGroupID					g_CollisionJointGroup;

static
char *							CollScript;
static
int								CollScriptSize;

//
//	GamePhysics functions
//

void
InitPhysics()
{
	g_World=dWorldCreate();
	dWorldSetAutoDisableFlag(g_World,true);
	dWorldSetAutoDisableAngularThreshold(g_World,0.1f);
	dWorldSetAutoDisableLinearThreshold(g_World,0.1f);
	dWorldSetCFM(g_World,0.01f);

	g_Space=dHashSpaceCreate(0);
	g_CollisionJointGroup=dJointGroupCreate(0);

	RayGeom=dCreateRay(g_Space,0);
	dGeomSetCategoryBits(RayGeom,0);
	dGeomSetCollideBits(RayGeom,0);
	dGeomDisable(RayGeom);
}

void
UnInitPhysics()
{
	if (CollScript != NULL) {
		g_GameScript->FreeScript(CollScript,CollScriptSize);
		CollScript=NULL;
	}

	dGeomDestroy(RayGeom);

	dJointGroupDestroy(g_CollisionJointGroup);
	dSpaceDestroy(g_Space);
	dWorldDestroy(g_World);
	dCloseODE();
}

void
PhyLoadScript(char *file_name)
{
	if (CollScript != NULL) {
		g_GameScript->FreeScript(CollScript,CollScriptSize);
	}
	CollScript=g_GameScript->LoadFile(file_name,CollScriptSize);
}

void
PhyGetGravity(float &x,float &y,float &z)
{
	x=GravityX;
	y=GravityY;
	z=GravityZ;
}

void
PhySetGravity(float x,float y,float z)
{
	dWorldSetGravity(g_World,x,y,z);
	GravityX=x;
	GravityY=y;
	GravityZ=z;
}

PhysicsObject_t *
PhyCreatePhysicsObject()
{
	PhysicsObject_t *phys_obj=new PhysicsObject_t;
	memset(phys_obj,0,sizeof(PhysicsObject_t));
	PhysicsObjectList.push_back(phys_obj);
	return(phys_obj);
}

void
PhyDeletePhysicsObject(PhysicsObject_t *phys_obj)
{
	PhysicsObjectList.remove(phys_obj);
	if (phys_obj->Joint != NULL) {
		dJointDestroy(phys_obj->Joint);
	}
	for (int i=0 ; i < MAX_GEOMS ; i++) {
		if (phys_obj->Geom[i] != NULL) {
			dGeomDestroy(phys_obj->Geom[i]);
		}
	}
	if (phys_obj->Body != NULL) {
		dBodyDestroy(phys_obj->Body);
	}
	delete phys_obj;
}

void
PhyMakeStatic(PhysicsObject_t *phys_obj)
{
	if (phys_obj != NULL) {
		if (phys_obj->Body != NULL) {
			dBodyDestroy(phys_obj->Body);
			phys_obj->Body=NULL;
		}
	}
}

PhysicsObject_t *
PhyAddBoxCollision(float width,float height,float depth,float mass_kg,bool is_static)
{
	PhysicsObject_t *phys_obj=PhyCreatePhysicsObject();
	phys_obj->Geom[0]=dCreateBox(g_Space,width,height,depth);
	if (is_static == false && mass_kg > 0) {
		dMass mass;
		dMassSetBoxTotal(&mass,mass_kg,width,width,width);
		phys_obj->Body=dBodyCreate(g_World);
		dBodySetMass(phys_obj->Body,&mass);
		dGeomSetBody(phys_obj->Geom[0],phys_obj->Body);
	}
	return(phys_obj);
}

PhysicsObject_t *
PhyAddSphereCollision(float radius,float mass_kg,bool is_static)
{
	PhysicsObject_t *phys_obj=PhyCreatePhysicsObject();
	phys_obj->Geom[0]=dCreateSphere(g_Space,radius);
	if (is_static == false && mass_kg > 0) {
		dMass mass;
		dMassSetSphereTotal(&mass,mass_kg,radius);
		phys_obj->Body=dBodyCreate(g_World);
		dBodySetMass(phys_obj->Body,&mass);
		dGeomSetBody(phys_obj->Geom[0],phys_obj->Body);
	}
	return(phys_obj);
}

PhysicsObject_t *
PhyAddCylinderCollision(float radius,float height,float mass_kg,bool is_static)
{
	PhysicsObject_t *phys_obj=PhyCreatePhysicsObject();
	phys_obj->Geom[0]=dCreateCCylinder(g_Space,radius,height);
	if (is_static == false && mass_kg > 0) {
		dMass mass;
		dMassSetCappedCylinderTotal(&mass,mass_kg,2,radius,height);
		phys_obj->Body=dBodyCreate(g_World);
		dBodySetMass(phys_obj->Body,&mass);
		dGeomSetBody(phys_obj->Geom[0],phys_obj->Body);
	}
	return(phys_obj);
}

PhysicsObject_t *
PhyAddCompoundCollision(unsigned int col_type,PhysicsObject_t *phys_obj,float offset_x,float offset_y,float offset_z,float size_x,float size_y,float size_z,float mass_kg,bool is_static)
{
	if (phys_obj == NULL) {
		phys_obj=PhyCreatePhysicsObject();
	}
	if (phys_obj != NULL) {
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] == NULL) {
				phys_obj->Geom[i]=dCreateGeomTransform(g_Space);
				dGeomID geom=NULL;
				switch (col_type) {
				case 'BOX':
					geom=dCreateBox(NULL,size_x,size_y,size_z);
					break;
				case 'SPHE':
					geom=dCreateSphere(NULL,size_x);
					break;
				}
				dGeomTransformSetGeom(phys_obj->Geom[i],geom);
				dGeomTransformSetCleanup(phys_obj->Geom[i],1);
				dGeomSetPosition(geom,offset_x,offset_y,offset_z);
				if (is_static == false && mass_kg > 0) {
					dMass mass;
					dMassSetBoxTotal(&mass,mass_kg,size_x,size_x,size_x);
					if (phys_obj->Body == NULL) {
						phys_obj->Body=dBodyCreate(g_World);
						dBodySetMass(phys_obj->Body,&mass);
					}
					dGeomSetBody(phys_obj->Geom[i],phys_obj->Body);
				}
				break;
			}
		}
	}
	return(phys_obj);
}

PhysicsObject_t *
PhyAddTriMeshCollision(float *vertex_data,int num_vertices,int *index_data,int num_indices)
{
	PhysicsObject_t *phys_obj=PhyCreatePhysicsObject();
	dTriMeshDataID trimesh_data_id=dGeomTriMeshDataCreate();
	dGeomTriMeshDataBuildSimple(trimesh_data_id,vertex_data,num_vertices,index_data,num_indices);
	phys_obj->Geom[0]=dCreateTriMesh(g_Space,trimesh_data_id,NULL,NULL,NULL);
	return(phys_obj);
}

void
PhySetCollisionBits(PhysicsObject_t *phys_obj,unsigned int cat_bits,unsigned int col_bits)
{
	if (phys_obj != NULL) {
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomSetCategoryBits(phys_obj->Geom[i],cat_bits);
				dGeomSetCollideBits(phys_obj->Geom[i],col_bits);
			}
		}
	}
}

void
PhySetPosition(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetPosition(phys_obj->Body,x,y,z);
	}
	else {
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomSetPosition(phys_obj->Geom[i],x,y,z);
			}
		}
	}
}

void
PhyGetPosition(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *pos=dBodyGetPosition(phys_obj->Body);
		x=pos[0];
		y=pos[1];
		z=pos[2];
	}
	else if (phys_obj->Geom[0] != NULL) {
		const float *pos=dGeomGetPosition(phys_obj->Geom[0]);
		x=pos[0];
		y=pos[1];
		z=pos[2];
	}
}

void
PhySetQuaternion(PhysicsObject_t *phys_obj,float x,float y,float z,float w)
{
	if (phys_obj->Body != NULL) {
		dQuaternion q;
		q[0]=w;
		q[1]=x;
		q[2]=y;
		q[3]=z;
		dBodySetQuaternion(phys_obj->Body,q);
	}
	else if (phys_obj->Geom[0] != NULL) {
		dQuaternion q;
		q[0]=w;
		q[1]=x;
		q[2]=y;
		q[3]=z;
		dGeomSetQuaternion(phys_obj->Geom[0],q);
	}
}

void
PhyGetQuaternion(PhysicsObject_t *phys_obj,float &x,float &y,float &z,float &w)
{
	if (phys_obj->Body != NULL) {
		const float *q=dBodyGetQuaternion(phys_obj->Body);
		w=q[0];
		x=q[1];
		y=q[2];
		z=q[3];
	}
	else if (phys_obj->Geom[0] != NULL) {
		dQuaternion q;
		dGeomGetQuaternion(phys_obj->Geom[0],q);
		w=q[0];
		x=q[1];
		y=q[2];
		z=q[3];
	}
}

void
PhyAddForce(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddForce(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
PhyAddForceRel(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddRelForce(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
PhySetForce(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetForce(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
PhyGetForce(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *f=dBodyGetForce(phys_obj->Body);
		x=f[0];
		y=f[1];
		z=f[2];
	}
}

void
PhyAddTorque(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddTorque(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
PhyAddTorqueRel(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddRelTorque(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
PhySetTorque(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetTorque(phys_obj->Body,x,y,z);
	}
}

void
PhyGetTorque(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *t=dBodyGetTorque(phys_obj->Body);
		x=t[0];
		y=t[1];
		z=t[2];
	}
}

void
PhySetVelocity(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetLinearVel(phys_obj->Body,x,y,z);
	}
}

void
PhyGetVelocity(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *v=dBodyGetLinearVel(phys_obj->Body);
		x=v[0];
		y=v[1];
		z=v[2];
	}
}

void
PhySetVelocityAng(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetAngularVel(phys_obj->Body,x,y,z);
	}
}

void
PhyGetVelocityAng(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *v=dBodyGetAngularVel(phys_obj->Body);
		x=v[0];
		y=v[1];
		z=v[2];
	}
}

void
PhyDisable(PhysicsObject_t *phys_obj)
{
	if (phys_obj != NULL) {
		if (phys_obj->Body != NULL) {
			dBodyDisable(phys_obj->Body);
		}
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomDisable(phys_obj->Geom[i]);
			}
		}
	}
}

void
PhyEnable(PhysicsObject_t *phys_obj)
{
	if (phys_obj != NULL) {
		if (phys_obj->Body != NULL) {
			dBodyEnable(phys_obj->Body);
		}
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomEnable(phys_obj->Geom[i]);
			}
		}
	}
}

void
PhyEnableAll()
{
	for (PhysicsObjectList_t::iterator p=PhysicsObjectList.begin() ; p != PhysicsObjectList.end() ; p++) {
		PhysicsObject_t *phys_obj=(*p);
		if (phys_obj->Body != NULL) {
			PhyEnable(phys_obj);
		}
	}
}

void
PhyZeroForces(PhysicsObject_t *phys_obj)
{
	PhySetForce(phys_obj,0,0,0);
	PhySetTorque(phys_obj,0,0,0);
	PhySetVelocity(phys_obj,0,0,0);
	PhySetVelocityAng(phys_obj,0,0,0);
}

void
PhySetData(PhysicsObject_t *phys_obj,void *data)
{
	if (phys_obj->Body != NULL) {
		dBodySetData(phys_obj->Body,data);
	}
	for (int i=0 ; i < MAX_GEOMS ; i++) {
		if (phys_obj->Geom[i] != NULL) {
			dGeomSetData(phys_obj->Geom[i],data);
		}
	}
}

extern
bool	GameAppCanCollide(CGameObject *gobj1,CGameObject *gobj2);
extern
float	GameAppCollideCFM(CGameObject *gobj1,CGameObject *gobj2);
extern
float	GameAppCollideFriction(CGameObject *gobj1,CGameObject *gobj2);
extern
float	GameAppCollideRestitution(CGameObject *gobj1,CGameObject *gobj2);
extern
void	GameAppCollision(CGameObject *gobj1,CGameObject *gobj2,float x,float y,float z,float nor_x,float nor_y,float nor_z,float pen);

static
void
CollideObjectsCallback(void *data,dGeomID o1,dGeomID o2)
{
	int	contacts_used;
	if ((dGeomGetCategoryBits(o1)&dGeomGetCollideBits(o2)) != 0 || (dGeomGetCategoryBits(o2)&dGeomGetCollideBits(o1)) != 0) {
		CGameObject *gobj1=(CGameObject *)dGeomGetData(o1);
		CGameObject *gobj2=(CGameObject *)dGeomGetData(o2);
		if (GameAppCanCollide(gobj1,gobj2)) {
			// colliding two non-space geoms, so generate contact points between o1 and o2
			dContact contact_array[64];
			int num_contacts=dCollide(o1,o2,64,&contact_array[0].geom,sizeof(dContact));
			// add these contact points to the simulation
			if (num_contacts > 0) {
				dBodyID body1=dGeomGetBody(o1);
				dBodyID body2=dGeomGetBody(o2);
				if (body1 != NULL && body2 != NULL) {
					if (GetBool(gobj1,VAR_IS_STATIC)) {
						body1=NULL;
					}
					else if (GetBool(gobj2,VAR_IS_STATIC)) {
						body2=NULL;
					}
				}
				if (num_contacts == 64) {
					Log("CollideObjectsCallback(): max contacts exceeded: %d (%s->%s)",num_contacts,gobj1->m_Tag,gobj2->m_Tag);
				}
				contacts_used=0;
				for (int c=0 ; c < num_contacts ; c++) {
					if (contact_array[c].geom.depth != 0) {
						//	filter out duplicate contacts
						for (int d=c+1 ; d < num_contacts ; d++) {
							if (contact_array[c].geom.depth == contact_array[d].geom.depth) {
								contact_array[d].geom.depth=0;
							}
						}
						int contact_mode=dContactBounce;
						float cfm=GameAppCollideCFM(gobj1,gobj2);
						if (cfm != 0) {
							contact_mode|=dContactSoftCFM;
							contact_array[c].surface.soft_cfm=cfm;
						}
						contact_array[c].surface.mode=contact_mode;
						contact_array[c].surface.mu=GameAppCollideFriction(gobj1,gobj2);		//	friction
						contact_array[c].surface.bounce=GameAppCollideRestitution(gobj1,gobj2);	//	bounciness
						dJointID joint_id=dJointCreateContact(g_World,g_CollisionJointGroup,&contact_array[c]);
						dJointAttach(joint_id,body1,body2);
						//	communicate the collision information to the game app
						float *pos=contact_array[c].geom.pos;
						float *nor=contact_array[c].geom.normal;
						float pen=contact_array[c].geom.depth;
						GameAppCollision(gobj1,gobj2,pos[0],pos[1],pos[2],nor[0],nor[1],nor[2],pen);
						if (CollScript != NULL) {
							g_GameScript->ExecCollisionCallback(CollScript,CollScriptSize,gobj1,gobj2,pos[0],pos[1],pos[2],nor[0],nor[1],nor[2],pen);
						}
						contacts_used++;
					}
				}
//				Log("CollideObjectsCallback(): contacts_used=%d/%d",contacts_used,num_contacts);
			}
		}
	}
}

void
UpdatePositions()
{
	g_BodiesEnabled=0;
	for (PhysicsObjectList_t::iterator p=PhysicsObjectList.begin() ; p != PhysicsObjectList.end() ; p++) {
		PhysicsObject_t *phys_obj=(*p);
		if (phys_obj->Body != NULL) {
			dBodyID b=phys_obj->Body;
			CGameObject *gobj=(CGameObject *)dBodyGetData(b);
			const float *pos=dBodyGetPosition(b);
			gobj->SetPosition(pos[0],pos[1],pos[2]);
			const float *q=dBodyGetQuaternion(b);
			gobj->SetQuaternion(q[1],q[2],q[3],q[0]);
			if (dBodyIsEnabled(b)) {
				g_BodiesEnabled++;
			}
		}
		else {
			for (int i=0 ; i < MAX_GEOMS ; i++) {
				if (phys_obj->Geom[i] != NULL) {
					dGeomID g=phys_obj->Geom[i];
					CGameObject *gobj=(CGameObject *)dGeomGetData(g);
					const float *pos=dGeomGetPosition(g);
					gobj->SetPosition(pos[0],pos[1],pos[2]);
					dQuaternion q;
					dGeomGetQuaternion(g,q);
					gobj->SetQuaternion(q[1],q[2],q[3],q[0]);
				}
			}
		}
	}
}

void
UpdateWorld(float delta_time)
{
	dWorldQuickStep(g_World,delta_time);
	UpdatePositions();
}

void
UpdatePhysics(float delta_time)
{
	dSpaceCollide(g_Space,0,&CollideObjectsCallback);
	dWorldQuickStep(g_World,delta_time);
	dJointGroupEmpty(g_CollisionJointGroup);
	UpdatePositions();
}

static
void
RayCollideHit(dContactGeom *contact)
{
	HitRayCollision.hit_x=contact->pos[0];
	HitRayCollision.hit_y=contact->pos[1];
	HitRayCollision.hit_z=contact->pos[2];
	HitRayCollision.nor_x=contact->normal[0];
	HitRayCollision.nor_y=contact->normal[1];
	HitRayCollision.nor_z=contact->normal[2];
	HitRayCollision.dist=contact->depth;
}

static
void
RayCollideCallback(void *data,dGeomID o1,dGeomID o2)
{
	if ((dGeomGetCategoryBits(o1)&dGeomGetCollideBits(o2)) != 0 || (dGeomGetCategoryBits(o2)&dGeomGetCollideBits(o1)) != 0) {
		dContactGeom contact;
		int num_contacts=dCollide(o1,o2,1,&contact,sizeof(dContactGeom));
		if (num_contacts != 0) {
			if (HitRayCollision.dist > contact.depth) {
				HitRayCollision.object=(o1 == RayGeom) ? dGeomGetData(o2) : dGeomGetData(o1);
				RayCollideHit(&contact);
				bRayHit=true;
			}
		}
	}
}

float	PhysicsHitRayTime;

HitRayCollision_t *
PhyHitRay(dGeomID geom_id,float x,float y,float z,float dir_x,float dir_y,float dir_z,float len,bool first_hit)
{
	LARGE_INTEGER hit_ray_time=GetTimer();
	bRayHit=false;
	dGeomRaySetLength(RayGeom,len);
	dGeomRaySet(RayGeom,x,y,z,dir_x,dir_y,dir_z);
	HitRayCollision.dist=FLT_MAX;
	if (geom_id != NULL) {
		dContactGeom contact;
		while (1) {
			bool hit=false;
			int num_contacts=dCollide(RayGeom,geom_id,1,&contact,sizeof(dContactGeom));
			if (num_contacts != 0 && contact.depth < HitRayCollision.dist) {
				hit=true;
			}
			if (hit) {
				RayCollideHit(&contact);
				HitRayCollision.object=dGeomGetData(geom_id);
				dGeomRaySetLength(RayGeom,contact.depth);
				bRayHit=true;
			}
			if (hit == false || first_hit) {
				PhysicsHitRayTime+=GetTimerDelta(hit_ray_time);
				if (bRayHit) {
					return(&HitRayCollision);
				}
				return(NULL);
			}
		}
	}
	else {
		dSpaceCollide2(RayGeom,(dGeomID)g_Space,NULL,&RayCollideCallback);
		if (bRayHit) {
			PhysicsHitRayTime+=GetTimerDelta(hit_ray_time);
			return(&HitRayCollision);
		}
	}
	PhysicsHitRayTime+=GetTimerDelta(hit_ray_time);
	return(NULL);
}
