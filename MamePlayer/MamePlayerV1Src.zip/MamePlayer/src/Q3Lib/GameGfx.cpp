// GameGfx.cpp: implementation of the CGfx class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	USE_RENDER_TARGET	0

#define	MAX_FONT_LINES	600

typedef struct FontText
{
	bool				world;
	bool				shadowed;
	int					font;
	int					x,y,z;
	float				scale;
	D3DXCOLOR			color;
	char				str[256];
} FontText_t;

static
FontText_t				FontText[MAX_FONT_LINES];

#define	MAX_FONTS		8

static
CD3DFont *				FontDevice[MAX_FONTS];

static
int						FontIndex;

bool					g_bDeviceLost;

bool					g_bLightingOverride=false;

bool					g_bBumpMapEnable=true;
bool					g_bBumpScaleOverride=false;
bool					g_bDetailMapEnable=true;
bool					g_bReflectionMapEnable=true;
bool					g_bUseShaders=true;

#if USE_EFFECT_FILE
bool					g_bHasWorld;
bool					g_bHasWorldTranspose;
bool					g_bHasView;
bool					g_bHasProjection;
bool					g_bHasWorldView;
bool					g_bHasWorldViewTranspose;
bool					g_bHasWorldViewProjection;
bool					g_bHasWorldVector;
bool					g_bHasObjectVector;
bool					g_bHasConstant;
bool					g_bHasNearFar;
bool					g_bHasWorldInverseTranspose;
bool					g_bHasWorldViewInverseTranspose;
bool					g_bHasLight;
bool					g_bHasDirectionalLight;
bool					g_bHasWorldLight;
bool					g_bHasObjectLight;
bool					g_bHasViewLight;
bool					g_bHasTFactor;
bool					g_bHasBumpScale;
bool					g_bHasBase;
bool					g_bHasNormal;
bool					g_bHasEnvironment;
bool					g_bHasNormalizer;
bool					g_bHasGloss;
#else
bool					g_bAlphaBlendEnable;
bool					g_bClipPlaneEnable;
bool					g_bFogEnable;
bool					g_bLightingEnable;
bool					g_bSpecularEnable;
bool					g_bStencilEnable;
bool					g_bZEnable;
bool					g_bZWriteEnable;

int						g_CullMode;
#endif

float					g_BumpScale=1;
float					g_EnvScale=4;
float					g_EnvOffset=1;

int						g_DisplayWidth;
int						g_DisplayHeight;

int						g_VisibleObjects;
int						g_VisiblePolys;

int						g_Frame;

float					g_Fov=60;
float					g_Aspect;
float					g_NearClip;
float					g_FarClip;

bool					g_FogEnable;
D3DXCOLOR				g_FogColor;
float					g_FogStart;
float					g_FogEnd;

static
bool					bFadeIn;
static
bool					bFadeOut;
static
float					FadeRate=1;
static
float					FadeValue=0;
static
D3DXCOLOR				FadeColor=D3DXCOLOR(1,1,1,1);

D3DXVECTOR3				g_ViewFwdVec;
D3DXVECTOR3				g_ViewRgtVec;
D3DXVECTOR3				g_ViewUpVec;
D3DXVECTOR3				g_ViewPos;

D3DXQUATERNION			g_ViewRot;

D3DXMATRIX				g_OrthoMatrix;
D3DXMATRIX				g_ProjectionMatrix;
D3DXMATRIX				g_ViewMatrix;
D3DXMATRIX				g_InvViewMatrix;

D3DCOLOR				g_ClearColor;
D3DFORMAT				g_Format;

D3DPRESENT_PARAMETERS	PresentParams;

D3DCAPS8				g_D3DCaps;

LPDIRECT3D8				g_D3D;
LPDIRECT3DDEVICE8		g_D3DDevice;

#if USE_RENDER_TARGET == 1
static
LPDIRECT3DSURFACE8		RenderTarget;
static
LPDIRECT3DTEXTURE8		RenderTargetTexture;
#endif

static
LPDIRECT3DCUBETEXTURE8	NormalizerMap;

static
TextureList_t			TextureList;

SpriteList_t			SpriteScreenList;
SpriteList_t			SpriteWorldList;

static
SpriteList_t			SpriteScreenVisibleList;
static
SpriteList_t			SpriteWorldVisibleList;

#define	D3DFVF_SPRITEVERTEX		(D3DFVF_XYZ|D3DFVF_TEX1)

struct SPRITEVERTEX {
	D3DXVECTOR3	pos;
	float		tu,tv;
};

static
LPDIRECT3DVERTEXBUFFER8	SpriteBuffer;

#define	D3DFVF_SHADOWVERTEX		(D3DFVF_XYZRHW|D3DFVF_DIFFUSE)

struct SHADOWVERTEX {
	D3DXVECTOR4	p;
	D3DCOLOR	color;
};

static
LPDIRECT3DVERTEXBUFFER8 ShadowVertexBuffer;
static
LPDIRECT3DVERTEXBUFFER8	FadeVertexBuffer;

#define	D3DFVF_TARGETVERTEX		(D3DFVF_XYZRHW|D3DFVF_TEX1)

struct TARGETVERTEX {
	D3DXVECTOR4	p;
	float		tu,tv;
};

static
LPDIRECT3DVERTEXBUFFER8 TargetVertexBuffer;

#if USE_EFFECT_FILE
LPD3DXEFFECT			g_D3DXEffect;
#endif

int						g_GammaLevel=255;

static
D3DGAMMARAMP			GammaRamp;
static
D3DGAMMARAMP			GammaRampDefault;

//
//	Direct3D graphics functions
//

void
GfxInitDirectX()
{
	g_D3D=Direct3DCreate8(D3D_SDK_VERSION);
	if (g_D3D != NULL) {
		g_D3D->GetDeviceCaps(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,&g_D3DCaps);
	}
}

void
GfxUnInitDirectX()
{
	GfxFreeSprites();
	GfxUnInitSpriteBuffer();
#if USE_RENDER_TARGET == 1
	if (RenderTarget != NULL) {
		RenderTarget->Release();
	}
	if (RenderTargetTexture != NULL) {
		RenderTargetTexture->Release();
	}
#endif
	if (NormalizerMap != NULL) {
		NormalizerMap->Release();
	}
	if (TargetVertexBuffer != NULL) {
		TargetVertexBuffer->Release();
	}
	if (ShadowVertexBuffer != NULL) {
		ShadowVertexBuffer->Release();
	}
	if (FadeVertexBuffer != NULL) {
		FadeVertexBuffer->Release();
	}
#if USE_EFFECT_FILE
	if (g_D3DXEffect != NULL) {
		g_D3DXEffect->Release();
	}
#endif
	GfxFreeTextureList();
	if (g_D3DDevice != NULL) {
		g_D3DDevice->SetGammaRamp(D3DSGR_NO_CALIBRATION,&GammaRampDefault);
		g_D3DDevice->Release();
	}
	g_D3DDevice=NULL;
	g_D3D->Release();
	g_D3D=NULL;
}

void
GfxFindBestFullscreenSize(int &width,int &height,D3DFORMAT format)
{
	int mode=-1;
	int w=0,h=0;
	unsigned int mode_count=g_D3D->GetAdapterModeCount(D3DADAPTER_DEFAULT);
	D3DDISPLAYMODE display_mode;
	for (unsigned int m=0 ; m < mode_count ; m++) {
		g_D3D->EnumAdapterModes(D3DADAPTER_DEFAULT,m,&display_mode);
		if (display_mode.Format == format && display_mode.RefreshRate == 60) {
			if (display_mode.Width == width && display_mode.Height == height) {
				return;
			}
			if (display_mode.Width >= w) {
				w=display_mode.Width;
				if (display_mode.Height >= h) {
					h=display_mode.Height;
				}
			}
		}
	}
	width=w;
	height=h;
}

/*
D3DFORMAT
GfxFindBestFullscreenFormat(int width,int height)
{
	D3DFORMAT format=D3DFMT_UNKNOWN;
	D3DCAPS8 device_caps;
	g_D3D->GetDeviceCaps(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,&device_caps);
	unsigned int mode_count=g_D3D->GetAdapterModeCount(D3DADAPTER_DEFAULT);
	for (unsigned int m=0 ; m < mode_count ; m++) {
		D3DDISPLAYMODE display_mode;
		g_D3D->EnumAdapterModes(D3DADAPTER_DEFAULT,m,&display_mode);
		if (display_mode.Width == width && display_mode.Height == height) {
			if (display_mode.Format == D3DFMT_A8R8G8B8) {
				format=display_mode.Format;
			}
			else if (display_mode.Format == D3DFMT_X8R8G8B8) {
				if (format != D3DFMT_A8R8G8B8) {
					format=display_mode.Format;
				}
			}
			else if (display_mode.Format == D3DFMT_R5G6B5) {
				if (format != D3DFMT_A8R8G8B8) {
					if (format != D3DFMT_X8R8G8B8) {
						format=D3DFMT_R5G6B5;
					}
				}
			}
		}
	}
	return(format);
}
*/

void
GfxSetDisplayMode(int width,int height,bool windowed)
{
	D3DDISPLAYMODE display_mode;
	g_D3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&display_mode);
	D3DFORMAT format=display_mode.Format;
	int selected_mode=GameAppGetSelectedDisplayMode();
	if (!windowed) {
		if (selected_mode != -1) {
			g_D3D->EnumAdapterModes(D3DADAPTER_DEFAULT,selected_mode,&display_mode);
			width=display_mode.Width;
			height=display_mode.Height;
			format=display_mode.Format;
		}
		else if (width != 0 && height != 0) {
			GfxFindBestFullscreenSize(width,height,format);
		}
	}
	if (width == 0 && height == 0) {
		width=display_mode.Width;
		height=display_mode.Height;
	}
	g_Aspect=(float)width/(float)height;
	g_Format=format;
	D3DFORMAT stencil_format=D3DFMT_D24S8;
/*
	if (g_D3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,format,D3DUSAGE_DEPTHSTENCIL,D3DRTYPE_SURFACE,stencil_format) != D3D_OK) {
		stencil_format=D3DFMT_D24X4S4;
		if (g_D3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,format,D3DUSAGE_DEPTHSTENCIL,D3DRTYPE_SURFACE,stencil_format) != D3D_OK) {
			stencil_format=D3DFMT_D15S1;
			if (g_D3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,format,D3DUSAGE_DEPTHSTENCIL,D3DRTYPE_SURFACE,stencil_format) != D3D_OK) {
				stencil_format=D3DFMT_D32;
				if (g_D3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,format,D3DUSAGE_DEPTHSTENCIL,D3DRTYPE_SURFACE,stencil_format) != D3D_OK) {
					stencil_format=D3DFMT_D16;
					if (g_D3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,format,D3DUSAGE_DEPTHSTENCIL,D3DRTYPE_SURFACE,stencil_format) != D3D_OK) {
						MessageBox(g_hWnd,"UNABLE TO FIND A SUITABLE DEPTH-STENCIL FORMAT","CRITICAL ERROR",MB_OK|MB_ICONERROR);
						Log("GfxSetDisplayMode(): Failed to find a suitable depth-stencil format");
						exit(1);
					}
				}
			}
		}
	}
*/
	memset(&PresentParams,0,sizeof(D3DPRESENT_PARAMETERS));
	PresentParams.BackBufferWidth=width;
	PresentParams.BackBufferHeight=height;
	PresentParams.BackBufferFormat=format;
	PresentParams.BackBufferCount=3;
	PresentParams.AutoDepthStencilFormat=stencil_format;
	PresentParams.EnableAutoDepthStencil=true;
	if (windowed) {
		PresentParams.SwapEffect=D3DSWAPEFFECT_DISCARD;
		PresentParams.FullScreen_RefreshRateInHz=0;
		PresentParams.Windowed=true;
	}
	else {
		PresentParams.SwapEffect=D3DSWAPEFFECT_DISCARD;
		PresentParams.FullScreen_PresentationInterval=D3DPRESENT_INTERVAL_DEFAULT;
		PresentParams.FullScreen_RefreshRateInHz=60;
		if (CnfDetailLevel == 0) {
			if (g_D3D->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,format,FALSE,D3DMULTISAMPLE_4_SAMPLES) == D3D_OK) {
				PresentParams.MultiSampleType=D3DMULTISAMPLE_4_SAMPLES;
			}
		}
		PresentParams.Windowed=false;
	}
	g_D3D->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,g_hWnd,D3DCREATE_HARDWARE_VERTEXPROCESSING,&PresentParams,&g_D3DDevice);
	if (g_D3DDevice == NULL) {
		PresentParams.MultiSampleType=D3DMULTISAMPLE_NONE;
		g_D3D->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,g_hWnd,D3DCREATE_HARDWARE_VERTEXPROCESSING,&PresentParams,&g_D3DDevice);
		if (g_D3DDevice == NULL) {
			g_D3D->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,g_hWnd,D3DCREATE_MIXED_VERTEXPROCESSING,&PresentParams,&g_D3DDevice);
			if (g_D3DDevice == NULL) {
				g_D3D->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,g_hWnd,D3DCREATE_SOFTWARE_VERTEXPROCESSING,&PresentParams,&g_D3DDevice);
				if (g_D3DDevice == NULL) {
					MessageBox(g_hWnd,"FAILED TO CREATE A D3D8 DEVICE","CRITICAL ERROR",MB_OK|MB_ICONERROR);
					Log("GfxSetDisplayMode(): Failed to create a device");
					exit(1);
				}
			}
		}
	}
#if USE_RENDER_TARGET == 1
	g_D3DDevice->CreateRenderTarget(width,height,format,D3DMULTISAMPLE_NONE,TRUE,&RenderTarget);
	D3DXCreateTexture(g_D3DDevice,width,height,1,0,format,D3DPOOL_MANAGED,&RenderTargetTexture);
#endif
	g_DisplayWidth=width;
	g_DisplayHeight=height;

	NormalizerMap=GfxMakeNormalizerMap(128);

	GfxSetOrtho(float(g_DisplayWidth),float(g_DisplayHeight),0,10000);
	GfxSetProjection(g_Fov,g_Aspect,1,50000);
	GfxSetView(D3DXVECTOR3(0,0,0),D3DXVECTOR3(0,0,0));
	GfxUpdateView();

	GfxInitRenderStates();
	GfxInitSpriteBuffer();

	if (!windowed) {
		AppShowCursor(false);
	}

	g_D3DDevice->GetGammaRamp(&GammaRampDefault);
	GfxAddGamma(256);
}

#if USE_EFFECT_FILE == 0
void
GfxAlphaBlendEnable()
{
	if (g_bAlphaBlendEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
	g_bAlphaBlendEnable=false;
}

void
GfxAlphaBlendDisable()
{
	if (g_bAlphaBlendEnable) {
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
		g_bAlphaBlendEnable=false;
	}
}

void
GfxClipPlaneEnable()
{
	if (g_bClipPlaneEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,D3DCLIPPLANE0);
	g_bClipPlaneEnable=true;
}

void
GfxClipPlaneDisable()
{
	if (g_bClipPlaneEnable) {
		g_D3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,0);
		g_bClipPlaneEnable=false;
	}
}

void
GfxCullModeNone()
{
	if (g_CullMode != D3DCULL_NONE) {
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
		g_CullMode=D3DCULL_NONE;
	}
}

void
GfxCullModeCW()
{
	if (g_CullMode != D3DCULL_CW) {
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CW);
		g_CullMode=D3DCULL_CW;
	}
}

void
GfxCullModeCCW()
{
	if (g_CullMode != D3DCULL_CCW) {
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
		g_CullMode=D3DCULL_CCW;
	}
}

void
GfxFogEnable()
{
	if (g_bFogEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,true);
	g_bFogEnable=true;
}

void
GfxFogDisable()
{
	if (g_bFogEnable) {
		g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,false);
		g_bFogEnable=false;
	}
}

void
GfxLightingEnable()
{
	if (g_bLightingEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,true);
	g_bLightingEnable=true;
}

void
GfxLightingDisable()
{
	if (g_bLightingEnable) {
		g_D3DDevice->SetRenderState(D3DRS_LIGHTING,false);
		g_bLightingEnable=false;
	}
}

void
GfxSpecularEnable()
{
	if (g_bSpecularEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_SPECULARENABLE,true);
	g_bSpecularEnable=true;
}

void
GfxSpecularDisable()
{
	if (g_bSpecularEnable) {
		g_D3DDevice->SetRenderState(D3DRS_SPECULARENABLE,false);
		g_bSpecularEnable=false;
	}
}

void
GfxStencilEnable()
{
	if (g_bStencilEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,true);
	g_bStencilEnable=true;
}

void
GfxStencilDisable()
{
	if (g_bStencilEnable) {
		g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,false);
		g_bStencilEnable=false;
	}
}

void
GfxZEnable()
{
	if (g_bZEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,true);
	g_bZEnable=true;
}

void
GfxZDisable()
{
	if (g_bZEnable) {
		g_D3DDevice->SetRenderState(D3DRS_ZENABLE,false);
		g_bZEnable=false;
	}
}

void
GfxZWriteEnable()
{
	if (g_bZWriteEnable) {
		return;
	}
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,true);
	g_bZWriteEnable=true;
}

void
GfxZWriteDisable()
{
	if (g_bZWriteEnable) {
		g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,false);
		g_bZWriteEnable=false;
	}
}

void
GfxSetClipPlane(float a,float b,float c,float d)
{
	float p[4]={a,b,c,d};
	g_D3DDevice->SetClipPlane(0,p);
}
#endif

bool
GfxAddGamma(int level)
{
	if ((level > 0 && g_GammaLevel < 255) || (level < 0 && g_GammaLevel > 0)) {
		g_GammaLevel+=level;
		if (g_GammaLevel > 255) {
			g_GammaLevel=255;
		}
		else if (g_GammaLevel < 1) {
			g_GammaLevel=1;
		}
		for (int i=0 ; i < 256 ; i++) {
			int gamma_level=i*g_GammaLevel;
			if (gamma_level > 65535) {
				gamma_level=65535;
			}
			GammaRamp.red[i]=(short)gamma_level;
			GammaRamp.green[i]=(short)gamma_level;
			GammaRamp.blue[i]=(short)gamma_level;
		}
		g_D3DDevice->SetGammaRamp(D3DSGR_NO_CALIBRATION,&GammaRamp);
		return(true);
	}
	return(false);
}

void
GfxInitRenderStates()
{
#if USE_EFFECT_FILE == 0
	g_bAlphaBlendEnable=false;
	g_bClipPlaneEnable=false;
	g_CullMode=D3DCULL_CCW;
	g_bFogEnable=false;
	g_bLightingEnable=true;
	g_bSpecularEnable=true;
	g_bStencilEnable=false;
	g_bZEnable=true;
	g_bZWriteEnable=true;
#endif
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,0);
	g_D3DDevice->SetRenderState(D3DRS_COLORVERTEX,false);
	g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
	g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,true);
	g_D3DDevice->SetRenderState(D3DRS_NORMALIZENORMALS,false);
	g_D3DDevice->SetRenderState(D3DRS_SPECULARENABLE,true);
	g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,true);
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,true);

	g_D3DDevice->SetRenderState(D3DRS_POINTSCALEENABLE,true);
	float point_scale_a=0;
	g_D3DDevice->SetRenderState(D3DRS_POINTSCALE_A,*((DWORD*)&point_scale_a));
	float point_scale_b=0;
	g_D3DDevice->SetRenderState(D3DRS_POINTSCALE_B,*((DWORD*)&point_scale_b));
	float point_scale_c=1;
	g_D3DDevice->SetRenderState(D3DRS_POINTSCALE_C,*((DWORD*)&point_scale_c));

	g_D3DDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);

	g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);

	g_D3DDevice->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_MODULATE);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_COLORARG2,D3DTA_CURRENT);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
#if USE_EFFECT_FILE
	g_D3DXEffect=GfxLoadEffect("shaders/difflit.sha","T0");
#endif
}

void
GfxRestoreRenderStates()
{
#if USE_EFFECT_FILE == 0
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,g_bAlphaBlendEnable);
	g_D3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE,(g_bClipPlaneEnable ? D3DCLIPPLANE0 : 0));
	g_D3DDevice->SetRenderState(D3DRS_COLORVERTEX,false);
	g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
	g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,g_bFogEnable);
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,g_bLightingEnable);
	g_D3DDevice->SetRenderState(D3DRS_SPECULARENABLE,g_bSpecularEnable);
	g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,g_bStencilEnable);
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,g_bZWriteEnable);
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,g_bZEnable);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(1,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(2,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
	g_D3DDevice->SetTextureStageState(3,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
#endif
}

void
GfxDeviceLost()
{
	for (int f=0 ; f < MAX_FONTS ; f++) {
		if (FontDevice[f] != NULL) {
			FontDevice[f]->InvalidateDeviceObjects();
		}
	}
	g_GameApp->LostDevice();
}

void
GfxDeviceReset()
{
	g_D3DDevice->Reset(&PresentParams);
	GfxInitRenderStates();
	GfxUpdateProjection();
	GfxUpdateView();
	for (int f=0 ; f < MAX_FONTS ; f++) {
		if (FontDevice[f] != NULL) {
			FontDevice[f]->RestoreDeviceObjects();
		}
	}
	g_GameApp->ResetDevice();
}

#if USE_EFFECT_FILE
static
char	TechniqueName[256];

void
GfxSetEffectParams(LPD3DXEFFECT effect,const char *technique_name)
{
	strcpy(TechniqueName,technique_name);
	//	matrices
	g_bHasWorld=(effect->IsParameterUsed("mW") ? true : false);
	g_bHasWorldView=(effect->IsParameterUsed("mWV") ? true : false);
	g_bHasWorldTranspose=(effect->IsParameterUsed("mWt") ? true : false);
	g_bHasView=(effect->IsParameterUsed("mV") ? true : false);
	g_bHasProjection=(effect->IsParameterUsed("mP") ? true : false);
	g_bHasWorldViewTranspose=(effect->IsParameterUsed("mWVt") ? true : false);
	g_bHasWorldViewProjection=(effect->IsParameterUsed("mWVP") ? true : false);
	g_bHasWorldInverseTranspose=(effect->IsParameterUsed("mWrt") ? true : false);
	g_bHasWorldViewInverseTranspose=(effect->IsParameterUsed("mWVrt") ? true : false);
	//	vectors
	g_bHasWorldVector=(effect->IsParameterUsed("pWV") ? true : false);
	g_bHasObjectVector=(effect->IsParameterUsed("pOV") ? true : false);
	g_bHasNearFar=(effect->IsParameterUsed("vNearFar") ? true : false);
	//	constants
	g_bHasConstant=(effect->IsParameterUsed("cnst") ? true : false);
	g_bHasLight=(effect->IsParameterUsed("cLgt") ? true : false);
	g_bHasDirectionalLight=(effect->IsParameterUsed("cOLgtDir") ? true : false);
	//	lights
	g_bHasWorldLight=(effect->IsParameterUsed("pWL") ? true : false);
	g_bHasObjectLight=(effect->IsParameterUsed("pOL") ? true : false);
	g_bHasViewLight=(effect->IsParameterUsed("pVL") ? true : false);
	g_bHasTFactor=(effect->IsParameterUsed("dTFactor") ? true : false);
	g_bHasBumpScale=(effect->IsParameterUsed("dBumpEnvMat00") ? true : false);
	//	textures
	g_bHasNormal=(effect->IsParameterUsed("tNormal") ? true : false);
	g_bHasNormalizer=(effect->IsParameterUsed("tNormalizer") ? true : false);
	g_bHasEnvironment=(effect->IsParameterUsed("tCube") ? true : false);
	g_bHasBase=(effect->IsParameterUsed("tBase") ? true : false);
	g_bHasGloss=(effect->IsParameterUsed("tGloss") ? true : false);
}

LPD3DXEFFECT
GfxLoadEffect(const char *file_name,const char *technique_name)
{
	LPD3DXEFFECT effect=NULL;
	unsigned long buf_size=0;
	void *buf=g_GameFile->GetFile(file_name,&buf_size);
	if (buf != NULL) {
		if (D3DXCreateEffect(g_D3DDevice,buf,buf_size,&effect,NULL) == D3D_OK) {
			if (effect->SetTechnique(technique_name) == S_OK) {
				if (effect->Validate() == S_OK) {
					GfxSetEffectParams(effect,technique_name);
				}
				else {
					Log("GfxLoadEffect(%s)->Validate() failed",file_name);
					effect->Release();
					effect=NULL;
				}
			}
			else {
				Log("GfxLoadEffect(%s)->SetTechnique(%s) failed",file_name,technique_name);
				effect->Release();
				effect=NULL;
			}
		}
		else {
			Log("GfxLoadEffect(%s) failed",file_name);
		}
		g_GameFile->FreeFileMem(buf);
	}
	return(effect);
}

//	no validation - assumes hardware can support the chosen technique
void
GfxSetEffect(LPD3DXEFFECT effect,const char *technique_name)
{
	if (strcmp(TechniqueName,technique_name) == 0) {
		return;
	}
	if (effect->SetTechnique(technique_name) == S_OK) {
		GfxSetEffectParams(effect,technique_name);
		return;
	}
	Log("GfxSetEffect()->SetTechnique(%s) failed",technique_name);
}
#endif

void
GfxInitFontSystem(int font_index,char *font_name,int height,int weight)
{
	if (FontDevice[font_index] != NULL) {
		delete FontDevice[font_index];
	}
	DWORD flags=(weight == 2) ? D3DFONT_BOLD : 0;
	flags|=D3DFONT_FILTERED;
	FontDevice[font_index]=new CD3DFont(font_name,height,flags);
	FontDevice[font_index]->InitDeviceObjects(g_D3DDevice);
	FontDevice[font_index]->RestoreDeviceObjects();
}

void
GfxUnInitFontSystem()
{
	for (int i=0 ; i < MAX_FONTS ; i++) {
		if (FontDevice[i] != NULL) {
			delete FontDevice[i];
			FontDevice[i]=NULL;
		}
	}
}

void
GfxResetText()
{
	FontIndex=0;
}

void
GfxRenderFontSystem()
{
	if (FontIndex == 0) {
		return;
	}
	for (int i=0 ; i < MAX_FONTS ; i++) {
		if (FontDevice[i] != NULL) {
			for (short n=0 ; n < FontIndex ; n++) {
				if (FontText[n].font == i) {
					if (FontText[n].world) {
						float s=FontText[n].scale;
						D3DXVECTOR3 scale(s,s,s);
						D3DXVECTOR3 p(FontText[n].x,FontText[n].y,FontText[n].z);
						D3DXQUATERNION rot;
						D3DXQuaternionIdentity(&rot);
						D3DXMATRIX m;
						D3DXMatrixTransformation(&m,NULL,NULL,&scale,NULL,&rot,&p);
						g_D3DDevice->SetTransform(D3DTS_WORLD,&m);
						D3DMATERIAL8 mat;
						memset(&mat,0,sizeof(D3DMATERIAL8));
						mat.Diffuse=FontText[n].color;
						mat.Emissive=FontText[n].color;
						g_D3DDevice->SetMaterial(&mat);
						FontDevice[i]->Render3DText(FontText[n].str,D3DFONT_FILTERED|D3DFONT_CENTERED);
					}
					else {
						SIZE size;
						FontDevice[i]->GetTextExtent(FontText[n].str,&size);
						int x=FontText[n].x;
						int y=FontText[n].y;
						if (x == -1) {
							x=(g_DisplayWidth/2)-(size.cx/2);
						}
						if (y == -1) {
							y=(g_DisplayHeight/2)-(size.cy/2);
						}
						if (FontText[n].shadowed) {
							FontDevice[i]->DrawText(x+1,y+1,D3DXCOLOR(0,0,0,1),FontText[n].str);
						}
						D3DXCOLOR color_rgba=FontText[n].color;
						D3DCOLOR color=D3DCOLOR_COLORVALUE(color_rgba.r,color_rgba.g,color_rgba.b,color_rgba.a);
						FontDevice[i]->DrawText(x,y,color,FontText[n].str);
					}
				}
			}
		}
	}
	GfxRestoreRenderStates();
	FontIndex=0;
}

int
GfxPrintTextLen(int font,char *str)
{
	SIZE size;
	FontDevice[font]->GetTextExtent(str,&size);
	return(size.cx);
}

int
GfxPrintTextLen(int font)
{
	return(GfxPrintTextLen(font,FontText[FontIndex-1].str));
}

void
GfxPrintText(int font,int x,int y,D3DXCOLOR color_rgba,const char *fmt,...)
{
	char buf[256];
	va_list argptr;

	if (g_GameApp->m_bRenderScene) {
		if (FontIndex < MAX_FONT_LINES) {
			va_start(argptr,fmt);
			vsprintf(buf,fmt,argptr);
			va_end(argptr);
			strcpy(FontText[FontIndex].str,buf);
			FontText[FontIndex].font=font;
			FontText[FontIndex].shadowed=false;
			FontText[FontIndex].world=false;
			FontText[FontIndex].x=x;
			FontText[FontIndex].y=y;
			FontText[FontIndex].z=0;
			FontText[FontIndex].scale=1;
			FontText[FontIndex].color=color_rgba;
			FontIndex++;
		}
	}
}

void
GfxPrintTextShadowed(int font,int x,int y,D3DXCOLOR color_rgba,const char *fmt,...)
{
	char buf[256];
	va_list argptr;

	if (g_GameApp->m_bRenderScene) {
		if (FontIndex < MAX_FONT_LINES) {
			va_start(argptr,fmt);
			vsprintf(buf,fmt,argptr);
			va_end(argptr);
			strcpy(FontText[FontIndex].str,buf);
			FontText[FontIndex].font=font;
			FontText[FontIndex].shadowed=true;
			FontText[FontIndex].world=false;
			FontText[FontIndex].x=x;
			FontText[FontIndex].y=y;
			FontText[FontIndex].z=0;
			FontText[FontIndex].scale=1;
			FontText[FontIndex].color=color_rgba;
			FontIndex++;
		}
	}
}

void
GfxPrintTextWorld(int font,int x,int y,int z,float scale,D3DXCOLOR color_rgba,const char *fmt,...)
{
	char buf[256];
	va_list argptr;

	if (g_GameApp->m_bRenderScene) {
		if (FontIndex < MAX_FONT_LINES) {
			va_start(argptr,fmt);
			vsprintf(buf,fmt,argptr);
			va_end(argptr);
			strcpy(FontText[FontIndex].str,buf);
			FontText[FontIndex].font=font;
			FontText[FontIndex].shadowed=false;
			FontText[FontIndex].world=true;
			FontText[FontIndex].x=x;
			FontText[FontIndex].y=y;
			FontText[FontIndex].z=z;
			FontText[FontIndex].scale=scale;
			FontText[FontIndex].color=color_rgba;
			FontIndex++;
		}
	}
}

DWORD
VectorToRGBA(D3DXVECTOR3 *v,float height)
{
	DWORD r=(DWORD)(127.0f*v->x+128.0f);
	DWORD g=(DWORD)(127.0f*v->y+128.0f);
	DWORD b=(DWORD)(127.0f*v->z+128.0f);
	DWORD a=(DWORD)(255.0f*height);
	return ((a<<24L)+(r<<16L)+(g<<8L)+(b<<0L));
}

void
GfxFreeTextureList()
{
	while (TextureList.size() > 0) {
		Texture_t *texture=(*TextureList.begin());
		unsigned long refs;
		if (texture->IsCubeMap) {
			LPDIRECT3DCUBETEXTURE8 tex=(LPDIRECT3DCUBETEXTURE8)texture->TexturePtr;
			refs=tex->Release();
		}
		else {
			LPDIRECT3DTEXTURE8 tex=(LPDIRECT3DTEXTURE8)texture->TexturePtr;
			refs=tex->Release();
		}
//		Log("GfxFreeTextureList(): %s->Refs=%d",texture->Filename,refs);
		delete texture;
		TextureList.pop_front();
	}
}

void
GfxFreeTexture(LPDIRECT3DTEXTURE8 tex)
{
	for (TextureList_t::iterator t=TextureList.begin() ; t != TextureList.end() ; t++) {
		Texture_t *texture=(*t);
		if (texture->TexturePtr == tex) {
			LPDIRECT3DTEXTURE8 tex_ptr=(LPDIRECT3DTEXTURE8)texture->TexturePtr;
			unsigned long refs=tex_ptr->Release();
			Log("GfxFreeTexture(): %s->Refs=%d ListSize=%d",texture->Filename,refs,TextureList.size()-1);
			delete texture;
			TextureList.erase(t);
			return;
		}
	}
}

LPDIRECT3DTEXTURE8
GfxGetTexture(const char *file_name)
{
	for (TextureList_t::iterator t=TextureList.begin() ; t != TextureList.end() ; t++) {
		Texture_t *texture=(*t);
		if (stricmp(texture->Filename,file_name) == 0) {
			return((LPDIRECT3DTEXTURE8)texture->TexturePtr);
		}
	}
//	Log("GfxGetTexture(%s): Texture not in list",file_name);
	return(NULL);
}

LPDIRECT3DCUBETEXTURE8
GfxGetNormalizerTexture()
{
	return(NormalizerMap);
}

LPDIRECT3DCUBETEXTURE8
GfxGetCubeTexture(const char *file_name)
{
	for (TextureList_t::iterator t=TextureList.begin() ; t != TextureList.end() ; t++) {
		Texture_t *texture=(*t);
		if (texture->IsCubeMap) {
			if (stricmp(texture->Filename,file_name) == 0) {
				return((LPDIRECT3DCUBETEXTURE8)texture->TexturePtr);
			}
		}
	}
	return(NULL);
}

const char *
GfxGetTextureFileName(LPDIRECT3DTEXTURE8 tex)
{
	if (tex != NULL) {
		for (TextureList_t::iterator t=TextureList.begin() ; t != TextureList.end() ; t++) {
			Texture_t *texture=(*t);
			if (texture->TexturePtr == tex) {
				return(texture->Filename);
			}
		}
	}
	return(NULL);
}

LPDIRECT3DTEXTURE8
GfxLoadTexture(const char *file_name,LPDIRECT3DTEXTURE8 texture_to_add,bool filter,bool mip)
{
	LPDIRECT3DTEXTURE8 texture_ptr=GfxGetTexture(file_name);
	if (texture_ptr != NULL) {
		return((LPDIRECT3DTEXTURE8)texture_ptr);
	}
	texture_ptr=texture_to_add;
	unsigned int mip_level=(mip ? D3DX_DEFAULT : 1);
	if (texture_ptr == NULL) {
/*
		if (filter) {
			D3DXCreateTextureFromFileEx(g_D3DDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,mip_level,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&texture_ptr);
		}
		else {
			D3DXCreateTextureFromFileEx(g_D3DDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,mip_level,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_NONE,D3DX_FILTER_NONE,0,NULL,NULL,&texture_ptr);
		}
*/
		unsigned long buf_size;
		void *buf=g_GameFile->GetFile(file_name,&buf_size);
		if (buf != NULL) {
			D3DXCreateTextureFromFileInMemoryEx(g_D3DDevice,buf,buf_size,D3DX_DEFAULT,D3DX_DEFAULT,mip_level,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&texture_ptr);
			g_GameFile->FreeFileMem(buf);
		}
	}
	if (texture_ptr != NULL) {
		Texture_t *texture=new Texture_t;
		memset(texture,0,sizeof(Texture_t));
		strcpy(texture->Filename,file_name);
		strupr(texture->Filename);
		texture->TexturePtr=texture_ptr;
		TextureList.push_back(texture);
		LogResource("%s",texture->Filename);
	}
	else {
		Log("GfxLoadTexture(%s): file not found",file_name);
	}
	return(texture_ptr);
}

LPDIRECT3DCUBETEXTURE8
GfxLoadCubeTexture(const char *file_name)
{
	LPDIRECT3DCUBETEXTURE8 texture_ptr=GfxGetCubeTexture(file_name);
	if (texture_ptr != NULL) {
		return((LPDIRECT3DCUBETEXTURE8)texture_ptr);
	}
	if (texture_ptr == NULL) {
//		D3DXCreateCubeTextureFromFileEx(g_D3DDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_DEFAULT,0,NULL,NULL,&texture_ptr);
		unsigned long buf_size;
		void *buf=g_GameFile->GetFile(file_name,&buf_size);
		if (buf != NULL) {
			D3DXCreateCubeTextureFromFileInMemoryEx(g_D3DDevice,buf,buf_size,D3DX_DEFAULT,D3DX_DEFAULT,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&texture_ptr);
			g_GameFile->FreeFileMem(buf);
		}
	}
	if (texture_ptr != NULL) {
		Texture_t *texture=new Texture_t;
		memset(texture,0,sizeof(Texture_t));
		strcpy(texture->Filename,file_name);
		strupr(texture->Filename);
		texture->IsCubeMap=true;
		texture->TexturePtr=texture_ptr;
		TextureList.push_back(texture);
		LogResource("%s",texture->Filename);
	}
	else {
		Log("GfxLoadCubeTexture(%s): file not found",file_name);
	}
	return(texture_ptr);
}

void
GfxGetTextureSize(LPDIRECT3DTEXTURE8 texture,int &width,int &height)
{
	D3DSURFACE_DESC desc;
	if (texture->GetLevelDesc(0,&desc) == D3D_OK) {
		width=desc.Width;
		height=desc.Height;
	}
}

inline DWORD F2DW( FLOAT f ) { return *((DWORD*)&f); }

void
GfxSetTextureStage(int stage,LPDIRECT3DTEXTURE8 texture,bool reflection_map,bool bump_map,bool bump_dot3,bool temp)
{
	g_D3DDevice->SetTexture(stage,texture);
	g_D3DDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,0);
	if (bump_map) {
		if (bump_dot3) {
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_DOTPRODUCT3);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_TFACTOR);
		}
		else {
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_BUMPENVMAP);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
		}
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG1,D3DTA_TEXTURE);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG2,D3DTA_CURRENT);
//		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
	}
	else if (reflection_map) {
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MODULATE);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG1,D3DTA_TEXTURE);
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG2,D3DTA_CURRENT);
	}
	else {
		if (bump_dot3) {	//	combiner
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MODULATE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_CURRENT);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_TEMP);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG1,D3DTA_CURRENT);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG2,D3DTA_TEMP);
		}
		else {
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MODULATE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG1,D3DTA_TEXTURE);
			g_D3DDevice->SetTextureStageState(stage,D3DTSS_ALPHAARG2,D3DTA_CURRENT);
		}
	}
	if (temp) {
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_TEMP);
	}
	else {
		g_D3DDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
	}
	g_D3DDevice->SetTextureStageState(stage+1,D3DTSS_COLOROP,D3DTOP_DISABLE);
	g_D3DDevice->SetTextureStageState(stage+1,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
}

void
GfxNormalizerFillWrapper(D3DXVECTOR4 *p_out,D3DXVECTOR3 *tex_coord,D3DXVECTOR3 *tex_size,LPVOID data)
{
	D3DXVec3Normalize(tex_coord,tex_coord);
	*tex_coord/=2;
	*tex_coord+=D3DXVECTOR3(0.5f,0.5f,0.5f);
	D3DXVECTOR4 color(tex_coord->x,tex_coord->y,tex_coord->z,1);
	*p_out=color;
}

LPDIRECT3DCUBETEXTURE8
GfxMakeNormalizerMap(int size)
{
	LPDIRECT3DCUBETEXTURE8 tex;
	if (g_D3DDevice->CreateCubeTexture(size,0,0,D3DFMT_A8R8G8B8,D3DPOOL_MANAGED,&tex) == D3D_OK) {
		if (D3DXFillCubeTexture(tex,GfxNormalizerFillWrapper,NULL) == D3D_OK) {
			return(tex);
		}
		tex->Release();
	}
	return(NULL);
}

LPDIRECT3DTEXTURE8
GfxMakeTextureBumpFormat(LPDIRECT3DTEXTURE8 tex,D3DFORMAT fmt)
{
	LPDIRECT3DTEXTURE8 bump_tex;
    D3DSURFACE_DESC    d3dsd;
    D3DLOCKED_RECT     d3dlr;

    tex->GetLevelDesc( 0, &d3dsd );
    // Create the bumpmap's surface and texture objects
    if (FAILED(g_D3DDevice->CreateTexture(d3dsd.Width,d3dsd.Height,1,0,fmt,D3DPOOL_MANAGED,&bump_tex))) {
		Log("GfxMakeTextureBumpFormat() failed");
        return(NULL);
    }

    // Fill the bits of the new texture surface with bits from
    // a private format.
    tex->LockRect( 0, &d3dlr, 0, 0 );
    DWORD dwSrcPitch = (DWORD)d3dlr.Pitch;
    BYTE* pSrcTopRow = (BYTE*)d3dlr.pBits;
    BYTE* pSrcCurRow = pSrcTopRow;
    BYTE* pSrcBotRow = pSrcTopRow + (dwSrcPitch * (d3dsd.Height - 1) );

    bump_tex->LockRect( 0, &d3dlr, 0, 0 );
    DWORD dwDstPitch = (DWORD)d3dlr.Pitch;
    BYTE* pDstTopRow = (BYTE*)d3dlr.pBits;
    BYTE* pDstCurRow = pDstTopRow;
    BYTE* pDstBotRow = pDstTopRow + (dwDstPitch * (d3dsd.Height - 1) );

    for( DWORD y=0; y<d3dsd.Height; y++ )
    {
        BYTE* pSrcB0; // addr of current pixel
        BYTE* pSrcB1; // addr of pixel below current pixel, wrapping to top if necessary
        BYTE* pSrcB2; // addr of pixel above current pixel, wrapping to bottom if necessary
        BYTE* pDstT;  // addr of dest pixel;

        pSrcB0 = pSrcCurRow;

        if( y == d3dsd.Height - 1)
            pSrcB1 = pSrcTopRow;
        else
            pSrcB1 = pSrcCurRow + dwSrcPitch;

        if( y == 0 )
            pSrcB2 = pSrcBotRow;
        else
            pSrcB2 = pSrcCurRow - dwSrcPitch;

        pDstT = pDstCurRow;

        for( DWORD x=0; x<d3dsd.Width; x++ )
        {
            LONG v00; // Current pixel
            LONG v01; // Pixel to the right of current pixel, wrapping to left edge if necessary
            LONG vM1; // Pixel to the left of current pixel, wrapping to right edge if necessary
            LONG v10; // Pixel one line below.
            LONG v1M; // Pixel one line above.

            v00 = *(pSrcB0+0);
            
            if( x == d3dsd.Width - 1 )
                v01 = *(pSrcCurRow);
            else
                v01 = *(pSrcB0+4);
            
            if( x == 0 )
                vM1 = *(pSrcCurRow + (4 * (d3dsd.Width - 1)));
            else
                vM1 = *(pSrcB0-4);
            v10 = *(pSrcB1+0);
            v1M = *(pSrcB2+0);

            LONG iDu = (vM1-v01); // The delta-u bump value
            LONG iDv = (v1M-v10); // The delta-v bump value

            // The luminance bump value (land masses are less shiny)
            WORD uL = ( v00>1 ) ? 63 : 127;

            switch( fmt )
            {
                case D3DFMT_V8U8:
                    *pDstT++ = (BYTE)iDu;
                    *pDstT++ = (BYTE)iDv;
                    break;

                case D3DFMT_L6V5U5:
                    *(WORD*)pDstT  = (WORD)( ( (iDu>>3) & 0x1f ) <<  0 );
                    *(WORD*)pDstT |= (WORD)( ( (iDv>>3) & 0x1f ) <<  5 );
                    *(WORD*)pDstT |= (WORD)( ( ( uL>>2) & 0x3f ) << 10 );
                    pDstT += 2;
                    break;

                case D3DFMT_X8L8V8U8:
                    *pDstT++ = (BYTE)iDu;
                    *pDstT++ = (BYTE)iDv;
                    *pDstT++ = (BYTE)uL;
                    *pDstT++ = (BYTE)0L;
                    break;
            }

            // Move one pixel to the right (src is 32-bpp)
            pSrcB0+=4;
            pSrcB1+=4;
            pSrcB2+=4;
        }

        // Move to the next line
        pSrcCurRow += dwSrcPitch;
        pDstCurRow += dwDstPitch;
    }

    bump_tex->UnlockRect(0);
    tex->UnlockRect(0);

    return (bump_tex);
}

void
GfxMakeTextureBumpMap(LPDIRECT3DTEXTURE8 texture)
{
	D3DLOCKED_RECT rect;
	D3DSURFACE_DESC d3dsd;
	texture->GetLevelDesc(0,&d3dsd);
	texture->LockRect(0,&rect,0,0);
	DWORD *pixels=(DWORD *)rect.pBits;
	//	For each pixel, generate a vector normal that represents the change
	//	in thea height field at that pixel
	for (DWORD j=0 ; j < d3dsd.Height ; j++) {
		for (DWORD i=0 ; i < d3dsd.Width ; i++) {
			DWORD color00=pixels[0];
            DWORD color10=pixels[1];
            DWORD color01=pixels[rect.Pitch/sizeof(DWORD)];

			FLOAT fHeight00=(FLOAT)((color00&0x00ff0000)>>16)/255.0f;
			FLOAT fHeight10=(FLOAT)((color10&0x00ff0000)>>16)/255.0f;
			FLOAT fHeight01=(FLOAT)((color01&0x00ff0000)>>16)/255.0f;

			D3DXVECTOR3 vPoint00(i+0.0f,j+0.0f,fHeight00);
			D3DXVECTOR3 vPoint10(i+1.0f,j+0.0f,fHeight10);
			D3DXVECTOR3 vPoint01(i+0.0f,j+1.0f,fHeight01);
			D3DXVECTOR3 v10=vPoint10-vPoint00;
			D3DXVECTOR3 v01=vPoint01-vPoint00;

			D3DXVECTOR3 vNormal;
			D3DXVec3Cross(&vNormal,&v10,&v01);
			D3DXVec3Normalize(&vNormal,&vNormal);

			// Store the normal as an RGBA value in the normal map
			*pixels++=VectorToRGBA(&vNormal,fHeight00);
		}
	}
	texture->UnlockRect(0);
}

void
GfxSetFogParams(D3DXCOLOR color_rgba,float fog_start,float fog_end)
{
	if (fog_start == 0 && fog_end == 0) {
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,FALSE);
#else
		GfxFogDisable();
#endif
		g_FogEnable=false;
	}
	else {
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,TRUE);
#else
		GfxFogEnable();
#endif
		g_D3DDevice->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_LINEAR);
		g_D3DDevice->SetRenderState(D3DRS_FOGSTART,*((DWORD *)(&fog_start)));
		g_D3DDevice->SetRenderState(D3DRS_FOGEND,*((DWORD *)(&fog_end)));
		g_D3DDevice->SetRenderState(D3DRS_FOGCOLOR,D3DCOLOR_COLORVALUE(color_rgba.r,color_rgba.g,color_rgba.b,color_rgba.a));
		g_FogColor=color_rgba;
		g_FogStart=fog_start;
		g_FogEnd=fog_end;
		g_FogEnable=true;
	}
}

void
GfxUpdateOrtho()
{
	g_D3DDevice->SetTransform(D3DTS_PROJECTION,&g_OrthoMatrix);
}

void
GfxSetOrtho(float width,float height,float near_clip,float far_clip)
{
	D3DXMatrixOrthoLH(&g_OrthoMatrix,width,height,near_clip,far_clip);
	GfxUpdateOrtho();
}

void
GfxUpdateProjection()
{
	g_D3DDevice->SetTransform(D3DTS_PROJECTION,&g_ProjectionMatrix);
}

void
GfxSetProjection(float fov,float aspect,float near_clip,float far_clip)
{
	D3DXMatrixPerspectiveFovLH(&g_ProjectionMatrix,D3DXToRadian(fov),aspect,near_clip,far_clip);
	g_Fov=fov;
	g_Aspect=aspect;
	g_NearClip=near_clip;
	g_FarClip=far_clip;
	GfxUpdateProjection();
}

void
GfxSetViewVectors()
{
	g_ViewFwdVec=D3DXVECTOR3(g_InvViewMatrix._31,g_InvViewMatrix._32,g_InvViewMatrix._33);
	g_ViewRgtVec=D3DXVECTOR3(g_InvViewMatrix._11,g_InvViewMatrix._21,g_InvViewMatrix._31);
	g_ViewUpVec=D3DXVECTOR3(g_InvViewMatrix._21,g_InvViewMatrix._22,g_InvViewMatrix._23);
}

void
GfxSetView(D3DXVECTOR3 pos,D3DXQUATERNION quat)
{
	D3DXMatrixTransformation(&g_InvViewMatrix,NULL,NULL,NULL,NULL,&quat,&pos);
	D3DXMatrixInverse(&g_ViewMatrix,NULL,&g_InvViewMatrix);
	GfxSetViewVectors();
	g_ViewRot=quat;
	g_ViewPos=pos;
}

void
GfxSetView(D3DXVECTOR3 pos,D3DXVECTOR3 rot)
{
	D3DXQUATERNION quat;
	D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(rot.y),D3DXToRadian(rot.x),D3DXToRadian(rot.z));
	GfxSetView(pos,quat);
}

void
GfxSetLookAt(D3DXVECTOR3 pos,D3DXVECTOR3 look_at_pos,D3DXVECTOR3 up_vec)
{
	D3DXMatrixLookAtLH(&g_ViewMatrix,&pos,&look_at_pos,&up_vec);
	D3DXMatrixInverse(&g_InvViewMatrix,NULL,&g_ViewMatrix);
	D3DXQuaternionRotationMatrix(&g_ViewRot,&g_InvViewMatrix);
	GfxSetViewVectors();
	g_ViewPos=pos;
}

void
GfxUpdateView()
{
	g_D3DDevice->SetTransform(D3DTS_VIEW,&g_ViewMatrix);
}

void
GfxFadeIn(float fade_rate,D3DXCOLOR color_argb)
{
	FadeRate=fade_rate;
	FadeColor=color_argb;
	bFadeOut=false;
	bFadeIn=true;
}

void
GfxFadeOut(float fade_rate,D3DXCOLOR color_argb)
{
	FadeRate=fade_rate;
	FadeColor=color_argb;
	bFadeOut=true;
	bFadeIn=false;
}

bool
GfxIsFadingIn()
{
	return(bFadeIn);
}

void
GfxFadeUpdate(float delta_time)
{
	if (bFadeOut) {
		FadeValue+=FadeRate*delta_time;
		if (FadeValue > 1) {
			FadeValue=1;
		}
	}
	else if (bFadeIn) {
		FadeValue-=FadeRate*delta_time;
		if (FadeValue < 0) {
			FadeValue=0;
		}
	}
}

bool
GfxFadeDone()
{
	if (FadeValue == 0 || FadeValue == 1) {
		return(true);
	}
	return(false);
}

void
GfxInitSpriteBuffer()
{
	if (g_D3DDevice->CreateVertexBuffer(sizeof(SPRITEVERTEX)*4,D3DUSAGE_WRITEONLY,D3DFVF_SPRITEVERTEX,D3DPOOL_MANAGED,&SpriteBuffer) == D3D_OK) {
		SPRITEVERTEX *v;
		if (SpriteBuffer->Lock(0,0,(unsigned char **)&v,0) == D3D_OK) {
			v[0].pos=D3DXVECTOR3(-0.5f, 0.5f,0);
			v[1].pos=D3DXVECTOR3( 0.5f, 0.5f,0);
			v[2].pos=D3DXVECTOR3(-0.5f,-0.5f,0);
			v[3].pos=D3DXVECTOR3( 0.5f,-0.5f,0);
			v[0].tu=0;
			v[0].tv=0;
			v[1].tu=1;
			v[1].tv=0;
			v[2].tu=0;
			v[2].tv=1;
			v[3].tu=1;
			v[3].tv=1;
			SpriteBuffer->Unlock();
		}
	}
}

void
GfxUnInitSpriteBuffer()
{
	if (SpriteBuffer != NULL) {
		SpriteBuffer->Release();
	}
}

Sprite_t *
GfxCreateSprite(LPDIRECT3DTEXTURE8 tex,bool is_world)
{
	if (tex != NULL) {
		Sprite_t *spr=new Sprite_t;
		memset(spr,0,sizeof(Sprite_t));
		spr->IsDecal=false;
		spr->IsTrans=true;
		spr->IsView=true;
		spr->IsVis=false;
		spr->IsWorld=is_world;
		spr->Scale=D3DXVECTOR3(1,1,1);
		spr->Color=D3DXCOLOR(1,1,1,1);
		spr->Texture=tex;
		int width,height;
		GfxGetTextureSize(spr->Texture,width,height);
		spr->Size=D3DXVECTOR2(width,height);
		spr->Scale=D3DXVECTOR3(width,height,1);
		if (is_world) {
			SpriteWorldList.push_back(spr);
		}
		else {
			SpriteScreenList.push_back(spr);
		}
		GfxShowSprite(spr);
		return(spr);
	}
	return(NULL);
}

Sprite_t *
GfxCreateSprite(const char *texture_file,bool is_world)
{
	LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(texture_file);
	Sprite_t *spr=GfxCreateSprite(tex,is_world);
	if (spr != NULL) {
		strcpy(spr->TextureFile,texture_file);
		return(spr);
	}
	return(NULL);
}

void
GfxSpriteDelete(Sprite_t *spr,bool free_texture)
{
	if (spr->IsWorld) {
		SpriteWorldVisibleList.remove(spr);
		SpriteWorldList.remove(spr);
	}
	else {
		SpriteScreenVisibleList.remove(spr);
		SpriteScreenList.remove(spr);
	}
	if (free_texture) {
		GfxFreeTexture(spr->Texture);
	}
	delete spr;
}

void
GfxFreeWorldSprites()
{
	while (SpriteWorldList.size() > 0) {
		Sprite_t *spr=(*SpriteWorldList.begin());
		SpriteWorldVisibleList.remove(spr);
		SpriteWorldList.pop_front();
		delete spr;
	}
}

void
GfxFreeSprites()
{
	SpriteScreenVisibleList.clear();
	while (SpriteScreenList.size() > 0) {
		Sprite_t *spr=(*SpriteScreenList.begin());
		SpriteScreenList.pop_front();
		delete spr;
	}
	GfxFreeWorldSprites();
}

void
GfxSetSpriteTexture(Sprite_t *spr,const char *file_name)
{
	spr->Texture=GfxLoadTexture(file_name);
	strcpy(spr->TextureFile,file_name);
}

void
GfxSetSpritePosition(Sprite_t *spr,float x,float y,float z)
{
	spr->Pos.x=x;
	spr->Pos.y=y;
	spr->Pos.z=z;
}

D3DXVECTOR3
GfxGetSpritePosition(Sprite_t *spr)
{
	return(D3DXVECTOR3(spr->Pos.x,spr->Pos.y,spr->Pos.z));
}

void
GfxSetSpriteRotation(Sprite_t *spr,float deg)
{
	spr->Rot.z=deg;
}

void
GfxSetSpriteScale(Sprite_t *spr,float scale_x,float scale_y)
{
	spr->Scale.x=scale_x;
	spr->Scale.y=scale_y;
}

D3DXVECTOR3
GfxGetSpriteScale(Sprite_t *spr)
{
	return(D3DXVECTOR3(spr->Scale.x,spr->Scale.y,spr->Scale.z));
}

void
GfxSetSpriteColor(Sprite_t *spr,float r,float g,float b,float a)
{
	spr->Color=D3DXCOLOR(r,g,b,a);
}

D3DXCOLOR
GfxGetSpriteColor(Sprite_t *spr)
{
	return(spr->Color);
}

void
GfxShowSprite(Sprite_t *spr)
{
	if (spr != NULL) {
		if (spr->IsVis) {
			return;
		}
		if (spr->IsWorld) {
			SpriteWorldVisibleList.push_back(spr);
		}
		else {
			SpriteScreenVisibleList.push_back(spr);
		}
		spr->IsVis=true;
	}
}

void
GfxHideSprite(Sprite_t *spr)
{
	if (spr == NULL) {
		return;
	}
	if (spr->IsVis) {
		if (spr->IsWorld) {
			SpriteWorldVisibleList.remove(spr);
		}
		else {
			SpriteScreenVisibleList.remove(spr);
		}
		spr->IsVis=false;
	}
}

void
GfxRenderScreenSprites()
{
	if (SpriteScreenVisibleList.size() > 0) {
		float w=g_DisplayWidth/2;
		float h=g_DisplayHeight/2;
		D3DXMATRIX mat;
		D3DXVECTOR3 pos;
		D3DXQUATERNION quat;
		D3DMATERIAL8 material;
		memset(&material,0,sizeof(D3DMATERIAL8));
		GfxUpdateOrtho();
		GfxSetTextureStage(0,NULL,false);
		D3DXMATRIX identity;
		D3DXMatrixIdentity(&identity);
		g_D3DDevice->SetTransform(D3DTS_VIEW,&identity);
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
		g_D3DDevice->SetRenderState(D3DRS_ZENABLE,false);
//		g_D3DDevice->SetRenderState(D3DRS_LIGHTING,true);
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
#else
		GfxAlphaBlendEnable();
		GfxZDisable();
		GfxCullModeNone();
#endif
//		g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
//		g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		g_D3DDevice->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
		g_D3DDevice->SetVertexShader(D3DFVF_SPRITEVERTEX);
		g_D3DDevice->SetStreamSource(0,SpriteBuffer,sizeof(SPRITEVERTEX));
		bool alpha_blend=true;
		for (SpriteList_t::iterator s=SpriteScreenVisibleList.begin() ; s != SpriteScreenVisibleList.end() ; s++) {
			Sprite_t *spr=(*s);
			if (spr->IsTrans) {
#if USE_EFFECT_FILE
				if (!alpha_blend) {
					g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
					alpha_blend=true;
				}
#else
				GfxAlphaBlendEnable();
#endif
			}
			else {
#if USE_EFFECT_FILE
				if (alpha_blend) {
					g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
					alpha_blend=false;
				}
#else
				GfxAlphaBlendDisable();
#endif
			}
			pos=D3DXVECTOR3(spr->Pos.x-w,h-spr->Pos.y,0);
			D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(spr->Rot.y),D3DXToRadian(spr->Rot.x),D3DXToRadian(spr->Rot.z));
			D3DXMatrixTransformation(&mat,NULL,NULL,&spr->Scale,NULL,&quat,&pos);
			g_D3DDevice->SetTransform(D3DTS_WORLD,&mat);
			material.Diffuse=spr->Color;
			material.Emissive=spr->Color;
			g_D3DDevice->SetMaterial(&material);
			g_D3DDevice->SetTexture(0,spr->Texture);
			g_D3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2);
			g_D3DDevice->SetTexture(0,NULL);
			g_VisiblePolys+=2;
		}
		g_D3DDevice->SetStreamSource(0,NULL,0);
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
		g_D3DDevice->SetRenderState(D3DRS_ZENABLE,true);
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
#else
		GfxCullModeCCW();
		GfxZEnable();
#endif
		GfxUpdateProjection();
		GfxUpdateView();
	}
}

void
GfxRenderWorldSprites()
{
	if (SpriteWorldVisibleList.size() > 0) {
		Sprite_t *spr;
		D3DXMATRIX mat;
		D3DXQUATERNION quat;
		D3DMATERIAL8 material;
		memset(&material,0,sizeof(D3DMATERIAL8));
		GfxSetTextureStage(0,NULL,false);
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
		g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,false);
		g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,false);
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
//		g_D3DDevice->SetTextureStageState(0,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
//		g_D3DDevice->SetTextureStageState(0,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
		g_D3DDevice->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
#else
		GfxAlphaBlendEnable();
		GfxZWriteDisable();
		GfxFogDisable();
		GfxCullModeNone();
#endif
//		g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
//		g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		g_D3DDevice->SetVertexShader(D3DFVF_SPRITEVERTEX);
		g_D3DDevice->SetStreamSource(0,SpriteBuffer,sizeof(SPRITEVERTEX));
		bool decal_blend=false;
		for (SpriteList_t::iterator s=SpriteWorldVisibleList.begin() ; s != SpriteWorldVisibleList.end() ; s++) {
			spr=(*s);
			if (spr->IsDecal) {
				if (!decal_blend) {
					g_D3DDevice->SetRenderState(D3DRS_ZBIAS,1);
					decal_blend=true;
				}
			}
			else {
				if (decal_blend) {
					g_D3DDevice->SetRenderState(D3DRS_ZBIAS,0);
					decal_blend=false;
				}
			}
			D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(spr->Rot.y),D3DXToRadian(spr->Rot.x),D3DXToRadian(spr->Rot.z));
			if (spr->IsView) {
				D3DXQuaternionMultiply(&quat,&quat,&g_ViewRot);
			}
			D3DXMatrixTransformation(&mat,NULL,NULL,&spr->Scale,NULL,&quat,&spr->Pos);
			g_D3DDevice->SetTransform(D3DTS_WORLD,&mat);
			material.Diffuse=spr->Color;
			material.Emissive=spr->Color;
			g_D3DDevice->SetMaterial(&material);
			g_D3DDevice->SetTexture(0,spr->Texture);
			g_D3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2);
			g_D3DDevice->SetTexture(0,NULL);
			g_VisiblePolys+=2;
		}
		g_D3DDevice->SetStreamSource(0,NULL,0);
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
		if (g_FogEnable) {
			g_D3DDevice->SetRenderState(D3DRS_FOGENABLE,true);
		}
		g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,true);
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
#else
		GfxCullModeCCW();
		if (g_FogEnable) {
			GfxFogEnable();
		}
		GfxZWriteEnable();
#endif
		g_D3DDevice->SetRenderState(D3DRS_ZBIAS,0);
	}
}

void
GfxRenderFadeQuad()
{
	if (FadeValue == 0) {
		return;
	}
	float fade_v=FadeValue*255.0f;
	float fade_r=FadeColor.r*255.0f;
	float fade_g=FadeColor.g*255.0f;
	float fade_b=FadeColor.b*255.0f;
	int fade_value,fade_color_r,fade_color_g,fade_color_b;
	FloatToInt(&fade_value,fade_v);
	FloatToInt(&fade_color_r,fade_r);
	FloatToInt(&fade_color_g,fade_g);
	FloatToInt(&fade_color_b,fade_b);
	DWORD color=D3DCOLOR_ARGB(fade_value,fade_color_r,fade_color_g,fade_color_b);
	if (FadeVertexBuffer == NULL) {
		g_D3DDevice->CreateVertexBuffer(sizeof(SHADOWVERTEX)*4,D3DUSAGE_WRITEONLY,D3DFVF_SHADOWVERTEX,D3DPOOL_MANAGED,&FadeVertexBuffer);
		SHADOWVERTEX *v;
		FadeVertexBuffer->Lock(0,0,(unsigned char **)&v,0);
		v[0].p=D3DXVECTOR4(0,g_DisplayHeight,0,1);
		v[0].color=color;
		v[1].p=D3DXVECTOR4(0,0,0,1);
		v[1].color=color;
		v[2].p=D3DXVECTOR4(g_DisplayWidth,g_DisplayHeight,0,1);
		v[2].color=color;
		v[3].p=D3DXVECTOR4(g_DisplayWidth,0,0,1);
		v[3].color=color;
		FadeVertexBuffer->Unlock();
	}
	else {
		SHADOWVERTEX *v;
		FadeVertexBuffer->Lock(0,0,(unsigned char **)&v,0);
		v[0].color=color;
		v[1].color=color;
		v[2].color=color;
		v[3].color=color;
		FadeVertexBuffer->Unlock();
	}
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,false);
	g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
#else
	GfxZDisable();
	GfxAlphaBlendEnable();
	GfxLightingDisable();
	GfxCullModeCCW();
#endif
//	g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
//	g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	g_D3DDevice->SetTexture(0,NULL);
	g_D3DDevice->SetVertexShader(D3DFVF_SHADOWVERTEX);
	g_D3DDevice->SetStreamSource(0,FadeVertexBuffer,sizeof(SHADOWVERTEX));
	g_D3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2);
	g_D3DDevice->SetStreamSource(0,NULL,0);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,true);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,true);
#else
	GfxLightingEnable();
	GfxZEnable();
#endif
	g_VisiblePolys+=2;
}

void
GfxRenderShadowQuad()
{
	if (ShadowVertexBuffer == NULL) {
//		DWORD color=0x7FFF00FF;
		DWORD color=0x9F000000;
		g_D3DDevice->CreateVertexBuffer(sizeof(SHADOWVERTEX)*4,D3DUSAGE_WRITEONLY,D3DFVF_SHADOWVERTEX,D3DPOOL_MANAGED,&ShadowVertexBuffer);
		SHADOWVERTEX *v;
		ShadowVertexBuffer->Lock(0,0,(unsigned char **)&v,0);
		v[0].p=D3DXVECTOR4(0,g_DisplayHeight,0,1);
		v[0].color=color;
		v[1].p=D3DXVECTOR4(0,0,0,1);
		v[1].color=color;
		v[2].p=D3DXVECTOR4(g_DisplayWidth,g_DisplayHeight,0,1);
		v[2].color=color;
		v[3].p=D3DXVECTOR4(g_DisplayWidth,0,0,1);
		v[3].color=color;
		ShadowVertexBuffer->Unlock();
	}
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,true);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,false);
	g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
#else
	GfxZDisable();
	GfxStencilEnable();
	GfxAlphaBlendEnable();
	GfxLightingDisable();
	GfxCullModeCCW();
#endif
	g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	g_D3DDevice->SetRenderState(D3DRS_STENCILREF,1);
	g_D3DDevice->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_LESSEQUAL);
	g_D3DDevice->SetRenderState(D3DRS_STENCILPASS,D3DSTENCILOP_KEEP);
	g_D3DDevice->SetTexture(0,NULL);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_DISABLE);
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
	g_D3DDevice->SetVertexShader(D3DFVF_SHADOWVERTEX);
	g_D3DDevice->SetStreamSource(0,ShadowVertexBuffer,sizeof(SHADOWVERTEX));
	g_D3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2);
	g_D3DDevice->SetStreamSource(0,NULL,0);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,true);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,true);
#else
	GfxLightingEnable();
	GfxAlphaBlendDisable();
	GfxStencilDisable();
	GfxZEnable();
#endif
	g_VisiblePolys+=2;
}

#if USE_RENDER_TARGET == 1
void
GfxPostProcessRenderTarget()
{
/*
	D3DLOCKED_RECT rect;
	if (RenderTarget != NULL) {
		if (RenderTarget->LockRect(&rect,NULL,0) == D3D_OK) {
			int pitch=rect.Pitch;
			D3DXCOLOR *pixels=(D3DXCOLOR *)rect.pBits;
			int height=g_DisplayHeight/4;
			int width=g_DisplayWidth;
			D3DXCOLOR color1,color2;
			for (int h=0 ; h < height ; h++) {
				for (int w=0 ; w < width ; w++) {
					color1=*pixels;
//					if (h > 0) {
//						color2=*(pixels-g_DisplayHeight);
//						D3DXColorModulate(&color1,&color1,&color2);
//					}
//					if (h < g_DisplayHeight-1) {
//						color2=*(pixels+g_DisplayHeight);
//						D3DXColorModulate(&color1,&color1,&color2);
//					}
					if (w > 0) {
						color2=*(pixels-1);
						D3DXColorModulate(&color1,&color1,&color2);
					}
					if (w < g_DisplayWidth-1) {
						color2=*(pixels+1);
						D3DXColorModulate(&color1,&color1,&color2);
					}
					*pixels++=color1;
				}
			}
			RenderTarget->UnlockRect();
			LPDIRECT3DSURFACE8 surf;
			if (RenderTargetTexture->GetSurfaceLevel(0,&surf) == D3D_OK) {
				g_D3DDevice->CopyRects(RenderTarget,NULL,0,surf,NULL);
				surf->Release();
			}
		}
	}
*/
}
#endif

void
GfxRenderTargetQuad()
{
#if USE_RENDER_TARGET == 1
	if (TargetVertexBuffer == NULL) {
		g_D3DDevice->CreateVertexBuffer(sizeof(TARGETVERTEX)*4,D3DUSAGE_WRITEONLY,D3DFVF_TARGETVERTEX,D3DPOOL_MANAGED,&TargetVertexBuffer);
		TARGETVERTEX *v;
		TargetVertexBuffer->Lock(0,0,(unsigned char **)&v,0);
		v[0].p=D3DXVECTOR4(0,g_DisplayHeight,0,1);
		v[0].tu=0;
		v[0].tv=1;
		v[1].p=D3DXVECTOR4(0,0,0,1);
		v[1].tu=0;
		v[1].tv=0;
		v[2].p=D3DXVECTOR4(g_DisplayWidth,g_DisplayHeight,0,1);
		v[2].tu=1;
		v[2].tv=1;
		v[3].p=D3DXVECTOR4(g_DisplayWidth,0,0,1);
		v[3].tu=1;
		v[3].tv=0;
		TargetVertexBuffer->Unlock();
	}
	GfxPostProcessRenderTarget();
	GfxSetTextureStage(0,RenderTargetTexture);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,false);
#else
	GfxZDisable();
	GfxAlphaBlendDisable();
	GfxLightingDisable();
#endif
	g_D3DDevice->SetVertexShader(D3DFVF_TARGETVERTEX);
	g_D3DDevice->SetStreamSource(0,TargetVertexBuffer,sizeof(TARGETVERTEX));
	g_D3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2);
	g_D3DDevice->SetTexture(0,NULL);
	g_D3DDevice->SetStreamSource(0,NULL,0);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,true);
	g_D3DDevice->SetRenderState(D3DRS_ZENABLE,true);
#else
	GfxLightingEnable();
	GfxZEnable();
#endif
	g_VisiblePolys+=2;
#endif
}

float	RenderUpdateTime;

void
GfxRenderScene()
{
	if (g_D3DDevice != NULL) {
		HRESULT hr=g_D3DDevice->TestCooperativeLevel();
		if (hr == D3D_OK) {

			LARGE_INTEGER render_scene_time=GetTimer();

			if (g_D3DDevice->BeginScene() == D3D_OK) {
#if USE_RENDER_TARGET == 1
				LPDIRECT3DSURFACE8 depth_surf;
				LPDIRECT3DSURFACE8 old_target=NULL;
				if (RenderTarget != NULL) {
					g_D3DDevice->GetRenderTarget(&old_target);
					g_D3DDevice->GetDepthStencilSurface(&depth_surf);
					g_D3DDevice->SetRenderTarget(RenderTarget,depth_surf);
				}
#endif
				g_D3DDevice->Clear(0,NULL,D3DCLEAR_STENCIL|D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,g_ClearColor,1,0);
		
				g_VisibleObjects=0;
				g_VisiblePolys=0;
				GfxUpdateView();
				RenderGameObjects();
				GfxRenderWorldSprites();
				RenderParticles();
				RenderTransObjects();
#if USE_RENDER_TARGET == 1
				if (RenderTarget != NULL) {
					g_D3DDevice->SetRenderTarget(old_target,depth_surf);
					GfxRenderTargetQuad();
					old_target->Release();
					depth_surf->Release();
				}
#endif
				GameAppRenderScene();
				GfxRenderScreenSprites();
				GfxRenderFadeQuad();
				GfxRenderFontSystem();
				
				g_D3DDevice->EndScene();

				RenderUpdateTime=GetTimerDelta(render_scene_time);

				g_D3DDevice->Present(NULL,NULL,NULL,NULL);

				g_Frame++;
			}
		}
		else if (hr == D3DERR_DEVICELOST) {
			if (!g_bDeviceLost) {
				GfxDeviceLost();
				g_bDeviceLost=true;
			}
		}
		else if (hr == D3DERR_DEVICENOTRESET) {
			if (g_bDeviceLost) {
				GfxDeviceReset();
				g_bDeviceLost=false;
			}
		}
	}
}

D3DXVECTOR3
WorldToScreen(D3DXVECTOR3 world_pos)
{
	D3DXVECTOR3 screen_pos;
	D3DXVECTOR3 cam_dir=AWE_DIR_VEC(world_pos,g_ViewPos);
	D3DXVec3Normalize(&cam_dir,&cam_dir);
	float pos_dot=D3DXVec3Dot(&g_ViewFwdVec,&cam_dir);
	if (pos_dot < 0) {
		D3DVIEWPORT8 viewport;
		viewport.X=0;
		viewport.Y=0;
		viewport.Width=g_DisplayWidth;
		viewport.Height=g_DisplayHeight;
		viewport.MinZ=0;
		viewport.MaxZ=1;
		D3DXMATRIX mat;
		D3DXMatrixIdentity(&mat);
		D3DXVECTOR3 pos;
		D3DXMATRIX proj_mat=g_ProjectionMatrix;
//		g_D3DDevice->GetTransform(D3DTS_PROJECTION,&proj_mat);
		D3DXVec3Project(&pos,&world_pos,&viewport,&proj_mat,&g_ViewMatrix,&mat);
		screen_pos.x=pos.x;
		screen_pos.y=pos.y;
	}
	else {
		screen_pos.x=-1;
		screen_pos.y=-1;
	}
	screen_pos.z=0;
	return(screen_pos);
}

D3DXVECTOR3
ScreenToWorldRay(float screen_x,float screen_y)
{
	D3DXMATRIX proj_mat=g_ProjectionMatrix;
	float x=(((2.0f*screen_x)/g_DisplayWidth)-1)/proj_mat._11;
	float y=-(((2.0f*screen_y)/g_DisplayHeight)-1)/proj_mat._22;
	float z=1.0f;
	D3DXVECTOR3 world_ray;
	world_ray.x=(x*g_InvViewMatrix._11)+(y*g_InvViewMatrix._21)+(z*g_InvViewMatrix._31);
	world_ray.y=(x*g_InvViewMatrix._12)+(y*g_InvViewMatrix._22)+(z*g_InvViewMatrix._32);
	world_ray.z=(x*g_InvViewMatrix._13)+(y*g_InvViewMatrix._23)+(z*g_InvViewMatrix._33);
	D3DXVec3Normalize(&world_ray,&world_ray);
	return(world_ray);
}
