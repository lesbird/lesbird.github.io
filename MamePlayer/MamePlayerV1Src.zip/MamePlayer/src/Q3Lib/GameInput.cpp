// GameInput.cpp: implementation of the CGameInput class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	JOYSTICK_RANGE	16384

static
bool					bShowJoystickInfo=false;

bool					g_bMouseAcquired;

int						g_NumJoysticks;

unsigned long			g_MouseButtons;
unsigned long			g_PrevMouseButtons;

unsigned long			g_MouseFlags=DISCL_EXCLUSIVE|DISCL_FOREGROUND;
unsigned long			g_JoystickFlags=DISCL_EXCLUSIVE|DISCL_FOREGROUND;

D3DXVECTOR3				g_MouseDelta;
D3DXVECTOR3				g_JoyAxis[NUM_JOYSTICKS][NUM_JOYSTICK_STICKS];

bool					g_bJoystickIs360[NUM_JOYSTICKS];

unsigned char			g_JoyButton[NUM_JOYSTICKS][NUM_JOYSTICK_BUTTONS];
unsigned char			g_PrevJoyButton[NUM_JOYSTICKS][NUM_JOYSTICK_BUTTONS];

long					g_JoyPOV[NUM_JOYSTICKS];
long					g_PrevJoyPOV[NUM_JOYSTICKS];

LPDIRECTINPUT8			g_DI;
LPDIRECTINPUTDEVICE8	g_DIJoystick[NUM_JOYSTICKS];
LPDIRECTINPUTDEVICE8	g_DIKeyboard;
LPDIRECTINPUTDEVICE8	g_DIMouse;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

static
BOOL CALLBACK
EnumJoystickCallback(LPCDIDEVICEINSTANCE dev_ins,VOID *context)
{
	DIDEVICEINSTANCE instance;
	if (g_NumJoysticks < NUM_JOYSTICKS) {
		long dev_type=GET_DIDEVICE_TYPE(dev_ins->dwDevType);
		if (dev_type == DI8DEVTYPE_JOYSTICK || dev_type == DI8DEVTYPE_GAMEPAD) {
			if (g_DI->CreateDevice(dev_ins->guidInstance,&g_DIJoystick[g_NumJoysticks],NULL) == DI_OK) {
				instance.dwSize=sizeof(DIDEVICEINSTANCE);
				g_DIJoystick[g_NumJoysticks]->GetDeviceInfo(&instance);
				if (strstr(instance.tszProductName,"XBOX 360") != NULL) {
					g_bJoystickIs360[g_NumJoysticks]=true;
				}
				else {
					g_bJoystickIs360[g_NumJoysticks]=false;
				}
				g_NumJoysticks++;
			}
		}
	}
	return(DIENUM_CONTINUE);
}

static
BOOL CALLBACK
EnumJoystickAxisCallback(LPCDIDEVICEOBJECTINSTANCE obj_ins,LPVOID ref)
{
	long joy_num=(long)ref;
	DIPROPRANGE prop_range;
	prop_range.diph.dwSize=sizeof(DIPROPRANGE);
	prop_range.diph.dwHeaderSize=sizeof(DIPROPHEADER);
	prop_range.diph.dwHow=DIPH_BYID;
	prop_range.diph.dwObj=obj_ins->dwType;
	prop_range.lMin=-JOYSTICK_RANGE;
	prop_range.lMax= JOYSTICK_RANGE;
	g_DIJoystick[joy_num]->SetProperty(DIPROP_RANGE,&prop_range.diph);
	return(DIENUM_CONTINUE);
}

static
float
JoyStickValue(long v)
{
	v=(v < 0) ? __min(v+2048,0) : __max(v-2048,0);
	float val=float(v)/JOYSTICK_RANGE;
	return(val/0.875f);
}

static
char *
ButtonString(unsigned char *rgb_buttons)
{
	static char buf[NUM_JOYSTICK_BUTTONS+1];
	for (int i=0 ; i < NUM_JOYSTICK_BUTTONS ; i++) {
		if ((rgb_buttons[i]&0x80) != 0) {
			buf[i]='1';
		}
		else {
			buf[i]='0';
		}
	}
	buf[NUM_JOYSTICK_BUTTONS]=0;
	return(buf);
}

static
void
ShowJoystickInfo(DIJOYSTATE2 *joy_state,int joy_num)
{
/*
	int n=joy_num*140;
	g_Gfx->PrintText(0, 30+n,GREEN_RGBA,"lX,lY,lZ      =%ld,%ld,%ld",joy_state->lX,joy_state->lY,joy_state->lZ);
	g_Gfx->PrintText(0, 40+n,GREEN_RGBA,"lRx,lRy,lRz   =%ld,%ld,%ld",joy_state->lRx,joy_state->lRy,joy_state->lRz);
	g_Gfx->PrintText(0, 50+n,GREEN_RGBA,"rglSlider     =%ld,%ld",joy_state->rglSlider[0],joy_state->rglSlider[1]);
	g_Gfx->PrintText(0, 60+n,GREEN_RGBA,"rgdwPOV       =%ld,%ld,%ld,%ld",joy_state->rgdwPOV[0],joy_state->rgdwPOV[1],joy_state->rgdwPOV[2],joy_state->rgdwPOV[3]);
	g_Gfx->PrintText(0, 70+n,GREEN_RGBA,"rgbButtons    =%s",ButtonString(joy_state->rgbButtons));
	g_Gfx->PrintText(0, 80+n,GREEN_RGBA,"lVX,lVY,lVZ   =%ld,%ld,%ld",joy_state->lVX,joy_state->lVY,joy_state->lVZ);
	g_Gfx->PrintText(0, 90+n,GREEN_RGBA,"lVRx,lVRy,lVRz=%ld,%ld,%ld",joy_state->lVRx,joy_state->lVRy,joy_state->lVRz);
	g_Gfx->PrintText(0,100+n,GREEN_RGBA,"rglVSlider    =%ld,%ld",joy_state->rglVSlider[0],joy_state->rglVSlider[1]);
	g_Gfx->PrintText(0,110+n,GREEN_RGBA,"lAX,lAY,lAZ   =%ld,%ld,%ld",joy_state->lAX,joy_state->lAY,joy_state->lAZ);
	g_Gfx->PrintText(0,120+n,GREEN_RGBA,"lARx,lARy,lARz=%ld,%ld,%ld",joy_state->lARx,joy_state->lARy,joy_state->lARz);
	g_Gfx->PrintText(0,130+n,GREEN_RGBA,"rglASlider    =%ld,%ld",joy_state->rglASlider[0],joy_state->rglASlider[1]);
	g_Gfx->PrintText(0,140+n,GREEN_RGBA,"lFX,lFY,lFZ   =%ld,%ld,%ld",joy_state->lFX,joy_state->lFY,joy_state->lFZ);
	g_Gfx->PrintText(0,150+n,GREEN_RGBA,"lFRx,lFRy,lFRz=%ld,%ld,%ld",joy_state->lFRx,joy_state->lFRy,joy_state->lFRz);
	g_Gfx->PrintText(0,160+n,GREEN_RGBA,"rglFSlider    =%ld,%ld",joy_state->rglFSlider[0],joy_state->rglFSlider[1]);
*/
}

void
InitInput()
{
	DirectInput8Create(g_hInstance,DIRECTINPUT_VERSION,IID_IDirectInput8,(LPVOID *)&g_DI,NULL);
	g_DI->CreateDevice(GUID_SysMouse,&g_DIMouse,NULL);
	g_DIMouse->SetCooperativeLevel(g_hWnd,g_MouseFlags);
	g_DIMouse->SetDataFormat(&c_dfDIMouse);
	AcquireMouse();

	g_NumJoysticks=0;
	g_DI->EnumDevices(DI8DEVCLASS_GAMECTRL,EnumJoystickCallback,NULL,DIEDFL_ATTACHEDONLY);
	for (int i=0 ; i < g_NumJoysticks ; i++) {
		if (g_DIJoystick[i] != NULL) {
			g_DIJoystick[i]->SetDataFormat(&c_dfDIJoystick2);
			g_DIJoystick[i]->SetCooperativeLevel(g_hWnd,g_JoystickFlags);
			g_DIJoystick[i]->EnumObjects(EnumJoystickAxisCallback,(VOID *)i,DIDFT_AXIS);
		}
	}
}

void
UnInitInput()
{
	UnacquireMouse();
	for (int i=0 ; i < NUM_JOYSTICKS ; i++) {
		if (g_DIJoystick[i] != NULL) {
			g_DIJoystick[i]->Release();
			g_DIJoystick[i]=NULL;
		}
	}
	if (g_DIKeyboard != NULL) {
		g_DIKeyboard->Release();
		g_DIKeyboard=NULL;
	}
	if (g_DIMouse != NULL) {
		g_DIMouse->Release();
		g_DIMouse=NULL;
	}
	if (g_DI != NULL) {
		g_DI->Release();
		g_DI=NULL;
	}
}

extern
bool	CnfLeftXInv;
extern
bool	CnfLeftYInv;
extern
bool	CnfLeftSwap;
extern
bool	CnfRightXInv;
extern
bool	CnfRightYInv;
extern
bool	CnfRightSwap;
extern
int		CnfMouseSens;

void
UpdateInput(float delta_time)
{
	D3DXVECTOR3 mouse_inp(0,0,0);
	if (g_bMouseAcquired) {
		DIMOUSESTATE mouse_state;
		g_DIMouse->GetDeviceState(sizeof(DIMOUSESTATE),&mouse_state);
		g_MouseDelta=D3DXVECTOR3(float(mouse_state.lX),float(mouse_state.lY),float(mouse_state.lZ));
		g_PrevMouseButtons=g_MouseButtons;
		g_MouseButtons=0;
		if ((mouse_state.rgbButtons[0]&0x80) != 0) {
			g_MouseButtons|=1;
		}
		if ((mouse_state.rgbButtons[1]&0x80) != 0) {
			g_MouseButtons|=2;
		}
		if ((mouse_state.rgbButtons[2]&0x80) != 0) {
			g_MouseButtons|=4;
		}
		mouse_inp=g_MouseDelta/(101-CnfMouseSens);
	}
	else {
		g_PrevMouseButtons=g_MouseButtons;
		g_MouseButtons=g_WinMouseButtons;
	}
	for (int j=0 ; j < NUM_JOYSTICKS ; j++) {
		g_JoyAxis[j][0]=D3DXVECTOR3(0,0,0);
		g_JoyAxis[j][1]=D3DXVECTOR3(0,0,0);
		if (g_NumJoysticks == 0) {
			for (int n=0 ; n < NUM_JOYSTICK_BUTTONS ; n++) {
				g_PrevJoyButton[j][n]=g_JoyButton[j][n];
				g_JoyButton[j][n]=0;
			}
		}
	}
	g_JoyAxis[0][0]=mouse_inp;
	for (int i=0 ; i < g_NumJoysticks ; i++) {
		if (g_DIJoystick[i] != NULL) {
			if (FAILED(g_DIJoystick[i]->Poll())) {
				g_DIJoystick[i]->Acquire();
			}
			else {
				DIJOYSTATE2 joy_state;
				g_DIJoystick[i]->GetDeviceState(sizeof(DIJOYSTATE2),&joy_state);
				if (bShowJoystickInfo) {
					ShowJoystickInfo(&joy_state,i);
				}
				float x1=JoyStickValue(joy_state.lX);
				if (CnfLeftXInv) {
					x1=-x1;
				}
				float y1=JoyStickValue(joy_state.lY);
				if (CnfLeftYInv) {
					y1=-y1;
				}
				if (CnfLeftSwap) {
					float temp=x1;
					x1=y1;
					y1=temp;
				}
				g_JoyAxis[i][0]+=D3DXVECTOR3(x1,y1,JoyStickValue(joy_state.lZ));
				float x2=0,y2=0,z2=0;
				if (joy_state.lRx != 0) {
					x2=JoyStickValue(joy_state.lRx);
					if (joy_state.lRy != 0) {
						y2=JoyStickValue(joy_state.lRy);
					}
				}
				else if (joy_state.lZ != 0) {
					x2=JoyStickValue(joy_state.lZ);
					if (joy_state.lRz != 0) {
						y2=JoyStickValue(joy_state.lRz);
					}
				}
				else {
					x2=JoyStickValue(joy_state.lRz);
					if (joy_state.rglSlider[0] != 0) {
						y2=JoyStickValue(joy_state.rglSlider[0]);
					}
				}
				if (CnfRightXInv) {
					x2=-x2;
				}
				if (CnfRightYInv) {
					y2=-y2;
				}
				if (CnfRightSwap) {
					float temp=y2;
					y2=x2;
					x2=temp;
				}
				g_JoyAxis[i][1]+=D3DXVECTOR3(x2,y2,z2);
				for (int n=0 ; n < NUM_JOYSTICK_BUTTONS ; n++) {
					g_PrevJoyButton[i][n]=g_JoyButton[i][n];
					g_JoyButton[i][n]=((joy_state.rgbButtons[n]&0x80) != 0) ? 1 : 0;
				}
				if (g_bJoystickIs360[i]) {
					int old_rleft=g_PrevJoyButton[i][JOYBUTTON_RLEFT];
					g_PrevJoyButton[i][JOYBUTTON_RLEFT]=g_PrevJoyButton[i][JOYBUTTON_RRIGHT];
					g_PrevJoyButton[i][JOYBUTTON_RRIGHT]=old_rleft;
					int old_rright=g_JoyButton[i][JOYBUTTON_RLEFT];
					g_JoyButton[i][JOYBUTTON_RLEFT]=g_JoyButton[i][JOYBUTTON_RRIGHT];
					g_JoyButton[i][JOYBUTTON_RRIGHT]=old_rright;
					g_PrevJoyButton[i][JOYBUTTON_R1]=g_PrevJoyButton[i][JOYBUTTON_L2];
					g_JoyButton[i][JOYBUTTON_R1]=g_JoyButton[i][JOYBUTTON_L2];
					if (g_JoyAxis[i][0].z < -0.8f) {
						g_JoyButton[i][JOYBUTTON_L2]=1;
					}
					if (g_JoyAxis[i][0].z > 0.8f) {
						g_JoyButton[i][JOYBUTTON_R2]=1;
					}
				}
				g_PrevJoyPOV[i]=g_JoyPOV[i];
				g_JoyPOV[i]=joy_state.rgdwPOV[0]/100;
				if (g_JoyPOV[i] == 315 || g_JoyPOV[i] == 0 || g_JoyPOV[i] == 45) {
					g_JoyButton[i][JOYBUTTON_LUP]=1;
				}
				if (g_JoyPOV[i] == 315 || g_JoyPOV[i] == 270 || g_JoyPOV[i] == 225) {
					g_JoyButton[i][JOYBUTTON_LLEFT]=1;
				}
				if (g_JoyPOV[i] == 225 || g_JoyPOV[i] == 180 || g_JoyPOV[i] == 135) {
					g_JoyButton[i][JOYBUTTON_LDOWN]=1;
				}
				if (g_JoyPOV[i] == 135 || g_JoyPOV[i] == 90 || g_JoyPOV[i] == 45) {
					g_JoyButton[i][JOYBUTTON_LRIGHT]=1;
				}
			}
		}
	}
}

void
AcquireMouse()
{
	if (g_DIMouse != NULL) {
		if (g_DIMouse->Acquire() == DI_OK) {
			g_bMouseAcquired=true;
		}
	}
}

void
UnacquireMouse()
{
	if (g_DIMouse != NULL) {
		g_DIMouse->Unacquire();
		g_bMouseAcquired=false;
	}
}

bool
GetMouseButton(int mouse_button)
{
	if ((g_MouseButtons&mouse_button) == mouse_button) {
		if ((g_PrevMouseButtons&mouse_button) != mouse_button) {
			return(true);
		}
	}
	return(false);
}

bool
PeekMouseButton(int mouse_button)
{
	return(((g_MouseButtons&mouse_button) == mouse_button) ? true : false);
}

bool
GetJoystickButton(int joy_num,int button_num)
{
	if ((g_JoyButton[joy_num][button_num]) != 0) {
		if ((g_PrevJoyButton[joy_num][button_num]) == 0) {
			return(true);
		}
	}
	return(false);
}

bool
PeekJoystickButton(int joy_num,int button_num)
{
	if ((g_JoyButton[joy_num][button_num]) != 0) {
		return(true);
	}
	return(false);
}

D3DXVECTOR3
GetJoystickAxis(int joy_num,int stick_num)
{
	return(g_JoyAxis[joy_num][stick_num]);
}
