// GameLine.cpp: implementation of the CGameLine class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	NUM_FACES		8
#define	NUM_VERTICES	10

typedef struct PosTex
{
	D3DXVECTOR3	pos;
	float		tu,tv;
} PosTex_t;

#define	POSTEX_FVF		(D3DFVF_XYZ|D3DFVF_TEX1)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameLine::CGameLine()
{
	AddInt(this,VAR_TYPE,'LINE');

	m_Thickness=1;
	m_Translucency=1;

	m_BegPoint=D3DXVECTOR3(0,0,0);
	m_EndPoint=D3DXVECTOR3(0,0,0);

	m_IndexBuffer=NULL;
	m_VertexBuffer=NULL;
	m_Texture=NULL;

	memset(&m_Material,0,sizeof(D3DMATERIAL8));
	m_Material.Diffuse=D3DXCOLOR(1,1,1,1);
	m_Material.Emissive=D3DXCOLOR(1,1,1,1);

	AddBool(this,VAR_IS_TRANSPARENT,true);
}

CGameLine::~CGameLine()
{
	if (m_VertexBuffer != NULL) {
		m_VertexBuffer->Release();
	}
	if (m_IndexBuffer != NULL) {
		m_IndexBuffer->Release();
	}
}

void
CGameLine::SetEndPoints(D3DXVECTOR3 start,D3DXVECTOR3 end,float thickness)
{
	m_BegPoint=start;
	m_EndPoint=end;
	m_Thickness=thickness;
	if (m_IndexBuffer == NULL) {
		g_D3DDevice->CreateIndexBuffer(NUM_FACES*3*sizeof(short),D3DUSAGE_WRITEONLY,D3DFMT_INDEX16,D3DPOOL_MANAGED,&m_IndexBuffer);
		if (m_IndexBuffer != NULL) {
			unsigned short *index_data;
			if (m_IndexBuffer->Lock(0,0,(unsigned char **)&index_data,0) == D3D_OK) {
				index_data[0]=0;	//	triangle 1
				index_data[1]=1;
				index_data[2]=2;
				index_data[3]=2;	//	triangle 2
				index_data[4]=3;
				index_data[5]=0;
				index_data[6]=5;	//	triangle 3
				index_data[7]=1;
				index_data[8]=2;
				index_data[9]=2;	//	triangle 4
				index_data[10]=4;
				index_data[11]=5;
				index_data[12]=1;	//	triangle 5
				index_data[13]=7;
				index_data[14]=6;
				index_data[15]=6;	//	triangle 6
				index_data[16]=2;
				index_data[17]=1;
				index_data[18]=1;	//	triangle 7
				index_data[19]=8;
				index_data[20]=9;
				index_data[21]=9;	//	triangle 8
				index_data[22]=2;
				index_data[23]=1;
				m_IndexBuffer->Unlock();
			}
			g_D3DDevice->CreateVertexBuffer(NUM_VERTICES*sizeof(PosTex_t),D3DUSAGE_WRITEONLY,POSTEX_FVF,D3DPOOL_MANAGED,&m_VertexBuffer);
			if (m_VertexBuffer != NULL) {
				PosTex_t *vertex_data;
				if (m_VertexBuffer->Lock(0,0,(unsigned char **)&vertex_data,0) == D3D_OK) {
					//	set texture coordinates here
					vertex_data[0].tu=1;
					vertex_data[0].tv=0;
					vertex_data[1].tu=1;
					vertex_data[1].tv=0.5f;
					vertex_data[2].tu=0;
					vertex_data[2].tv=0.5f;
					vertex_data[3].tu=0;
					vertex_data[3].tv=0;
					vertex_data[4].tu=0;
					vertex_data[4].tv=0;
					vertex_data[5].tu=1;
					vertex_data[5].tv=0;
					vertex_data[6].tu=0;
					vertex_data[6].tv=1;
					vertex_data[7].tu=1;
					vertex_data[7].tv=1;
					vertex_data[8].tu=1;
					vertex_data[8].tv=1;
					vertex_data[9].tu=0;
					vertex_data[9].tv=1;
					m_VertexBuffer->Unlock();
				}
			}
		}
	}
	if (m_VertexBuffer != NULL) {
		D3DXVECTOR3 len_vec=AWE_DIR_VEC(start,end);
		float len=D3DXVec3Length(&len_vec);
		D3DXVECTOR3 angle=VectorToAngleRadian(len_vec);
		D3DXQUATERNION quat;
		D3DXQuaternionRotationYawPitchRoll(&quat,angle.y,angle.x,angle.z);
		D3DXMatrixTransformation(&m_WorldMatrix,NULL,NULL,NULL,NULL,&quat,&start);
		PosTex_t *vertex_data;
		if (m_VertexBuffer->Lock(0,0,(unsigned char **)&vertex_data,0) == D3D_OK) {
			vertex_data[0].pos=D3DXVECTOR3(0,thickness,0);
			vertex_data[1].pos=D3DXVECTOR3(0,0,0);
			vertex_data[2].pos=D3DXVECTOR3(0,0,len);
			vertex_data[3].pos=D3DXVECTOR3(0,thickness,len);
			vertex_data[4].pos=D3DXVECTOR3(-thickness,0,len);
			vertex_data[5].pos=D3DXVECTOR3(-thickness,0,0);
			vertex_data[6].pos=D3DXVECTOR3(0,-thickness,len);
			vertex_data[7].pos=D3DXVECTOR3(0,-thickness,0);
			vertex_data[8].pos=D3DXVECTOR3(thickness,0,0);
			vertex_data[9].pos=D3DXVECTOR3(thickness,0, len);
			m_VertexBuffer->Unlock();
		}
	}
}

void
CGameLine::SetColor(D3DXCOLOR color_rgba)
{
	m_Material.Diffuse=color_rgba;
	m_Material.Emissive=color_rgba;
}

void
CGameLine::LoadFile(const char *texture_file)
{
	if (texture_file != NULL) {
		m_Texture=GfxLoadTexture(texture_file);
		AddVar(this,VAR_FILE,texture_file);
	}
	else {
		m_Texture=NULL;
	}
}

void
CGameLine::RenderObject()
{
	g_D3DDevice->SetTransform(D3DTS_WORLD,&m_WorldMatrix);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);
	g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
#else
	GfxAlphaBlendEnable();
	GfxZWriteDisable();
	GfxCullModeNone();
#endif
	m_Material.Diffuse.a=m_Translucency;
	g_D3DDevice->SetMaterial(&m_Material);
	g_D3DDevice->SetTexture(0,m_Texture);
	g_D3DDevice->SetStreamSource(0,m_VertexBuffer,sizeof(PosTex_t));
	g_D3DDevice->SetVertexShader(POSTEX_FVF);
	g_D3DDevice->SetIndices(m_IndexBuffer,0);
	g_D3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0,NUM_VERTICES,0,NUM_FACES);
	g_D3DDevice->SetStreamSource(0,NULL,0);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,TRUE);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,FALSE);
#else
	GfxCullModeCCW();
	GfxZWriteEnable();
#endif
}
