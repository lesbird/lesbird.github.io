// GameParticles.cpp: implementation of the CGameParticles class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	PARTICLE_FVF	(D3DFVF_DIFFUSE|D3DFVF_XYZ)

typedef struct ParticleVertex
{
	D3DXVECTOR3		pos;
	D3DCOLOR		color;
} ParticleVertex_t;

ParticleEmitterList_t	ParticleEmitterList;

static
int						ActiveParticleCount;
static
int						PeakParticleCount;

CGameParticles *		g_Particles;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameParticles::CGameParticles()
{
	g_Particles=this;
}

CGameParticles::~CGameParticles()
{
	while (ParticleEmitterList.size() > 0) {
		ParticleEmitter_t *particle_emitter=(*ParticleEmitterList.begin());
		ParticleEmitterList.pop_front();
		DeleteParticleEmitter(particle_emitter);
	}
	g_Particles=NULL;
}

ParticleEmitter_t *
CGameParticles::FindEmitter(const char *name)
{
	for (ParticleEmitterList_t::iterator e=ParticleEmitterList.begin() ; e != ParticleEmitterList.end() ; e++) {
		ParticleEmitter_t *emitter=(*e);
		if (stricmp(emitter->name,name) == 0) {
			return(emitter);
		}
	}
	return(NULL);
}

void
CGameParticles::CreateParticleEmitter(ParticleEmitter_t *particle_emitter,int max_particles,const char *texture_file)
{
	if (texture_file == NULL) {
		particle_emitter->texture=NULL;
	}
	else {
		particle_emitter->texture=GfxLoadTexture(texture_file,NULL,true,false);
//		D3DXCreateTextureFromFileEx(g_D3DDevice,texture_file,D3DX_DEFAULT,D3DX_DEFAULT,1,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_DEFAULT,0,NULL,NULL,&particle_emitter->texture);
	}
	g_D3DDevice->CreateVertexBuffer(sizeof(ParticleVertex_t)*max_particles,D3DUSAGE_POINTS,PARTICLE_FVF,D3DPOOL_MANAGED,&particle_emitter->vertex_buffer);
}

ParticleEmitter_t *
CGameParticles::CreateParticleEmitter(const char *name,int max_particles,const char *texture_file,float size,bool is_static,bool is_world)
{
	ParticleEmitter_t *particle_emitter=new ParticleEmitter_t;
	strcpy(particle_emitter->name,name);
	particle_emitter->is_active=true;
	particle_emitter->is_static=is_static;
	particle_emitter->is_world=is_world;
	particle_emitter->size=size;
	particle_emitter->texture=NULL;
	particle_emitter->active_particles.clear();
	particle_emitter->inactive_particles.clear();
	particle_emitter->particle=new Particle_t[max_particles];
	for (int i=0 ; i < max_particles ; i++) {
		particle_emitter->inactive_particles.push_back(&particle_emitter->particle[i]);
	}
	CreateParticleEmitter(particle_emitter,max_particles,texture_file);
	ParticleEmitterList.push_back(particle_emitter);
	return(particle_emitter);
}

void
CGameParticles::DeleteParticleEmitter(ParticleEmitter_t *particle_emitter)
{
	particle_emitter->active_particles.clear();
	particle_emitter->inactive_particles.clear();
	delete [] particle_emitter->particle;
	particle_emitter->vertex_buffer->Release();
//	if (particle_emitter->texture != NULL) {
//		particle_emitter->texture->Release();
//	}
	delete particle_emitter;
}

void
CGameParticles::ResetParticleEmitter(ParticleEmitter_t *particle_emitter)
{
	while (particle_emitter->active_particles.size() != 0) {
		Particle_t *particle=(*particle_emitter->active_particles.begin());
		particle_emitter->inactive_particles.push_back(particle);
		particle_emitter->active_particles.pop_front();
	}
}

void
CGameParticles::AddParticle(ParticleEmitter_t *particle_emitter,D3DXVECTOR3 pos,D3DXVECTOR3 vel,D3DXVECTOR3 acc,float life,D3DCOLOR color_argb)
{
	if (g_bNextStep) {
		if (particle_emitter->is_active) {
			if (particle_emitter->inactive_particles.size() != 0) {
				Particle_t *particle=(*particle_emitter->inactive_particles.begin());
				particle->pos=pos;
				particle->vel=vel;
				particle->acc=acc;
				particle->life=life;
				particle->alpha_scale=life;
				particle->color=color_argb;
				particle_emitter->inactive_particles.pop_front();
				particle_emitter->active_particles.push_back(particle);
			}
		}
	}
}

void
CGameParticles::Tick(float delta_time)
{
	ActiveParticleCount=0;
	ParticleVertex_t *particle_vertex;
	for (ParticleEmitterList_t::iterator e=ParticleEmitterList.begin() ; e != ParticleEmitterList.end() ; e++) {
		ParticleEmitter_t *particle_emitter=(*e);
		int size_to_lock=(int)particle_emitter->active_particles.size()*sizeof(ParticleVertex_t);
		if (size_to_lock > 0) {
			if (particle_emitter->vertex_buffer->Lock(0,size_to_lock,(unsigned char **)&particle_vertex,0) == D3D_OK) {
				int i=0;
				for (ParticleList_t::iterator a=particle_emitter->active_particles.begin() ; a != particle_emitter->active_particles.end() ; ) {
					Particle_t *particle=(*a);
					if (!particle_emitter->is_static) {
						particle->life-=delta_time;
						if (particle->life <= 0) {
							a=particle_emitter->active_particles.erase(a);
							particle_emitter->inactive_particles.push_back(particle);
						}
						else {
							particle->vel+=particle->acc*delta_time;
							particle->pos+=particle->vel*delta_time;
							a++;
						}
					}
					particle_vertex[i].pos=particle->pos;
					int alpha=255;
					if (particle->alpha_scale != 0) {
						float life=__max(0,particle->life);
						if (particle_emitter->is_static) {
							float l=life*255.0f;
							FloatToInt(&alpha,l);
						}
						else {
							float l=(life/particle->alpha_scale)*255.0f;
							FloatToInt(&alpha,l);
							alpha=__min(alpha,255);
						}
					}
					particle_vertex[i].color=(particle->color)&0x00FFFFFF;
					particle_vertex[i].color|=((alpha&0xFF)<<24);
					i++;
					if (particle_emitter->is_static) {
						a++;
					}
				}
				particle_emitter->vertex_buffer->Unlock();
			}
		}
		ActiveParticleCount+=(int)particle_emitter->active_particles.size();
	}
	if (ActiveParticleCount > PeakParticleCount) {
		PeakParticleCount=ActiveParticleCount;
	}
}

void
CGameParticles::Render()
{
	D3DXMATRIX identity;
	D3DXMatrixIdentity(&identity);
	g_D3DDevice->SetTransform(D3DTS_WORLD,&identity);
//	g_D3DDevice->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_MODULATE);
//	g_D3DDevice->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
	g_D3DDevice->SetRenderState(D3DRS_POINTSPRITEENABLE,TRUE);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);
	g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,FALSE);
#else
	GfxZWriteDisable();
	GfxAlphaBlendEnable();
	GfxLightingDisable();
#endif
//	g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
//	g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	g_D3DDevice->SetVertexShader(PARTICLE_FVF);
	for (ParticleEmitterList_t::iterator e=ParticleEmitterList.begin() ; e != ParticleEmitterList.end() ; e++) {
		ParticleEmitter_t *particle_emitter=(*e);
		if (particle_emitter->active_particles.size() != 0) {
			if (particle_emitter->is_world) {
				g_D3DDevice->SetRenderState(D3DRS_POINTSCALEENABLE,true);
				GfxUpdateProjection();
				GfxUpdateView();
			}
			else {
				g_D3DDevice->SetTransform(D3DTS_VIEW,&identity);
				g_D3DDevice->SetRenderState(D3DRS_POINTSCALEENABLE,false);
				GfxUpdateOrtho();
			}
			g_D3DDevice->SetRenderState(D3DRS_POINTSIZE,*((DWORD *)&particle_emitter->size));
//			g_D3DDevice->SetTexture(0,particle_emitter->texture);
			GfxSetTextureStage(0,particle_emitter->texture,false,false,false,false);
			g_D3DDevice->SetStreamSource(0,particle_emitter->vertex_buffer,sizeof(ParticleVertex_t));
			g_D3DDevice->DrawPrimitive(D3DPT_POINTLIST,0,(unsigned int)particle_emitter->active_particles.size());
			g_D3DDevice->SetStreamSource(0,NULL,0);
			g_D3DDevice->SetTexture(0,NULL);
			g_VisiblePolys+=particle_emitter->active_particles.size()*2;
		}
	}
	g_D3DDevice->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);
#if USE_EFFECT_FILE
	g_D3DDevice->SetRenderState(D3DRS_LIGHTING,TRUE);
	g_D3DDevice->SetRenderState(D3DRS_POINTSPRITEENABLE,FALSE);
	g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,TRUE);
#else
	GfxLightingEnable();
	GfxZWriteEnable();
#endif
}

void
InitParticles()
{
	CGameParticles *particles=new CGameParticles;
}

void
UnInitParticles()
{
	delete g_Particles;
}

void
UpdateParticles(float delta_time)
{
	g_Particles->Tick(delta_time);
}

void
RenderParticles()
{
	g_Particles->Render();
}
