// GameMesh.h: interface for the CGameMesh class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEMESH_H__46C8EF67_31C3_4C08_98C1_2F78669FD0E7__INCLUDED_)
#define AFX_GAMEMESH_H__46C8EF67_31C3_4C08_98C1_2F78669FD0E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

#define	ENV_BUMP			1	//	set to 0 to use Dot3 bump mapping

#define	VAR_BOX_SIZE		'BOXS'
#define	VAR_BUMP_SCALE		'BUMS'
#define	VAR_INDEX_COUNT		'ICNT'
#define	VAR_INDEX_DATA		'IDAT'
#define	VAR_MESH			'MESH'
#define	VAR_SHADOW			'SHAD'
#define	VAR_TEXTURE_BASE	'TEXA'
#define	VAR_TEXTURE_BLEND	'TEXL'
#define	VAR_TEXTURE_BUMP	'TEXB'
#define	VAR_TEXTURE_CUBE	'TEXC'
#define	VAR_TEXTURE_DET		'TEXD'
#define	VAR_TEXTURE_NORM	'TEXN'
#define	VAR_TEXTURE_REF		'TEXR'
#define	VAR_TEXTURE_SHADOW	'TEXS'
#define	VAR_TEXTURE_VOLUME	'TEXV'
#define	VAR_TEXTURE_XFORM0	'TXX0'
#define	VAR_TEXTURE_XFORM1	'TXX1'
#define	VAR_TEXTURE_XFORM2	'TXX2'
#define	VAR_TEXTURE_XFORM3	'TXX3'
#define	VAR_TEXTURE_XFORMP0	'TXP0'
#define	VAR_TEXTURE_XFORMP1	'TXP1'
#define	VAR_TEXTURE_XFORMP2	'TXP2'
#define	VAR_TEXTURE_XFORMP3	'TXP3'
#define	VAR_TEXTURE_XFORMR0	'TXQ0'
#define	VAR_TEXTURE_XFORMR1	'TXQ1'
#define	VAR_TEXTURE_XFORMR2	'TXQ2'
#define	VAR_TEXTURE_XFORMR3	'TXQ3'
#define	VAR_TEXTURE_XFORMS0	'TXS0'
#define	VAR_TEXTURE_XFORMS1	'TXS1'
#define	VAR_TEXTURE_XFORMS2	'TXS2'
#define	VAR_TEXTURE_XFORMS3	'TXS3'
#define	VAR_TEXTURE_XRATE0	'TXR0'
#define	VAR_TEXTURE_XRATE1	'TXR1'
#define	VAR_TEXTURE_XRATE2	'TXR2'
#define	VAR_TEXTURE_XRATE3	'TXR3'
#define	VAR_TEXTURE			'TEXT'
#define	VAR_VERTEX_DATA		'VDAT'
#define	VAR_VERTEX_COUNT	'VCNT'

typedef struct Mesh_s
{
	int					Refs;
	char				FileName[128];
	LPD3DXMESH			Mesh;
	int					NumMaterials;
	D3DMATERIAL8 *		Materials;
	LPDIRECT3DTEXTURE8 *Textures;
} Mesh_t;

typedef list<Mesh_t *>	MeshList_t;

#if ENV_BUMP == 1
#define	POSNORTEX_FVF	(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)

typedef struct PosNorTex_s
{
	D3DXVECTOR3		pos;
	D3DXVECTOR3		nor;
	float			tu1,tv1;
} PosNorTex_t;
#else
#define	POSNORTEX_FVF	(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX3|D3DFVF_TEXCOORDSIZE2(0)|D3DFVF_TEXCOORDSIZE3(1)|D3DFVF_TEXCOORDSIZE3(2))

typedef struct PosNorTex_s
{
	D3DXVECTOR3		pos;
	D3DXVECTOR3		nor;
	float			tu1,tv1;
	float			tu2,tv2,tw2;	//	u tangent vector
	float			tu3,tv3,tw3;	//	v tangent vector
} PosNorTex_t;
#endif

class CShadowVolume;

class CGameMesh : public CGameObject  
{
public:
	CGameMesh();
	virtual ~CGameMesh();

	virtual void		UnInitGameMesh();

	virtual void		InitShadowVolume();
	virtual void		UnInitShadowVolume();

	virtual void		SetPosition(float x,float y,float z);
	virtual void		GetPosition(float &x,float &y,float &z);
	virtual void		SetRotation(float x,float y,float z);
	virtual void		GetRotation(float &x,float &y,float &z);
	virtual void		SetQuaternion(float x,float y,float z,float w);
	virtual void		GetQuaternion(float &x,float &y,float &z,float &w);
	virtual void		SetScale(float x,float y,float z);
	virtual void		GetScale(float &x,float &y,float &z);
	virtual void		SetColor(float r,float g,float b);
	virtual void		GetColor(float &r,float &g,float &b);

	virtual void		SetTextureTransform(int stage,int type,float rate);

	virtual void		UpdateVars();

	virtual void		MakeBox(D3DXVECTOR3 size,const char *texture_file);
	virtual void		LoadFile(const char *file_name,bool has_specular=false);
	virtual void		LoadEffects(const char *file_name);
	virtual void		LoadScriptFile(const char *file_name);
	virtual void		LoadEffect(const char *file_name,const char *technique_name=NULL);
	virtual void		SetEffectTechnique(const char *technique_name);
	virtual void		LoadBlendMap(const char *file_name);
	virtual void		LoadBumpMap(const char *file_name,float bump_scale=0);
	virtual void		LoadCubeMap(const char *file_name);
	virtual void		LoadDetailMap(const char *file_name);
	virtual void		LoadReflectionMap(const char *file_name);
	virtual void		LoadTexture(const char *file_name);

	virtual void		LostObject();
	virtual void		ResetObject();
	virtual void		UpdateObject(float delta_time);

	virtual void		DelCollision();
	virtual void		AddBoxCollision(bool is_static=false);
	virtual void		AddCylinderCollision(bool is_static=false);
	virtual void		AddSphereCollision(bool is_static=false);
	virtual void		AddCompoundCollision(unsigned int col_type,D3DXVECTOR3 offset,D3DXVECTOR3 box_size,bool is_static=false);
	virtual void		AddTriMeshCollision();
	virtual void		ResetCollision();

	virtual void		PreRenderObject();
	virtual void		RenderObject();
	virtual void		PostRenderObject();

public:
	D3DXMATRIX			m_TextureTransform[4];
	D3DXVECTOR3			m_TextureTransformPos[4];
	float				m_TextureTransformRate[4];
	D3DXVECTOR3			m_TextureTransformRot[4];
	D3DXVECTOR3			m_TextureTransformScale[4];
	int					m_TextureTransformType[4];
	DWORD				m_TexCoordIndex[4];

	D3DXMATRIX			m_ShadowCache;
	D3DXVECTOR3 *		m_ShadowVerts;
	D3DXVECTOR3	*		m_ShadowNorms;
	WORD *				m_ShadowIndices;
	int					m_ShadowNumFaces;

	float				m_OutlineThickness;

	D3DXCOLOR			m_Color;
	D3DXCOLOR			m_OutlineColor;

	D3DXVECTOR3			m_Pos;
	D3DXVECTOR3			m_Rot;
	D3DXVECTOR3			m_Scale;

	D3DXQUATERNION		m_Quat;

	D3DXMATRIX			m_WorldMatrix;

	bool				m_bHasShadow;
	bool				m_bOutline;

	CShadowVolume *		m_ShadowVolume;
};

extern
bool			g_bShadowMapEnable;
extern
bool			g_bShowCollision;

extern
D3DXVECTOR3		g_ShadowMapScale;
extern
D3DXVECTOR3		g_ShadowMapRot;
extern
D3DXVECTOR3		g_ShadowMapPos;

extern
D3DXVECTOR3		g_ShadowLightPos;

extern
void GameAppTextureTransform(CGameMesh *mesh_obj,int tex_index,int xform_type,float xform_rate,float delta_time);

extern
void GameAppUpdateMesh(CGameMesh *mesh_obj,float delta_time);
/*
extern
void GameAppDrawMesh(CGameMesh *mesh_obj);
*/
#endif // !defined(AFX_GAMEMESH_H__46C8EF67_31C3_4C08_98C1_2F78669FD0E7__INCLUDED_)
