// GameFile.h: interface for the CGameFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEFILE_H__C3B0DF80_5A99_4829_BC39_72275DC5AF31__INCLUDED_)
#define AFX_GAMEFILE_H__C3B0DF80_5A99_4829_BC39_72275DC5AF31__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	MAX_FILES		512
#define	FILE_NAME_SIZE	256

typedef struct DataFileHdr
{
	int					NumFiles;
	char				Filename[MAX_FILES][FILE_NAME_SIZE];
	unsigned long		FileSize[MAX_FILES];
	unsigned long		FilePos[MAX_FILES];
} DataFileHdr_t;

typedef struct DataFile
{
	void *				Data;
	unsigned long		Pos;
	unsigned long		Size;
} DataFile_t;

class CGameFile  
{
public:
	CGameFile();
	virtual ~CGameFile();

	bool				OpenDataFile(const char *data_file_name);
	void				CloseDataFile();
	void *				GetFile(const char *file_name,unsigned long *size=NULL);
	void				FreeFileMem(void *file_ptr);
	bool				Exist(const char *file_name);

	DataFile_t *		Open(const char *file_name);
	void				Close(DataFile_t *fp);

	bool				Eof(DataFile_t *fp);
	unsigned long		Gets(char *s,int n,DataFile_t *fp);
	unsigned long		Read(void *buf,unsigned long size,unsigned long count,DataFile_t *fp);
	void				Seek(DataFile_t *fp,unsigned long offset,int from);
	unsigned long		Tell(DataFile_t *fp);

	void				BuildDataFileList(char *file_path,FILE *out_fp,const char *ignore_list[],int num_ignore_files);
	void				BuildDataFile(const char *data_file_name,const char *ignore_list[],int num_ignore_files);

public:
	FILE *				m_DataFile;
	DataFileHdr_t		m_DataFileHdr;
	unsigned long		m_DataFilePos;
};

extern
CGameFile *				g_GameFile;

extern
void					InitFileSystem();
extern
void					UnInitFileSystem();

extern
void					GameAppInitFileSystem();

#endif // !defined(AFX_GAMEFILE_H__C3B0DF80_5A99_4829_BC39_72275DC5AF31__INCLUDED_)
