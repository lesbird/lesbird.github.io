// Win32.h: 32-bit Windows related global functions
//
//////////////////////////////////////////////////////////////////////

#if !defined(GAMEAPP32_H)
#define GAMEAPP32_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	RAND(x)			(rand()%x)
#define	RAND_RANGE(x)	(RAND(x)-(x>>1))
#define	RAND_SEED(x)	(srand(x))

enum {
	KEY_NULL=0,
	KEY_ESC,
	KEY_1,KEY_2,KEY_3,KEY_4,KEY_5,KEY_6,KEY_7,KEY_8,KEY_9,KEY_0,
	KEY_MINUS,KEY_EQUALS,KEY_BACKSPACE,KEY_TAB,
	KEY_Q,KEY_W,KEY_E,KEY_R,KEY_T,KEY_Y,KEY_U,KEY_I,KEY_O,KEY_P,
	KEY_LEFTBRACKET,KEY_RIGHTBRACKET,KEY_ENTER,KEY_CTRL,
	KEY_A,KEY_S,KEY_D,KEY_F,KEY_G,KEY_H,KEY_J,KEY_K,KEY_L,
	KEY_SEMICOLON,KEY_SINGLEQUOTE,KEY_TILDE,KEY_LSHIFT,KEY_BACKSLASH,
	KEY_Z,KEY_X,KEY_C,KEY_V,KEY_B,KEY_N,KEY_M,
	KEY_COMMA,KEY_PERIOD,KEY_SLASH,KEY_RSHIFT,KEY_PRINTSCREEN,KEY_ALT,KEY_SPACE,KEY_CAPS,
	KEY_F1,KEY_F2,KEY_F3,KEY_F4,KEY_F5,KEY_F6,KEY_F7,KEY_F8,KEY_F9,KEY_F10,
	KEY_NUMLOCK,KEY_SCROLL,KEY_HOME,KEY_UP,KEY_PGUP,KEY_PADMINUS,
	KEY_LEFT,KEY_CENTER,KEY_RIGHT,KEY_PADPLUS,KEY_END,KEY_DOWN,KEY_PGDN,
	KEY_INS,KEY_DEL,
	KEY_F11=87,KEY_F12
};

enum {
	MEDIA_NONE,
	MEDIA_PLAY,
	MEDIA_PAUSE,
	MEDIA_STOP,
	MEDIA_MAX
};

extern
const char *			g_KeyLabel[];

extern
HWND					g_hWnd;
extern
HINSTANCE				g_hInstance;
extern
HCURSOR					g_hCursor;

extern
bool					g_bAppActive;

extern
bool					g_bCursorVisible;
extern
bool					g_bHasFocus;
extern
bool					g_bNextStep;
extern
bool					g_bSingleStep;

extern
bool					g_bLogEnable;

extern
char					g_Char;

extern
bool					g_AutoInsert;

extern
int						g_WinRemote;

extern
unsigned char			g_WinMouseButtons;
extern
int						g_WinMouseX,
						g_WinMouseY,
						g_WinMouseWheel;

extern
int						g_WindowHeight;
extern
int						g_WindowWidth;

extern
float					g_Fps,
						g_FpsAvg;

extern
char *					g_GameName;

extern
char					g_LastLog[];

extern
void					ResetTimer();
extern
LARGE_INTEGER			GetTimer();
extern
float					GetTimerDelta(LARGE_INTEGER &last_time);

extern
void					GameAppInit();
extern
void					GameAppUnInit();

extern
void					GameAppGetWindowSize(int &width,int &height);
extern
void					GameAppSetWindowSize(int width,int height);

extern
void					GameAppPauseGame(bool pause_flag);

extern
void					GameAppUpdateFrame(float delta_time);

extern
void					AppShowCursor(bool show_flag);

extern
char					GetChar();
extern
char					PeekChar();
extern
bool					GetKey(int scan_code);
extern
bool					PeekKey(int scan_code);

extern
void					Log(char *fmt,...);
extern
void					LogResource(char *fmt,...);

#endif
