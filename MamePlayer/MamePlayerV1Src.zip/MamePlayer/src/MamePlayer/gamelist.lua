--	insert any additional games into the list

mam.insertgame("d:/games/diamond caves ii/dc2.exe","Diamond Caves 2","2006","Peter Elzner","d:/games/diamond caves ii/screens/dc2.jpg")
