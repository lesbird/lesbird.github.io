Download screens.zip for Mame32 and unzip them here
