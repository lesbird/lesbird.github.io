Download and install DirectX 9 June 2010 SDK
Use Visual Studio 2010 to build
