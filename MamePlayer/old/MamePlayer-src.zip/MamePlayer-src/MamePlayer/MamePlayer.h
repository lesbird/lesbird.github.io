#pragma once
#include "GameApp.h"
#include "GameSprite.h"

#define	DESC_SIZE	128
#define	MANU_SIZE	64
#define	ROMN_SIZE	16
#define	YEAR_SIZE	8

typedef struct GAME
{
	bool						bClone;
	bool						bVisible;
	bool						bFavorite;
	char						Desc[DESC_SIZE];
	char						Manu[MANU_SIZE];
	char						Rom[ROMN_SIZE];
	char						Year[YEAR_SIZE];
} Game_t;

class CMamePlayer :
	public CGameApp
{
public:
	CMamePlayer(void);
	virtual ~CMamePlayer(void);

public:
	int							CountVisibleGames();
	int							FindNextLetter(int cur_letter);
	int							FindPrevLetter(int cur_letter);
	int							FindNearestGame(Game_t *game);

	void						SaveGameState();
	void						LoadGameState();

	void						Init(IDirect3DDevice9 *d3dDevice);
	void						UnInit();
	void						UnInitGameList();

	bool						IsRightKeyPressed();
	bool						IsLeftKeyPressed();
	bool						IsUpKeyPressed();
	bool						IsDownKeyPressed();
	bool						IsStartKeyPressed();

	void						Tick(float delta_time);

	void						LoadFavorites();
	void						SaveFavorites();

	void						ShowAllGames();
	void						ShowFavorites();

	void						ParseXml();
	void						ParseXmlInsertGame(Game_t *game);

	void						LaunchGame(Game_t *game);

public:
	bool						m_bClick;
	bool						m_bLaunch;
	bool						m_bParsing;
	bool						m_bParseXml;
	bool						m_bShowClones;
	bool						m_bShowHiddenGames;
	bool						m_bShowFavorites;

	TCHAR						m_GameTextureFile[MAX_PATH];

	int							m_CurrentGame;

	Game_t *					m_SelectedGame;

	CGameSprite *				m_GameImage;
	CGameSprite *				m_Title;

	LPDIRECT3DTEXTURE9			m_DefaultTexture;
	LPDIRECT3DTEXTURE9			m_GameTexture;

	CGrowableArray<Game_t *>	m_GameList;
	CGrowableArray<Game_t *>	m_FavoriteList;
};
