// MamePlayer (C) 2007-2012 Les Bird
// Built with Visual Studio Express 2010
// 3/2012 - converted to Visual Studio Express 2010
// 7/2012 - fixed minor bugs, made it compatible with MAME 0.145

#include "dxut.h"
#include "MamePlayer.h"
#include "GameXml.h"
#include <time.h>

bool				g_AppFullScreen=false;

LPTSTR				g_AppName=L"MamePlayer (C) 2007, 2012 Les Bird";

CMamePlayer *		g_MameApp;

int					g_VisibleGameCount;
bool				g_UpdateList = true;

//
//
//

CMamePlayer::CMamePlayer(void)
{
	m_bClick=false;
	m_bLaunch=false;
	m_bParsing=false;
	m_bParseXml=false;
	m_bShowClones=false;
	m_bShowHiddenGames=false;
	m_bShowFavorites = false;
	m_Char=0;
	m_GameTextureFile[0]=0;

	m_CurrentGame=0;

	m_SelectedGame=NULL;

	m_GameImage=NULL;
	m_Title=NULL;

	m_DefaultTexture=NULL;
	m_GameTexture=NULL;

	m_GameList.Reset();
	m_FavoriteList.Reset();

	g_MameApp=this;
}

CMamePlayer::~CMamePlayer(void)
{
	g_MameApp=NULL;
}

int
CMamePlayer::CountVisibleGames()
{
	g_VisibleGameCount = 0;
	for (int i=0 ; i < m_GameList.GetSize() ; i++)
	{
		Game_t *game=m_GameList.GetAt(i);
		if (game->bClone && !m_bShowClones)
		{
			continue;
		}
		if (game->bVisible || m_bShowHiddenGames)
		{
			g_VisibleGameCount++;
		}
	}
	return g_VisibleGameCount;
}

int
CMamePlayer::FindPrevLetter(int cur_letter)
{
	int c=toupper(cur_letter);
	DXUTOutputDebugString(L"FindPrevLetter %c\n", c);
	while (--c >= '0')
	{
		int n = 0;
		int count = 0;
		if (m_bShowFavorites)
		{
			count = m_FavoriteList.GetSize();
		}
		else
		{
			count = m_GameList.GetSize();
		}
		for (int i=0 ; i < count ; i++)
		{
			Game_t *game = NULL;
			if (m_bShowFavorites)
			{
				game = m_FavoriteList.GetAt(i);
			}
			else
			{
				game = m_GameList.GetAt(i);
			}
			if (game->bClone && !m_bShowClones)
			{
				continue;
			}
			if (game->bVisible || m_bShowHiddenGames)
			{
				if (toupper(game->Desc[0]) == c)
				{
					DXUTOutputDebugString(L"%d %s\n", n, game->Desc);
					return(n);
				}
				n++;
			}
		}
	}
	return(-1);
}

int
CMamePlayer::FindNextLetter(int cur_letter)
{
	int c=toupper(cur_letter);
	DXUTOutputDebugString(L"FindNextLetter %c\n", c);
	while (++c <= '_')
	{
		int n = 0;
		int count = 0;
		if (m_bShowFavorites)
		{
			count = m_FavoriteList.GetSize();
		}
		else
		{
			count = m_GameList.GetSize();
		}
		for (int i=0 ; i < count ; i++)
		{
			Game_t *game = NULL;
			if (m_bShowFavorites)
			{
				game = m_FavoriteList.GetAt(i);
			}
			else
			{
				game = m_GameList.GetAt(i);
			}
			if (game->bClone && !m_bShowClones)
			{
				continue;
			}
			if (game->bVisible || m_bShowHiddenGames)
			{
				if (toupper(game->Desc[0]) == c)
				{
					DXUTOutputDebugString(L"%d %s\n", n, game->Desc);
					return(n);
				}
				n++;
			}
		}
	}
	return(-1);
}

int
CMamePlayer::FindNearestGame(Game_t *game)
{
	if (m_bShowFavorites)
	{
		for (int i = 0; i < m_FavoriteList.GetSize(); i++)
		{
			Game_t *g = m_FavoriteList.GetAt(i);
			if (strcmp(g->Desc, game->Desc) >= 0)
			{
				return i;
			}
		}
		return m_FavoriteList.GetSize() - 1;
	}
	int n = 0;
	for (int i = 0; i < m_GameList.GetSize(); i++)
	{
		Game_t *g = m_GameList.GetAt(i);
		if (g->bClone && !m_bShowClones) 
		{
			continue;
		}
		if (strcmp(g->Desc, game->Desc) >= 0)
		{
			return n;
		}
		n++;
	}
	return m_GameList.GetSize() - 1;
}

void
CMamePlayer::SaveGameState()
{
	FILE *fp = fopen("gamestate.sav", "wb");
	if (fp != NULL)
	{
		fwrite(&m_bShowFavorites, sizeof(bool), 1, fp);
		fwrite(&m_CurrentGame, sizeof(int), 1, fp);
		fclose(fp);
	}
}

void
CMamePlayer::LoadGameState()
{
	FILE *fp = fopen("gamestate.sav", "rb");
	if (fp != NULL)
	{
		fread(&m_bShowFavorites, sizeof(bool), 1, fp);
		fread(&m_CurrentGame, sizeof(int), 1, fp);
		fclose(fp);
	}
}

void
CMamePlayer::Init(IDirect3DDevice9 *d3dDevice)
{
	CGameApp::Init(d3dDevice);

	m_Title=new CGameSprite;
	m_Title->Load(d3dDevice,L"MamePlayer/Bitmaps/MAMELogoTM.jpg");
	m_Title->m_Scale=D3DXVECTOR3(m_Width/m_Title->m_Width,(m_Height/4)/m_Title->m_Height,1);
	m_Title->m_Pos=D3DXVECTOR3(m_Width/2.0f,(m_Height/4.0f)-64,0);
	m_Title->Show();

	D3DXCreateTextureFromFileEx(d3dDevice,L"MamePlayer/Bitmaps/MAMELogoTM_sml.jpg",256,256,1,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_DEFAULT,D3DX_DEFAULT,0,NULL,NULL,&m_DefaultTexture);

	m_GameImage=new CGameSprite;
	m_GameImage->Init(d3dDevice);
	m_GameImage->LoadTexture(m_DefaultTexture);
	m_GameImage->m_Scale=D3DXVECTOR3(384.0f/m_GameImage->m_Width,256.0f/m_GameImage->m_Height,1);
	m_GameImage->m_Pos=D3DXVECTOR3(m_Width/4.0f,(m_Height/2.0f)+64,0);
	m_GameImage->Show();

	m_MouseX=m_Width/2;
	m_MouseY=m_Height/2;
	SetCursorPos(m_MouseX,m_MouseY);
	ShowCursor(FALSE);
}

void
CMamePlayer::UnInit()
{
	SaveGameState();

	m_GameImage->LoadTexture(NULL);

	CGameApp::UnInit();

	UnInitGameList();
}

void
CMamePlayer::UnInitGameList()
{
	while (m_GameList.GetSize() > 0) {
		Game_t *game=m_GameList.GetAt(0);
		m_GameList.Remove(0);
		delete game;
	}
	m_FavoriteList.RemoveAll();
	SAFE_RELEASE(m_DefaultTexture);
	SAFE_RELEASE(m_GameTexture);
}

bool
CMamePlayer::IsRightKeyPressed()
{
	if (IsKeyPressed(VK_RIGHT) || IsKeyPressed(VK_NUMPAD6) || IsKeyPressed('g'))
	{
		return true;
	}
	return false;
}

bool
CMamePlayer::IsLeftKeyPressed()
{
	if (IsKeyPressed(VK_LEFT) || IsKeyPressed(VK_NUMPAD4) || IsKeyPressed('d'))
	{
		return true;
	}
	return false;
}

bool
CMamePlayer::IsUpKeyPressed()
{
	if (IsKeyPressed(VK_UP) || IsKeyPressed(VK_NUMPAD8) || IsKeyPressed('r'))
	{
		return true;
	}
	return false;
}

bool
CMamePlayer::IsDownKeyPressed()
{
	if (IsKeyPressed(VK_DOWN) || IsKeyPressed(VK_NUMPAD2) || IsKeyPressed('f'))
	{
		return true;
	}
	return false;
}

bool
CMamePlayer::IsStartKeyPressed()
{
	if (IsKeyPressed(VK_LCONTROL) || IsKeyPressed(VK_RETURN) || IsKeyPressed('a'))
	{
		return true;
	}
	return false;
}

void
CMamePlayer::Tick(float delta_time)
{
	static float key_time, key_repeat;
	static float screen_save_timer;
	static int key_down[256];

	CGameApp::Tick(delta_time);

	bool key_time_flag = false;
	bool any_key_down = false;
	for (int i = 0; i < 256; i++)
	{
		if (IsKeyPressed(i))
		{
			if (key_down[i] == 0)
			{
				key_down[i] = 1;
				key_time_flag = true;
				key_time = 0;
			}
			any_key_down = true;
		}
		else
		{
			key_down[i] = 0;
		}
	}

	if (any_key_down)
	{
		screen_save_timer = 0;
		if (!m_Title->m_bIsVisible)
		{
			m_Title->Show();
			m_GameImage->Show();
			g_UpdateList = true;
			return;
		}
	}

	screen_save_timer += delta_time;

	if (screen_save_timer > 300)
	{
		if (m_Title->m_bIsVisible)
		{
			m_Title->Hide();
			m_GameImage->Hide();
		}

		float a = fabs(cosf(screen_save_timer));
		PrintText((m_Width / 2) - 350, m_Height / 2, 1, D3DXCOLOR(1,1,1,a), L"<< T A P   A   B U T T O N   T O   P L A Y >>");
		goto date_and_time;
	}

	if (key_repeat == 0 || !any_key_down)
	{
		key_repeat = 0.25f;
	}

	key_time += delta_time;
	if ((key_time > key_repeat) && (IsDownKeyPressed() || IsUpKeyPressed()))
	{
		key_repeat -= 0.025f;
		if (key_repeat <= 0)
		{
			key_repeat = 0.01f;
		}
		key_time_flag = true;
		key_time = 0;
	}

	bool left_down=DXUTIsMouseButtonDown(VK_LBUTTON);

	if (m_GameList.GetSize() == 0) {
		if (m_bParseXml) {
			ParseXml();
			ShowAllGames();
			LoadFavorites();
			LoadGameState();
			CountVisibleGames();
			m_bParseXml=false;
		}
		else {
			PrintText(m_Width/2,m_Height-90,1,D3DXCOLOR(0,1,0,1),L"...PARSING...");
			m_bParseXml=true;
		}
	}
	else if (m_bLaunch) {
		D3DXVECTOR3 target_pos(m_Width/2.0f,m_Height/2.0f,0);
		D3DXVECTOR3 mov_pos=target_pos-m_GameImage->m_Pos;
		m_GameImage->m_Pos+=mov_pos*(5*delta_time);
		D3DXVECTOR3 dst=m_GameImage->m_Pos-target_pos;
		if (D3DXVec3Length(&dst) < 1) {
			LaunchGame(m_SelectedGame);
			m_GameImage->m_Pos=D3DXVECTOR3(m_Width/4.0f,(m_Height/2.0f)+64,0);
			m_bLaunch=false;
		}
	}
	else 
	{
		if (DXUTIsKeyDown(VK_F1)) 
		{
			int y=(m_Height/2)-60;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"MAMEPLAYER");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"====================================");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"F1:       HELP");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"F5:       TOGGLE ALL GAMES/FAVORITES");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"F8:       ADD/REMOVE FAVORITE");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"F10:      CLEAR FAVORITES LIST");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"CTRL:     LAUNCH GAME");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"ENTER:    LAUNCH GAME");
			y+=30;
			PrintText(m_Width/2,y,0,D3DXCOLOR(1,1,1,1),L"TAB:      PICK RANDOM GAME");
			y+=30;
			return;
		}

		int count=m_GameList.GetSize();
		if (m_bShowFavorites)
		{
			count = m_FavoriteList.GetSize();
		}
		int n = 0;

		int top_line=int(m_Title->m_Pos.y)+128;
		int bot_line=(m_Height-128);
		int num_lines=(bot_line-top_line)/25;
		int mid_line=(num_lines/4);
		int y=top_line;
		if (m_CurrentGame < mid_line)
		{
			y = top_line + ((mid_line - m_CurrentGame) * 25);
		}
		for (int i=0 ; i < count ; i++) 
		{
			Game_t *game = NULL;
			if (m_bShowFavorites)
			{
				game = m_FavoriteList.GetAt(i);
			}
			else
			{
				game = m_GameList.GetAt(i);
			}
			if (game->bClone && !m_bShowClones) 
			{
				continue;
			}
			if (game->bVisible || m_bShowHiddenGames) 
			{
				int top = m_CurrentGame - mid_line;
				if (n >= top && n < top + num_lines) 
				{
					TCHAR desc_w[DESC_SIZE];
					MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,game->Desc,-1,desc_w,DESC_SIZE);
					for (UINT j = 0 ; j < wcslen(desc_w) ; j++) 
					{
						if (j > 0 && (desc_w[j] == '(' || desc_w[j] == '[')) 
						{
							desc_w[j] = 0;
							break;
						}
					}
					if (n == m_CurrentGame) 
					{
						m_SelectedGame = game;
						D3DXCOLOR color(1,1,1,1);
						if (!game->bVisible) 
						{
							color = D3DXCOLOR(1,0,0,1);
						}
						if (game->bFavorite)
						{
							color = D3DXCOLOR(1, 1, 0, 1);
						}
						PrintText(m_Width/2, y, 1, color, L"%s", desc_w);
						y += 30;
						TCHAR year_w[YEAR_SIZE];
						MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, game->Year, -1, year_w, YEAR_SIZE);
						TCHAR manu_w[MANU_SIZE];
						MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, game->Manu, -1, manu_w, MANU_SIZE);
						if (game->bVisible) 
						{
							PrintText(m_Width/2, y, 0, D3DXCOLOR(0,1,0,1), L"(%s %s)", year_w, manu_w);
						}
						else 
						{
							PrintText(m_Width/2, y, 0, D3DXCOLOR(1,0,0,1), L"(%s %s)", year_w, manu_w);
						}
						y += 25;
						if (g_UpdateList)
						{
							TCHAR rom_w[ROMN_SIZE];
							MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, game->Rom, -1, rom_w, ROMN_SIZE);
							TCHAR tex_file[MAX_PATH];
							swprintf_s(tex_file, MAX_PATH, L"MamePlayer/Screens/%s.png", rom_w);
							if (wcscmp(tex_file, m_GameTextureFile) != 0)
							{
								SAFE_RELEASE(m_GameTexture);
								if (_waccess_s(tex_file,0) == 0) 
								{
									if (D3DXCreateTextureFromFileEx(DXUTGetD3D9Device(),tex_file,256,256,1,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_DEFAULT,D3DX_DEFAULT,0,NULL,NULL,&m_GameTexture) == D3D_OK) 
									{
										m_GameImage->LoadTexture(m_GameTexture);
									}
									else
									{
										m_GameImage->LoadTexture(m_DefaultTexture);
										m_GameTexture=NULL;
									}
								}
								else 
								{
									m_GameImage->LoadTexture(m_DefaultTexture);
									m_GameTexture=NULL;
								}
								wcscpy_s(m_GameTextureFile,MAX_PATH,tex_file);
							}
							g_UpdateList = false;
						}
					}
					else 
					{
						if (game->bVisible) 
						{
							if (game->bFavorite && !m_bShowFavorites)
							{
								PrintText(m_Width / 2, y, 0, D3DXCOLOR(0.75f,0.75f,0,1), L"%s", desc_w);
							}
							else
							{
								PrintText(m_Width / 2, y, 0, D3DXCOLOR(0.5f,0.5f,0.5f,1), L"%s", desc_w);
							}
						}
						else 
						{
							PrintText(m_Width / 2, y, 0, D3DXCOLOR(0.5f,0,0,1), L"%s", desc_w);
						}
						y+=25;
					}
				}
				n++;
			}
		}

		PrintText(m_Width/2, m_Height - 90, 0, D3DXCOLOR(0,1,0,1), L"%d/%d", m_CurrentGame + 1, n);

		int sens = 2;
		if (m_MouseWheelDelta < 0 || (IsDownKeyPressed() && key_time_flag) || m_MouseDeltaY > 0)
		{
			if (m_MouseDeltaY == 0)
			{
				m_MouseDeltaY = sens;
			}
			if (m_CurrentGame < count - 1)
			{
				m_CurrentGame += (m_MouseDeltaY / sens);
				if (m_CurrentGame > count - 1)
				{
					m_CurrentGame = count - 1;
				}
				g_UpdateList = true;
			}
			m_MouseWheelDelta = 0;
			screen_save_timer = 0;
		}
		else if (m_MouseWheelDelta > 0 || (IsUpKeyPressed() && key_time_flag) || m_MouseDeltaY < 0)
		{
			if (m_MouseDeltaY == 0)
			{
				m_MouseDeltaY = -sens;
			}
			if (m_CurrentGame > 0) 
			{
				m_CurrentGame += (m_MouseDeltaY / sens);
				if (m_CurrentGame < 0)
				{
					m_CurrentGame = 0;
				}
				g_UpdateList = true;
			}
			m_MouseWheelDelta = 0;
			screen_save_timer = 0;
		}
		else if (IsRightKeyPressed() && key_time_flag) 
		{
			int n = FindNextLetter(m_SelectedGame->Desc[0]);
			if (n != -1)
			{
				m_CurrentGame = n;
				g_UpdateList = true;
			}
		}
		else if (IsLeftKeyPressed() && key_time_flag) 
		{
			int n = FindPrevLetter(m_SelectedGame->Desc[0]);
			if (n != -1) 
			{
				m_CurrentGame = n;
				g_UpdateList = true;
			}
		}
		
		if (IsKeyPressed(VK_F10) && key_time_flag) 
		{
			m_FavoriteList.RemoveAll();
			remove("favorites.dat");
			ShowAllGames();
			g_UpdateList = true;
		}
		else if ((IsKeyPressed(VK_F5) || (IsKeyPressed(VK_LSHIFT) && IsKeyPressed('R'))) && key_time_flag)
		{
			m_bShowFavorites = (m_bShowFavorites ? false : true);
			m_CurrentGame = FindNearestGame(m_SelectedGame);
			g_UpdateList = true;
		}
		else if ((IsKeyPressed(VK_F8) || (IsKeyPressed(VK_LSHIFT) && IsKeyPressed('D'))) && key_time_flag)
		{
			if (m_SelectedGame != NULL) 
			{
				bool removed = false;
				for (int i = 0 ; i < m_FavoriteList.GetSize() ; i++) 
				{
					Game_t *fav = m_FavoriteList.GetAt(i);
					if (strcmp(fav->Rom, m_SelectedGame->Rom) == 0) 
					{
						m_SelectedGame->bFavorite = false;
						m_FavoriteList.Remove(i);
						SaveFavorites();
						removed = true;
						break;
					}
				}
				if (!removed)
				{
					Game_t *fav = m_SelectedGame;
					m_SelectedGame->bFavorite = true;
					m_FavoriteList.Add(fav);
					SaveFavorites();
				}
				g_UpdateList = true;
			}
		}
		if (IsKeyPressed(VK_TAB) && key_time_flag) {
			if (n > 1) {
				m_CurrentGame = rand()%(n - 1);
				g_UpdateList = true;
			}
		}
		if (m_bClick) {
			if (!left_down) {
				m_bClick = false;
			}
		}
		else {
			if (left_down || (IsStartKeyPressed() && key_time_flag)) {
				m_bClick = true;
				m_bLaunch = true;
			}
		}
	}

date_and_time:
	time_t t;
	time(&t);
	struct tm *gmt=localtime(&t);
	char buf[64];
	static char last_time_buf[64];
	strftime(buf,256,"%I:%M %p",gmt);
	if (strcmp(buf,last_time_buf) != 0) {
		strcpy(last_time_buf,buf);
	}
	TCHAR time_w[64];
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,buf,-1,time_w,64);
	PrintText(m_Width - 140,20,1,D3DXCOLOR(0.5f,0.5f,0.5f,0.5f),L"%s",time_w);
	strftime(buf,256,"%A %B %d, %Y",gmt);
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,buf,-1,time_w,64);
	PrintText(10,20,1,D3DXCOLOR(0.5f,0.5f,0.5f,0.5f),L"%s",time_w);

	SetMousePos(m_Width/2,m_Height/2);
}

void
CMamePlayer::LoadFavorites()
{
	FILE *fp=NULL;

	fopen_s(&fp,"favorites.dat","rb");
	if (fp != NULL) 
	{
		//	clear out the favorites list
		m_FavoriteList.RemoveAll();
		while (!feof(fp)) 
		{
			char fav_list[ROMN_SIZE];
			ZeroMemory(&fav_list, ROMN_SIZE);
			fread(&fav_list, ROMN_SIZE, 1, fp);
			for (int i = 0; i < m_GameList.GetSize(); i++)
			{
				Game_t *game = m_GameList.GetAt(i);
				if (strcmp(game->Rom, fav_list) == 0)
				{
					m_FavoriteList.Add(game);
					game->bFavorite = true;
					break;
				}
			}
		}
		fclose(fp);
		//	show favorite games
		ShowFavorites();
	}
}

void
CMamePlayer::SaveFavorites()
{
	FILE *fp=NULL;

	fopen_s(&fp,"favorites.dat","wb");
	if (fp != NULL)
	{
		for (int i=0 ; i < m_FavoriteList.GetSize() ; i++)
		{
			Game_t *fav=m_FavoriteList.GetAt(i);
			fwrite(&fav->Rom, ROMN_SIZE, 1, fp);
		}
		fclose(fp);
	}
}

void
CMamePlayer::ShowAllGames()
{
	for (int i=0 ; i < m_GameList.GetSize() ; i++)
	{
		Game_t *game=m_GameList.GetAt(i);
		game->bVisible=true;
	}
}

void
CMamePlayer::ShowFavorites()
{
	m_bShowFavorites = true;
}

void
CMamePlayer::ParseXml()
{
	CGameXml *xml=new CGameXml();
	xml->Load("list.xml");
	if (xml->FindNode("mame")) {
		LPCSTR vers=xml->GetValue("build");
		float v=(float)atof(vers);
		if (v >= 0.112) {
			while (xml->FindNode("game")) {
				Game_t *game=new Game_t;
				ZeroMemory(game,sizeof(Game_t));
				game->bVisible=false;
				LPCSTR rom=xml->GetValue("name");
				if (rom != NULL) {
					strcpy_s(game->Rom,ROMN_SIZE,rom);
				}
				LPCSTR clone=xml->GetValue("cloneof");
				if (clone != NULL) {
					game->bClone=true;
				}
				LPCSTR desc=xml->GetValue("description");
				if (desc != NULL) {
					char tmp[DESC_SIZE];
					strcpy_s(tmp,DESC_SIZE,desc);
					unsigned int i = 0;
					int n = 0;
					while (i < strlen(tmp))
					{
						if (i + 4 < strlen(tmp) && tmp[i] == '&' && tmp[i + 1] == 'a' && tmp[i + 2] == 'm' && tmp[i + 3] == 'p' && tmp[i + 4] == ';')
						{
							game->Desc[n++] = '&';
							i += 4;
						}
						else
						{
							game->Desc[n++] = tmp[i];
						}
						i++;
					}
				}
				LPCSTR year=xml->GetValue("year");
				if (year != NULL) {
					strcpy_s(game->Year,YEAR_SIZE,year);
				}
				LPCSTR manu=xml->GetValue("manufacturer");
				if (manu != NULL) {
					strcpy_s(game->Manu,MANU_SIZE,manu);
				}
				ParseXmlInsertGame(game);
			}
		}
	}
	delete xml;
}

void
CMamePlayer::ParseXmlInsertGame(Game_t *game)
{
	for (int i=0 ; i < m_GameList.GetSize() ; i++) {
		Game_t *g=m_GameList.GetAt(i);
		if (strcmp(game->Desc,g->Desc) < 0) {
			m_GameList.Insert(i,game);
			return;
		}
	}
	m_GameList.Add(game);
}

void
CMamePlayer::LaunchGame(Game_t *game)
{
	STARTUPINFO startup_info;
	ZeroMemory(&startup_info,sizeof(STARTUPINFO));
	startup_info.cb=sizeof(STARTUPINFO);
	startup_info.dwFlags=STARTF_USESHOWWINDOW;
	startup_info.wShowWindow=SW_MINIMIZE;
	PROCESS_INFORMATION process_info;
	ZeroMemory(&process_info,sizeof(PROCESS_INFORMATION));

//	float aspect=float(m_Width)/float(m_Height);

	TCHAR rom_w[ROMN_SIZE];
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,game->Rom,-1,rom_w,ROMN_SIZE);
	TCHAR cmd_line[MAX_PATH];
//	StringCbPrintf(cmd_line,MAX_PATH,L"%s -direct3d -noswitchres -triplebuffer -skip_gameinfo -nobezel -nobackdrop -mouse -joystick -ctrlr mame",game->Rom);
	StringCbPrintf(cmd_line,MAX_PATH,L" %s -skip_gameinfo -nobezel -nobackdrop -mouse -ctrlr mame",rom_w);
	if (CreateProcess(L"mame.exe",cmd_line,NULL,NULL,FALSE,0,NULL,NULL,&startup_info,&process_info)) {
		WaitForSingleObject(process_info.hProcess,INFINITE);
		CloseHandle(process_info.hProcess);
		CloseHandle(process_info.hThread);
	}
}

CGameApp *
SpawnGameApp()
{
	CMamePlayer *sample_app=new CMamePlayer;
	return(sample_app);
}
