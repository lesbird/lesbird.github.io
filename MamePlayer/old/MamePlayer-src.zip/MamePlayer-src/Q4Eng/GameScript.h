#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "lualib.h"
#include "lauxlib.h"

#ifdef __cplusplus
}
#endif

#ifdef _DEBUG
#pragma comment(lib,"lua-dbg.lib")
#else
#pragma comment(lib,"lua.lib")
#endif

class CGameScript
{
public:
	CGameScript(void);
	virtual ~CGameScript(void);

	virtual void	Init();
	virtual int		Exec(char *script_code,int script_size);

public:
	lua_State *		m_LuaState;
};
