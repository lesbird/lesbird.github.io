#include "DXUT.h"
#include "DXUTSettingsDlg.h"
#include "SDKmisc.h"
#include "GameApp.h"
#include "GameLight.h"
#include "GameMesh.h"
/*
#include "GamePhysics.h"
#include "GameScript.h"
*/
#include "GameSprite.h"

#define	MAX_TEXT_LINES		200

typedef struct TextLine_s
{
	int			x;
	int			y;
	int			font;
	D3DXCOLOR	color;
	WCHAR		text[256];
} TextLine_t;

static
TextLine_t		TextLine[MAX_TEXT_LINES];
static
int				TextCount;

CGameApp *		g_GameApp;

extern
CD3DSettingsDlg	g_SettingsDlg;          // Device settings dialog

//

CGameApp::CGameApp(void)
{
	m_bBumpMap=true;
	m_bDetailMap=true;
	m_bReflectionMap=true;
	m_bSpecularMap=true;

	m_bCameraOverride=false;
	m_bCursorVisible=true;

	m_Char=0;

	m_MouseX=0;
	m_MouseY=0;
	m_MouseDeltaX=0;
	m_MouseDeltaY=0;
	m_MouseEventX=0;
	m_MouseEventY=0;
	m_MouseWheelDelta=0;

	m_Aspect=800.0f/600.0f;
	m_Far=100000;
	m_Fov=D3DX_PI/4;
	m_Near=10;

	m_Height=800;
	m_Width=600;

	m_CamPos=D3DXVECTOR3(0,0,0);
	m_CamRot=D3DXVECTOR3(0,0,0);
	m_CamSpd=D3DXVECTOR3(0,0,0);

	D3DXMatrixIdentity(&m_CamProjMatrix);
	D3DXMatrixIdentity(&m_CamViewMatrix);

	for (int f=0 ; f < MAX_FONTS ; f++) {
		m_Font[f]=NULL;
	}

	m_FontSprite=NULL;

	g_GameApp=this;
}

CGameApp::~CGameApp(void)
{
	g_GameApp=NULL;
}

bool
CGameApp::MsgProc(HWND hWnd,UINT msg,WPARAM wparam,LPARAM lparam)
{
/*
	int mouse_x=(short)LOWORD(lparam);
	int mouse_y=(short)HIWORD(lparam);
	m_MouseDeltaX=m_MouseX-mouse_x;
	m_MouseDeltaY=m_MouseY-mouse_y;
	m_MouseX=mouse_x;
	m_MouseY=mouse_y;
	switch (msg) {
	case WM_LBUTTONDOWN:
		m_bMouseButtonL=true;
		return(TRUE);
		break;
	case WM_LBUTTONUP:
		m_bMouseButtonL=false;
		return(TRUE);
		break;
	case WM_RBUTTONDOWN:
		m_bMouseButtonR=true;
		return(TRUE);
		break;
	case WM_RBUTTONUP:
		m_bMouseButtonR=false;
		return(TRUE);
		break;
	case WM_MBUTTONDOWN:
		m_bMouseButtonM=true;
		return(TRUE);
		break;
	case WM_MBUTTONUP:
		m_bMouseButtonM=false;
		return(TRUE);
		break;
	}
*/
	return(FALSE);
}

void
CGameApp::MouseEvent(bool left_button,bool right_button,bool middle_button,int mouse_wheel_delta,int x,int y)
{
	m_MouseEventX=x;
	m_MouseEventY=y;
	m_MouseWheelDelta=mouse_wheel_delta;
}

void
CGameApp::SetMousePos(int x,int y)
{
	SetCursorPos(x,y);
	m_MouseX=x;
	m_MouseY=y;
}

void
CGameApp::ShowMouseCursor(bool vis)
{
	if (vis) {
		if (!m_bCursorVisible) {
			ShowCursor(TRUE);
		}
	}
	else {
		if (m_bCursorVisible) {
			ShowCursor(FALSE);
		}
	}
	m_bCursorVisible=vis;
}

void
CGameApp::KeyboardEvent(UINT c,bool key_down,bool alt_down)
{
	if (key_down) {
		m_Char=(char)c;
	}
}

bool
CGameApp::IsKeyPressed(int key)
{
	if (DXUTIsKeyDown((BYTE)key)) {
		return(true);
	}
	return(false);
}

/*
void WINAPI
CGameApp::StaticFill3DWrapper(D3DXVECTOR4 *o,const D3DXVECTOR3 *tex_coord,const D3DXVECTOR3 *tex_size,LPVOID data)
{
	D3DXVECTOR3 n;
	D3DXVec3Normalize(&n,tex_coord);
	n/=2;
	n+=D3DXVECTOR3(0.5f,0.5f,0.5f);
	*o=D3DXVECTOR4(n.x,n.y,n.z,1);
}
*/

void
CGameApp::InitProjection(float fov,float near_plane,float far_plane,int width,int height)
{
	m_Aspect=float(width)/float(height);
	m_Far=far_plane;
	m_Near=near_plane;
	m_Fov=fov;
	m_Width=width;
	m_Height=height;
	D3DXMatrixPerspectiveFovLH(&m_CamProjMatrix,m_Fov,m_Aspect,m_Near,m_Far);
}

void
CGameApp::InitRenderStates(IDirect3DDevice9 *d3dDevice)
{
	d3dDevice->SetRenderState(D3DRS_LIGHTING,TRUE);
	d3dDevice->SetRenderState(D3DRS_SPECULARENABLE,TRUE);
	d3dDevice->SetRenderState(D3DRS_SPECULARMATERIALSOURCE,D3DMCS_MATERIAL);
	d3dDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	d3dDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	for (int i=0 ; i < 8 ; i++) {
		d3dDevice->SetSamplerState(i,D3DSAMP_MINFILTER,D3DTEXF_LINEAR);
		d3dDevice->SetSamplerState(i,D3DSAMP_MAGFILTER,D3DTEXF_LINEAR);
		d3dDevice->SetSamplerState(i,D3DSAMP_MIPFILTER,D3DTEXF_LINEAR);
	}
}

void
CGameApp::Init(IDirect3DDevice9 *d3dDevice)
{
	remove("debug.txt");

//	GameInitPhysics();

	InitRenderStates(d3dDevice);

	D3DXCreateFont(d3dDevice,15,0,FW_NORMAL,1,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,L"Courier New",&m_Font[0]);
	D3DXCreateFont(d3dDevice,30,0,FW_BOLD,1,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,L"Courier New",&m_Font[1]);
	D3DXCreateSprite(d3dDevice,&m_FontSprite);
/*
	UINT mip_levels=0,size=128;
	D3DFORMAT format=D3DFMT_A8R8G8B8;
	if (D3DXCheckCubeTextureRequirements(d3dDevice,&size,&mip_levels,0,&format,D3DPOOL_MANAGED) == D3D_OK) {
		d3dDevice->CreateCubeTexture(size,0,0,format,D3DPOOL_MANAGED,&m_TextureNormalizer,NULL);
		D3DXFillCubeTexture(m_TextureNormalizer,StaticFill3DWrapper,NULL);
	}
*/
}

void
CGameApp::UnInit()
{
	while (GameObjectList.GetSize() > 0) {
		CGameObject *gobj=GameObjectList.GetAt(0);
		delete gobj;
	}
	while (LightObjectList.GetSize() > 0) {
		CGameLight *light=LightObjectList.GetAt(0);
		delete light;
	}
	for (int f=0 ; f < MAX_FONTS ; f++) {
		SAFE_RELEASE(m_Font[f]);
		m_Font[f]=NULL;
	}
	SAFE_RELEASE(m_FontSprite);
	m_FontSprite=NULL;

//	GameUnInitPhysics();
}

void
CGameApp::DeviceDestroy()
{
	for (int i=0 ; i < GameObjectList.GetSize() ; i++) {
		CGameObject *gobj=GameObjectList.GetAt(i);
		gobj->DeviceDestroy();
	}
}

void
CGameApp::DeviceLost()
{
	if (m_FontSprite != NULL) {
		m_FontSprite->OnLostDevice();
	}
	for (int f=0 ; f < MAX_FONTS ; f++) {
		if (m_Font[f] != NULL) {
			m_Font[f]->OnLostDevice();
		}
	}
	for (int i=0 ; i < GameObjectList.GetSize() ; i++) {
		CGameObject *gobj=GameObjectList.GetAt(i);
		gobj->DeviceLost();
	}
}

void
CGameApp::DeviceReset(IDirect3DDevice9 *d3dDevice)
{
	InitRenderStates(d3dDevice);

	if (m_FontSprite != NULL) {
		m_FontSprite->OnResetDevice();
	}
	for (int f=0 ; f < MAX_FONTS ; f++) {
		if (m_Font[f] != NULL) {
			m_Font[f]->OnResetDevice();
		}
	}
	for (int i=0 ; i < GameObjectList.GetSize() ; i++) {
		CGameObject *gobj=GameObjectList.GetAt(i);
		gobj->DeviceReset(d3dDevice);
	}
	InitProjection(m_Fov,m_Near,m_Far,m_Width,m_Height);
}

void
CGameApp::PrintText(int x,int y,int font,D3DXCOLOR color,const WCHAR *fmt,...)
{
	va_list	argptr;

	if (TextCount < MAX_TEXT_LINES) {
		TextLine_t *text_line=&TextLine[TextCount++];
		text_line->x=x;
		text_line->y=y;
		text_line->font=font;
		text_line->color=color;
		va_start(argptr,fmt);
		StringCbVPrintf(text_line->text,256,fmt,argptr);
		va_end(argptr);
	}
}

void
CGameApp::Tick(float delta_time)
{
	POINT point;

	GetCursorPos(&point);
	m_MouseDeltaX=point.x-m_MouseX;
	m_MouseDeltaY=point.y-m_MouseY;
	m_MouseX=point.x;
	m_MouseY=point.y;

	TextCount=0;
	for (int i=0 ; i < GameObjectList.GetSize() ; i++) {
		CGameObject *gobj=GameObjectList.GetAt(i);
		if (gobj != NULL) {
			gobj->Tick(delta_time);
		}
	}

//	g_GamePhysics->UpdatePhysics(delta_time);

	TickCamera(delta_time);

	if (IsKeyPressed(VK_F2)) {
		g_SettingsDlg.SetActive(!g_SettingsDlg.IsActive());
	}
//	PrintText(0,m_Height/2,D3DXCOLOR(1,1,1,1),L"Mouse: %d,%d",m_MouseX,m_MouseY);
}

void
CGameApp::TickCamera(float delta_time)
{
	if (m_bCameraOverride) {
		return;
	}
	D3DXQUATERNION quat;
	D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(m_CamRot.y),D3DXToRadian(m_CamRot.x),D3DXToRadian(m_CamRot.z));
	D3DXMATRIX mat;
	D3DXMatrixRotationQuaternion(&mat,&quat);
	D3DXVECTOR3 mov(0,0,0);
	D3DXVec3TransformNormal(&mov,&m_CamSpd,&mat);
	m_CamPos+=(mov*delta_time);
}

void
CGameApp::Render(IDirect3DDevice9 *d3dDevice)
{
	if (!m_bCameraOverride) {
		D3DXQUATERNION quat;
		D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(m_CamRot.y),D3DXToRadian(m_CamRot.x),D3DXToRadian(m_CamRot.z));
		D3DXMATRIX mat_rot;
		D3DXMatrixRotationQuaternion(&mat_rot,&quat);
		D3DXVECTOR3 view_dir(0,0,100);
		D3DXVec3TransformNormal(&view_dir,&view_dir,&mat_rot);
		D3DXVECTOR3 view_pos=m_CamPos+view_dir;
		D3DXVECTOR3 view_up(0,1,0);
		D3DXMatrixLookAtLH(&m_CamViewMatrix,&m_CamPos,&view_pos,&view_up);
	}
	d3dDevice->SetTransform(D3DTS_VIEW,&m_CamViewMatrix);
	d3dDevice->SetTransform(D3DTS_PROJECTION,&m_CamProjMatrix);

	for (int j=0 ; j < 8 ; j++) {
		d3dDevice->LightEnable(j,FALSE);
	}
	g_LightIndex=0;
	for (int l=0 ; l < LightObjectList.GetSize() ; l++) {
		CGameLight *light=LightObjectList.GetAt(l);
		if (light != NULL) {
			light->Render(d3dDevice);
		}
	}
	for (int i=0 ; i < MeshObjectList.GetSize() ; i++) {
		CGameMesh *gobj=MeshObjectList.GetAt(i);
		if (gobj != NULL) {
			gobj->Render(d3dDevice);
		}
	}
	if (SpriteObjectList.GetSize() > 0) {
		for (int s=0 ; s < SpriteObjectList.GetSize() ; s++) {
			CGameSprite *gobj=SpriteObjectList.GetAt(s);
			if (gobj != NULL) {
				gobj->Render(d3dDevice);
			}
		}
	}
}

void
CGameApp::RenderText()
{
	m_FontSprite->Begin(D3DXSPRITE_ALPHABLEND);
	for (int f=0 ; f < MAX_FONTS ; f++) {
		for (int i=0 ; i < TextCount ; i++) {
			TextLine_t *text_line=&TextLine[i];
			if (text_line->font == f) {
				RECT rect;
				SetRect(&rect,text_line->x,text_line->y,0,0);
				m_Font[f]->DrawText(m_FontSprite,text_line->text,-1,&rect,DT_NOCLIP,text_line->color);
			}
		}
	}
	m_FontSprite->End();
}

void
Log(char *fmt,...)
{
	va_list argptr;

	FILE *fp=fopen("debug.txt","a");
	if (fp != NULL) {
		va_start(argptr,fmt);
		vfprintf(fp,fmt,argptr);
		va_end(argptr);
		fclose(fp);
	}
}
