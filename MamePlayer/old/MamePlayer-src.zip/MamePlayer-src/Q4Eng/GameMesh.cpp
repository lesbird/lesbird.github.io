#include "DXUT.h"
#include "GameMesh.h"
#include "GameApp.h"
#include "GameLight.h"

#pragma warning(disable:4996)

typedef struct VERTEX
{
	D3DXVECTOR3	p;		//	pos
	D3DXVECTOR3	n;		//	normal
	DWORD		d;		//	diffuse color
	D3DXVECTOR2	t;		//	tex coord
	D3DXVECTOR3	bi;		//	bi-normal
	D3DXVECTOR3	ta;		//	tangent
} Vertex_t;

int				g_BumpMethod=0;

CGrowableArray<CGameMesh *>	MeshObjectList;

CGameMesh::CGameMesh(void)
{
	m_Type='MESH';

	m_bDot3Modulate=false;
	m_bDot3Tfactor=false;
	m_bHasTangents=false;

	m_File[0]=0;

	m_NumMaterials=0;

	m_BumpScale=D3DXVECTOR3(1,1,1);
	m_DetailScale=D3DXVECTOR3(1,1,1);
	m_TextureScale=D3DXVECTOR3(1,1,1);
	m_SpecularScale=D3DXVECTOR3(1,1,1);

	m_Material=NULL;
	m_Texture=NULL;
	m_TextureBump=NULL;
	m_TextureDetail=NULL;
	m_TextureOverride=NULL;
	m_TextureReflect=NULL;
	m_TextureSpecular=NULL;
	m_Mesh=NULL;
}

CGameMesh::~CGameMesh(void)
{
	Hide();
	for (DWORD i=0 ; i < m_NumMaterials ; i++) {
		SAFE_RELEASE(m_Texture[i]);
		SAFE_RELEASE(m_TextureBump[i]);
		SAFE_RELEASE(m_TextureReflect[i]);
		SAFE_RELEASE(m_TextureSpecular[i]);
	}
	SAFE_DELETE_ARRAY(m_Texture);
	SAFE_DELETE_ARRAY(m_TextureBump);
	SAFE_DELETE_ARRAY(m_TextureReflect);
	SAFE_DELETE_ARRAY(m_TextureSpecular);
	SAFE_DELETE_ARRAY(m_Material);
	SAFE_RELEASE(m_TextureDetail);
	SAFE_RELEASE(m_TextureOverride);
	SAFE_RELEASE(m_Mesh);
}

void
CGameMesh::Hide()
{
	int index=MeshObjectList.IndexOf(this);
	if (index != -1) {
		MeshObjectList.Remove(index);
		m_bIsVisible=false;
	}
}

void
CGameMesh::Show()
{
	int index=MeshObjectList.IndexOf(this);
	if (index == -1) {
		if (m_Mesh != NULL) {
			MeshObjectList.Add(this);
			m_bIsVisible=true;
		}
	}
}

void
CGameMesh::Load(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float bump_amplitude,bool save_to_text)
{
	TCHAR mesh_path[MAX_PATH],mesh_name[MAX_PATH];

	_wsplitpath_s(file_name,NULL,0,mesh_path,MAX_PATH,mesh_name,MAX_PATH,NULL,0);
	ID3DXBuffer *adjacency=NULL;
	ID3DXBuffer *materials=NULL;
	ID3DXBuffer *effects=NULL;
	StringCbCopy(m_File,sizeof(m_File),file_name);
	D3DXLoadMeshFromX(file_name,D3DXMESH_MANAGED,d3dDevice,&adjacency,&materials,&effects,&m_NumMaterials,&m_Mesh);
	if (m_Mesh != NULL) {
		if (save_to_text) {
			D3DXSaveMeshToX(file_name,m_Mesh,(DWORD *)adjacency->GetBufferPointer(),(D3DXMATERIAL *)materials->GetBufferPointer(),NULL,m_NumMaterials,D3DXF_FILEFORMAT_TEXT);
		}
		m_Mesh->OptimizeInplace(D3DXMESHOPT_COMPACT|D3DXMESHOPT_ATTRSORT,(DWORD *)adjacency->GetBufferPointer(),NULL,NULL,NULL);
		if (m_NumMaterials != 0) {
			D3DXMATERIAL *d3dx_material=(D3DXMATERIAL *)materials->GetBufferPointer();
			m_Material=new D3DMATERIAL9[m_NumMaterials];
			m_Texture=new LPDIRECT3DTEXTURE9[m_NumMaterials];
			m_TextureBump=new LPDIRECT3DTEXTURE9[m_NumMaterials];
			m_TextureReflect=new LPDIRECT3DTEXTURE9[m_NumMaterials];
			m_TextureSpecular=new LPDIRECT3DTEXTURE9[m_NumMaterials];
			for (DWORD i=0 ; i < m_NumMaterials ; i++) {
				m_Texture[i]=NULL;
				m_TextureBump[i]=NULL;
				m_TextureReflect[i]=NULL;
				m_TextureSpecular[i]=NULL;
				m_Material[i]=d3dx_material[i].MatD3D;
				m_Material[i].Specular=D3DXCOLOR(0,0,0,0);
				m_Material[i].Power=__max(m_Material[i].Power,25);
				if (d3dx_material[i].pTextureFilename != NULL && lstrlenA(d3dx_material[i].pTextureFilename) > 0) {
					CHAR tex_ext[_MAX_EXT],tex_name[_MAX_FNAME];
					_splitpath_s(d3dx_material[i].pTextureFilename,NULL,0,NULL,0,tex_name,_MAX_FNAME,tex_ext,_MAX_EXT);
					TCHAR tex_ext_w[MAX_PATH];
					mbstowcs(tex_ext_w,tex_ext,MAX_PATH);
					TCHAR tex_name_w[MAX_PATH];
					mbstowcs(tex_name_w,tex_name,MAX_PATH);
					TCHAR fname_w[MAX_PATH];
					StringCchPrintf(fname_w,MAX_PATH,L"%s%s%s",mesh_path,tex_name_w,tex_ext_w);
					if (GetFileAttributes(fname_w) != INVALID_FILE_ATTRIBUTES) {
						D3DXCreateTextureFromFileEx(d3dDevice,fname_w,D3DX_DEFAULT,D3DX_DEFAULT,0,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&m_Texture[i]);
					}
					StringCchPrintf(fname_w,MAX_PATH,L"%s%s_bumpmap%s",mesh_path,tex_name_w,tex_ext_w);
					if (GetFileAttributes(fname_w) != INVALID_FILE_ATTRIBUTES) {
						LoadBumpMap(d3dDevice,fname_w,bump_amplitude,i);
					}
					StringCchPrintf(fname_w,MAX_PATH,L"%s%s_reflectmap%s",mesh_path,tex_name_w,tex_ext_w);
					if (GetFileAttributes(fname_w) != INVALID_FILE_ATTRIBUTES) {
						LoadReflectionMap(d3dDevice,fname_w,i);
					}
					StringCchPrintf(fname_w,MAX_PATH,L"%s%s_detailmap%s",mesh_path,tex_name_w,tex_ext_w);
					if (GetFileAttributes(fname_w) != INVALID_FILE_ATTRIBUTES) {
						LoadDetailMap(d3dDevice,fname_w);
					}
					StringCchPrintf(fname_w,MAX_PATH,L"%s%s_specularmap%s",mesh_path,tex_name_w,tex_ext_w);
					if (GetFileAttributes(fname_w) != INVALID_FILE_ATTRIBUTES) {
						LoadSpecularMap(d3dDevice,fname_w,1,i);
					}
				}
			}
		}
	}
	SAFE_RELEASE(effects);
	SAFE_RELEASE(materials);
	SAFE_RELEASE(adjacency);
}

void
CGameMesh::ConvertHeightMap(IDirect3DDevice9 *d3dDevice,LPDIRECT3DTEXTURE9 height_map,float amplitude,int index)
{
	D3DSURFACE_DESC desc;
	height_map->GetLevelDesc(0,&desc);
	SAFE_RELEASE(m_TextureBump[index]);
	D3DXCreateTexture(d3dDevice,desc.Width,desc.Height,0,0,D3DFMT_A8R8G8B8,D3DPOOL_MANAGED,&m_TextureBump[index]);
	if (m_TextureBump[index] != NULL) {
		if (D3DXComputeNormalMap(m_TextureBump[index],height_map,NULL,0,D3DX_CHANNEL_RED,amplitude) == D3D_OK) {
			if (m_Mesh != NULL && !m_bHasTangents) {
				const D3DVERTEXELEMENT9 vertex_decl[] =
				{
					{ 0, 0,  D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
					{ 0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0 },
					{ 0, 24, D3DDECLTYPE_D3DCOLOR,D3DDECLMETHOD_DEFAULT,D3DDECLUSAGE_COLOR,    0 },
					{ 0, 28, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
					{ 0, 36, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BINORMAL, 0 },
					{ 0, 48, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TANGENT,  0 },
					D3DDECL_END()
				};
				ID3DXMesh *cloned_mesh=NULL;
				m_Mesh->CloneMesh(m_Mesh->GetOptions(),vertex_decl,d3dDevice,&cloned_mesh);

				if (cloned_mesh != NULL) {
					ID3DXMesh *mesh=NULL;
					if (D3DXComputeTangentFrameEx(cloned_mesh,D3DDECLUSAGE_TEXCOORD,0,D3DDECLUSAGE_TANGENT,0,D3DDECLUSAGE_BINORMAL,0,D3DDECLUSAGE_NORMAL,0,0,NULL,-1,0,-1,&mesh,NULL) == D3D_OK) {
						SAFE_RELEASE(cloned_mesh);
						SAFE_RELEASE(m_Mesh);
						m_Mesh=mesh;
					}
					else {
						SAFE_RELEASE(m_Mesh);
						m_Mesh=cloned_mesh;
					}
				}
				m_bHasTangents=true;
			}
		}
	}
}

void
CGameMesh::LoadBumpMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float amplitude,int index)
{
	if (m_Mesh != NULL) {
		LPDIRECT3DTEXTURE9 height_map;
		D3DXCreateTextureFromFile(d3dDevice,file_name,&height_map);
		if (height_map != NULL) {
			ConvertHeightMap(d3dDevice,height_map,amplitude,index);
			SAFE_RELEASE(height_map);
		}
	}
}

void
CGameMesh::LoadDetailMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float scale)
{
	if (m_Mesh != NULL) {
		SAFE_RELEASE(m_TextureDetail);
		D3DXCreateTextureFromFileEx(d3dDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&m_TextureDetail);
		m_DetailScale=D3DXVECTOR3(scale,scale,scale);
	}
}

void
CGameMesh::LoadTextureMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name)
{
	if (m_Mesh != NULL) {
		SAFE_RELEASE(m_TextureOverride);
		D3DXCreateTextureFromFileEx(d3dDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&m_TextureOverride);
	}
}

void
CGameMesh::LoadReflectionMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,int index)
{
	if (m_Mesh != NULL) {
		SAFE_RELEASE(m_TextureReflect[index]);
		D3DXCreateTextureFromFileEx(d3dDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&m_TextureReflect[index]);
	}
}

void
CGameMesh::LoadSpecularMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float scale,int index)
{
	if (m_Mesh != NULL) {
		SAFE_RELEASE(m_TextureSpecular[index]);
		D3DXCreateTextureFromFileEx(d3dDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_FILTER_LINEAR,D3DX_FILTER_LINEAR,0,NULL,NULL,&m_TextureSpecular[index]);
		m_SpecularScale=D3DXVECTOR3(scale,scale,scale);
	}
}

void
CGameMesh::SetTextureTransform(IDirect3DDevice9 *d3dDevice,DWORD stage,D3DXMATRIX *mat)
{
	D3DTRANSFORMSTATETYPE t;

	switch (stage) {
	default:
		t=D3DTS_TEXTURE0;
		break;
	case 1:
		t=D3DTS_TEXTURE1;
		break;
	case 2:
		t=D3DTS_TEXTURE2;
		break;
	case 3:
		t=D3DTS_TEXTURE3;
		break;
	case 4:
		t=D3DTS_TEXTURE4;
		break;
	case 5:
		t=D3DTS_TEXTURE5;
		break;
	case 6:
		t=D3DTS_TEXTURE6;
		break;
	case 7:
		t=D3DTS_TEXTURE7;
		break;
	}
	d3dDevice->SetTransform(t,mat);
	d3dDevice->SetTextureStageState(stage,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
}

DWORD
VectorToRGBA(D3DXVECTOR3 v)
{
	DWORD red=(DWORD)(127*v.x+128);
	DWORD grn=(DWORD)(127*v.y+128);
	DWORD blu=(DWORD)(127*v.z+128);
	DWORD d=(DWORD)(0xFF000000+(red<<16)+(grn<<8)+blu);
	return(d);
}

void
CGameMesh::ComputeLightVector()
{
	CGameLight *light=NULL;

	float closest_dx=FLT_MAX;
	for (int l=0 ; l < LightObjectList.GetSize() ; l++) {
		CGameLight *light_obj=LightObjectList.GetAt(l);
		if (light_obj->m_bIsVisible) {
			if (light_obj->m_Light.Type == D3DLIGHT_POINT) {
				D3DXVECTOR3 p=light_obj->m_Light.Position;
				D3DXVECTOR3 d=m_Pos-p;
				float dx=D3DXVec3LengthSq(&d);
				if (dx < closest_dx) {
					light=light_obj;
					closest_dx=dx;
				}
			}
		}
	}
	if (light == NULL) {
		light=LightObjectList.GetAt(0);
	}
	if (light != NULL) {
		//	per-object lighting
		if (m_bDot3Tfactor) {
			D3DXVECTOR3 light_dir;
			if (light->m_Light.Type == D3DLIGHT_POINT) {
				light_dir=m_Pos-light->m_Pos;
				D3DXVec3Normalize(&light_dir,&light_dir);
			}
			else {
				light_dir=light->m_Light.Direction;
			}
			DWORD tfactor=VectorToRGBA(light_dir);
			DXUTGetD3D9Device()->SetRenderState(D3DRS_TEXTUREFACTOR,tfactor);
		}
		//	per-vertex lighting
		else {
			D3DXVECTOR3 light_ms;
			if (light->m_Light.Type == D3DLIGHT_POINT) {
				D3DXVECTOR3 light_ws=light->m_Light.Position;
				D3DXMATRIX world_inv;
				D3DXMatrixInverse(&world_inv,NULL,&m_WorldMatrix);
				D3DXVec3TransformCoord(&light_ms,&light_ws,&world_inv);
			}
			Vertex_t *vert;
			if (m_Mesh->LockVertexBuffer(0,(LPVOID *)&vert) == D3D_OK) {
				for (DWORD i=0 ; i < m_Mesh->GetNumVertices() ; i++) {
					D3DXVECTOR3 light_dir;
					if (light->m_Light.Type == D3DLIGHT_POINT) {
						light_dir=light_ms-vert[i].p;
					}
					else {
						light_dir=D3DXVECTOR3(light->m_Light.Direction.x,light->m_Light.Direction.y,light->m_Light.Direction.z);
					}
					D3DXVec3Normalize(&light_dir,&light_dir);
					D3DXMATRIX inv_tang_mat(
						vert[i].ta.x,vert[i].bi.x,vert[i].n.x,0,
						vert[i].ta.y,vert[i].bi.y,vert[i].n.y,0,
						vert[i].ta.z,vert[i].bi.z,vert[i].n.z,0,
								   0,           0,          0,1);
					D3DXVECTOR3 light_dir_ts;
					D3DXVec3TransformNormal(&light_dir_ts,&light_dir,&inv_tang_mat);
					vert[i].d=VectorToRGBA(light_dir_ts);
				}
				m_Mesh->UnlockVertexBuffer();
			}
		}
	}
}

void
CGameMesh::Render(IDirect3DDevice9 *d3dDevice)
{
	CGameObject::Render(d3dDevice);
	{
		if (m_Scale != D3DXVECTOR3(1,1,1)) {
			d3dDevice->SetRenderState(D3DRS_NORMALIZENORMALS,TRUE);
		}
		else {
			d3dDevice->SetRenderState(D3DRS_NORMALIZENORMALS,FALSE);
		}
		d3dDevice->SetRenderState(D3DRS_DIFFUSEMATERIALSOURCE,D3DMCS_MATERIAL);

		if (g_BumpMethod == 0) {
			//	base texture (stage 0)
			d3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_MODULATE);
			d3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
			d3dDevice->SetTextureStageState(0,D3DTSS_COLORARG2,D3DTA_CURRENT);
			D3DXMATRIX tex_scale;
			D3DXMatrixScaling(&tex_scale,m_TextureScale.x,m_TextureScale.y,m_TextureScale.z);
			SetTextureTransform(d3dDevice,0,&tex_scale);
			if (g_GameApp->m_bBumpMap) {
				for (DWORD j=0 ; j < m_NumMaterials ; j++) {
					if (m_TextureBump[j] != NULL) {
						ComputeLightVector();
						break;
					}
				}
			}
			for (DWORD i=0 ; i < m_NumMaterials ; i++) {
				int stage=1;
				d3dDevice->SetMaterial(&m_Material[i]);
				//	detail map (stage 1)
				if (g_GameApp->m_bDetailMap && m_TextureDetail != NULL) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,0);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MULTIPLYADD);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
					d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
					D3DXMATRIX mat;
					D3DXMatrixScaling(&mat,m_DetailScale.x,m_DetailScale.y,m_DetailScale.z);
					SetTextureTransform(d3dDevice,stage,&mat);
					d3dDevice->SetTexture(stage,m_TextureDetail);
					stage++;
				}
				//	reflect texture (stage 2)
				if (g_GameApp->m_bReflectionMap && m_TextureReflect[i] != NULL) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MODULATE);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
					d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
					D3DXMATRIX mat;
					D3DXMatrixIdentity(&mat);
					SetTextureTransform(d3dDevice,stage,&mat);
					d3dDevice->SetTexture(stage,m_TextureReflect[i]);
					stage++;
				}
				//	specular texture (stage 3)
				if (g_GameApp->m_bSpecularMap && m_TextureSpecular[i] != NULL) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,0);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MULTIPLYADD);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
					d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
					D3DXMATRIX mat;
					D3DXMatrixScaling(&mat,m_SpecularScale.x,m_SpecularScale.y,m_SpecularScale.z);
					SetTextureTransform(d3dDevice,stage,&mat);
					d3dDevice->SetTexture(stage,m_TextureSpecular[i]);
					stage++;
				}
				//	dot3 bump texture (stage 4,5)
				if (g_GameApp->m_bBumpMap && m_TextureBump[i] != NULL) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,0);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_DOTPRODUCT3);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
					if (m_bDot3Tfactor) {
						d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_TFACTOR);
					}
					else {
						d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_DIFFUSE);
					}
					d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_TEMP);
					D3DXMATRIX mat;
					D3DXMatrixScaling(&mat,m_BumpScale.x,m_BumpScale.y,m_BumpScale.z);
					SetTextureTransform(d3dDevice,stage,&mat);
					d3dDevice->SetTexture(stage,m_TextureBump[i]);
					stage++;
					//	combiner
					if (m_bDot3Modulate) {
						d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MODULATE);
					}
					else {
						d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MULTIPLYADD);
					}
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_CURRENT);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_TEMP);
					d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
					d3dDevice->SetTexture(stage,NULL);
					stage++;
				}
				while (stage < 8) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_DISABLE);
					d3dDevice->SetTexture(stage,NULL);
					stage++;
				}
				LPDIRECT3DTEXTURE9 tex=NULL;
				if (m_TextureOverride != NULL) {
					tex=m_TextureOverride;
				}
				else {
					tex=m_Texture[i];
				}
				d3dDevice->SetTexture(0,tex);
				m_Mesh->DrawSubset(i);
			}
		}
		else if (g_BumpMethod == 1) {
			if (g_GameApp->m_bBumpMap) {
				for (DWORD j=0 ; j < m_NumMaterials ; j++) {
					if (m_TextureBump[j] != NULL) {
						ComputeLightVector();
						break;
					}
				}
			}
			for (DWORD i=0 ; i < m_NumMaterials ; i++) {
				int stage=0;
				d3dDevice->SetMaterial(&m_Material[i]);
				if (m_TextureBump[i] != NULL) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,0);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_DOTPRODUCT3);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_DIFFUSE);
					d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
					d3dDevice->SetTexture(stage,m_TextureBump[i]);
					stage++;
				}
				d3dDevice->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,0);
				d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_MODULATE);
				d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG1,D3DTA_TEXTURE);
				d3dDevice->SetTextureStageState(stage,D3DTSS_COLORARG2,D3DTA_CURRENT);
				d3dDevice->SetTextureStageState(stage,D3DTSS_RESULTARG,D3DTA_CURRENT);
				d3dDevice->SetTexture(stage,m_Texture[i]);
				stage++;
				while (stage < 8) {
					d3dDevice->SetTextureStageState(stage,D3DTSS_COLOROP,D3DTOP_DISABLE);
					d3dDevice->SetTexture(stage,NULL);
					stage++;
				}
				m_Mesh->DrawSubset(i);
			}
		}
	}
}
