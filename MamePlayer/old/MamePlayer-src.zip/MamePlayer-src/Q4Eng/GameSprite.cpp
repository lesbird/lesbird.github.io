#include "DXUT.h"
#include "GameSprite.h"

CGrowableArray<CGameSprite *>	SpriteObjectList;

CGameSprite::CGameSprite(void)
{
	m_Type='SPRI';

	m_TextureFile[0]=0;

	m_Color=D3DCOLOR_RGBA(255,255,255,255);

	m_Width=0;
	m_Height=0;

	m_Texture=NULL;
	m_Sprite=NULL;
}

CGameSprite::~CGameSprite(void)
{
	Hide();	//	remove from the SpriteObjectList
	SAFE_RELEASE(m_Texture);
	SAFE_RELEASE(m_Sprite);
}

void
CGameSprite::Init(IDirect3DDevice9 *d3dDevice)
{
	if (m_Sprite == NULL) {
		D3DXCreateSprite(d3dDevice,&m_Sprite);
	}
}

void
CGameSprite::DeviceDestroy()
{
}

void
CGameSprite::DeviceLost()
{
	if (m_Sprite != NULL) {
		m_Sprite->OnLostDevice();
	}
}

void
CGameSprite::DeviceReset(IDirect3DDevice9 *d3dDevice)
{
	if (m_Sprite != NULL) {
		m_Sprite->OnResetDevice();
	}
}

void
CGameSprite::Hide()
{
	int index=SpriteObjectList.IndexOf(this);
	if (index != -1) {
		SpriteObjectList.Remove(index);
		m_bIsVisible = false;
	}
}

void
CGameSprite::Show()
{
	int index=SpriteObjectList.IndexOf(this);
	if (index == -1) {
		if (m_Sprite != NULL) {
			SpriteObjectList.Add(this);
			m_bIsVisible = true;
		}
	}
}

void
CGameSprite::ShowFirst()
{
	Hide();
	if (m_Sprite != NULL) {
		SpriteObjectList.Insert(0,this);
	}
}

void
CGameSprite::Load(IDirect3DDevice9 *d3dDevice,TCHAR *file_name)
{
	if (file_name != NULL) {
		LoadTexture(d3dDevice,file_name);
	}
	Init(d3dDevice);
}

void
CGameSprite::LoadTexture(IDirect3DDevice9 *d3dDevice,TCHAR *file_name)
{
	if (file_name == NULL || file_name[0] == 0) {
		return;
	}
	if (m_TextureFile[0] != 0) {
		if (wcscmp(m_TextureFile,file_name) == 0) {
			return;
		}
	}
	SAFE_RELEASE(m_Texture);
	m_TextureFile[0]=0;
	D3DXCreateTextureFromFileEx(d3dDevice,file_name,D3DX_DEFAULT,D3DX_DEFAULT,1,0,D3DFMT_UNKNOWN,D3DPOOL_MANAGED,D3DX_DEFAULT,D3DX_DEFAULT,0,NULL,NULL,&m_Texture);
	if (m_Texture != NULL) {
		LoadTexture(m_Texture);
		StringCbCopy(m_TextureFile,MAX_PATH,file_name);
	}
}

void
CGameSprite::LoadTexture(IDirect3DTexture9 *texture)
{
//	SAFE_RELEASE(m_Texture);
	m_Texture=texture;
	if (texture == NULL) {
		m_Width=0;
		m_Height=0;
	}
	else {
		D3DSURFACE_DESC desc;
		m_Texture->GetLevelDesc(0,&desc);
		m_Width=float(desc.Width);
		m_Height=float(desc.Height);
		m_TextureFile[0]=0;
	}
}

void
CGameSprite::Render(IDirect3DDevice9 *d3dDevice)
{
	if (m_Texture == NULL || m_Width == 0 || m_Height == 0)
	{
		return;
	}
	D3DXQUATERNION quat;
	D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(m_Rot.y),D3DXToRadian(m_Rot.x),D3DXToRadian(m_Rot.z));
	D3DXMatrixTransformation(&m_WorldMatrix,NULL,NULL,&m_Scale,NULL,&quat,&m_Pos);
	m_Sprite->SetTransform(&m_WorldMatrix);
	D3DXVECTOR3 center(m_Width/2,m_Height/2,0);
	m_Sprite->Begin(D3DXSPRITE_ALPHABLEND);
	m_Sprite->Draw(m_Texture,NULL,&center,NULL,m_Color);
	m_Sprite->End();
}
