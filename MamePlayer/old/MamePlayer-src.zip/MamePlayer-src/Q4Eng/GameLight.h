#pragma once
#include "GameObject.h"

class CGameLight :
	public CGameObject
{
public:
	CGameLight(void);
	virtual ~CGameLight(void);

	virtual void		Hide();
	virtual void		Show();

	virtual void		SetColorAmbient(D3DXCOLOR color_rgba);
	virtual void		SetColorDiffuse(D3DXCOLOR color_rgba);
	virtual void		SetColorSpecular(D3DXCOLOR color_rgba);
	virtual void		SetDir(D3DXVECTOR3 dir);
	virtual void		SetPos(D3DXVECTOR3 pos);
	virtual void		SetPointParams(float range,float atten_0,float atten_1,float atten_2);
	virtual void		SetSpotParams(float falloff,float theta,float phi);
	virtual void		SetTypeDir();
	virtual void		SetTypePoint();
	virtual void		SetTypeSpot();

	virtual void		Render(IDirect3DDevice9 *d3dDevice);

public:
	DWORD				m_LightIndex;

	D3DLIGHT9			m_Light;
};

extern
DWORD					g_LightIndex;

extern
CGrowableArray<CGameLight *>	LightObjectList;
