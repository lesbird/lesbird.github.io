#include "dxut.h"
#include "GameMesh.h"
#include "GameVehicle.h"
#include "Vitamina.hpp"
#include "CollisionDetection.hpp"

#include "GameApp.h"

using namespace Vitamina;

#pragma comment(lib,"FastCarVc8.lib")

CGameVehicle::CGameVehicle()
{
	m_Offset=D3DXVECTOR3(0,0,0);
}

CGameVehicle::~CGameVehicle()
{
}

/*
static
void
StaticCollisionDetection(CFastCar *fast_car)
{
	CPlane plane={{0,1,0},0};
	CDisk disk;
	for (int w=0 ; w < MAX_WHEELS ; w++) {
		CWheelContact &c=fast_car->contact[w][0];
		disk.radius=fast_car->GetWheelRadius(w);
		fast_car->GetWheelPosition(disk.center,w);
		fast_car->GetWheelAxle(disk.normal,w);
		bool not_parallel=DiskPlaneCollision(&c.penetration,c.point,disk,plane);
		if (not_parallel && c.penetration > 0) {
			fast_car->number_of_contacts=1;
			c.normal[0]=plane.normal[0];
			c.normal[1]=plane.normal[1];
			c.normal[2]=plane.normal[2];
		}
		else {
			fast_car->number_of_contacts=0;
		}
	}
}
*/

void
CGameVehicle::BuildCar(float w,float h,float l,float mass_kg,float wheel_r,float wheel_w,float wheel_mass_kg,TCHAR *body_file,TCHAR *wheel_file)
{
	m_FastCar=new CGearBox;
	m_FastCar->collision_detection_callback=PlaneWheelCollisionDetectionCallback;
	float chassis_toi[3];
	CuboidMomentsOfInertia(chassis_toi,mass_kg,w,h,l);
	float wheel_toi[3];
	CylinderMomentsOfInertia(wheel_toi,wheel_mass_kg,wheel_r,wheel_w);
	float wheel_pos_f[3]={w,-h,l};
	float wheel_pos_r[3]={-w,-h,l};
	float gravity[3]={0,-9.8f,0};
	m_FastCar->Build(gravity,wheel_pos_f,wheel_pos_r,wheel_r,wheel_r,chassis_toi,wheel_toi,wheel_toi,mass_kg,wheel_mass_kg,wheel_mass_kg);
	m_FastCar->suspension_stiffness[0]*=0.4f;
	m_FastCar->suspension_stiffness[1]*=0.4f;
	m_FastCar->suspension_stiffness[2]*=0.4f;
	m_FastCar->suspension_stiffness[3]*=0.4f;
	m_FastCar->SuggestedSuspensionDamping(m_FastCar->suspension_damping);
	m_FastCar->static_friction[0]=0.8f;
	m_FastCar->static_friction[1]=0.8f;
	m_FastCar->static_friction[2]=0.8f;
	m_FastCar->static_friction[3]=0.8f;

	m_TimeStep=0.8f*m_FastCar->SuggestedTimeStep();
	float dyn_v=m_FastCar->SuggestedDynamicVelocity(m_TimeStep);
	if (dyn_v != -1) {
		m_FastCar->dynamic_velocity=dyn_v;
	}
	m_FastCar->SetupGearBox(NULL,NULL,0,150,10,5,1,wheel_r,200,1000,0,1,1,0,0);
	m_FastCar->SetOrientation(front_to_z_top_to_y);

//	m_TimeStep*=3;
	m_TimeStep/=3;

	Load(DXUTGetD3D9Device(),body_file,25);
	m_bOverrideRender=true;
	for (int w=0 ; w < MAX_WHEELS ; w++) {
		m_Wheel[w]=new CGameMesh;
		m_Wheel[w]->Load(DXUTGetD3D9Device(),wheel_file,25);
		m_Wheel[w]->m_bOverrideRender=true;
	}
}

void
CGameVehicle::Tick(float delta_time)
{
	CGameMesh::Tick(delta_time);

	m_FastCar->EulerEvolve(m_TimeStep);
}

void
CGameVehicle::Render(IDirect3DDevice9 *d3dDevice)
{
	m_FastCar->GetPosition(m_Pos);
	m_FastCar->GetTransform(m_WorldMatrix);
	D3DXVec3TransformNormal(&m_Offset,&m_Offset,&m_WorldMatrix);
	D3DXMATRIX offset_mat;
	D3DXMatrixTranslation(&offset_mat,m_Offset.x,m_Offset.y,m_Offset.z);
	D3DXMatrixMultiply(&m_WorldMatrix,&m_WorldMatrix,&offset_mat);
	d3dDevice->SetTransform(D3DTS_WORLD,&m_WorldMatrix);
	CGameMesh::Render(d3dDevice);

	for (int w=0 ; w < MAX_WHEELS ; w++) {
		switch (w) {
		case 0:
		case 1:
			m_FastCar->GetWheelTransform(m_Wheel[w]->m_WorldMatrix,w);
			break;
		case 2:
		case 3:
			m_FastCar->GetWheelTransformSymmetrical(m_Wheel[w]->m_WorldMatrix,w);
			break;
		}
		d3dDevice->SetTransform(D3DTS_WORLD,&m_Wheel[w]->m_WorldMatrix);
		m_Wheel[w]->Render(d3dDevice);
	}
}
