// GamePhysics.h: declarations for physics functions
//
//////////////////////////////////////////////////////////////////////

#pragma once
/*
#include "ode/ode.h"

#pragma comment(lib,"OdeVc7.lib")

typedef struct HitRayCollision
{
	float			hit_x;
	float			hit_y;
	float			hit_z;
	float			nor_x;
	float			nor_y;
	float			nor_z;
	float			dist;
	void *			object;
} HitRayCollision_t;

#define	MAX_GEOMS			4

typedef struct PhysicsObject
{
	dBodyID			Body;
	dGeomID			Geom[MAX_GEOMS];
	dJointID		Joint;
} PhysicsObject_t;

typedef CGrowableArray<PhysicsObject_t *>	PhysicsObjectList_t;

class CGamePhysics
{
public:
	CGamePhysics(void);
	virtual ~CGamePhysics(void);

	virtual void				InitPhysics();
	virtual void				UnInitPhysics();

	virtual void				GetGravity(float &x,float &y,float &z);
	virtual void				SetGravity(float x,float y,float z);

	virtual PhysicsObject_t *	CreatePhysicsObject();
	virtual void				DeletePhysicsObject(PhysicsObject_t *phys_obj);

	virtual PhysicsObject_t *	AddBoxCollision(float width,float height,float depth,float mass_kg,bool is_static=false);
	virtual PhysicsObject_t *	AddSphereCollision(float radius,float mass_kg,bool is_static=false);
	virtual PhysicsObject_t *	AddCylinderCollision(float radius,float height,float mass_kg,bool is_static=false);
	virtual PhysicsObject_t *	AddCompoundCollision(unsigned int col_type,PhysicsObject_t *phys_obj,float offset_x,float offset_y,float offset_z,float size_x,float size_y,float size_z,float mass_kg,bool is_static=false);
	virtual PhysicsObject_t *	AddTriMeshCollision(float *vertex_data,int num_vertices,int *index_data,int num_indices);

	virtual void				MakeStatic(PhysicsObject_t *phys_obj);
	virtual void				SetCollisionBits(PhysicsObject_t *phys_obj,unsigned int cat_bits,unsigned int col_bits);
	virtual void				SetData(PhysicsObject_t *phys_obj,void *data);
	virtual void				ZeroForces(PhysicsObject_t *phys_obj);

	virtual void				Disable(PhysicsObject_t *phys_obj);
	virtual void				Enable(PhysicsObject_t *phys_obj);
	virtual void				EnableAll();

	virtual void				SetPosition(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				GetPosition(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
	virtual void				SetQuaternion(PhysicsObject_t *phys_obj,float x,float y,float z,float w);
	virtual void				GetQuaternion(PhysicsObject_t *phys_obj,float &x,float &y,float &z,float &w);
	virtual void				AddForce(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				AddForceRel(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				SetForce(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				GetForce(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
	virtual void				AddTorque(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				AddTorqueRel(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				SetTorque(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				GetTorque(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
	virtual void				SetVelocity(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				GetVelocity(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
	virtual void				SetVelocityAng(PhysicsObject_t *phys_obj,float x,float y,float z);
	virtual void				GetVelocityAng(PhysicsObject_t *phys_obj,float &x,float &y,float &z);

	virtual HitRayCollision_t *	HitRay(dGeomID geom_id,float x,float y,float z,float dir_x,float dir_y,float dir_z,float len,bool first_hit=false);

	virtual void				UpdateWorld(float delta_time);
	virtual void				UpdatePhysics(float delta_time);
	virtual void				UpdatePositions();

public:
	dJointGroupID				m_CollisionJointGroup;
	dSpaceID					m_Space;
	dWorldID					m_World;
};
*/

/*
extern
CGamePhysics *					GameInitPhysics();
extern
void							GameUnInitPhysics();

extern
PhysicsObjectList_t				PhysicsObjectList;

extern
CGamePhysics *					g_GamePhysics;
*/
