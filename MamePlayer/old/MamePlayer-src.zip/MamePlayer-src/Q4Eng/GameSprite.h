#pragma once
#include "gameobject.h"

class CGameSprite :
	public CGameObject
{
public:
	CGameSprite(void);
	virtual ~CGameSprite(void);

	virtual void		Init(IDirect3DDevice9 *d3dDevice);

	virtual void		DeviceDestroy();
	virtual void		DeviceLost();
	virtual void		DeviceReset(IDirect3DDevice9 *d3dDevice);

	virtual void		Hide();
	virtual void		Show();
	virtual void		ShowFirst();

	virtual void		Load(IDirect3DDevice9 *d3dDevice,TCHAR *file_name);
	virtual void		LoadTexture(IDirect3DDevice9 *d3dDevice,TCHAR *file_name);
	virtual void		LoadTexture(IDirect3DTexture9 *texture);

	virtual void		Render(IDirect3DDevice9 *d3dDevice);

public:
	TCHAR				m_TextureFile[MAX_PATH];

	float				m_Width;
	float				m_Height;

	D3DCOLOR			m_Color;

	IDirect3DTexture9 *	m_Texture;
	ID3DXSprite *		m_Sprite;
};

extern
CGrowableArray<CGameSprite *>	SpriteObjectList;
