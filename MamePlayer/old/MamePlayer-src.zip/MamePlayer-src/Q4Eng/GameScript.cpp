#include "DXUT.h"
#include "GameScript.h"
#include "GameApp.h"
#include "GameMesh.h"
#include "GamePhysics.h"

#pragma warning(disable:4244)

#define	GAM_LIBNAME	"gam"
#define	INP_LIBNAME	"inp"
#define	MSH_LIBNAME	"msh"
#define	OBJ_LIBNAME	"obj"
#define	PAR_LIBNAME	"par"
#define	PHY_LIBNAME	"phy"
#define	SND_LIBNAME	"snd"
#define	SPR_LIBNAME	"spr"
#define	VEC_LIBNAME	"vec"

//
//
//

CGameScript::CGameScript()
{
	m_LuaState=lua_open();
	if (m_LuaState != NULL) {
		Init();
	}
}

CGameScript::~CGameScript()
{
	if (m_LuaState != NULL) {
		lua_close(m_LuaState);
		m_LuaState=NULL;
	}
}

static
void
GameScriptLuaError(lua_State *lua_state,int status)
{
	while (lua_isstring(lua_state,-1)) {
		const char *err_code=lua_tolstring(lua_state,-1,NULL);
		if (err_code != NULL) {
			Log("GAMESCRIPT ERROR: %s",err_code);
		}
		lua_pop(lua_state,1);
	}
}

//	GameObject functions

static
int
GameScriptGamFindObj(lua_State *l)
{
	const char *tag=lua_tolstring(l,1,NULL);
	if (tag != NULL) {
		lua_pushlightuserdata(l,CGameObject::FindTag(tag));
		return(1);
	}
	return(0);
}

static
int
GameScriptGamFindNextObj(lua_State *l)
{
	const char *tag=lua_tolstring(l,1,NULL);
	if (tag != NULL) {
		CGameObject *gobj=(CGameObject *)lua_touserdata(l,2);
		if (gobj != NULL) {
			lua_pushlightuserdata(l,CGameObject::FindNextTag(tag,gobj));
			return(1);
		}
	}
	return(0);
}

static
int
GameScriptGamSetPos(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_Pos=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptGamSetRot(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_Rot=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptGamSetScale(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_Scale=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptGamSetTag(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->SetTag(lua_tolstring(l,2,NULL));
	return(0);
}

static
int
GameScriptGamShow(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	if (lua_toboolean(l,2)) {
		gobj->Show();
	}
	else {
		gobj->Hide();
	}
	return(0);
}

static const
luaL_Reg GamLib[]={
	{"find",GameScriptGamFindObj},
	{"findNext",GameScriptGamFindNextObj},
	{"setPos",GameScriptGamSetPos},
	{"setRot",GameScriptGamSetRot},
	{"setScale",GameScriptGamSetScale},
	{"setTag",GameScriptGamSetTag},
	{"show",GameScriptGamShow},
	{NULL,NULL}
};

//	Mesh functions

static
int
GameScriptMeshLoad(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	float bump_amplitude=lua_tonumber(l,2);
	if (file_name != NULL && strlen(file_name) > 0) {
		size_t num;
		TCHAR buf[256];
		mbstowcs_s(&num,buf,256,file_name,strlen(file_name));
		CGameMesh *mesh=new CGameMesh;
		mesh->Load(DXUTGetD3D9Device(),buf,bump_amplitude,false);
		lua_pushlightuserdata(l,mesh);
		return(1);
	}
	return(0);
}

static
int
GameScriptMeshLoadBumpMap(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	const char *file_name=lua_tolstring(l,2,NULL);
	size_t num;
	TCHAR buf[256];
	mbstowcs_s(&num,buf,256,file_name,strlen(file_name));
	gobj->LoadBumpMap(DXUTGetD3D9Device(),buf,lua_tonumber(l,3),0);
	return(0);
}

static
int
GameScriptMeshLoadDetailMap(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	const char *file_name=lua_tolstring(l,2,NULL);
	size_t num;
	TCHAR buf[256];
	mbstowcs_s(&num,buf,256,file_name,strlen(file_name));
	gobj->LoadDetailMap(DXUTGetD3D9Device(),buf,lua_tonumber(l,3));
	return(0);
}

static
int
GameScriptMeshLoadReflectionMap(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	const char *file_name=lua_tolstring(l,2,NULL);
	size_t num;
	TCHAR buf[256];
	mbstowcs_s(&num,buf,256,file_name,strlen(file_name));
	gobj->LoadReflectionMap(DXUTGetD3D9Device(),buf);
	return(0);
}

static
int
GameScriptMeshLoadSpecularMap(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	const char *file_name=lua_tolstring(l,2,NULL);
	size_t num;
	TCHAR buf[256];
	mbstowcs_s(&num,buf,256,file_name,strlen(file_name));
	gobj->LoadSpecularMap(DXUTGetD3D9Device(),buf,lua_tonumber(l,3));
	return(0);
}

static
int
GameScriptMeshLoadTextureMap(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	const char *file_name=lua_tolstring(l,2,NULL);
	size_t num;
	TCHAR buf[256];
	mbstowcs_s(&num,buf,256,file_name,strlen(file_name));
	gobj->LoadTextureMap(DXUTGetD3D9Device(),buf);
	return(0);
}

static
int
GameScriptMeshSetBumpScale(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	gobj->m_BumpScale=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptMeshSetDetailScale(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	gobj->m_DetailScale=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptMeshSetSpecularScale(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	gobj->m_SpecularScale=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptMeshSetTextureScale(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	gobj->m_TextureScale=D3DXVECTOR3(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptMeshSetTextureTransform(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	gobj->SetTextureTransform(DXUTGetD3D9Device(),lua_tonumber(l,2),(D3DXMATRIX *)lua_touserdata(l,3));
	return(0);
}

static const
luaL_Reg MshLib[]={
	{"load",GameScriptMeshLoad},
	{"loadBumpMap",GameScriptMeshLoadBumpMap},
	{"loadDetailMap",GameScriptMeshLoadDetailMap},
	{"loadReflectionMap",GameScriptMeshLoadReflectionMap},
	{"loadSpecularMap",GameScriptMeshLoadSpecularMap},
	{"loadTextureMap",GameScriptMeshLoadTextureMap},
	{"setBumpScale",GameScriptMeshSetBumpScale},
	{"setDetailScale",GameScriptMeshSetDetailScale},
	{"setSpecularScale",GameScriptMeshSetSpecularScale},
	{"setTextureScale",GameScriptMeshSetTextureScale},
	{"setTextureXform",GameScriptMeshSetTextureTransform},
	{NULL,NULL}
};

//	Physics functions

static
int
GameScriptPhyAddCollisionBox(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_PhysicsObject=g_GamePhysics->AddBoxCollision(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4),lua_tonumber(l,5),lua_toboolean(l,6));
	return(0);
}

static
int
GameScriptPhyAddCollisionCompound(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_PhysicsObject=g_GamePhysics->AddCompoundCollision(lua_tointeger(l,2),gobj->m_PhysicsObject,lua_tonumber(l,3),lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6),lua_tonumber(l,7),lua_tonumber(l,8),lua_tonumber(l,9),lua_toboolean(l,10));
	return(0);
}

static
int
GameScriptPhyAddCollisionCylinder(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_PhysicsObject=g_GamePhysics->AddCylinderCollision(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4),lua_toboolean(l,5));
	return(0);
}

static
int
GameScriptPhyAddCollisionSphere(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->m_PhysicsObject=g_GamePhysics->AddSphereCollision(lua_tonumber(l,2),lua_tonumber(l,3),lua_toboolean(l,4));
	return(0);
}

static
int
GameScriptPhyAddCollisionTriMesh(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	if (gobj->m_Type == 'MESH') {
//		gobj->AddTriMeshCollision();
	}
	return(0);
}

static
int
GameScriptPhyAddForce(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->AddForce(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhyAddForceRel(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->AddForceRel(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhyAddTorque(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->AddTorque(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhyAddTorqueRel(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->AddTorqueRel(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhyDisable(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->Disable(gobj->m_PhysicsObject);
	return(0);
}

static
int
GameScriptPhyEnable(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->Enable(gobj->m_PhysicsObject);
	return(0);
}

static
int
GameScriptPhyGetAngVelocity(lua_State *l)
{
	float x,y,z;

	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->GetVelocityAng(gobj->m_PhysicsObject,x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhyGetGravity(lua_State *l)
{
	float x,y,z;

	g_GamePhysics->GetGravity(x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhyGetForce(lua_State *l)
{
	float x,y,z;

	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->GetForce(gobj->m_PhysicsObject,x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhyGetPos(lua_State *l)
{
	float x,y,z;

	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->GetPosition(gobj->m_PhysicsObject,x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhyGetQuat(lua_State *l)
{
	float x,y,z,w;

	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->GetQuaternion(gobj->m_PhysicsObject,x,y,z,w);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	lua_pushnumber(l,w);
	return(4);
}

static
int
GameScriptPhyGetTorque(lua_State *l)
{
	float x,y,z;

	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->GetTorque(gobj->m_PhysicsObject,x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhyGetVelocity(lua_State *l)
{
	float x,y,z;

	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->GetVelocity(gobj->m_PhysicsObject,x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhySetAngVelocity(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetVelocityAng(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhySetCollisionBits(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetCollisionBits(gobj->m_PhysicsObject,lua_tointeger(l,2),lua_tointeger(l,3));
	return(0);
}

static
int
GameScriptPhySetForce(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetForce(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhySetGravity(lua_State *l)
{
	g_GamePhysics->SetGravity(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	return(0);
}

static
int
GameScriptPhySetPos(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetPosition(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhySetQuat(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetQuaternion(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4),lua_tonumber(l,5));
	return(0);
}

static
int
GameScriptPhySetTorque(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetTorque(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhySetVelocity(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->SetVelocity(gobj->m_PhysicsObject,lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptPhyZeroForces(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	g_GamePhysics->ZeroForces(gobj->m_PhysicsObject);
	return(0);
}

static const
luaL_Reg PhyLib[]={
	{"addCollisionBox",GameScriptPhyAddCollisionBox},
	{"addCollisionCompound",GameScriptPhyAddCollisionCompound},
	{"addCollisionCylinder",GameScriptPhyAddCollisionCylinder},
	{"addCollisionSphere",GameScriptPhyAddCollisionSphere},
	{"addCollisionTriMesh",GameScriptPhyAddCollisionTriMesh},
	{"addForce",GameScriptPhyAddForce},
	{"addForceRel",GameScriptPhyAddForceRel},
	{"addTorque",GameScriptPhyAddTorque},
	{"addTorqueRel",GameScriptPhyAddTorqueRel},
	{"disable",GameScriptPhyDisable},
	{"enable",GameScriptPhyEnable},
	{"getAngVelocity",GameScriptPhyGetAngVelocity},
	{"getGravity",GameScriptPhyGetGravity},
	{"getForce",GameScriptPhyGetForce},
	{"getPos",GameScriptPhyGetPos},
	{"getQuat",GameScriptPhyGetQuat},
	{"getTorque",GameScriptPhyGetTorque},
	{"getVelocity",GameScriptPhyGetVelocity},
	{"setAngVelocity",GameScriptPhySetAngVelocity},
	{"setCollisionBits",GameScriptPhySetCollisionBits},
	{"setForce",GameScriptPhySetForce},
	{"setGravity",GameScriptPhySetGravity},
	{"setPos",GameScriptPhySetPos},
	{"setQuat",GameScriptPhySetQuat},
	{"setTorque",GameScriptPhySetTorque},
	{"setVelocity",GameScriptPhySetVelocity},
	{"zeroForces",GameScriptPhyZeroForces},
	{NULL,NULL}
};

//	3D vector math functions

static
int
GameScriptVecCross(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 v;
	D3DXVec3Cross(&v,&v1,&v2);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecDir(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 v=v2-v1;
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecDot(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	float d=D3DXVec3Dot(&v1,&v2);
	lua_pushnumber(l,d);
	return(1);
}

static
int
GameScriptVecLen(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	float len=D3DXVec3Length(&v);
	lua_pushnumber(l,len);
	return(1);
}

static
int
GameScriptVecLenSq(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	float len=D3DXVec3LengthSq(&v);
	lua_pushnumber(l,len);
	return(1);
}

static
int
GameScriptVecMul(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	float x=v1.x*v2.x;
	float y=v1.y*v2.y;
	float z=v1.z*v2.z;
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptVecNorm(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVec3Normalize(&v,&v);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecScale(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	float s=lua_tonumber(l,4);
	D3DXVec3Scale(&v,&v,s);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

/*
static
int
GameScriptVecToDeg(lua_State *l)
{
	D3DXVECTOR3 p1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 p2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 deg=VectorToAngleDegree(p1,p2);
	lua_pushnumber(l,deg.x);
	lua_pushnumber(l,deg.y);
	lua_pushnumber(l,deg.z);
	return(3);
}

static
int
GameScriptVecToRad(lua_State *l)
{
	D3DXVECTOR3 p1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 p2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 rad=VectorToAngleRadian(p1,p2);
	lua_pushnumber(l,rad.x);
	lua_pushnumber(l,rad.y);
	lua_pushnumber(l,rad.z);
	return(3);
}
*/

static
int
GameScriptVecXform(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXMATRIX *m=(D3DXMATRIX *)lua_touserdata(l,4);
	D3DXVec3TransformNormal(&v,&v,m);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static const
luaL_Reg VecLib[]={
	{"cross",GameScriptVecCross},
	{"dir",GameScriptVecDir},
	{"dot",GameScriptVecDot},
	{"len",GameScriptVecLen},
	{"lensq",GameScriptVecLenSq},
	{"mul",GameScriptVecMul},
	{"norm",GameScriptVecNorm},
	{"scale",GameScriptVecScale},
//	{"todeg",GameScriptVecToDeg},
//	{"torad",GameScriptVecToRad},
	{"xform",GameScriptVecXform},
	{NULL,NULL}
};

void
CGameScript::Init()
{
	luaopen_math(m_LuaState);
	luaopen_string(m_LuaState);
	luaL_register(m_LuaState,GAM_LIBNAME,GamLib);
//	luaL_register(m_LuaState,INP_LIBNAME,InpLib);
	luaL_register(m_LuaState,MSH_LIBNAME,MshLib);
//	luaL_register(m_LuaState,OBJ_LIBNAME,ObjLib);
//	luaL_register(m_LuaState,PAR_LIBNAME,ParLib);
	luaL_register(m_LuaState,PHY_LIBNAME,PhyLib);
//	luaL_register(m_LuaState,SND_LIBNAME,SndLib);
//	luaL_register(m_LuaState,SPR_LIBNAME,SprLib);
	luaL_register(m_LuaState,VEC_LIBNAME,VecLib);
}

int
CGameScript::Exec(char *script_code,int script_size)
{
	int status=luaL_loadbuffer(m_LuaState,script_code,script_size,"Exec");
	if (status == 0) {
		status=lua_pcall(m_LuaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_LuaState,status);
	}
	return(status);
}
