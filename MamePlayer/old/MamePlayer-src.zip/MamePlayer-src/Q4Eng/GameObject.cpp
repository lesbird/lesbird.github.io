#include "DXUT.h"
#include "GameObject.h"

CGrowableArray<CGameObject *>	GameObjectList;

CGameObject::CGameObject(void)
{
	m_Type='GOBJ';

	m_bIsVisible=false;
	m_bOverrideRender=false;

	m_Pos=D3DXVECTOR3(0,0,0);
	m_Rot=D3DXVECTOR3(0,0,0);
	m_Scale=D3DXVECTOR3(1,1,1);

	D3DXQuaternionIdentity(&m_Quat);

	D3DXMatrixIdentity(&m_WorldMatrix);

//	m_PhysicsObject=NULL;

	GameObjectList.Add(this);
}

CGameObject::~CGameObject(void)
{
	int index=GameObjectList.IndexOf(this);
	if (index != -1) {
		GameObjectList.Remove(index);
	}
}

CGameObject *
CGameObject::FindTag(const char *tag_name)
{
	for (int i=0 ; i < GameObjectList.GetSize() ; i++) {
		CGameObject *gobj=GameObjectList.GetAt(i);
		if (_stricmp(gobj->m_Tag,tag_name) == 0) {
			return(gobj);
		}
	}
	return(NULL);
}

CGameObject *
CGameObject::FindNextTag(const char *tag_name,CGameObject *gobj)
{
	bool found_obj=false;
	for (int i=0 ; i < GameObjectList.GetSize() ; i++) {
		CGameObject *lobj=GameObjectList.GetAt(i);
		if (found_obj) {
			if (_stricmp(lobj->m_Tag,tag_name) == 0) {
				return(lobj);
			}
		}
		else {
			if (lobj == gobj) {
				found_obj=true;
			}
		}
	}
	return(NULL);
}

void
CGameObject::DeviceDestroy()
{
}

void
CGameObject::DeviceLost()
{
}

void
CGameObject::DeviceReset(IDirect3DDevice9 *d3dDevice)
{
}

void
CGameObject::Hide()
{
	m_bIsVisible=false;
}

void
CGameObject::Show()
{
	m_bIsVisible=true;
}

void
CGameObject::SetTag(const char *tag_name)
{
	StringCchCopyA(m_Tag,MAX_TAG_SIZE,tag_name);
}

void
CGameObject::Tick(float delta_time)
{
}

void
CGameObject::Render(IDirect3DDevice9 *d3dDevice)
{
	if (m_bOverrideRender) {
		return;
	}
	D3DXQUATERNION quat;
	D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(m_Rot.y),D3DXToRadian(m_Rot.x),D3DXToRadian(m_Rot.z));
	D3DXQuaternionMultiply(&quat,&quat,&m_Quat);
	D3DXMatrixTransformation(&m_WorldMatrix,NULL,NULL,&m_Scale,NULL,&quat,&m_Pos);
	d3dDevice->SetTransform(D3DTS_WORLD,&m_WorldMatrix);
}
