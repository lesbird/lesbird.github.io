// GamePhysics.cpp: implementation of the CGamePhysics class.
//
//////////////////////////////////////////////////////////////////////

#include "DXUT.h"
#include "GamePhysics.h"
#include "GameObject.h"

static
bool							bRayHit=false;

static
float							GravityX,GravityY,GravityZ;

static
HitRayCollision_t				HitRayCollision;

static
dGeomID							RayGeom;

PhysicsObjectList_t				PhysicsObjectList;

CGamePhysics *					g_GamePhysics;

//
//	GamePhysics functions
//

void
dDebug(int num, const char *msg, ...)
{
}

void
dMessage(int num, const char *msg, ...)
{
}

CGamePhysics::CGamePhysics(void)
{
	g_GamePhysics=this;

	InitPhysics();
}

CGamePhysics::~CGamePhysics(void)
{
	UnInitPhysics();

	g_GamePhysics=NULL;
}

void
CGamePhysics::InitPhysics()
{
	m_World=dWorldCreate();
	dWorldSetAutoDisableFlag(m_World,true);
	dWorldSetAutoDisableAngularThreshold(m_World,0.1f);
	dWorldSetAutoDisableLinearThreshold(m_World,0.1f);
	dWorldSetCFM(m_World,0.01f);

	m_Space=dHashSpaceCreate(0);
	m_CollisionJointGroup=dJointGroupCreate(0);

	RayGeom=dCreateRay(m_Space,0);
	dGeomSetCategoryBits(RayGeom,0);
	dGeomSetCollideBits(RayGeom,0);
	dGeomDisable(RayGeom);
}

void
CGamePhysics::UnInitPhysics()
{
	dGeomDestroy(RayGeom);

	dJointGroupDestroy(m_CollisionJointGroup);
	dSpaceDestroy(m_Space);
	dWorldDestroy(m_World);
	dCloseODE();
}

void
CGamePhysics::GetGravity(float &x,float &y,float &z)
{
	x=GravityX;
	y=GravityY;
	z=GravityZ;
}

void
CGamePhysics::SetGravity(float x,float y,float z)
{
	dWorldSetGravity(m_World,x,y,z);
	GravityX=x;
	GravityY=y;
	GravityZ=z;
}

PhysicsObject_t *
CGamePhysics::CreatePhysicsObject()
{
	PhysicsObject_t *phys_obj=new PhysicsObject_t;
	memset(phys_obj,0,sizeof(PhysicsObject_t));
	PhysicsObjectList.Add(phys_obj);
	return(phys_obj);
}

void
CGamePhysics::DeletePhysicsObject(PhysicsObject_t *phys_obj)
{
	int index=PhysicsObjectList.IndexOf(phys_obj);
	if (index != -1) {
		PhysicsObjectList.Remove(index);
	}
	if (phys_obj->Joint != NULL) {
		dJointDestroy(phys_obj->Joint);
	}
	for (int i=0 ; i < MAX_GEOMS ; i++) {
		if (phys_obj->Geom[i] != NULL) {
			dGeomDestroy(phys_obj->Geom[i]);
		}
	}
	if (phys_obj->Body != NULL) {
		dBodyDestroy(phys_obj->Body);
	}
	delete phys_obj;
}

void
CGamePhysics::MakeStatic(PhysicsObject_t *phys_obj)
{
	if (phys_obj != NULL) {
		if (phys_obj->Body != NULL) {
			dBodyDestroy(phys_obj->Body);
			phys_obj->Body=NULL;
		}
	}
}

PhysicsObject_t *
CGamePhysics::AddBoxCollision(float width,float height,float depth,float mass_kg,bool is_static)
{
	PhysicsObject_t *phys_obj=CreatePhysicsObject();
	phys_obj->Geom[0]=dCreateBox(m_Space,width,height,depth);
	if (is_static == false && mass_kg > 0) {
		dMass mass;
		dMassSetBoxTotal(&mass,mass_kg,width,width,width);
		phys_obj->Body=dBodyCreate(m_World);
		dBodySetMass(phys_obj->Body,&mass);
		dGeomSetBody(phys_obj->Geom[0],phys_obj->Body);
	}
	return(phys_obj);
}

PhysicsObject_t *
CGamePhysics::AddSphereCollision(float radius,float mass_kg,bool is_static)
{
	PhysicsObject_t *phys_obj=CreatePhysicsObject();
	phys_obj->Geom[0]=dCreateSphere(m_Space,radius);
	if (is_static == false && mass_kg > 0) {
		dMass mass;
		dMassSetSphereTotal(&mass,mass_kg,radius);
		phys_obj->Body=dBodyCreate(m_World);
		dBodySetMass(phys_obj->Body,&mass);
		dGeomSetBody(phys_obj->Geom[0],phys_obj->Body);
	}
	return(phys_obj);
}

PhysicsObject_t *
CGamePhysics::AddCylinderCollision(float radius,float height,float mass_kg,bool is_static)
{
/*
	PhysicsObject_t *phys_obj=CreatePhysicsObject();
	phys_obj->Geom[0]=dCreateCCylinder(m_Space,radius,height);
	if (is_static == false && mass_kg > 0) {
		dMass mass;
		dMassSetCappedCylinderTotal(&mass,mass_kg,2,radius,height);
		phys_obj->Body=dBodyCreate(m_World);
		dBodySetMass(phys_obj->Body,&mass);
		dGeomSetBody(phys_obj->Geom[0],phys_obj->Body);
	}
	return(phys_obj);
*/
	return(NULL);
}

PhysicsObject_t *
CGamePhysics::AddCompoundCollision(unsigned int col_type,PhysicsObject_t *phys_obj,float offset_x,float offset_y,float offset_z,float size_x,float size_y,float size_z,float mass_kg,bool is_static)
{
	if (phys_obj == NULL) {
		phys_obj=CreatePhysicsObject();
	}
	if (phys_obj != NULL) {
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] == NULL) {
				phys_obj->Geom[i]=dCreateGeomTransform(m_Space);
				dGeomID geom=NULL;
				switch (col_type) {
				case 'BOX':
					geom=dCreateBox(NULL,size_x,size_y,size_z);
					break;
				case 'SPHE':
					geom=dCreateSphere(NULL,size_x);
					break;
				}
				dGeomTransformSetGeom(phys_obj->Geom[i],geom);
				dGeomTransformSetCleanup(phys_obj->Geom[i],1);
				dGeomSetPosition(geom,offset_x,offset_y,offset_z);
				if (is_static == false && mass_kg > 0) {
					dMass mass;
					dMassSetBoxTotal(&mass,mass_kg,size_x,size_x,size_x);
					if (phys_obj->Body == NULL) {
						phys_obj->Body=dBodyCreate(m_World);
						dBodySetMass(phys_obj->Body,&mass);
					}
					dGeomSetBody(phys_obj->Geom[i],phys_obj->Body);
				}
				break;
			}
		}
	}
	return(phys_obj);
}

PhysicsObject_t *
CGamePhysics::AddTriMeshCollision(float *vertex_data,int num_vertices,int *index_data,int num_indices)
{
	PhysicsObject_t *phys_obj=CreatePhysicsObject();
	dTriMeshDataID trimesh_data_id=dGeomTriMeshDataCreate();
	dGeomTriMeshDataBuildSimple(trimesh_data_id,vertex_data,num_vertices,index_data,num_indices);
	phys_obj->Geom[0]=dCreateTriMesh(m_Space,trimesh_data_id,NULL,NULL,NULL);
	return(phys_obj);
}

void
CGamePhysics::SetCollisionBits(PhysicsObject_t *phys_obj,unsigned int cat_bits,unsigned int col_bits)
{
	if (phys_obj != NULL) {
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomSetCategoryBits(phys_obj->Geom[i],cat_bits);
				dGeomSetCollideBits(phys_obj->Geom[i],col_bits);
			}
		}
	}
}

void
CGamePhysics::SetPosition(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetPosition(phys_obj->Body,x,y,z);
	}
	else {
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomSetPosition(phys_obj->Geom[i],x,y,z);
			}
		}
	}
}

void
CGamePhysics::GetPosition(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *pos=dBodyGetPosition(phys_obj->Body);
		x=pos[0];
		y=pos[1];
		z=pos[2];
	}
	else if (phys_obj->Geom[0] != NULL) {
		const float *pos=dGeomGetPosition(phys_obj->Geom[0]);
		x=pos[0];
		y=pos[1];
		z=pos[2];
	}
}

void
CGamePhysics::SetQuaternion(PhysicsObject_t *phys_obj,float x,float y,float z,float w)
{
	if (phys_obj->Body != NULL) {
		dQuaternion q;
		q[0]=w;
		q[1]=x;
		q[2]=y;
		q[3]=z;
		dBodySetQuaternion(phys_obj->Body,q);
	}
	else if (phys_obj->Geom[0] != NULL) {
		dQuaternion q;
		q[0]=w;
		q[1]=x;
		q[2]=y;
		q[3]=z;
		dGeomSetQuaternion(phys_obj->Geom[0],q);
	}
}

void
CGamePhysics::GetQuaternion(PhysicsObject_t *phys_obj,float &x,float &y,float &z,float &w)
{
	if (phys_obj->Body != NULL) {
		const float *q=dBodyGetQuaternion(phys_obj->Body);
		w=q[0];
		x=q[1];
		y=q[2];
		z=q[3];
	}
	else if (phys_obj->Geom[0] != NULL) {
		dQuaternion q;
		dGeomGetQuaternion(phys_obj->Geom[0],q);
		w=q[0];
		x=q[1];
		y=q[2];
		z=q[3];
	}
}

void
CGamePhysics::AddForce(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddForce(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
CGamePhysics::AddForceRel(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddRelForce(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
CGamePhysics::SetForce(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetForce(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
CGamePhysics::GetForce(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *f=dBodyGetForce(phys_obj->Body);
		x=f[0];
		y=f[1];
		z=f[2];
	}
}

void
CGamePhysics::AddTorque(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddTorque(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
CGamePhysics::AddTorqueRel(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodyAddRelTorque(phys_obj->Body,x,y,z);
		dBodyEnable(phys_obj->Body);
	}
}

void
CGamePhysics::SetTorque(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetTorque(phys_obj->Body,x,y,z);
	}
}

void
CGamePhysics::GetTorque(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *t=dBodyGetTorque(phys_obj->Body);
		x=t[0];
		y=t[1];
		z=t[2];
	}
}

void
CGamePhysics::SetVelocity(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetLinearVel(phys_obj->Body,x,y,z);
	}
}

void
CGamePhysics::GetVelocity(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *v=dBodyGetLinearVel(phys_obj->Body);
		x=v[0];
		y=v[1];
		z=v[2];
	}
}

void
CGamePhysics::SetVelocityAng(PhysicsObject_t *phys_obj,float x,float y,float z)
{
	if (phys_obj->Body != NULL) {
		dBodySetAngularVel(phys_obj->Body,x,y,z);
	}
}

void
CGamePhysics::GetVelocityAng(PhysicsObject_t *phys_obj,float &x,float &y,float &z)
{
	if (phys_obj->Body != NULL) {
		const float *v=dBodyGetAngularVel(phys_obj->Body);
		x=v[0];
		y=v[1];
		z=v[2];
	}
}

void
CGamePhysics::Disable(PhysicsObject_t *phys_obj)
{
	if (phys_obj != NULL) {
		if (phys_obj->Body != NULL) {
			dBodyDisable(phys_obj->Body);
		}
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomDisable(phys_obj->Geom[i]);
			}
		}
	}
}

void
CGamePhysics::Enable(PhysicsObject_t *phys_obj)
{
	if (phys_obj != NULL) {
		if (phys_obj->Body != NULL) {
			dBodyEnable(phys_obj->Body);
		}
		for (int i=0 ; i < MAX_GEOMS ; i++) {
			if (phys_obj->Geom[i] != NULL) {
				dGeomEnable(phys_obj->Geom[i]);
			}
		}
	}
}

void
CGamePhysics::EnableAll()
{
	for (int i=0 ; i < PhysicsObjectList.GetSize() ; i++) {
		PhysicsObject_t *phys_obj=PhysicsObjectList.GetAt(i);
		if (phys_obj->Body != NULL) {
			Enable(phys_obj);
		}
	}
}

void
CGamePhysics::ZeroForces(PhysicsObject_t *phys_obj)
{
	SetForce(phys_obj,0,0,0);
	SetTorque(phys_obj,0,0,0);
	SetVelocity(phys_obj,0,0,0);
	SetVelocityAng(phys_obj,0,0,0);
}

void
CGamePhysics::SetData(PhysicsObject_t *phys_obj,void *data)
{
	if (phys_obj->Body != NULL) {
		dBodySetData(phys_obj->Body,data);
	}
	for (int i=0 ; i < MAX_GEOMS ; i++) {
		if (phys_obj->Geom[i] != NULL) {
			dGeomSetData(phys_obj->Geom[i],data);
		}
	}
}

static
void
CollideObjectsCallback(void *data,dGeomID o1,dGeomID o2)
{
	int	contacts_used;
	if ((dGeomGetCategoryBits(o1)&dGeomGetCollideBits(o2)) != 0 || (dGeomGetCategoryBits(o2)&dGeomGetCollideBits(o1)) != 0) {
		// colliding two non-space geoms, so generate contact points between o1 and o2
		dContact contact_array[64];
		int num_contacts=dCollide(o1,o2,64,&contact_array[0].geom,sizeof(dContact));
		// add these contact points to the simulation
		if (num_contacts > 0) {
			dBodyID body1=dGeomGetBody(o1);
			dBodyID body2=dGeomGetBody(o2);
			contacts_used=0;
			for (int c=0 ; c < num_contacts ; c++) {
				if (contact_array[c].geom.depth != 0) {
					//	filter out duplicate contacts
					for (int d=c+1 ; d < num_contacts ; d++) {
						if (contact_array[c].geom.depth == contact_array[d].geom.depth) {
							contact_array[d].geom.depth=0;
						}
					}
					int contact_mode=dContactBounce;
					contact_array[c].surface.mode=contact_mode;
					contact_array[c].surface.mu=0.5f;		//	friction
					contact_array[c].surface.bounce=0.5f;	//	bounciness
					dJointID joint_id=dJointCreateContact(g_GamePhysics->m_World,g_GamePhysics->m_CollisionJointGroup,&contact_array[c]);
					dJointAttach(joint_id,body1,body2);
					contacts_used++;
				}
			}
		}
	}
}

void
CGamePhysics::UpdatePositions()
{
	for (int p=0 ; p < PhysicsObjectList.GetSize() ; p++) {
		PhysicsObject_t *phys_obj=PhysicsObjectList.GetAt(p);
		if (phys_obj->Body != NULL) {
			dBodyID b=phys_obj->Body;
			CGameObject *gobj=(CGameObject *)dBodyGetData(b);
			const float *pos=dBodyGetPosition(b);
			gobj->m_Pos=D3DXVECTOR3(pos[0],pos[1],pos[2]);
			const float *q=dBodyGetQuaternion(b);
			gobj->m_Quat=D3DXQUATERNION(q[1],q[2],q[3],q[0]);
		}
		else {
			for (int i=0 ; i < MAX_GEOMS ; i++) {
				if (phys_obj->Geom[i] != NULL) {
					dGeomID g=phys_obj->Geom[i];
					CGameObject *gobj=(CGameObject *)dGeomGetData(g);
					const float *pos=dGeomGetPosition(g);
					gobj->m_Pos=D3DXVECTOR3(pos[0],pos[1],pos[2]);
					dQuaternion q;
					dGeomGetQuaternion(g,q);
					gobj->m_Quat=D3DXQUATERNION(q[1],q[2],q[3],q[0]);
				}
			}
		}
	}
}

void
CGamePhysics::UpdateWorld(float delta_time)
{
	dWorldQuickStep(m_World,delta_time);
	UpdatePositions();
}

void
CGamePhysics::UpdatePhysics(float delta_time)
{
	dSpaceCollide(m_Space,0,&CollideObjectsCallback);
	dWorldQuickStep(m_World,delta_time);
	dJointGroupEmpty(m_CollisionJointGroup);
	UpdatePositions();
}

static
void
RayCollideHit(dContactGeom *contact)
{
	HitRayCollision.hit_x=contact->pos[0];
	HitRayCollision.hit_y=contact->pos[1];
	HitRayCollision.hit_z=contact->pos[2];
	HitRayCollision.nor_x=contact->normal[0];
	HitRayCollision.nor_y=contact->normal[1];
	HitRayCollision.nor_z=contact->normal[2];
	HitRayCollision.dist=contact->depth;
}

static
void
RayCollideCallback(void *data,dGeomID o1,dGeomID o2)
{
	if ((dGeomGetCategoryBits(o1)&dGeomGetCollideBits(o2)) != 0 || (dGeomGetCategoryBits(o2)&dGeomGetCollideBits(o1)) != 0) {
		dContactGeom contact;
		int num_contacts=dCollide(o1,o2,1,&contact,sizeof(dContactGeom));
		if (num_contacts != 0) {
			if (HitRayCollision.dist > contact.depth) {
				HitRayCollision.object=(o1 == RayGeom) ? dGeomGetData(o2) : dGeomGetData(o1);
				RayCollideHit(&contact);
				bRayHit=true;
			}
		}
	}
}

HitRayCollision_t *
CGamePhysics::HitRay(dGeomID geom_id,float x,float y,float z,float dir_x,float dir_y,float dir_z,float len,bool first_hit)
{
	bRayHit=false;
	dGeomRaySetLength(RayGeom,len);
	dGeomRaySet(RayGeom,x,y,z,dir_x,dir_y,dir_z);
	HitRayCollision.dist=FLT_MAX;
	if (geom_id != NULL) {
		dContactGeom contact;
		while (1) {
			bool hit=false;
			int num_contacts=dCollide(RayGeom,geom_id,1,&contact,sizeof(dContactGeom));
			if (num_contacts != 0 && contact.depth < HitRayCollision.dist) {
				hit=true;
			}
			if (hit) {
				RayCollideHit(&contact);
				HitRayCollision.object=dGeomGetData(geom_id);
				dGeomRaySetLength(RayGeom,contact.depth);
				bRayHit=true;
			}
			if (hit == false || first_hit) {
				if (bRayHit) {
					return(&HitRayCollision);
				}
				return(NULL);
			}
		}
	}
	else {
		dSpaceCollide2(RayGeom,(dGeomID)g_GamePhysics->m_Space,NULL,&RayCollideCallback);
		if (bRayHit) {
			return(&HitRayCollision);
		}
	}
	return(NULL);
}

CGamePhysics *
GameInitPhysics()
{
	CGamePhysics *phys_eng=new CGamePhysics;
	return(phys_eng);
}

void
GameUnInitPhysics()
{
	if (g_GamePhysics != NULL) {
		delete g_GamePhysics;
	}
}
