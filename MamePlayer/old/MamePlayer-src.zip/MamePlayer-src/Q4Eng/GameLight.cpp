#include "DXUT.h"
#include "GameLight.h"

DWORD	g_LightIndex;

CGrowableArray<CGameLight *>	LightObjectList;

//
//
//

CGameLight::CGameLight(void)
{
	m_Type='LITE';

	ZeroMemory(&m_Light,sizeof(D3DLIGHT9));
	SetTypeDir();
	SetColorDiffuse(D3DXCOLOR(1,1,1,1));
	SetColorSpecular(D3DXCOLOR(1,1,1,1));
	SetDir(D3DXVECTOR3(0,-1,0));
	SetPointParams(100000,0,0,0.00001f);

	m_bIsVisible=false;
}

CGameLight::~CGameLight(void)
{
	Hide();
}

void
CGameLight::Hide()
{
	int index=LightObjectList.IndexOf(this);
	if (index != -1) {
		LightObjectList.Remove(index);
		m_bIsVisible=false;
	}
}

void
CGameLight::Show()
{
	int index=LightObjectList.IndexOf(this);
	if (index == -1) {
		LightObjectList.Add(this);
		m_bIsVisible=true;
	}
}

void
CGameLight::SetColorAmbient(D3DXCOLOR color_rgba)
{
	m_Light.Ambient=color_rgba;
}

void
CGameLight::SetColorDiffuse(D3DXCOLOR color_rgba)
{
	m_Light.Diffuse=color_rgba;
}

void
CGameLight::SetColorSpecular(D3DXCOLOR color_rgba)
{
	m_Light.Specular=color_rgba;
}

void
CGameLight::SetDir(D3DXVECTOR3 dir)
{
	m_Light.Direction=dir;
}

void
CGameLight::SetPos(D3DXVECTOR3 pos)
{
	m_Light.Position=pos;
	m_Pos=pos;
}

void
CGameLight::SetPointParams(float range,float atten_0,float atten_1,float atten_2)
{
	m_Light.Range=range;
	m_Light.Attenuation0=atten_0;
	m_Light.Attenuation1=atten_1;
	m_Light.Attenuation2=atten_2;
}

void
CGameLight::SetSpotParams(float falloff,float theta,float phi)
{
	m_Light.Falloff=falloff;
	m_Light.Theta=theta;
	m_Light.Phi=phi;
}

void
CGameLight::SetTypeDir()
{
	m_Light.Type=D3DLIGHT_DIRECTIONAL;
}

void
CGameLight::SetTypePoint()
{
	m_Light.Type=D3DLIGHT_POINT;
}

void
CGameLight::SetTypeSpot()
{
	m_Light.Type=D3DLIGHT_SPOT;
}

void
CGameLight::Render(IDirect3DDevice9 *d3dDevice)
{
	m_LightIndex=g_LightIndex++;
	d3dDevice->SetLight(m_LightIndex,&m_Light);
	d3dDevice->LightEnable(m_LightIndex,TRUE);
}
