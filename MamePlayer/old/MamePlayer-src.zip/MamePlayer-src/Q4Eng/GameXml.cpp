#include "DXUT.h"
#include "GameXml.h"

//
//
//

CGameXml::CGameXml()
{
	m_XmlLine[0]=0;
	m_XmlNodeName[0]=0;

	m_XmlNodePos=0;

	m_XmlFp=NULL;
}

CGameXml::~CGameXml()
{
	if (m_XmlFp != NULL) {
		fclose(m_XmlFp);
	}
}

void
CGameXml::Load(LPCSTR file_name)
{
	if (m_XmlFp == NULL) {
		fopen_s(&m_XmlFp,file_name,"rb");
	}
}

bool
CGameXml::FindNode(LPCSTR node_name)
{
	char search_name[XML_NAME_SIZE];
	sprintf_s(search_name,XML_NAME_SIZE,"<%s ",node_name);
	long start_pos=ftell(m_XmlFp);
	while (!feof(m_XmlFp)) {
		long cur_pos=ftell(m_XmlFp);
		if (fgets(m_XmlLine,XML_LINE_SIZE,m_XmlFp) != NULL) {
			if (strstr(m_XmlLine,search_name) != NULL) {
				m_XmlNodePos=cur_pos;
				strcpy_s(m_XmlNodeName,XML_NAME_SIZE,node_name);
				return(true);
			}
		}
	}
	fseek(m_XmlFp,start_pos,SEEK_SET);
	return(NULL);
}

LPCSTR
CGameXml::GetValue(LPCSTR element_name)
{
	static char value[XML_LINE_SIZE];

	char end_tag[XML_NAME_SIZE];
	sprintf_s(end_tag,XML_NAME_SIZE,"</%s>",m_XmlNodeName);
	char search_name[XML_NAME_SIZE];
	sprintf_s(search_name,XML_NAME_SIZE,"%s=",element_name);
	char search_name2[XML_NAME_SIZE];
	sprintf_s(search_name2,XML_NAME_SIZE,"<%s>",element_name);
	fseek(m_XmlFp,m_XmlNodePos,SEEK_SET);
	char *ptr=NULL;
	int c,i,n;
	do {
		ptr=strstr(m_XmlLine,search_name);
		if (ptr != NULL) {
			c=i=n=0;
			ptr+=strlen(search_name);
			do {
				if (ptr[i] == '\"') {
					c++;
				}
				else {
					value[n++]=ptr[i];
				}
				i++;
			} while (c < 2);
			value[n++]=0;
			return(value);
		}
		ptr=strstr(m_XmlLine,search_name2);
		if (ptr != NULL) {
			ptr+=strlen(search_name2);
			char buf[256];
			strcpy_s(buf,256,ptr);
			char end_tag[256];
			sprintf_s(end_tag,256,"</%s>",element_name);
			char *ptr2=strstr(buf,end_tag);
			if (ptr2 != NULL) {
				ptr2[0]=0;
			}
			int i=n=0;
			while (buf[i] != 0) {
				if (buf[i] == '&' && buf[i+1] == 'l' && buf[i+2] == 't' && buf[i+3] == ';') {
					value[n++]='<';
					i+=4;
				}
				else if (buf[i] == '&' && buf[i+1] == 'g' && buf[i+2] == 't' && buf[i+3] == ';') {
					value[n++]='>';
					i+=4;
				}
				else {
					value[n++]=buf[i++];
				}
			}
			value[n++]=0;
			return(value);
		}
		fgets(m_XmlLine,XML_LINE_SIZE,m_XmlFp);
	} while (strstr(m_XmlLine,end_tag) == NULL && feof(m_XmlFp) == 0);
	return(NULL);
}
