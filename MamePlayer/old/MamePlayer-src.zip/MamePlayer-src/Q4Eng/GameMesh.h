#pragma once
#include "gameobject.h"

class CGameMesh :
	public CGameObject
{
public:
	CGameMesh(void);
	virtual ~CGameMesh(void);

	virtual void		Hide();
	virtual void		Show();

	virtual void		Load(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float bump_amplitude=10,bool save_to_text=false);
	virtual void		ConvertHeightMap(IDirect3DDevice9 *d3dDevice,LPDIRECT3DTEXTURE9 height_map,float amplitude,int index);
	virtual void		LoadBumpMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float amplitude=10,int index=0);
	virtual void		LoadDetailMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float scale=1);
	virtual void		LoadTextureMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name);
	virtual void		LoadReflectionMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,int index=0);
	virtual void		LoadSpecularMap(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,float scale=1,int index=0);

	virtual void		SetTextureTransform(IDirect3DDevice9 *d3dDevice,DWORD stage,D3DXMATRIX *mat);

	virtual void		ComputeLightVector();

	virtual void		Render(IDirect3DDevice9 *d3dDevice);

public:
	bool				m_bDot3Modulate;
	bool				m_bDot3Tfactor;
	bool				m_bHasTangents;

	TCHAR				m_File[MAX_PATH];

	DWORD				m_NumMaterials;

	D3DXVECTOR3			m_BumpScale;
	D3DXVECTOR3			m_DetailScale;
	D3DXVECTOR3			m_SpecularScale;
	D3DXVECTOR3			m_TextureScale;

	D3DMATERIAL9 *		m_Material;
	IDirect3DTexture9 **m_Texture;
	IDirect3DTexture9 **m_TextureBump;
	IDirect3DTexture9 *	m_TextureDetail;
	IDirect3DTexture9 *	m_TextureOverride;
	IDirect3DTexture9 **m_TextureReflect;
	IDirect3DTexture9 **m_TextureSpecular;
	ID3DXMesh *			m_Mesh;
};

extern
CGrowableArray<CGameMesh *>	MeshObjectList;
