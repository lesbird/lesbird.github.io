#pragma once

#define	XML_LINE_SIZE		512
#define	XML_NAME_SIZE		64

class CGameXml
{
public:
	CGameXml(void);
	virtual ~CGameXml(void);

public:
	virtual void			Load(LPCSTR file_name);

	virtual bool			FindNode(LPCSTR node_name);
	virtual LPCSTR			GetValue(LPCSTR element_name);

public:
	char					m_XmlLine[XML_LINE_SIZE];
	char					m_XmlNodeName[XML_NAME_SIZE];

	long					m_XmlNodePos;

	FILE *					m_XmlFp;
};
