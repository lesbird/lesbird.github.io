#pragma once

#include "GamePhysics.h"

#define	MAX_TAG_SIZE	32

class CGameObject
{
public:
	CGameObject(void);
	virtual ~CGameObject(void);

	static CGameObject *FindTag(const char *tag_name);
	static CGameObject *FindNextTag(const char *tag_name,CGameObject *gobj);

	virtual void		DeviceDestroy();
	virtual void		DeviceLost();
	virtual void		DeviceReset(IDirect3DDevice9 *d3dDevice);
	virtual void		Hide();
	virtual void		Show();
	virtual void		SetTag(const char *tag_name);
	virtual void		Tick(float delta_time);
	virtual void		Render(IDirect3DDevice9 *d3dDevice);

public:
	bool				m_bIsVisible;
	bool				m_bOverrideRender;

	CHAR				m_Tag[MAX_TAG_SIZE];

	unsigned int		m_Type;

	D3DXVECTOR3			m_Pos;
	D3DXVECTOR3			m_Rot;
	D3DXVECTOR3			m_Scale;
	D3DXQUATERNION		m_Quat;

	D3DXMATRIX			m_WorldMatrix;

//	PhysicsObject_t *	m_PhysicsObject;
};

extern
CGrowableArray<CGameObject *>	GameObjectList;
