#pragma once
#include "gameobject.h"
#include "FastCar.hpp"
#include "CollisionDetection.hpp"
#include "CollisionHandler.hpp"

#define	MAX_WHEELS		4

class CGameVehicle :
	public CGameMesh
{
public:
	CGameVehicle(void);
	virtual ~CGameVehicle(void);

	virtual void		BuildCar(float w,float h,float d,float mass_kg,float wheel_r,float wheel_w,float wheel_mass_kg,TCHAR *body_file,TCHAR *wheel_file);
	virtual void		Tick(float delta_time);
	virtual void		Render(IDirect3DDevice9 *d3dDevice);

public:
	float				m_TimeStep;

	D3DXVECTOR3			m_Offset;

	CGearBox *			m_FastCar;

	CGameMesh *			m_Body;
	CGameMesh *			m_Wheel[MAX_WHEELS];
};
