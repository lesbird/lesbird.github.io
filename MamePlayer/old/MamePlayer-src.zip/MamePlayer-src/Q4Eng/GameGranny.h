#pragma once
#include "gamemesh.h"
#include "granny.h"

typedef struct GRANNY_MESH
{
	granny_mesh *			GrannyMesh;
	granny_mesh_binding *	GrannyMeshBinding;
	granny_mesh_deformer *	GrannyMeshDeformer;
	IDirect3DIndexBuffer9 *	IndexBuffer;
	IDirect3DVertexBuffer9 *VertexBuffer;
	int						TextureCount;
	texture **				TextureReferences;
} GrannyMesh_t;

typedef struct GRANNY_MODEL
{
	granny_model_instance *	GrannyInstance;
	granny_world_pose *		WorldPose;
	int						MeshCount;
	GrannyMesh_t *			Meshes;
} GrannyModel_t;

class CGameGranny :
	public CGameMesh
{
public:
	CGameGranny(void);
	virtual ~CGameGranny(void);

public:
	virtual void		Load(IDirect3DDevice9 *d3dDevice,LPTSTR file_name,LPTSTR effect_file_name=NULL);

	virtual void		Render(IDirect3DDevice9 *d3dDevice);

public:

};

extern
CGrowableArray<CGameGranny *>	GrannyObjectList;
