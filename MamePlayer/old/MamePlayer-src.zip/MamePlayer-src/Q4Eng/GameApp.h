#pragma once

#define	MAX_FONTS			2

class CGameApp
{
public:
	CGameApp(void);
	virtual ~CGameApp(void);

public:
	virtual bool			MsgProc(HWND hWnd,UINT msg,WPARAM wparam,LPARAM lparam);
	virtual void			MouseEvent(bool left_button,bool right_button,bool middle_button,int mouse_wheel_delta,int x,int y);
	virtual void			SetMousePos(int x,int y);
	virtual void			ShowMouseCursor(bool vis);

	virtual void			KeyboardEvent(UINT c,bool key_down,bool alt_down);
	virtual bool			IsKeyPressed(int key);

	static void WINAPI		StaticFill3DWrapper(D3DXVECTOR4 *o,const D3DXVECTOR3 *tex_coord,const D3DXVECTOR3 *tex_size,LPVOID data);

	virtual void			InitProjection(float fov,float near_plane,float far_plane,int width,int height);
	virtual void			InitRenderStates(IDirect3DDevice9 *d3dDevice);
	virtual void			Init(IDirect3DDevice9 *d3dDevice);
	virtual void			UnInit();

	virtual void			DeviceDestroy();
	virtual void			DeviceLost();
	virtual void			DeviceReset(IDirect3DDevice9 *d3dDevice);

	virtual void			PrintText(int x,int y,int font,D3DXCOLOR color,const WCHAR *fmt,...);

	virtual void			Tick(float delta_time);
	virtual void			TickCamera(float delta_time);

	virtual void			Render(IDirect3DDevice9 *d3dDevice);
	virtual void			RenderText();

public:
	bool					m_bBumpMap;
	bool					m_bDetailMap;
	bool					m_bReflectionMap;
	bool					m_bSpecularMap;

	bool					m_bCameraOverride;
	bool					m_bCursorVisible;

	char					m_Char;

	int						m_MouseX;
	int						m_MouseY;
	int						m_MouseDeltaX;
	int						m_MouseDeltaY;
	int						m_MouseEventX;
	int						m_MouseEventY;
	int						m_MouseWheelDelta;

	float					m_Aspect;
	float					m_Far;
	float					m_Fov;
	float					m_Near;

	int						m_Height;
	int						m_Width;

	D3DXVECTOR3				m_CamPos;
	D3DXVECTOR3				m_CamRot;
	D3DXVECTOR3				m_CamSpd;

	D3DXMATRIX				m_CamProjMatrix;
	D3DXMATRIX				m_CamViewMatrix;

	ID3DXSprite *			m_FontSprite;
	ID3DXFont *				m_Font[MAX_FONTS];
};

extern
bool		g_AppFullScreen;

extern
CGameApp *	g_GameApp;

extern
LPTSTR		g_AppName;

extern
CGameApp *	SpawnGameApp();

extern
void		Log(char *fmt,...);
