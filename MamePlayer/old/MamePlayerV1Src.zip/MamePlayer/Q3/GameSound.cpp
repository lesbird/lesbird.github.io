// GameSound.cpp: implementation of the CGameSound class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	ENABLE_SOUND		1

LPDIRECTSOUND8				g_DS8;

int							PlayingSoundCount;

static
SndBufferList_t				SndBufferList;
static
SndBufferList_t				SndPlayingList;

static
LPDIRECTSOUND3DLISTENER		SndListener;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameSound::CGameSound()
{

}

CGameSound::~CGameSound()
{

}

void
SndFreeAllSounds()
{
#if ENABLE_SOUND
	while (SndBufferList.size() > 0) {
		SndBuffer_t *snd=(*SndBufferList.begin());
		SndBufferList.pop_front();
		snd->Sound->Release();
//		Log("SndFreeAllSounds(): %s",snd->FileName);
		delete snd;
	}
#endif
}

void
SndRemoveSound(SND_HANDLE buffer)
{
#if ENABLE_SOUND
	SndStop(buffer);
	SndBufferList.remove(buffer);
	buffer->Sound->Release();
//	Log("SndRemoveSound(): %s",buffer->FileName);
	delete buffer;
#endif
}

void
InitSound()
{
#if ENABLE_SOUND
	if (DirectSoundCreate8(NULL,&g_DS8,NULL) == DS_OK) {
		if (g_DS8->SetCooperativeLevel(g_hWnd,DSSCL_EXCLUSIVE) == DS_OK) {
			DSBUFFERDESC buffer_desc;
			memset(&buffer_desc,0,sizeof(DSBUFFERDESC));
			buffer_desc.dwSize=sizeof(DSBUFFERDESC);
			buffer_desc.dwFlags=DSBCAPS_CTRL3D|DSBCAPS_PRIMARYBUFFER;
			buffer_desc.dwBufferBytes=0;
			buffer_desc.lpwfxFormat=NULL;
			LPDIRECTSOUNDBUFFER buffer;
			if (g_DS8->CreateSoundBuffer(&buffer_desc,&buffer,NULL) == DS_OK) {
				int channels=2;
				int bits_per_sample=16;
				int samples_per_sec=22050;
				WAVEFORMATEX wave_format;
				memset(&wave_format,0,sizeof(WAVEFORMATEX));
				wave_format.wFormatTag=WAVE_FORMAT_PCM;
				wave_format.nChannels=channels;
				wave_format.nSamplesPerSec=samples_per_sec;
				wave_format.wBitsPerSample=bits_per_sample;
				wave_format.nBlockAlign=bits_per_sample/(8*channels);
				wave_format.nAvgBytesPerSec=samples_per_sec/wave_format.nBlockAlign;
				if (buffer->SetFormat(&wave_format) != DS_OK) {
//					Log("InitSound(): SetFormat() failed");
				}
				buffer->QueryInterface(IID_IDirectSound3DListener,(VOID **)&SndListener);
				if (SndListener != NULL) {
					SndListener->SetOrientation(0,0,1,0,1,0,DS3D_IMMEDIATE);
					SndListener->SetRolloffFactor(4,DS3D_IMMEDIATE);
				}
				buffer->Release();
			}
		}
	}
#endif
}

void
UnInitSound()
{
#if ENABLE_SOUND
	SndFreeAllSounds();
	if (SndListener != NULL) {
		SndListener->Release();
		SndListener=NULL;
	}
	if (g_DS8 != NULL) {
		g_DS8->Release();
		g_DS8=NULL;
	}
#endif
}

void
SndSetWorldScale(float scale)
{
#if ENABLE_SOUND
	if (SndListener != NULL) {
		SndListener->SetDistanceFactor(scale/10,DS3D_IMMEDIATE);
	}
#endif
}

void
SndSetListener(D3DXVECTOR3 pos,D3DXVECTOR3 vel)
{
#if ENABLE_SOUND
	if (SndListener != NULL) {
		SndListener->SetPosition(pos.x,pos.y,pos.z,DS3D_DEFERRED);
		SndListener->SetVelocity(vel.x,vel.y,vel.z,DS3D_DEFERRED);
	}
#endif
}

SND_HANDLE
SndGetBuffer(char *file_name)
{
#if ENABLE_SOUND
	for (SndBufferList_t::iterator s=SndBufferList.begin() ; s != SndBufferList.end() ; s++) {
		SndBuffer_t *buffer=(*s);
		if (stricmp(buffer->FileName,file_name) == 0) {
			return(buffer);
		}
	}
#endif
	Log("SndGetBuffer(%s): Not found",file_name);
	return(NULL);
}

void
SndStopBuffer(SndBuffer_t *buffer)
{
#if ENABLE_SOUND
	if (buffer != NULL) {
		buffer->Sound->Stop();
		buffer->Sound->SetCurrentPosition(0);
		buffer->bPlaying=false;
		SndPlayingList.remove(buffer);
	}
#endif
}

#define	USE_DATA_FILE	1

#if USE_DATA_FILE
char *
SndFindChunk(void *buf,unsigned long buf_size,char id1,char id2,char id3,char id4,unsigned long &chunk_size)
{
	int n=0;
	char *ptr=(char *)buf;
	bool found_chunk=false;
	while (n < buf_size) {
		while (*ptr != id1 && n < buf_size) {
			ptr++;
			n++;
		}
		if (n < buf_size) {
			if (*(ptr+1) == id2 && *(ptr+2) == id3 && *(ptr+3) == id4) {
				ptr+=4;
				memcpy(&chunk_size,ptr,sizeof(long));
				ptr+=4;
				return(ptr);
			}
			ptr++;
			n++;
		}
	}
	return(NULL);
}
#endif

SND_HANDLE
SndPreCache(char *file_name)
{
	SndBuffer_t *buffer=NULL;
#if ENABLE_SOUND
	if (g_DS8 == NULL) {
		return(NULL);
	}
#if USE_DATA_FILE
	unsigned long buf_size;
	void *buf=g_GameFile->GetFile(file_name,&buf_size);
	if (buf == NULL) {
		g_GameFile->FreeFileMem(buf);
		Log("SndPreCache(%s): Not found",file_name);
		return(NULL);
	}
	unsigned long chunk_size;
	WAVEFORMATEX *wave_format=NULL;
	char *ptr=SndFindChunk(buf,buf_size,'f','m','t',' ',chunk_size);
	if (ptr != NULL) {
		PCMWAVEFORMAT pcm_wave_format;
		memcpy(&pcm_wave_format,ptr,sizeof(PCMWAVEFORMAT));
		ptr+=sizeof(PCMWAVEFORMAT);
		if (pcm_wave_format.wf.wFormatTag == WAVE_FORMAT_PCM) {
			wave_format=(WAVEFORMATEX *)new char[sizeof(WAVEFORMATEX)];
			memcpy(wave_format,&pcm_wave_format,sizeof(WAVEFORMATEX));
			wave_format->cbSize=0;
		}
		else {
			short extra_bytes=0;
			memcpy(&extra_bytes,ptr,sizeof(short));
			ptr+=sizeof(short);
			wave_format=(WAVEFORMATEX *)new char[sizeof(WAVEFORMATEX)+extra_bytes];
			memcpy(wave_format,&pcm_wave_format,sizeof(WAVEFORMATEX));
			wave_format->cbSize=extra_bytes;
			char *dst=(char *)(&wave_format->cbSize)+sizeof(int);
			memcpy(dst,ptr,extra_bytes);
		}
		ptr=SndFindChunk(buf,buf_size,'d','a','t','a',chunk_size);
	}
	if (ptr == NULL) {
		if (wave_format != NULL) {
			delete wave_format;
		}
		g_GameFile->FreeFileMem(buf);
		return(NULL);
	}
#else
	CWaveFile wave_file;
	if (FAILED(wave_file.Open(file_name,NULL,WAVEFILE_READ))) {
		wave_file.Close();
		Log("SndPreCache(%s): Not found",file_name);
		return(NULL);
	}
#endif
	DSBUFFERDESC buffer_desc;
	buffer_desc.dwSize=sizeof(DSBUFFERDESC);
	buffer_desc.dwFlags=DSBCAPS_CTRL3D|DSBCAPS_MUTE3DATMAXDISTANCE;
	buffer_desc.dwReserved=0;
	buffer_desc.guid3DAlgorithm=DS3DALG_DEFAULT;
#if USE_DATA_FILE
	buffer_desc.dwBufferBytes=chunk_size;
	buffer_desc.lpwfxFormat=wave_format;
#else
	buffer_desc.dwBufferBytes=wave_file.GetSize();
	buffer_desc.lpwfxFormat=wave_file.m_pwfx;
#endif
	LPDIRECTSOUNDBUFFER sound;
	if (g_DS8->CreateSoundBuffer(&buffer_desc,&sound,NULL) == DS_OK) {
		buffer=new SndBuffer_t;
		memset(buffer,0,sizeof(SndBuffer_t));
		strcpy(buffer->FileName,file_name);
		strupr(buffer->FileName);
		BYTE *locked_buffer=NULL;
		DWORD locked_buffer_size=0;
		if (sound->Lock(0,0,(VOID **)&locked_buffer,&locked_buffer_size,NULL,NULL,DSBLOCK_ENTIREBUFFER) == DS_OK) {
#if USE_DATA_FILE
			memcpy(locked_buffer,ptr,locked_buffer_size);
#else
			unsigned long bytes_read=0;
			wave_file.Read(locked_buffer,locked_buffer_size,&bytes_read);
#endif
			sound->Unlock(locked_buffer,locked_buffer_size,NULL,0);
		}
		buffer->Sound=sound;
		LPDIRECTSOUND3DBUFFER buf3D=NULL;
		buffer->Sound->QueryInterface(IID_IDirectSound3DBuffer,(VOID **)&buf3D);
		if (buf3D != NULL) {
			buf3D->SetMaxDistance(8000,DS3D_DEFERRED);
			buf3D->SetMinDistance(2000,DS3D_DEFERRED);
			buf3D->Release();
		}
		buffer->bPlaying=false;
		SndBufferList.push_back(buffer);
		LogResource("%s",buffer->FileName);
	}
#if USE_DATA_FILE
	if (wave_format != NULL) {
		delete wave_format;
	}
	g_GameFile->FreeFileMem(buf);
#else
	wave_file.Close();
#endif
#endif
	return(buffer);
}

void
SndPlaySound(SND_HANDLE buffer,bool is_3D,bool loop_sound=false)
{
#if ENABLE_SOUND
	if (buffer == NULL) {
		return;
	}
	SndStopBuffer(buffer);
	LPDIRECTSOUND3DBUFFER buf3D=NULL;
	buffer->Sound->QueryInterface(IID_IDirectSound3DBuffer,(VOID **)&buf3D);
	if (buf3D != NULL) {
		if (is_3D) {
			PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr((CGameObject *)buffer->Object,VAR_PHYSICS);
			if (phys_obj != NULL) {
				float x,y,z;
				PhyGetPosition(phys_obj,x,y,z);
				buf3D->SetPosition(x,y,z,DS3D_DEFERRED);
				float vx,vy,vz;
				PhyGetVelocity(phys_obj,vx,vy,vz);
				buf3D->SetVelocity(vx,vy,vz,DS3D_DEFERRED);
			}
			buf3D->SetMode(DS3DMODE_NORMAL,DS3D_DEFERRED);
		}
		else {
			buf3D->SetMode(DS3DMODE_DISABLE,DS3D_DEFERRED);
		}
		buf3D->Release();
	}
	buffer->Sound->Play(0,0,(loop_sound ? DSBPLAY_LOOPING : 0));
	buffer->bPlaying=true;
	SndPlayingList.push_back(buffer);
#endif
}

SND_HANDLE
SndLoopBuffer(SND_HANDLE buffer,CGameObject *gobj)
{
#if ENABLE_SOUND
	if (buffer != NULL) {
		buffer->Timer=0;
		buffer->Object=gobj;
		SndPlaySound(buffer,(gobj != NULL) ? true : false,true);
	}
#endif
	return(buffer);
}

SND_HANDLE
SndLoop(char *file_name,CGameObject *gobj)
{
	SND_HANDLE buffer=SndGetBuffer(file_name);
#if ENABLE_SOUND
	if (buffer == NULL) {
		buffer=SndPreCache(file_name);
	}
#endif
	return(SndLoopBuffer(buffer,gobj));
}

SND_HANDLE
SndPlayBuffer(SND_HANDLE buffer,CGameObject *gobj)
{
#if ENABLE_SOUND
	if (buffer != NULL) {
		buffer->Timer=0;
		buffer->Object=gobj;
		SndPlaySound(buffer,(gobj != NULL) ? true : false);
	}
#endif
	return(buffer);
}

SND_HANDLE
SndPlay(char *file_name,CGameObject *gobj)
{
	SND_HANDLE buffer=SndGetBuffer(file_name);
#if ENABLE_SOUND
	if (buffer == NULL) {
		buffer=SndPreCache(file_name);
	}
#endif
	return(SndPlayBuffer(buffer,gobj));
}

SND_HANDLE
SndPlayPos(char *file_name,D3DXVECTOR3 pos,bool loop)
{
	SND_HANDLE buffer;
	if (loop) {
		buffer=SndLoop(file_name);
	}
	else {
		buffer=SndPlay(file_name);
	}
#if ENABLE_SOUND
	if (buffer != NULL) {
		LPDIRECTSOUND3DBUFFER buf3D=NULL;
		buffer->Sound->QueryInterface(IID_IDirectSound3DBuffer,(VOID **)&buf3D);
		if (buf3D != NULL) {
			buf3D->SetMode(DS3DMODE_NORMAL,DS3D_DEFERRED);
			buf3D->SetPosition(pos.x,pos.y,pos.z,DS3D_DEFERRED);
			buf3D->Release();
		}
	}
#endif
	return(buffer);
}

void
SndStop(SND_HANDLE buffer)
{
#if ENABLE_SOUND
	SndStopBuffer(buffer);
#endif
}

bool
SndIsPlaying(SND_HANDLE buffer)
{
#if ENABLE_SOUND
	if (buffer != NULL) {
		if (buffer->bPlaying) {
			return(true);
		}
	}
#endif
	return(false);
}

void
SndClearPlayList()
{
	SndPlayingList.clear();
}

void
SndComputeVol(SND_HANDLE buffer)
{
#if ENABLE_SOUND
	LPDIRECTSOUND3DBUFFER buf3D=NULL;
	buffer->Sound->QueryInterface(IID_IDirectSound3DBuffer,(VOID **)&buf3D);
	if (buf3D != NULL) {
		PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr((CGameObject *)buffer->Object,VAR_PHYSICS);
		if (phys_obj != NULL) {
			float x,y,z;
			PhyGetPosition(phys_obj,x,y,z);
			buf3D->SetPosition(x,y,z,DS3D_DEFERRED);
			float vx,vy,vz;
			PhyGetVelocity(phys_obj,vx,vy,vz);
			buf3D->SetVelocity(vx,vy,vz,DS3D_DEFERRED);
		}
		else {
			CGameMesh *mesh=(CGameMesh *)buffer->Object;
			buf3D->SetPosition(mesh->m_Pos.x,mesh->m_Pos.y,mesh->m_Pos.z,DS3D_DEFERRED);
			buf3D->SetVelocity(0,0,0,DS3D_DEFERRED);
		}
		buf3D->Release();
	}
/*
	CGameObject *gobj=(CGameObject *)buffer->Object;
	float x,y,z;
	GetVec3(gobj,VAR_POS,x,y,z);
	D3DXVECTOR3 dir=AWE_DIR_VEC(g_ViewPos,D3DXVECTOR3(x,y,z));
	float len=D3DXVec3LengthSq(&dir);
	float vol=__min(len/WorldScale,1)*DSBVOLUME_MIN;
	LPDIRECTSOUNDBUFFER buf=buffer->Sound->GetBuffer(0);
	buf->SetVolume(vol);
	D3DXVec3Normalize(&dir,&dir);
	float d=D3DXVec3Dot(&g_ViewRgtVec,&dir);
	float pan=d*DSBPAN_RIGHT;
	buf->SetPan(pan);
*/
#endif
}

void
UpdateSound(float delta_time)
{
#if ENABLE_SOUND
	PlayingSoundCount=0;
	for (SndBufferList_t::iterator s=SndPlayingList.begin() ; s != SndPlayingList.end() ; ) {
		SND_HANDLE buffer=(*s);
		DWORD status;
		buffer->Sound->GetStatus(&status);
		buffer->Timer+=delta_time;
		if (buffer->Timer > 0.1f) {
			if ((status&DSBSTATUS_PLAYING) == 0) {
				GameSoundIsDone(buffer);
				buffer->bPlaying=false;
				s=SndPlayingList.erase(s);
				continue;
			}
		}
		if (buffer->Object != NULL) {
			if ((status&DSBSTATUS_LOOPING) != 0) {
				SndComputeVol(buffer);
			}
		}
		PlayingSoundCount++;
		s++;
	}
	if (SndListener != NULL) {
		SndListener->CommitDeferredSettings();
	}
#endif
}
