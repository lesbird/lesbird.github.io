// GameWin32.cpp: 32-bit windows related global functions
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"
#include <windowsx.h>
#include <winuser.h>
#include <time.h>

//	global declarations

const char *g_KeyLabel[]={
	"",
	"ESC",
	"1","2","3","4","5","6","7","8","9","0",
	"-","=","BS","TAB",
	"Q","W","E","R","T","Y","U","I","O","P",
	"[","]","ENTER","CTRL",
	"A","S","D","F","G","H","J","K","L",
	";","'","~","LSHIFT","\\",
	"Z","X","C","V","B","N","M",
	",",".","/","RSHIFT","PSCREEN","ALT","SPACE","CAPS",
	"F1","F2","F3","F4","F5","F6","F7","F8","F9","F10",
	"NUMLOCK","SCROLL","HOME","UP","PGUP","MINUS",
	"LEFT","CENTER","RIGHT","PLUS","END","DOWN","PGDN",
	"INS","DEL"
};

bool			g_bAppActive=true;
bool			g_bCursorVisible=false;
bool			g_bFpsInfo=false;
bool			g_bHasFocus=true;
bool			g_bPaused=false;

bool			g_bLogEnable=true;

bool			g_bNextStep=true;
bool			g_bSingleStep=false;

bool			g_bKey[256];

char			g_Char;

bool			g_AutoInsert;

int				g_WinRemote;

unsigned char	g_WinMouseButtons;
int				g_WinMouseX,
				g_WinMouseY,
				g_WinMouseWheel;

int				g_WindowHeight;
int				g_WindowWidth;

float			g_Fps,
				g_FpsSum,
				g_FpsAvg;

HWND			g_hWnd;
HINSTANCE		g_hInstance;
HCURSOR			g_hCursor;

LARGE_INTEGER	g_LastTime,
				g_PerfFreq;

//	global functions

void
ResetTimer()
{
	QueryPerformanceCounter(&g_LastTime);
}

LARGE_INTEGER
GetTimer()
{
	LARGE_INTEGER current_time;
	QueryPerformanceCounter(&current_time);
	return(current_time);
}

float
GetTimerDelta(LARGE_INTEGER &last_time)
{
	LARGE_INTEGER current_time=GetTimer();
	float delta_time=float(current_time.QuadPart-last_time.QuadPart)/float(g_PerfFreq.QuadPart);
	last_time=current_time;
	return(delta_time);
}

void
ComputeFps(float delta_time)
{
	if (delta_time != 0) {
		g_Fps=1.0f/delta_time;
		g_FpsSum+=g_Fps;
		g_FpsAvg=g_FpsSum*0.01f;
		g_FpsSum-=g_FpsAvg;
	}
}

void
AppShowCursor(bool show_flag)
{
	Log("AppShowCursor(%d)",show_flag);
	if (show_flag) {
		if (g_bCursorVisible) {
			return;
		}
		UnacquireMouse();
		if (g_hCursor == NULL) {
			g_hCursor=LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW));
		}
		g_bCursorVisible=show_flag;
		SetCursor(g_hCursor);
		ShowCursor(show_flag);
	}
	else {
		if (g_bCursorVisible) {
			if (!g_bWindowedMode) {
				AcquireMouse();
			}
			if (g_hCursor != NULL) {
				SetCursor(NULL);
				DestroyCursor(g_hCursor);
				g_hCursor=NULL;
			}
			g_bCursorVisible=show_flag;
			ShowCursor(show_flag);
		}
	}
}

UINT g_uQueryCancelAutoPlay=0;

LRESULT CALLBACK
MsgProc(HWND hwnd,UINT umsg,WPARAM wParam,LPARAM lParam)
{
//	Log("MsgProc: umsg=%ld (%X) wparam=%ld (%X) lparam=%ld (%X)",umsg,umsg,wParam,wParam,lParam,lParam);
	switch (umsg) {
	case WM_ACTIVATEAPP:
		{
			Log("WM_ACTIVATEAPP focus=%d",wParam);
			g_bHasFocus=(wParam == 0 ? false : true);
			if (g_bHasFocus) {
//				AppShowCursor(false);
				GameAppPauseGame(false);
			}
			else {
				UnacquireMouse();
				GameAppPauseGame(true);
//				g_bCursorVisible=true;
			}
			if (g_bCursorVisible) {
				g_bCursorVisible=false;
				AppShowCursor(true);
			}
		}
		return(0);
	case WM_PAINT:
		{
			PAINTSTRUCT paint;
			HDC hdc=BeginPaint(g_hWnd,&paint);
			GfxRenderScene();
			EndPaint(g_hWnd,&paint);
		}
		return(0);
	case WM_SYSCOMMAND:
		{
			switch (wParam) {
			case SC_MONITORPOWER:
			case SC_SCREENSAVE:
				return(0);
			}
		}
		break;
	case WM_SYSKEYDOWN:
		{
			if (wParam == VK_F4) {
				g_bAppActive=false;
			}
		}
		return(0);
	case WM_CLOSE:
	case WM_QUIT:
		{
			g_bAppActive=false;
		}
		return(0);
	case WM_DESTROY:
		{
			PostQuitMessage(0);
		}
		return(0);
	case WM_CHAR:
		{
			g_Char=(char)wParam;
		}
		return(0);
	case WM_KEYDOWN:
		{
			if ((lParam&0x4000) == 0) {
				int scan_code=(int)(lParam>>16)&0xFF;
				g_bKey[scan_code]=true;
			}
		}
		return(0);
	case WM_KEYUP:
		{
			int scan_code=(int)(lParam>>16)&0xFF;
			g_bKey[scan_code]=false;
		}
		return(0);
	case WM_MOUSEWHEEL:
		{
			g_WinMouseWheel=(int)wParam>>16;
		}
		return(0);
	case WM_MOUSEMOVE:
		{
			POINT point;
			point.x=GET_X_LPARAM(lParam);
			point.y=GET_Y_LPARAM(lParam);
			ClientToScreen(g_hWnd,&point);
			g_WinMouseX=point.x;
			g_WinMouseY=point.y;
		}
		return(0);
	case WM_LBUTTONDOWN:
		g_WinMouseButtons|=1;
		return(0);
	case WM_LBUTTONUP:
		g_WinMouseButtons&=(~1);
		return(0);
	case WM_RBUTTONDOWN:
		g_WinMouseButtons|=2;
		return(0);
	case WM_RBUTTONUP:
		g_WinMouseButtons&=(~2);
		return(0);
	case WM_MBUTTONDOWN:
		g_WinMouseButtons|=4;
		return(0);
	case WM_MBUTTONUP:
		g_WinMouseButtons&=(~4);
		return(0);
	case 0x0319:	//	media remote
		switch (lParam) {
		case 0x102E0000:	//	play
			g_WinRemote=MEDIA_PLAY;
			break;
		case 0x102F0000:	//	pause
			g_WinRemote=MEDIA_PAUSE;
			break;
		case 0x000D0000:	//	stop
			g_WinRemote=MEDIA_STOP;
			break;
		}
		break;
	default:
		if (g_uQueryCancelAutoPlay == 0) {
			g_uQueryCancelAutoPlay=RegisterWindowMessage("QueryCancelAutoPlay");
		}
		if (umsg != 0 && umsg == g_uQueryCancelAutoPlay) {
			g_AutoInsert=true;
			return(TRUE);
		}
		break;
	}
	return(DefWindowProc(hwnd,umsg,wParam,lParam));
}

void
AppCreateWindow()
{
	WNDCLASSEX wnd_class;
	wnd_class.cbSize=sizeof(WNDCLASSEX);
	wnd_class.style=0;
	wnd_class.lpfnWndProc=MsgProc;
	wnd_class.cbClsExtra=0;
	wnd_class.cbWndExtra=0;
	wnd_class.hInstance=g_hInstance;
	wnd_class.hIcon=LoadIcon(g_hInstance,IDI_APPLICATION);
	wnd_class.hCursor=LoadCursor(g_hInstance,IDC_ARROW);
	wnd_class.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	wnd_class.lpszMenuName=NULL;
	wnd_class.lpszClassName=g_GameName;
	wnd_class.hIconSm=NULL;
	if (RegisterClassEx(&wnd_class) != 0) {
		RECT rect;
		GetWindowRect(GetDesktopWindow(),&rect);
		int width=rect.right-rect.left;
		int height=rect.bottom-rect.top;
		GameAppGetWindowSize(width,height);
		int x,y;
		x=((rect.right-rect.left)/2)-(width/2);
		y=((rect.bottom-rect.top)/2)-(height/2);
		g_hWnd=CreateWindowEx(0,g_GameName,g_GameName,WS_POPUP,x,y,width,height,NULL,NULL,g_hInstance,NULL);
		if (g_hWnd != NULL) {
			ShowWindow(g_hWnd,SW_SHOW);
			UpdateWindow(g_hWnd);
		}
		g_WindowWidth=width;
		g_WindowHeight=height;
	}
}

void
AppDestroyWindow()
{
	if (g_hWnd != NULL) {
		DestroyWindow(g_hWnd);
	}
}

void
AppStartTime()
{
	char time_str[9],date_str[9];
	_strtime(time_str);
	_strdate(date_str);
//	Log("Application started on %s @ %s",date_str,time_str);
}

void
AppStopTime()
{
	char time_str[9],date_str[9];
	_strtime(time_str);
	_strdate(date_str);
	Log("Application stopped on %s @ %s",date_str,time_str);
}

void
MainLoop()
{
	MSG msg;
	ResetTimer();
	while (g_bAppActive) {
		if (g_bHasFocus) {
			while (PeekMessage(&msg,g_hWnd,0,0,PM_REMOVE)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else {
			if (GetMessage(&msg,g_hWnd,0,0)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		if (g_bAppActive) {
			float delta_time=GetTimerDelta(g_LastTime);
			if (delta_time > 0) {
				delta_time=__min(delta_time,0.033f);
				GameAppUpdateFrame(delta_time);
				g_WinMouseWheel=0;
			}
		}
	}
}

int WINAPI
WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmd)
{
	HWND hwnd=FindWindow(g_GameName,NULL);
	if (hwnd != NULL) {
		MessageBox(NULL,"A game is already in progress",g_GameName,MB_OK|MB_ICONEXCLAMATION|MB_SYSTEMMODAL);
		exit(0);
	}

	SetErrorMode(SEM_NOOPENFILEERRORBOX|SEM_FAILCRITICALERRORS);

	BOOL low_power;
	SystemParametersInfo(SPI_GETLOWPOWERACTIVE,0,&low_power,0);
	SystemParametersInfo(SPI_SETLOWPOWERACTIVE,0,NULL,0);
	BOOL power_off;
	SystemParametersInfo(SPI_GETPOWEROFFACTIVE,0,&power_off,0);
	SystemParametersInfo(SPI_SETPOWEROFFACTIVE,0,NULL,0);
	BOOL screen_save;
	SystemParametersInfo(SPI_GETSCREENSAVEACTIVE,0,&screen_save,0);
	SystemParametersInfo(SPI_SETSCREENSAVEACTIVE,0,NULL,0);

	srand((unsigned)time(NULL));

	QueryPerformanceFrequency(&g_PerfFreq);
	ResetTimer();

	build_sqrt_table();	//	from GameMath.cpp

	remove("debuglog.txt");
	remove("resourcelog.txt");

	AppStartTime();
	g_hInstance=hInstance;

	AppCreateWindow();
	
	GfxInitDirectX();
	GameAppSetWindowSize(g_WindowWidth,g_WindowHeight);
	
	if (g_hWnd != NULL && g_bAppActive) {
		InitGameApp();
		MainLoop();
		UnInitGameApp();
	}

	GfxUnInitDirectX();

	AppDestroyWindow();
	AppStopTime();

	if (low_power) {
		SystemParametersInfo(SPI_SETLOWPOWERACTIVE,1,NULL,0);
	}
	if (power_off) {
		SystemParametersInfo(SPI_SETPOWEROFFACTIVE,1,NULL,0);
	}
	if (screen_save) {
		SystemParametersInfo(SPI_SETSCREENSAVEACTIVE,1,NULL,0);
	}

	SetErrorMode(0);

	return(0);
}

char
GetChar()
{
	char c=g_Char;
	g_Char=0;
	return(c);
}

char
PeekChar()
{
	return(g_Char);
}

bool
GetKey(int scan_code)
{
	if (g_bKey[scan_code]) {
		g_bKey[scan_code]=false;
		return(true);
	}
	return(false);
}

bool
PeekKey(int scan_code)
{
	return(g_bKey[scan_code]);
}

long
Random(long max_num)
{
	float r=float(rand())/RAND_MAX;
	long rnum=long(r*max_num);
	return(rnum);
}

char g_LastLog[256];

void
Log(char *fmt,...)
{
	char buf[256];
	va_list argptr;

	if (g_bLogEnable) {
		FILE *fp=fopen("debuglog.txt","a");
		if (fp != NULL) {
			va_start(argptr,fmt);
			vsprintf(buf,fmt,argptr);
			va_end(argptr);
			fprintf(fp,"%s\n",buf);
			fclose(fp);
			sprintf(g_LastLog,"%s",buf);
		}
	}
}

void
LogResource(char *fmt,...)
{
	va_list argptr;

	if (g_bLogEnable) {
		FILE *fp=fopen("resourcelog.txt","a");
		if (fp != NULL) {
			va_start(argptr,fmt);
			vfprintf(fp,fmt,argptr);
			fprintf(fp,"\n");
			va_end(argptr);
			fclose(fp);
		}
	}
}
