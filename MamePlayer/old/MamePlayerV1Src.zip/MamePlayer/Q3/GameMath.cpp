// GameMath.cpp: 3D math utility functions
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

unsigned int		fast_sqrt_table[0x10000];	// declare table of square roots 

typedef union FastSqrtUnion
{
	float			f;
	unsigned int	i;
} FastSqrtUnion;

void
build_sqrt_table()
{
	unsigned int i;
	FastSqrtUnion s;

	for (i = 0; i <= 0x7FFF; i++) {
		// Build a float with the bit pattern i as mantissa
		//  and an exponent of 0, stored as 127
		s.i = (i << 8) | (0x7F << 23);
		s.f = (float)sqrt(s.f);
		// Take the square root then strip the first 7 bits of
		//  the mantissa into the table
		fast_sqrt_table[i + 0x8000] = (s.i & 0x7FFFFF);
		// Repeat the process, this time with an exponent of 1, 
		//  stored as 128
		s.i = (i << 8) | (0x80 << 23);
		s.f = (float)sqrt(s.f);
		fast_sqrt_table[i] = (s.i & 0x7FFFFF);
	}
}

D3DXVECTOR3
MatrixToAngleDegree(D3DXMATRIX mat)
{
	D3DXVECTOR3 rot;
	if (mat._12 == 0 && mat._22 == 0) {
		rot.y=0;
		rot.z=AWE_ANGLE_360(D3DXToDegree(atan2f(mat._21,mat._11)));
	}
	else {
		rot.y=AWE_ANGLE_360(D3DXToDegree(atan2f(mat._31,mat._33)));
		rot.z=AWE_ANGLE_360(D3DXToDegree(atan2f(-mat._12,mat._22)));
	}
	rot.x=AWE_ANGLE_360(D3DXToDegree(asinf(-mat._32)));
	return(rot);
}

D3DXVECTOR3
MatrixToPosition(D3DXMATRIX mat)
{
	return(D3DXVECTOR3(mat._41,mat._42,mat._43));
}

D3DXVECTOR3
VectorToAngleDegree(D3DXVECTOR3 dir_vec)
{
	D3DXVec3Normalize(&dir_vec,&dir_vec);
	float deg_y=D3DXToDegree(atan2f(dir_vec.x,dir_vec.z));
	float deg_x=D3DXToDegree(asinf(-dir_vec.y));
	float deg_z=0;
	return(D3DXVECTOR3(deg_x,deg_y,deg_z));
}

D3DXVECTOR3
VectorToAngleDegree(D3DXVECTOR3 start_pos,D3DXVECTOR3 end_pos)
{
	D3DXVECTOR3 dir_vec=AWE_DIR_VEC(start_pos,end_pos);
	return(VectorToAngleDegree(dir_vec));
}

D3DXVECTOR3
VectorToAngleRadian(D3DXVECTOR3 dir_vec)
{
	D3DXVec3Normalize(&dir_vec,&dir_vec);
	float rad_y=(atan2f(dir_vec.x,dir_vec.z));
	float rad_x=(asinf(-dir_vec.y));
	float rad_z=0;
	return(D3DXVECTOR3(rad_x,rad_y,rad_z));
}

D3DXVECTOR3
VectorToAngleRadian(D3DXVECTOR3 start_pos,D3DXVECTOR3 end_pos)
{
	D3DXVECTOR3 dir_vec=AWE_DIR_VEC(start_pos,end_pos);
	return(VectorToAngleRadian(dir_vec));
}
