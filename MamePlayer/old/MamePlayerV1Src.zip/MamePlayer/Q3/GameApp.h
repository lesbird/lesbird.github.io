// FrameApp.h: interface for the CFrameApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRAMEAPP_H__4F98796A_226A_47EE_A0F6_0A88EEDAFB4F__INCLUDED_)
#define AFX_FRAMEAPP_H__4F98796A_226A_47EE_A0F6_0A88EEDAFB4F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

#define	LOCKED_RATE		0

#if LOCKED_RATE
#define	FRAME_TIME		(0.0167f)
#else
#define	FRAME_TIME		(delta_time)
#endif

class CGameApp  
{
public:
	CGameApp();
	virtual ~CGameApp();

	virtual void		InitApp();
	virtual void		UnInitApp();
	virtual void		RemoveGameObject(CGameObject *gobj);

	virtual void		ResetDevice();
	virtual void		ResetGameObject(CGameObject *gobj);
	virtual void		LostDevice();
	virtual void		LostGameObject(CGameObject *gobj);

	virtual void		KeyPress(unsigned int c);
	virtual void		KeyRelease(unsigned int c);

	virtual void		LoadScriptFile(const char *file_name);
	virtual char *		LoadScriptFileCallback(const char *file_name,int &script_size,int &script_status);
	virtual void		ExecScriptFile(const char *file_name);

	virtual void		InitGame();
	virtual void		UnInitGame();

	virtual void		UpdateGame(float delta_time);

	virtual void		UpdateApp(float delta_time);

	virtual void		UpdateGameObjects(float delta_time);
	virtual void		UpdateGameObject(class CGameObject *gobj,float delta_time);

	virtual bool		CullObject(CGameObject *gobj);
	virtual void		RenderGameObjects();
	virtual void		RenderTransObjects();
	virtual void		RenderOrthoObjects();
	virtual void		RenderGameObject(class CGameObject *gobj);

	virtual void		RenderText(void *text_renderer);

public:
	bool				m_bRenderScene;

	float				m_GameTime;

	char *				m_ScriptCode;
	int					m_ScriptSize;
	int					m_ScriptStatus;
	char *				m_TexXformScript;
	int					m_TexXformScriptSize;
	int					m_TexXformScriptStatus;
};

extern
bool					g_bWindowedMode;

extern
bool					g_bCullObjects;
extern
bool					g_bFreeCamera;
extern
bool					g_bUpdateObjects;
extern
bool					g_bUpdatePhysics;
extern
bool					g_bSpecialKeys;

extern
CGameApp *				g_GameApp;

extern
void					InitGameApp();
extern
void					UnInitGameApp();

extern
void					RenderGameObjects();
extern
void					RenderTransObjects();

#endif // !defined(AFX_FRAMEAPP_H__4F98796A_226A_47EE_A0F6_0A88EEDAFB4F__INCLUDED_)
