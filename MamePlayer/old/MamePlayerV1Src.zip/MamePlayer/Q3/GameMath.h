// 3DMath.h: interface for the C3DMath class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DMATH_H__53DCA9A5_5986_40D6_BBEB_4C891F70206E__INCLUDED_)
#define AFX_3DMATH_H__53DCA9A5_5986_40D6_BBEB_4C891F70206E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	AWE_DIR_VEC(s,e)	(e-s)
#define	AWE_PI				D3DX_PI
#define	AWE_ANGLE_360(a)	((a >= 360) ? a-360 : (a < 0) ? 360+a : a)

//	Fast math functions from NVidia's public domain fastmath.cpp
#define FP_BITS(fp)			(*(DWORD *)&(fp))
#define FP_ABS_BITS(fp)		(FP_BITS(fp)&0x7FFFFFFF)
#define FP_SIGN_BIT(fp)		(FP_BITS(fp)&0x80000000)
#define FP_ONE_BITS			0x3F800000
// r = 1/p
#define FP_INV(r,p)                                                          \
{                                                                            \
    int _i = 2 * FP_ONE_BITS - *(int *)&(p);                                 \
    r = *(float *)&_i;                                                       \
    r = r * (2.0f - (p) * r);                                                \
}

#define FP_EXP(e,p)                                                          \
{                                                                            \
    int _i;                                                                  \
    e = -1.44269504f * (float)0x00800000 * (p);                              \
    _i = (int)e + 0x3F800000;                                                \
    e = *(float *)&_i;                                                       \
}

#define FP_NORM_TO_BYTE(i,p)                                                 \
{                                                                            \
    float _n = (p) + 1.0f;                                                   \
    i = *(int *)&_n;                                                         \
    if (i >= 0x40000000)     i = 0xFF;                                       \
    else if (i <=0x3F800000) i = 0;                                          \
    else i = ((i) >> 15) & 0xFF;                                             \
}

inline unsigned long FP_NORM_TO_BYTE2(float p)                                                 
{                                                                            
  float fpTmp = p + 1.0f;                                                      
  return ((*(unsigned *)&fpTmp) >> 15) & 0xFF;  
}

inline unsigned long FP_NORM_TO_BYTE3(float p)     
{
  float ftmp = p + 12582912.0f;                                                      
  return ((*(unsigned long *)&ftmp) & 0xFF);
}

extern
void			build_sqrt_table();

extern
unsigned int	fast_sqrt_table[];

inline float fastsqrt(float n)
{
	if (FP_BITS(n) == 0)
		return 0.0;	// check for square root of 0
	FP_BITS(n) = fast_sqrt_table[(FP_BITS(n) >> 8) & 0xFFFF] | ((((FP_BITS(n) - 0x3F800000) >> 1) + 0x3F800000) & 0x7F800000);
	return n;
}

// At the assembly level the recommended workaround for the second FIST bug is the same for the first; 
// inserting the FRNDINT instruction immediately preceding the FIST instruction. 

__forceinline void FloatToInt(int *int_pointer, float f) 
{
	__asm  fld  f
	__asm  mov  edx,int_pointer
	__asm  FRNDINT
	__asm  fistp dword ptr [edx];
}
//	end of fast math functions from fastmath.cpp

extern
D3DXVECTOR3					MatrixToAngleDegree(D3DXMATRIX mat);
extern
D3DXVECTOR3					MatrixToPosition(D3DXMATRIX mat);

extern
D3DXVECTOR3					VectorToAngleDegree(D3DXVECTOR3 dir_vec);
extern
D3DXVECTOR3					VectorToAngleDegree(D3DXVECTOR3 start_pos,D3DXVECTOR3 end_pos);
extern
D3DXVECTOR3					VectorToAngleRadian(D3DXVECTOR3 dir_vec);
extern
D3DXVECTOR3					VectorToAngleRadian(D3DXVECTOR3 start_pos,D3DXVECTOR3 end_pos);

#endif // !defined(AFX_3DMATH_H__53DCA9A5_5986_40D6_BBEB_4C891F70206E__INCLUDED_)
