// GamePhysics.h: declarations for physics functions
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEPHYSICS_H__881138E0_721E_4E4F_832D_01F40228C88C__INCLUDED_)
#define AFX_GAMEPHYSICS_H__881138E0_721E_4E4F_832D_01F40228C88C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ode/ode.h"
/*
#ifdef _DEBUG
#pragma comment(lib,"OdeVc6-dbg.lib")
#else
#pragma comment(lib,"OdeVc6.lib")
#endif
*/
#pragma comment(lib,"OdeVc6.lib")

#define	VAR_PHYSICS			'PHYS'
#define	VAR_PHYSICS_TYPE	'PHYT'

typedef struct HitRayCollision
{
	float			hit_x;
	float			hit_y;
	float			hit_z;
	float			nor_x;
	float			nor_y;
	float			nor_z;
	float			dist;
	void *			object;
} HitRayCollision_t;

#define	MAX_GEOMS			4

typedef struct PhysicsObject
{
	dBodyID			Body;
	dGeomID			Geom[MAX_GEOMS];
	dJointID		Joint;
} PhysicsObject_t;

typedef list<PhysicsObject_t *>	PhysicsObjectList_t;

extern
PhysicsObjectList_t	PhysicsObjectList;

extern
int					g_BodiesEnabled;

extern
dWorldID			g_World;

extern
dSpaceID			g_Space;

extern
void				InitPhysics();
extern
void				UnInitPhysics();
extern
void				PhyLoadScript(char *file_name);
extern
void				PhyGetGravity(float &x,float &y,float &z);
extern
void				PhySetGravity(float x,float y,float z);
extern
PhysicsObject_t *	PhyCreatePhysicsObject();
extern
void				PhyDeletePhysicsObject(PhysicsObject_t *phys_obj);
extern
void				PhyMakeStatic(PhysicsObject_t *phys_obj);
extern
PhysicsObject_t *	PhyAddBoxCollision(float width,float height,float depth,float mass_kg,bool is_static=false);
extern
PhysicsObject_t *	PhyAddSphereCollision(float radius,float mass_kg,bool is_static=false);
extern
PhysicsObject_t *	PhyAddCylinderCollision(float radius,float height,float mass_kg,bool is_static=false);
extern
PhysicsObject_t *	PhyAddCompoundCollision(unsigned int col_type,PhysicsObject_t *phys_obj,float offset_x,float offset_y,float offset_z,float size_x,float size_y,float size_z,float mass_kg,bool is_static=false);
extern
PhysicsObject_t *	PhyAddTriMeshCollision(float *vertex_data,int num_vertices,int *index_data,int num_indices);
extern
void				PhySetCollisionBits(PhysicsObject_t *phys_obj,unsigned int cat_bits,unsigned int col_bits);
extern
void				PhySetPosition(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyGetPosition(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
extern
void				PhySetQuaternion(PhysicsObject_t *phys_obj,float x,float y,float z,float w);
extern
void				PhyGetQuaternion(PhysicsObject_t *phys_obj,float &x,float &y,float &z,float &w);
extern
void				PhyAddForce(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyAddForceRel(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhySetForce(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyGetForce(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
extern
void				PhyAddTorque(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyAddTorqueRel(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhySetTorque(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyGetTorque(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
extern
void				PhySetVelocity(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyGetVelocity(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
extern
void				PhySetVelocityAng(PhysicsObject_t *phys_obj,float x,float y,float z);
extern
void				PhyGetVelocityAng(PhysicsObject_t *phys_obj,float &x,float &y,float &z);
extern
void				PhyDisable(PhysicsObject_t *phys_obj);
extern
void				PhyEnable(PhysicsObject_t *phys_obj);
extern
void				PhyEnableAll();
extern
void				PhyZeroForces(PhysicsObject_t *phys_obj);
extern
void				PhySetData(PhysicsObject_t *phys_obj,void *data);

extern
void				UpdateWorld(float delta_time);

extern
void				UpdatePhysics(float delta_time);

extern
HitRayCollision_t *	PhyHitRay(dGeomID geom_id,float x,float y,float z,float dir_x,float dir_y,float dir_z,float len,bool first_hit=false);

#endif // !defined(AFX_GAMEPHYSICS_H__881138E0_721E_4E4F_832D_01F40228C88C__INCLUDED_)
