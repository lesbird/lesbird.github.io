// GameScript.cpp: implementation of the CGameScript class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	GAM_LIBNAME	"gam"
#define	INP_LIBNAME	"inp"
#define	MSH_LIBNAME	"msh"
#define	OBJ_LIBNAME	"obj"
#define	PAR_LIBNAME	"par"
#define	PHY_LIBNAME	"phy"
#define	SND_LIBNAME	"snd"
#define	SPR_LIBNAME	"spr"
#define	VEC_LIBNAME	"vec"
/*
typedef list<Script_t *>	ScriptList_t;

static
ScriptList_t	ScriptList;
*/
int		ScriptExecs;

float	ScriptUpdateTime;

CGameScript *	g_GameScript;

int		ScriptMem;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameScript::CGameScript()
{
	m_luaState=lua_open();
	if (m_luaState != NULL) {
		Init();
	}
}

CGameScript::~CGameScript()
{
	if (m_luaState != NULL) {
		lua_close(m_luaState);
		m_luaState=NULL;
	}
}

static
unsigned int
GameScriptStrToVar(const char *str)
{
	if (strlen(str) <= 4) {
		return(StrToVar(str));
	}
	unsigned int v=0;
	for (int i=0 ; i < strlen(str) ; i++) {
		v+=str[i];
	}
	return(v);
}

static
void
GameScriptLog(char *fmt,...)
{
	char buf[256];
	va_list argptr;
	va_start(argptr,fmt);
	vsprintf(buf,fmt,argptr);
	va_end(argptr);
	Log("%s",buf);
}

//	game functions

static
int
GameScriptGamAddDirLight(lua_State *l)
{
	float dir_x=lua_tonumber(l,1);
	float dir_y=lua_tonumber(l,2);
	float dir_z=lua_tonumber(l,3);
	CGameLight *light=new CGameLight;
	light->SetDirection(dir_x,dir_y,dir_z);
	lua_pushlightuserdata(l,light);
	return(1);
}

static
int
GameScriptGamAddPointLight(lua_State *l)
{
	float x=lua_tonumber(l,1);
	float y=lua_tonumber(l,2);
	float z=lua_tonumber(l,3);
	CGameLight *light=new CGameLight;
	light->SetPosition(x,y,z);
	lua_pushlightuserdata(l,light);
	return(1);
}

static
int
GameScriptGamFadeIn(lua_State *l)
{
	float fade_rate=lua_tonumber(l,1);
	float r=lua_tonumber(l,2);
	float g=lua_tonumber(l,3);
	float b=lua_tonumber(l,4);
	float a=lua_tonumber(l,5);
	GfxFadeIn(fade_rate,D3DXCOLOR(a,r,g,b));
	return(0);
}

static
int
GameScriptGamFadeOut(lua_State *l)
{
	float fade_rate=lua_tonumber(l,1);
	float r=lua_tonumber(l,2);
	float g=lua_tonumber(l,3);
	float b=lua_tonumber(l,4);
	float a=lua_tonumber(l,5);
	GfxFadeOut(fade_rate,D3DXCOLOR(a,r,g,b));
	return(0);
}

static
int
GameScriptGamFindObj(lua_State *l)
{
	const char *tag=lua_tolstring(l,1,NULL);
	if (tag != NULL) {
		lua_pushlightuserdata(l,FindTag(tag));
		return(1);
	}
	return(0);
}

static
int
GameScriptGamFindNextObj(lua_State *l)
{
	const char *tag=lua_tolstring(l,1,NULL);
	if (tag != NULL) {
		CGameObject *gobj=(CGameObject *)lua_touserdata(l,2);
		if (gobj != NULL) {
			lua_pushlightuserdata(l,FindNextTag(tag,gobj));
			return(1);
		}
	}
	return(0);
}

static
int
GameScriptGamFreeTexture(lua_State *l)
{
	LPDIRECT3DTEXTURE8 tex=(LPDIRECT3DTEXTURE8)lua_touserdata(l,1);
	GfxFreeTexture(tex);
	return(0);
}

static
int
GameScriptGamFreeTextureName(lua_State *l)
{
	LPDIRECT3DTEXTURE8 tex=GfxGetTexture(lua_tostring(l,1));
	GfxFreeTexture(tex);
	return(0);
}

static
int
GameScriptGamFreeTextures(lua_State *l)
{
	GfxFreeTextureList();
	return(0);
}

static
int
GameScriptGamGetGameTime(lua_State *l)
{
	lua_pushnumber(l,g_GameApp->m_GameTime);
	return(1);
}

static
int
GameScriptGamGetProjection(lua_State *l)
{
	lua_pushnumber(l,g_Fov);
	lua_pushnumber(l,g_Aspect);
	lua_pushnumber(l,g_NearClip);
	lua_pushnumber(l,g_FarClip);
	return(4);
}

static
int
GameScriptGamGetScreenSize(lua_State *l)
{
	lua_pushinteger(l,g_DisplayWidth);
	lua_pushinteger(l,g_DisplayHeight);
	return(2);
}

static
int
GameScriptGamGetView(lua_State *l)
{
	lua_pushnumber(l,g_ViewPos.x);
	lua_pushnumber(l,g_ViewPos.y);
	lua_pushnumber(l,g_ViewPos.z);
	lua_pushnumber(l,g_ViewRot.x);
	lua_pushnumber(l,g_ViewRot.y);
	lua_pushnumber(l,g_ViewRot.z);
	return(6);
}

static
int
GameScriptGamGetViewMatrix(lua_State *l)
{
	D3DXMATRIX *m=&g_ViewMatrix;
	lua_pushlightuserdata(l,m);
	return(1);
}

static
int
GameScriptGamGetViewMatrixInv(lua_State *l)
{
	D3DXMATRIX *m=&g_InvViewMatrix;
	lua_pushlightuserdata(l,m);
	return(1);
}

static
int
GameScriptGamGetViewPos(lua_State *l)
{
	lua_pushnumber(l,g_ViewPos.x);
	lua_pushnumber(l,g_ViewPos.y);
	lua_pushnumber(l,g_ViewPos.z);
	return(3);
}

static
int
GameScriptGamGetViewVectorFwd(lua_State *l)
{
	lua_pushnumber(l,g_ViewFwdVec.x);
	lua_pushnumber(l,g_ViewFwdVec.y);
	lua_pushnumber(l,g_ViewFwdVec.z);
	return(3);
}

static
int
GameScriptGamGetViewVectorRgt(lua_State *l)
{
	lua_pushnumber(l,g_ViewRgtVec.x);
	lua_pushnumber(l,g_ViewRgtVec.y);
	lua_pushnumber(l,g_ViewRgtVec.z);
	return(3);
}

static
int
GameScriptGamGetViewVectorUp(lua_State *l)
{
	lua_pushnumber(l,g_ViewUpVec.x);
	lua_pushnumber(l,g_ViewUpVec.y);
	lua_pushnumber(l,g_ViewUpVec.z);
	return(3);
}

static
int
GameScriptGamIsFadeDone(lua_State *l)
{
	lua_pushboolean(l,GfxFadeDone());
	return(1);
}

static
int
GameScriptGamKillApp(lua_State *l)
{
	g_bAppActive=false;
	return(0);
}

static
int
GameScriptGamLoadFont(lua_State *l)
{
	int font_index=lua_tointeger(l,1);
	const char *font_name=lua_tolstring(l,2,NULL);
	int font_size=lua_tointeger(l,3);
	int font_weight=lua_tointeger(l,4);
	GfxInitFontSystem(font_index,(char *)font_name,font_size,font_weight);
	return(0);
}

static
int
GameScriptGamLoadTexture(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(file_name);
	lua_pushlightuserdata(l,tex);
	return(1);
}

static
int
GameScriptGamLog(lua_State *l)
{
	const char *str=lua_tolstring(l,1,NULL);
	GameScriptLog("SCRIPTLOG: %s",str);
	return(0);
}

static
int
GameScriptGamLookAt(lua_State *l)
{
	float x=lua_tonumber(l,1);
	float y=lua_tonumber(l,2);
	float z=lua_tonumber(l,3);
	float x2=lua_tonumber(l,4);
	float y2=lua_tonumber(l,5);
	float z2=lua_tonumber(l,6);
	GfxSetLookAt(D3DXVECTOR3(x,y,z),D3DXVECTOR3(x2,y2,z2),D3DXVECTOR3(0,1,0));
	return(0);
}

static
int
GameScriptGamMakeArgb(lua_State *l)
{
	int a=lua_tointeger(l,1);
	int r=lua_tointeger(l,2);
	int g=lua_tointeger(l,3);
	int b=lua_tointeger(l,4);
	unsigned int color_argb=(a<<24)|(r<<16)|(g<<8)|b;
	lua_pushinteger(l,color_argb);
	return(1);
}

static
int
GameScriptGamPrintText(lua_State *l)
{
	int font=lua_tointeger(l,1);
	int x=lua_tointeger(l,2);
	int y=lua_tointeger(l,3);
	float r=lua_tonumber(l,4);
	float g=lua_tonumber(l,5);
	float b=lua_tonumber(l,6);
	float a=lua_tonumber(l,7);
	const char *s=lua_tolstring(l,8,NULL);
	GfxPrintText(font,x,y,D3DXCOLOR(r,g,b,a),s);
	return(0);
}

static
int
GameScriptGamPrintTextLen(lua_State *l)
{
	int font=lua_tointeger(l,1);
	const char *s=lua_tolstring(l,2,NULL);
	int len=GfxPrintTextLen(font,(char *)s);
	lua_pushinteger(l,len);
	return(1);
}

static
int
GameScriptGamPrintTextWorld(lua_State *l)
{
	int font=lua_tointeger(l,1);
	int x=lua_tointeger(l,2);
	int y=lua_tointeger(l,3);
	int z=lua_tointeger(l,4);
	float scale=lua_tonumber(l,5);
	D3DXCOLOR color_rgba(lua_tonumber(l,6),lua_tonumber(l,7),lua_tonumber(l,8),lua_tonumber(l,9));
	const char *s=lua_tolstring(l,10,NULL);
	GfxPrintTextWorld(font,x,y,z,scale,color_rgba,s);
	return(0);
}

static
int
GameScriptGamPtrIsEq(lua_State *l)
{
	void *ptr1=lua_touserdata(l,1);
	void *ptr2=lua_touserdata(l,2);
	if (ptr1 == ptr2) {
		lua_pushboolean(l,true);
	}
	else {
		lua_pushboolean(l,false);
	}
	return(1);
}

static
int
GameScriptGamPtrIsNil(lua_State *l)
{
	void *ptr=lua_touserdata(l,1);
	if (ptr == NULL) {
		lua_pushboolean(l,true);
	}
	else {
		lua_pushboolean(l,false);
	}
	return(1);
}

static
int
GameScriptGamPtrIsValid(lua_State *l)
{
	void *ptr=lua_touserdata(l,1);
	if (ptr != NULL) {
		lua_pushboolean(l,true);
	}
	else {
		lua_pushboolean(l,false);
	}
	return(1);
}

static
int
GameScriptGamScreenToWorldRay(lua_State *l)
{
	D3DXVECTOR3 world_ray=ScreenToWorldRay(lua_tonumber(l,1),lua_tonumber(l,2));
	lua_pushnumber(l,world_ray.x);
	lua_pushnumber(l,world_ray.y);
	lua_pushnumber(l,world_ray.z);
	return(3);
}

static
int
GameScriptGamSetDisplayMode(lua_State *l)
{
	int w=lua_tointeger(l,1);
	int h=lua_tointeger(l,2);
	bool win=(lua_toboolean(l,3) ? true : false);
	GfxSetDisplayMode(w,h,win);
	return(0);
}

static
int
GameScriptGamSetFog(lua_State *l)
{
	D3DXCOLOR color_rgba(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	float fog_start=lua_tonumber(l,5);
	float fog_end=lua_tonumber(l,6);
	GfxSetFogParams(color_rgba,fog_start,fog_end);
	return(0);
}

static
int
GameScriptGamSetLightColor(lua_State *l)
{
	CGameLight *light=(CGameLight *)lua_touserdata(l,1);
	float r=lua_tonumber(l,2);
	float g=lua_tonumber(l,3);
	float b=lua_tonumber(l,4);
	light->SetColor(r,g,b);
	return(0);
}

static
int
GameScriptGamSetLightDir(lua_State *l)
{
	CGameLight *light=(CGameLight *)lua_touserdata(l,1);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	float z=lua_tonumber(l,4);
	light->SetDirection(x,y,z);
	return(0);
}

static
int
GameScriptGamSetLightPos(lua_State *l)
{
	CGameLight *light=(CGameLight *)lua_touserdata(l,1);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	float z=lua_tonumber(l,4);
	light->SetPosition(x,y,z);
	return(0);
}

static
int
GameScriptGamSetLightProperties(lua_State *l)
{
	CGameLight *light=(CGameLight *)lua_touserdata(l,1);
	float range=lua_tonumber(l,2);
	float atten1=lua_tonumber(l,3);
	float atten2=lua_tonumber(l,4);
	float atten3=lua_tonumber(l,5);
	light->SetProperties(range,atten1,atten2,atten3);
	return(0);
}

static
int
GameScriptGamSetLightRotation(lua_State *l)
{
	CGameLight *light=(CGameLight *)lua_touserdata(l,1);
	float deg_x=lua_tonumber(l,2);
	float deg_y=lua_tonumber(l,3);
	float deg_z=lua_tonumber(l,4);
	light->SetRotation(deg_x,deg_y,deg_z);
	return(0);
}

static
int
GameScriptGamSetProjection(lua_State *l)
{
	float fov=lua_tonumber(l,1);
	float aspect=lua_tonumber(l,2);
	float nearclip=lua_tonumber(l,3);
	float farclip=lua_tonumber(l,4);
	GfxSetProjection(fov,aspect,nearclip,farclip);
	return(0);
}

static
int
GameScriptGamSetShadowLightPos(lua_State *l)
{
	float x=lua_tonumber(l,1);
	float y=lua_tonumber(l,2);
	float z=lua_tonumber(l,3);
	g_ShadowLightPos=D3DXVECTOR3(x,y,z);
	return(0);
}

static
int
GameScriptGamSetView(lua_State *l)
{
	D3DXVECTOR3 pos(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 rot(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	GfxSetView(pos,rot);
	return(0);
}

static
int
GameScriptGamSetViewPos(lua_State *l)
{
	D3DXVECTOR3 pos(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	GfxSetView(pos,g_ViewRot);
	return(0);
}

static
int
GameScriptGamWorldToScreen(lua_State *l)
{
	D3DXVECTOR3 screen_pos=WorldToScreen(D3DXVECTOR3(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3)));
	lua_pushnumber(l,screen_pos.x);
	lua_pushnumber(l,screen_pos.y);
	return(2);
}

//	input functions

static
int
GameScriptInpGetJoyButton(lua_State *l)
{
	int j=lua_tointeger(l,1);
	int n=lua_tointeger(l,2);
	lua_pushboolean(l,GetJoystickButton(j,n));
	return(1);
}

static
int
GameScriptInpGetKey(lua_State *l)
{
	int i=lua_tointeger(l,1);
	lua_pushboolean(l,GetKey(i));
	return(1);
}

static
int
GameScriptInpGetMouseButton(lua_State *l)
{
	int n=lua_tointeger(l,1);
	lua_pushboolean(l,GetMouseButton(n));
	return(1);
}

static
int
GameScriptInpPeekJoyButton(lua_State *l)
{
	int j=lua_tointeger(l,1);
	int n=lua_tointeger(l,2);
	lua_pushboolean(l,PeekJoystickButton(j,n));
	return(1);
}

static
int
GameScriptInpPeekKey(lua_State *l)
{
	int i=lua_tointeger(l,1);
	lua_pushboolean(l,PeekKey(i));
	return(1);
}

static
int
GameScriptInpPeekMouseButton(lua_State *l)
{
	int n=lua_tointeger(l,1);
	lua_pushboolean(l,PeekMouseButton(n));
	return(1);
}

static
int
GameScriptInpGetJoyAxis(lua_State *l)
{
	int j=lua_tointeger(l,1);
	int s=lua_tointeger(l,2);
	D3DXVECTOR3 axis=GetJoystickAxis(j,s);
	lua_pushnumber(l,axis.x);
	lua_pushnumber(l,axis.y);
	lua_pushnumber(l,axis.z);
	return(3);
}

//	mesh object functions

static
int
GameScriptMeshBoxCollision(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	bool is_static=(lua_toboolean(l,2) != 0) ? true : false;
	mesh_obj->AddBoxCollision(is_static);
	return(0);
}

static
int
GameScriptMeshDelCollision(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	mesh_obj->DelCollision();
	return(0);
}

static
int
GameScriptMeshGetColor(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	float r,g,b;
	mesh_obj->GetColor(r,g,b);
	lua_pushnumber(l,r);
	lua_pushnumber(l,g);
	lua_pushnumber(l,b);
	return(3);
}

static
int
GameScriptMeshInitShadowVolume(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	mesh_obj->InitShadowVolume();
	return(0);
}

static
int
GameScriptMeshLoad(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	if (file_name != NULL) {
		CGameMesh *mesh_obj=new CGameMesh;
		mesh_obj->LoadFile(file_name);
		lua_pushlightuserdata(l,mesh_obj);
		return(1);
	}
	return(0);
}

static
int
GameScriptMeshLoadEffect(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	const char *file_name=lua_tolstring(l,2,NULL);
	const char *tech_name=lua_tolstring(l,3,NULL);
	mesh_obj->LoadEffect(file_name,tech_name);
	return(0);
}

static
int
GameScriptMeshMakeBox(lua_State *l)
{
	float x=lua_tonumber(l,1);
	float y=lua_tonumber(l,2);
	float z=lua_tonumber(l,3);
	const char *file_name=lua_tolstring(l,4,NULL);
	if (file_name != NULL) {
		CGameMesh *mesh_obj=new CGameMesh;
		mesh_obj->MakeBox(D3DXVECTOR3(x,y,z),file_name);
		lua_pushlightuserdata(l,mesh_obj);
		return(1);
	}
	return(0);
}

static
int
GameScriptMeshSetColor(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	float r=lua_tonumber(l,2);
	float g=lua_tonumber(l,3);
	float b=lua_tonumber(l,4);
	mesh_obj->SetColor(r,g,b);
	return(0);
}

static
int
GameScriptMeshSetTechnique(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	const char *tech_name=lua_tolstring(l,2,NULL);
	mesh_obj->SetEffectTechnique(tech_name);
	return(0);
}

static
int
GameScriptMeshSetTextureTransform(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	int s=lua_tointeger(l,2);
	int type=lua_tointeger(l,3);
	float rate=lua_tonumber(l,4);
	mesh_obj->SetTextureTransform(s,type,rate);
	return(0);
}

static
int
GameScriptMeshSphereCollision(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	bool is_static=(lua_toboolean(l,2) != 0) ? true : false;
	mesh_obj->AddSphereCollision(is_static);
	return(0);
}

static
int
GameScriptMeshTriMeshCollision(lua_State *l)
{
	CGameMesh *mesh_obj=(CGameMesh *)lua_touserdata(l,1);
	mesh_obj->AddTriMeshCollision();
	return(0);
}

//	game object functions

static
int
GameScriptObjGetBool(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	bool val=GetBool(gobj,v);
	lua_pushboolean(l,val);
	return(1);
}

static
int
GameScriptObjGetCategory(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	unsigned int cat=GetInt(gobj,VAR_CATEGORY);
	lua_pushinteger(l,cat);
	return(1);
}

static
int
GameScriptObjGetFloat(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	float val=GetFloat(gobj,v);
	lua_pushnumber(l,val);
	return(1);
}

static
int
GameScriptObjGetIndex(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushinteger(l,gobj->m_ObjectIndex);
	return(1);
}

static
int
GameScriptObjGetInt(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	unsigned int val=GetInt(gobj,v);
	lua_pushinteger(l,val);
	return(1);
}

static
int
GameScriptObjGetKillTime(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushnumber(l,gobj->m_KillTime);
	return(1);
}

static
int
GameScriptObjGetLifeTime(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float life=gobj->m_LifeTime;
	lua_pushnumber(l,life);
	return(1);
}

static
int
GameScriptObjGetName(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *name=GetVar(gobj,VAR_NAME);
	lua_pushstring(l,name);
	return(1);
}

static
int
GameScriptObjGetPos(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float x,y,z;
	gobj->GetPosition(x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptObjGetPtr(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	void *ptr=GetPtr(gobj,v);
	lua_pushlightuserdata(l,ptr);
	return(1);
}

static
int
GameScriptObjGetQuat(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	float x,y,z,w;
	if (phys_obj != NULL) {
		PhyGetQuaternion(phys_obj,x,y,z,w);
	}
	else {
		gobj->GetQuaternion(x,y,z,w);
	}
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	lua_pushnumber(l,w);
	return(4);
}

static
int
GameScriptObjGetRadius(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float radius=GetFloat(gobj,VAR_RADIUS);
	lua_pushnumber(l,radius);
	return(1);
}

static
int
GameScriptObjGetRot(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float x,y,z;
	gobj->GetRotation(x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptObjGetScale(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float x,y,z;
	gobj->GetScale(x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptObjGetState(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	int state=gobj->m_State;
	lua_pushinteger(l,state);
	return(1);
}

static
int
GameScriptObjGetTag(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushstring(l,gobj->m_Tag);
	return(1);
}

static
int
GameScriptObjGetType(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	unsigned int type=GetInt(gobj,VAR_TYPE);
	lua_pushinteger(l,type);
	return(1);
}

static
int
GameScriptObjGetVar(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	const char *val=GetVar(gobj,v);
	if (val != NULL) {
		lua_pushstring(l,val);
		return(1);
	}
	return(0);
}

static
int
GameScriptObjGetVec(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	D3DXVECTOR3 vec(0,0,0);
	GetVec3(gobj,v,vec.x,vec.y,vec.z);
	lua_pushnumber(l,vec.x);
	lua_pushnumber(l,vec.y);
	lua_pushnumber(l,vec.z);
	return(3);
}

static
int
GameScriptObjGetWorldMat(lua_State *l)
{
	CGameMesh *gobj=(CGameMesh *)lua_touserdata(l,1);
	D3DXMATRIX *m=&gobj->m_WorldMatrix;
	lua_pushlightuserdata(l,m);
	return(1);
}

static
int
GameScriptObjHide(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	Hide(gobj);
	return(0);
}

static
int
GameScriptObjIsAlive(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushboolean(l,GetBool(gobj,VAR_IS_ALIVE));
	return(1);
}

static
int
GameScriptObjIsOrtho(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushboolean(l,GetBool(gobj,VAR_IS_ORTHO));
	return(1);
}

static
int
GameScriptObjIsTag(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *s=lua_tolstring(l,2,NULL);
	if (stricmp(gobj->m_Tag,s) == 0) {
		lua_pushboolean(l,1);
	}
	else {
		lua_pushboolean(l,0);
	}
	return(1);
}

static
int
GameScriptObjIsUnlit(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushboolean(l,GetBool(gobj,VAR_IS_UNLIT));
	return(1);
}

static
int
GameScriptObjIsVisible(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	lua_pushboolean(l,GetBool(gobj,VAR_IS_VISIBLE));
	return(1);
}

static
int
GameScriptObjKill(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	AddBool(gobj,VAR_IS_ALIVE,false);
	gobj->m_KillTime=0;
	return(0);
}

/*
static
int
GameScriptObjMoveOnLift(lua_State *l)
{
	CGameObject *lift_obj=(CGameObject *)lua_touserdata(l,1);
	float mov_y=lua_tonumber(l,2);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(lift_obj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		dGeomID lift_geom=phys_obj->Geom[0];
		for (PhysicsObjectList_t::iterator p=PhysicsObjectList.begin() ; p != PhysicsObjectList.end() ; p++) {
			phys_obj=(*p);
			if (phys_obj->Body != NULL) {
				for (int i=0 ; i < MAX_GEOMS ; i++) {
					if (phys_obj->Geom[i] != NULL) {
						dContactGeom contact;
						if (dCollide(lift_geom,phys_obj->Geom[i],1,&contact,sizeof(dContactGeom)) > 0) {
							const float *pos=dBodyGetPosition(phys_obj->Body);
							dBodySetPosition(phys_obj->Body,pos[0],pos[1]+mov_y,pos[2]);
							break;
						}
					}
				}
			}
		}
	}
	return(0);
}
*/
				
static
int
GameScriptObjSetActive(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	int b=lua_toboolean(l,2);
	AddBool(gobj,VAR_IS_ACTIVE,(b != 0) ? true : false);
	return(0);
}

static
int
GameScriptObjSetAlive(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	AddBool(gobj,VAR_IS_ALIVE,true);
	return(0);
}

static
int
GameScriptObjSetBool(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	int val=lua_toboolean(l,3);
	unsigned int v=GameScriptStrToVar(var);
	AddBool(gobj,v,(val != 0) ? true : false);
	return(0);
}

static
int
GameScriptObjSetCategory(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	unsigned int val=lua_tointeger(l,2);
	AddInt(gobj,VAR_CATEGORY,val);
	return(0);
}

static
int
GameScriptObjSetFloat(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	float val=lua_tonumber(l,3);
	unsigned int v=GameScriptStrToVar(var);
	AddFloat(gobj,v,val);
	return(0);
}

static
int
GameScriptObjSetInt(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int val=lua_tointeger(l,3);
	unsigned int v=GameScriptStrToVar(var);
	AddInt(gobj,v,val);
	return(0);
}

static
int
GameScriptObjSetOrtho(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	int val=lua_toboolean(l,2);
	AddBool(gobj,VAR_IS_ORTHO,(val != 0) ? true : false);
	return(0);
}

static
int
GameScriptObjSetOutline(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	if (GetInt(gobj,VAR_TYPE) == 'MESH') {
		int val=lua_toboolean(l,2);
		CGameMesh *mesh_obj=(CGameMesh *)gobj;
		mesh_obj->m_bOutline=(val != 0) ? true : false;
	}
	return(0);
}

static
int
GameScriptObjSetOutlineParams(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	if (GetInt(gobj,VAR_TYPE) == 'MESH') {
		float r=lua_tonumber(l,2);
		float g=lua_tonumber(l,3);
		float b=lua_tonumber(l,4);
		float a=lua_tonumber(l,5);
		D3DXCOLOR color=D3DXCOLOR(r,g,b,a);
		float thickness=lua_tonumber(l,6);
		CGameMesh *mesh_obj=(CGameMesh *)gobj;
		mesh_obj->m_OutlineColor=color;
		mesh_obj->m_OutlineThickness=thickness;
	}
	return(0);
}

static
int
GameScriptObjSetPos(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	float z=lua_tonumber(l,4);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhySetPosition(phys_obj,x,y,z);
	}
	else {
		gobj->SetPosition(x,y,z);
	}
	return(0);
}

static
int
GameScriptObjSetPtr(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	void *ptr=lua_touserdata(l,3);
	AddPtr(gobj,v,ptr);
	return(0);
}

static
int
GameScriptObjSetQuat(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	D3DXQUATERNION quat;
	quat.x=lua_tonumber(l,2);
	quat.y=lua_tonumber(l,3);
	quat.z=lua_tonumber(l,4);
	quat.w=lua_tonumber(l,5);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhySetQuaternion(phys_obj,quat.x,quat.y,quat.z,quat.w);
	}
	else {
		gobj->SetQuaternion(quat.x,quat.y,quat.z,quat.w);
	}
	return(0);
}

static
int
GameScriptObjSetRot(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	float z=lua_tonumber(l,4);
	D3DXQUATERNION quat;
	D3DXQuaternionRotationYawPitchRoll(&quat,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhySetQuaternion(phys_obj,quat.x,quat.y,quat.z,quat.w);
	}
	else {
		gobj->SetQuaternion(quat.x,quat.y,quat.z,quat.w);
	}
	gobj->SetRotation(x,y,z);
	return(0);
}

static
int
GameScriptObjSetScale(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	gobj->SetScale(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	return(0);
}

static
int
GameScriptObjSetState(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	int state=lua_tointeger(l,2);
	gobj->m_State=state;
	return(0);
}

static
int
GameScriptObjSetTag(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *tag=lua_tolstring(l,2,NULL);
	gobj->SetTag(tag);
	return(0);
}

static
int
GameScriptObjSetUnlit(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	int val=lua_toboolean(l,2);
	AddBool(gobj,VAR_IS_UNLIT,(val != 0) ? true : false);
	return(0);
}

static
int
GameScriptObjSetVar(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	const char *val=lua_tolstring(l,3,NULL);
	unsigned int v=GameScriptStrToVar(var);
	AddVar(gobj,v,val);
	return(0);
}

static
int
GameScriptObjSetVec(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	const char *var=lua_tolstring(l,2,NULL);
	unsigned int v=GameScriptStrToVar(var);
	D3DXVECTOR3 vec(lua_tonumber(l,3),lua_tonumber(l,4),lua_tonumber(l,5));
	AddVec3(gobj,v,vec.x,vec.y,vec.z);
	return(0);
}

static
int
GameScriptObjShow(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	Show(gobj);
	return(0);
}

//	particle functions

static
int
GameScriptParAddParticle(lua_State *l)
{
	ParticleEmitter_t *emitter=(ParticleEmitter_t *)lua_touserdata(l,1);
	if (emitter != NULL) {
		D3DXVECTOR3 pos(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
		D3DXVECTOR3 vel(lua_tonumber(l,5),lua_tonumber(l,6),lua_tonumber(l,7));
		D3DXVECTOR3 acc(lua_tonumber(l,8),lua_tonumber(l,9),lua_tonumber(l,10));
		float life=lua_tonumber(l,11);
		unsigned int color_argb=lua_tointeger(l,12);
		g_Particles->AddParticle(emitter,pos,vel,acc,life,color_argb);
	}
	return(0);
}

static
int
GameScriptParCreateEmitter(lua_State *l)
{
	const char *emitter_name=lua_tolstring(l,1,NULL);
	int num=lua_tointeger(l,2);
	const char *texture_file=lua_tolstring(l,3,NULL);
	float size=lua_tonumber(l,4);
	bool is_s=(lua_toboolean(l,5) ? true : false);
	bool is_w=(lua_toboolean(l,6) ? true : false);
	g_Particles->CreateParticleEmitter(emitter_name,num,texture_file,size,is_s,is_w);
	return(0);
}

static
int
GameScriptParDeleteEmitter(lua_State *l)
{
	const char *emitter_name=lua_tolstring(l,1,NULL);
	ParticleEmitter_t *emitter=g_Particles->FindEmitter(emitter_name);
	if (emitter != NULL) {
		g_Particles->DeleteParticleEmitter(emitter);
	}
	return(0);
}

static
int
GameScriptParFindEmitter(lua_State *l)
{
	static bool find_error=false;

	const char *emitter_name=lua_tolstring(l,1,NULL);
	ParticleEmitter_t *emitter=g_Particles->FindEmitter(emitter_name);
	if (emitter != NULL) {
		lua_pushlightuserdata(l,emitter);
		return(1);
	}
	else if (!find_error) {
		Log("GameScriptParFindEmitter(%s): Failed",emitter_name);
		find_error=true;
	}
	return(0);
}

static
int
GameScriptParResetEmitter(lua_State *l)
{
	const char *emitter_name=lua_tolstring(l,1,NULL);
	ParticleEmitter_t *emitter=g_Particles->FindEmitter(emitter_name);
	if (emitter != NULL) {
		g_Particles->ResetParticleEmitter(emitter);
	}
	return(0);
}

//	physics functions

static
int
GameScriptPhyAddForce(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhyAddForce(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhyAddForceRel(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhyAddForceRel(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhyAddTorque(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhyAddTorque(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhyDisable(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhyDisable(phys_obj);
	}
	return(0);
}

static
int
GameScriptPhyEnable(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhyEnable(phys_obj);
	}
	return(0);
}

static
int
GameScriptPhyEnableAll(lua_State *l)
{
	PhyEnableAll();
	return(0);
}

static
int
GameScriptPhyGetForce(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x,y,z;
		PhyGetForce(phys_obj,x,y,z);
		lua_pushnumber(l,x);
		lua_pushnumber(l,y);
		lua_pushnumber(l,z);
	}
	else {
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
	}
	return(3);
}

static
int
GameScriptPhyGetGravity(lua_State *l)
{
	float x,y,z;
	PhyGetGravity(x,y,z);
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptPhyGetTorque(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x,y,z;
		PhyGetTorque(phys_obj,x,y,z);
		lua_pushnumber(l,x);
		lua_pushnumber(l,y);
		lua_pushnumber(l,z);
	}
	else {
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
	}
	return(3);
}

static
int
GameScriptPhyGetVelocity(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x,y,z;
		PhyGetVelocity(phys_obj,x,y,z);
		lua_pushnumber(l,x);
		lua_pushnumber(l,y);
		lua_pushnumber(l,z);
	}
	else {
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
	}
	return(3);
}

static
int
GameScriptPhyGetVelocityAng(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x,y,z;
		PhyGetVelocityAng(phys_obj,x,y,z);
		lua_pushnumber(l,x);
		lua_pushnumber(l,y);
		lua_pushnumber(l,z);
	}
	else {
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
		lua_pushnumber(l,0);
	}
	return(3);
}

static
HitRayCollision_t *
GameScriptHitRay(CGameObject *instigator,D3DXVECTOR3 pos,D3DXVECTOR3 dir,float closest_len,bool first_hit)
{
	static HitRayCollision_t closest_hit;

	dGeomID closest_geom;
	D3DXVECTOR3 closest_pos,closest_nor;
	CGameObject *closest_obj=NULL;
	for (PhysicsObjectList_t::iterator p=PhysicsObjectList.begin() ; p != PhysicsObjectList.end() ; p++) {
		PhysicsObject_t *phys_obj=(*p);
		CGameObject *gobj=(CGameObject *)dGeomGetData(phys_obj->Geom[0]);
		if (gobj != NULL && gobj != instigator) {
			if (GetBool(gobj,VAR_IS_VISIBLE)) {
				for (int i=0 ; i < MAX_GEOMS ; i++) {
					HitRayCollision_t *hit_ray=PhyHitRay(phys_obj->Geom[i],pos.x,pos.y,pos.z,dir.x,dir.y,dir.z,closest_len,first_hit);
					if (hit_ray != NULL) {
						if (hit_ray->dist <= closest_len) {
							closest_len=hit_ray->dist;
							closest_geom=phys_obj->Geom[i];
							closest_pos=D3DXVECTOR3(hit_ray->hit_x,hit_ray->hit_y,hit_ray->hit_z);
							closest_nor=D3DXVECTOR3(hit_ray->nor_x,hit_ray->nor_y,hit_ray->nor_z);
							closest_obj=(CGameObject *)hit_ray->object;
						}
					}
				}
				if (first_hit && closest_obj != NULL) {
					break;
				}
			}
		}
	}
	if (closest_obj != NULL) {
		closest_hit.object=closest_obj;
		closest_hit.hit_x=closest_pos.x;
		closest_hit.hit_y=closest_pos.y;
		closest_hit.hit_z=closest_pos.z;
		closest_hit.nor_x=closest_nor.x;
		closest_hit.nor_y=closest_nor.y;
		closest_hit.nor_z=closest_nor.z;
		closest_hit.dist=closest_len;
		return(&closest_hit);
	}
	return(NULL);
}

static
int
GameScriptPhyHitRay(lua_State *l)
{
	CGameObject *instigator=(CGameObject *)lua_touserdata(l,1);
	D3DXVECTOR3 pos(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	D3DXVECTOR3 dir(lua_tonumber(l,5),lua_tonumber(l,6),lua_tonumber(l,7));
	float closest_len=lua_tonumber(l,8);

	HitRayCollision_t *hit_ray=GameScriptHitRay(instigator,pos,dir,closest_len,false);
	if (hit_ray != NULL) {
		lua_pushlightuserdata(l,hit_ray->object);
		lua_pushnumber(l,hit_ray->hit_x);
		lua_pushnumber(l,hit_ray->hit_y);
		lua_pushnumber(l,hit_ray->hit_z);
		lua_pushnumber(l,hit_ray->nor_x);
		lua_pushnumber(l,hit_ray->nor_y);
		lua_pushnumber(l,hit_ray->nor_z);
		lua_pushnumber(l,hit_ray->dist);
		return(8);
	}
	lua_pushnil(l);
	return(1);
}

static
int
GameScriptPhyHitRayPtr(lua_State *l)
{
	CGameObject *instigator=(CGameObject *)lua_touserdata(l,1);
	D3DXVECTOR3 pos(lua_tonumber(l,2),lua_tonumber(l,3),lua_tonumber(l,4));
	D3DXVECTOR3 dir(lua_tonumber(l,5),lua_tonumber(l,6),lua_tonumber(l,7));
	float closest_len=lua_tonumber(l,8);

	HitRayCollision_t *hit_ray=GameScriptHitRay(instigator,pos,dir,closest_len,false);
	lua_pushlightuserdata(l,hit_ray);
	return(1);
}

static
int
GameScriptPhyGetRayObj(lua_State *l)
{
	HitRayCollision_t *hit_ray=(HitRayCollision_t *)lua_touserdata(l,1);
	lua_pushlightuserdata(l,hit_ray->object);
	return(1);
}

static
int
GameScriptPhyGetRayPos(lua_State *l)
{
	HitRayCollision_t *hit_ray=(HitRayCollision_t *)lua_touserdata(l,1);
	lua_pushnumber(l,hit_ray->hit_x);
	lua_pushnumber(l,hit_ray->hit_y);
	lua_pushnumber(l,hit_ray->hit_z);
	return(3);
}

static
int
GameScriptPhyGetRayNor(lua_State *l)
{
	HitRayCollision_t *hit_ray=(HitRayCollision_t *)lua_touserdata(l,1);
	lua_pushnumber(l,hit_ray->nor_x);
	lua_pushnumber(l,hit_ray->nor_y);
	lua_pushnumber(l,hit_ray->nor_z);
	return(3);
}

static
int
GameScriptPhyGetRayLen(lua_State *l)
{
	HitRayCollision_t *hit_ray=(HitRayCollision_t *)lua_touserdata(l,1);
	lua_pushnumber(l,hit_ray->dist);
	return(1);
}

static
int
GameScriptPhyLineOfSight(lua_State *l)
{
	D3DXVECTOR3 pos(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 dst(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));

	D3DXVECTOR3 dir=AWE_DIR_VEC(pos,dst);
	float closest_len=D3DXVec3Length(&dir);

	HitRayCollision_t *hit_ray=GameScriptHitRay(NULL,pos,dir,closest_len,true);
	if (hit_ray != NULL) {
		lua_pushboolean(l,false);
	}
	else {
		lua_pushboolean(l,true);
	}
	return(1);
}

static
int
GameScriptPhySetBits(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhySetCollisionBits(phys_obj,lua_tointeger(l,2),lua_tointeger(l,3));
	}
	return(0);
}

static
int
GameScriptPhySetForce(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhySetForce(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhySetGravity(lua_State *l)
{
	float x=lua_tonumber(l,1);
	float y=lua_tonumber(l,2);
	float z=lua_tonumber(l,3);
	PhySetGravity(x,y,z);
	return(0);
}

static
int
GameScriptPhySetTorque(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhySetTorque(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhySetVelocity(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhySetVelocity(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhySetVelocityAng(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		float x=lua_tonumber(l,2);
		float y=lua_tonumber(l,3);
		float z=lua_tonumber(l,4);
		PhySetVelocityAng(phys_obj,x,y,z);
	}
	return(0);
}

static
int
GameScriptPhyZeroForces(lua_State *l)
{
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,1);
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(gobj,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhyZeroForces(phys_obj);
	}
	return(0);
}

//	sound functions

static
int
GameScriptSoundIsName(lua_State *l)
{
	SND_HANDLE handle=(SND_HANDLE)lua_touserdata(l,1);
	const char *name=lua_tolstring(l,2,NULL);
	if (strstr(handle->FileName,name) != NULL) {
		lua_pushboolean(l,1);
	}
	else {
		lua_pushboolean(l,0);
	}
	return(1);
}

static
int
GameScriptSoundIsPlayingFile(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	SND_HANDLE handle=SndGetBuffer((char *)file_name);
	if (handle != NULL) {
		lua_pushboolean(l,SndIsPlaying(handle));
	}
	lua_pushboolean(l,0);
	return(1);
}

static
int
GameScriptSoundIsPlaying(lua_State *l)
{
	SND_HANDLE handle=(SND_HANDLE)lua_touserdata(l,1);
	lua_pushboolean(l,SndIsPlaying(handle));
	return(1);
}

static
int
GameScriptSoundLoop(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,2);
	SND_HANDLE handle=SndLoop((char *)file_name,gobj);
	lua_pushlightuserdata(l,handle);
	return(1);
}

static
int
GameScriptSoundLoopHandle(lua_State *l)
{
	SND_HANDLE handle=(SND_HANDLE)lua_touserdata(l,1);
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,2);
	SndLoopBuffer(handle,gobj);
	return(0);
}

static
int
GameScriptSoundPlay(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,2);
	SND_HANDLE handle=SndPlay((char *)file_name,gobj);
	lua_pushlightuserdata(l,handle);
	return(1);
}

static
int
GameScriptSoundPlayHandle(lua_State *l)
{
	SND_HANDLE handle=(SND_HANDLE)lua_touserdata(l,1);
	CGameObject *gobj=(CGameObject *)lua_touserdata(l,2);
	SndPlayBuffer(handle,gobj);
	return(0);
}

static
int
GameScriptSoundPlayPos(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	float z=lua_tonumber(l,4);
	bool loop=(lua_toboolean(l,5) != 0) ? true : false;
	SND_HANDLE handle=SndPlayPos((char *)file_name,D3DXVECTOR3(x,y,z),loop);
	lua_pushlightuserdata(l,handle);
	return(1);
}

static
int
GameScriptSoundPreCache(lua_State *l)
{
	const char *file_name=lua_tolstring(l,1,NULL);
	SND_HANDLE handle=SndPreCache((char *)file_name);
	lua_pushlightuserdata(l,handle);
	return(1);
}

static
int
GameScriptSoundSetListener(lua_State *l)
{
	float x=lua_tonumber(l,1);
	float y=lua_tonumber(l,2);
	float z=lua_tonumber(l,3);
	float vx=lua_tonumber(l,4);
	float vy=lua_tonumber(l,5);
	float vz=lua_tonumber(l,6);
	SndSetListener(D3DXVECTOR3(x,y,z),D3DXVECTOR3(vx,vy,vz));
	return(0);
}

static
int
GameScriptSoundStop(lua_State *l)
{
	SND_HANDLE handle=(SND_HANDLE)lua_touserdata(l,1);
	SndStop(handle);
	return(0);
}

//	sprite functions

static
int
GameScriptSpriteCreate(lua_State *l)
{
	const char *texture_file=lua_tolstring(l,1,NULL);
	Sprite_t *spr=GfxCreateSprite(texture_file,false);
	lua_pushlightuserdata(l,spr);
	return(1);
}

static
int
GameScriptSpriteCreateWorld(lua_State *l)
{
	const char *texture_file=lua_tolstring(l,1,NULL);
	Sprite_t *spr=GfxCreateSprite(texture_file,true);
	lua_pushlightuserdata(l,spr);
	return(1);
}

static
int
GameScriptSpriteDelete(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	GfxSpriteDelete(spr);
	return(0);
}

static
int
GameScriptSpriteFreeSprites(lua_State *l)
{
	GfxFreeSprites();
	return(0);
}

static
int
GameScriptSpriteGetColor(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	lua_pushnumber(l,spr->Color.r);
	lua_pushnumber(l,spr->Color.g);
	lua_pushnumber(l,spr->Color.b);
	lua_pushnumber(l,spr->Color.a);
	return(4);
}

static
int
GameScriptSpriteGetPos(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	lua_pushnumber(l,spr->Pos.x);
	lua_pushnumber(l,spr->Pos.y);
	lua_pushnumber(l,spr->Pos.z);
	return(3);
}

static
int
GameScriptSpriteGetRot(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	lua_pushnumber(l,spr->Rot.x);
	lua_pushnumber(l,spr->Rot.y);
	lua_pushnumber(l,spr->Rot.z);
	return(3);
}

static
int
GameScriptSpriteGetScale(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	lua_pushnumber(l,spr->Scale.x);
	lua_pushnumber(l,spr->Scale.y);
	return(2);
}

static
int
GameScriptSpriteGetTexture(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	lua_pushlightuserdata(l,spr->Texture);
	return(1);
}

static
int
GameScriptSpriteHide(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	GfxHideSprite(spr);
	return(0);
}

static
int
GameScriptSpriteIsVisible(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	if (spr->IsVis) {
		lua_pushboolean(l,true);
	}
	else {
		lua_pushboolean(l,false);
	}
	return(1);
}

static
int
GameScriptSpriteSetColor(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	float r=lua_tonumber(l,2);
	float g=lua_tonumber(l,3);
	float b=lua_tonumber(l,4);
	float a=lua_tonumber(l,5);
	GfxSetSpriteColor(spr,r,g,b,a);
	return(0);
}

static
int
GameScriptSpriteSetPos(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	float z=lua_tonumber(l,4);
	GfxSetSpritePosition(spr,x,y,z);
	return(0);
}

static
int
GameScriptSpriteSetRot(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	float deg=lua_tonumber(l,2);
	GfxSetSpriteRotation(spr,deg);
	return(0);
}

static
int
GameScriptSpriteSetScale(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	float x=lua_tonumber(l,2);
	float y=lua_tonumber(l,3);
	GfxSetSpriteScale(spr,x,y);
	return(0);
}

static
int
GameScriptSpriteSetTexture(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	const char *texture_file=lua_tolstring(l,2,NULL);
	GfxSetSpriteTexture(spr,texture_file);
	return(0);
}

static
int
GameScriptSpriteShow(lua_State *l)
{
	Sprite_t *spr=(Sprite_t *)lua_touserdata(l,1);
	GfxShowSprite(spr);
	return(0);
}

//	3D vector math functions

static
int
GameScriptVecCross(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 v;
	D3DXVec3Cross(&v,&v1,&v2);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecDir(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 v=AWE_DIR_VEC(v1,v2);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecDot(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	float d=D3DXVec3Dot(&v1,&v2);
	lua_pushnumber(l,d);
	return(1);
}

static
int
GameScriptVecLen(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	float len=D3DXVec3Length(&v);
	lua_pushnumber(l,len);
	return(1);
}

static
int
GameScriptVecLenSq(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	float len=D3DXVec3LengthSq(&v);
	lua_pushnumber(l,len);
	return(1);
}

static
int
GameScriptVecMul(lua_State *l)
{
	D3DXVECTOR3 v1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 v2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	float x=v1.x*v2.x;
	float y=v1.y*v2.y;
	float z=v1.z*v2.z;
	lua_pushnumber(l,x);
	lua_pushnumber(l,y);
	lua_pushnumber(l,z);
	return(3);
}

static
int
GameScriptVecNorm(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVec3Normalize(&v,&v);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecScale(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	float s=lua_tonumber(l,4);
	D3DXVec3Scale(&v,&v,s);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

static
int
GameScriptVecToDeg(lua_State *l)
{
	D3DXVECTOR3 p1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 p2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 deg=VectorToAngleDegree(p1,p2);
	lua_pushnumber(l,deg.x);
	lua_pushnumber(l,deg.y);
	lua_pushnumber(l,deg.z);
	return(3);
}

static
int
GameScriptVecToRad(lua_State *l)
{
	D3DXVECTOR3 p1(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXVECTOR3 p2(lua_tonumber(l,4),lua_tonumber(l,5),lua_tonumber(l,6));
	D3DXVECTOR3 rad=VectorToAngleRadian(p1,p2);
	lua_pushnumber(l,rad.x);
	lua_pushnumber(l,rad.y);
	lua_pushnumber(l,rad.z);
	return(3);
}

static
int
GameScriptVecXform(lua_State *l)
{
	D3DXVECTOR3 v(lua_tonumber(l,1),lua_tonumber(l,2),lua_tonumber(l,3));
	D3DXMATRIX *m=(D3DXMATRIX *)lua_touserdata(l,4);
	D3DXVec3TransformNormal(&v,&v,m);
	lua_pushnumber(l,v.x);
	lua_pushnumber(l,v.y);
	lua_pushnumber(l,v.z);
	return(3);
}

//
//
//

static const
luaL_Reg GamLib[]={
	{"adddirlight",GameScriptGamAddDirLight},
	{"addpointlight",GameScriptGamAddPointLight},
	{"fadein",GameScriptGamFadeIn},
	{"fadeout",GameScriptGamFadeOut},
	{"findobj",GameScriptGamFindObj},
	{"findnextobj",GameScriptGamFindNextObj},
	{"freetexture",GameScriptGamFreeTexture},
	{"freetexturename",GameScriptGamFreeTextureName},
	{"freetextures",GameScriptGamFreeTextures},
	{"getgametime",GameScriptGamGetGameTime},
	{"getprojection",GameScriptGamGetProjection},
	{"getscreensize",GameScriptGamGetScreenSize},
	{"getview",GameScriptGamGetView},
	{"getviewmatrix",GameScriptGamGetViewMatrix},
	{"getviewmatrixinv",GameScriptGamGetViewMatrixInv},
	{"getviewpos",GameScriptGamGetViewPos},
	{"getviewfwd",GameScriptGamGetViewVectorFwd},
	{"getviewrgt",GameScriptGamGetViewVectorRgt},
	{"getviewup",GameScriptGamGetViewVectorUp},
	{"isfadedone",GameScriptGamIsFadeDone},
	{"killapp",GameScriptGamKillApp},
	{"loadfont",GameScriptGamLoadFont},
	{"loadtexture",GameScriptGamLoadTexture},
	{"log",GameScriptGamLog},
	{"lookat",GameScriptGamLookAt},
	{"makeargb",GameScriptGamMakeArgb},
	{"printtext",GameScriptGamPrintText},
	{"printtextlen",GameScriptGamPrintTextLen},
	{"printtextworld",GameScriptGamPrintTextWorld},
	{"ptriseq",GameScriptGamPtrIsEq},
	{"ptrisnil",GameScriptGamPtrIsNil},
	{"ptrisvalid",GameScriptGamPtrIsValid},
	{"screentoworldray",GameScriptGamScreenToWorldRay},
	{"setdisplaymode",GameScriptGamSetDisplayMode},
	{"setfog",GameScriptGamSetFog},
	{"setlightcolor",GameScriptGamSetLightColor},
	{"setlightdir",GameScriptGamSetLightDir},
	{"setlightpos",GameScriptGamSetLightPos},
	{"setlightprop",GameScriptGamSetLightProperties},
	{"setlightrot",GameScriptGamSetLightRotation},
	{"setprojection",GameScriptGamSetProjection},
	{"setshadowlightpos",GameScriptGamSetShadowLightPos},
	{"setview",GameScriptGamSetView},
	{"setviewpos",GameScriptGamSetViewPos},
	{"worldtoscreen",GameScriptGamWorldToScreen},
	{NULL,NULL}
};

static const
luaL_Reg InpLib[]={
	{"getjoybutton",GameScriptInpGetJoyButton},
	{"getkey",GameScriptInpGetKey},
	{"getmousebutton",GameScriptInpGetMouseButton},
	{"peekjoybutton",GameScriptInpPeekJoyButton},
	{"peekkey",GameScriptInpPeekKey},
	{"peekmousebutton",GameScriptInpPeekMouseButton},
	{"getjoyaxis",GameScriptInpGetJoyAxis},
	{NULL,NULL}
};

static const
luaL_Reg MshLib[]={
	{"boxcollision",GameScriptMeshBoxCollision},
	{"delcollision",GameScriptMeshDelCollision},
	{"getcolor",GameScriptMeshGetColor},
	{"initshadowvolume",GameScriptMeshInitShadowVolume},
	{"load",GameScriptMeshLoad},
	{"loadeffect",GameScriptMeshLoadEffect},
	{"makebox",GameScriptMeshMakeBox},
	{"setcolor",GameScriptMeshSetColor},
	{"settechnique",GameScriptMeshSetTechnique},
	{"settexturexform",GameScriptMeshSetTextureTransform},
	{"spherecollision",GameScriptMeshSphereCollision},
	{"trimeshcollision",GameScriptMeshTriMeshCollision},
	{NULL,NULL}
};

static const
luaL_Reg ObjLib[]={
	{"getbool",GameScriptObjGetBool},
	{"getcategory",GameScriptObjGetCategory},
	{"getfloat",GameScriptObjGetFloat},
	{"getindex",GameScriptObjGetIndex},
	{"getint",GameScriptObjGetInt},
	{"getkilltime",GameScriptObjGetKillTime},
	{"getlifetime",GameScriptObjGetLifeTime},
	{"getname",GameScriptObjGetName},
	{"getpos",GameScriptObjGetPos},
	{"getptr",GameScriptObjGetPtr},
	{"getquat",GameScriptObjGetQuat},
	{"getradius",GameScriptObjGetRadius},
	{"getrot",GameScriptObjGetRot},
	{"getscale",GameScriptObjGetScale},
	{"getstate",GameScriptObjGetState},
	{"gettag",GameScriptObjGetTag},
	{"gettype",GameScriptObjGetType},
	{"getvar",GameScriptObjGetVar},
	{"getvec",GameScriptObjGetVec},
	{"getworldmatrix",GameScriptObjGetWorldMat},
	{"hide",GameScriptObjHide},
	{"isalive",GameScriptObjIsAlive},
	{"isortho",GameScriptObjIsOrtho},
	{"istag",GameScriptObjIsTag},
	{"isunlit",GameScriptObjIsUnlit},
	{"isvisible",GameScriptObjIsVisible},
	{"kill",GameScriptObjKill},
//	{"moveonlift",GameScriptObjMoveOnLift},
	{"setactive",GameScriptObjSetActive},
	{"setalive",GameScriptObjSetAlive},
	{"setbool",GameScriptObjSetBool},
	{"setcategory",GameScriptObjSetCategory},
	{"setfloat",GameScriptObjSetFloat},
	{"setint",GameScriptObjSetInt},
	{"setortho",GameScriptObjSetOrtho},
	{"setoutline",GameScriptObjSetOutline},
	{"setoutlineparams",GameScriptObjSetOutlineParams},
	{"setpos",GameScriptObjSetPos},
	{"setptr",GameScriptObjSetPtr},
	{"setquat",GameScriptObjSetQuat},
	{"setrot",GameScriptObjSetRot},
	{"setscale",GameScriptObjSetScale},
	{"setstate",GameScriptObjSetState},
	{"settag",GameScriptObjSetTag},
	{"setunlit",GameScriptObjSetUnlit},
	{"setvar",GameScriptObjSetVar},
	{"setvec",GameScriptObjSetVec},
	{"show",GameScriptObjShow},
	{NULL,NULL}
};

static const
luaL_Reg ParLib[]={
	{"addparticle",GameScriptParAddParticle},
	{"createemitter",GameScriptParCreateEmitter},
	{"deleteemitter",GameScriptParDeleteEmitter},
	{"findemitter",GameScriptParFindEmitter},
	{"resetemitter",GameScriptParResetEmitter},
	{NULL,NULL}
};

static const
luaL_Reg PhyLib[]={
	{"addforce",GameScriptPhyAddForce},
	{"addforcerel",GameScriptPhyAddForceRel},
	{"addtorque",GameScriptPhyAddTorque},
	{"disable",GameScriptPhyDisable},
	{"enable",GameScriptPhyEnable},
	{"enableall",GameScriptPhyEnableAll},
	{"getforce",GameScriptPhyGetForce},
	{"getgravity",GameScriptPhyGetGravity},
	{"getraylen",GameScriptPhyGetRayLen},
	{"getraynor",GameScriptPhyGetRayNor},
	{"getrayobj",GameScriptPhyGetRayObj},
	{"getraypos",GameScriptPhyGetRayPos},
	{"gettorque",GameScriptPhyGetTorque},
	{"getvelocity",GameScriptPhyGetVelocity},
	{"getvelocityang",GameScriptPhyGetVelocityAng},
	{"hitray",GameScriptPhyHitRay},
	{"hitrayptr",GameScriptPhyHitRayPtr},
	{"lineofsight",GameScriptPhyLineOfSight},
	{"setbits",GameScriptPhySetBits},
	{"setforce",GameScriptPhySetForce},
	{"setgravity",GameScriptPhySetGravity},
	{"settorque",GameScriptPhySetTorque},
	{"setvelocity",GameScriptPhySetVelocity},
	{"setvelocityang",GameScriptPhySetVelocityAng},
	{"zeroforces",GameScriptPhyZeroForces},
	{NULL,NULL}
};

static const
luaL_Reg SndLib[]={
	{"isname",GameScriptSoundIsName},
	{"isplayingfile",GameScriptSoundIsPlayingFile},
	{"isplaying",GameScriptSoundIsPlaying},
	{"loop",GameScriptSoundLoop},
	{"loophandle",GameScriptSoundLoopHandle},
	{"play",GameScriptSoundPlay},
	{"playhandle",GameScriptSoundPlayHandle},
	{"playpos",GameScriptSoundPlayPos},
	{"precache",GameScriptSoundPreCache},
	{"setlistener",GameScriptSoundSetListener},
	{"stop",GameScriptSoundStop},
	{NULL,NULL}
};

static const
luaL_Reg SprLib[]={
	{"create",GameScriptSpriteCreate},
	{"createworld",GameScriptSpriteCreateWorld},
	{"delete",GameScriptSpriteDelete},
	{"freesprites",GameScriptSpriteFreeSprites},
	{"getcolor",GameScriptSpriteGetColor},
	{"getpos",GameScriptSpriteGetPos},
	{"getrot",GameScriptSpriteGetRot},
	{"getscale",GameScriptSpriteGetScale},
	{"gettexture",GameScriptSpriteGetTexture},
	{"hide",GameScriptSpriteHide},
	{"isvisible",GameScriptSpriteIsVisible},
	{"setcolor",GameScriptSpriteSetColor},
	{"setpos",GameScriptSpriteSetPos},
	{"setrot",GameScriptSpriteSetRot},
	{"setscale",GameScriptSpriteSetScale},
	{"settexture",GameScriptSpriteSetTexture},
	{"show",GameScriptSpriteShow},
	{NULL,NULL}
};

static const
luaL_Reg VecLib[]={
	{"cross",GameScriptVecCross},
	{"dir",GameScriptVecDir},
	{"dot",GameScriptVecDot},
	{"len",GameScriptVecLen},
	{"lensq",GameScriptVecLenSq},
	{"mul",GameScriptVecMul},
	{"norm",GameScriptVecNorm},
	{"scale",GameScriptVecScale},
	{"todeg",GameScriptVecToDeg},
	{"torad",GameScriptVecToRad},
	{"xform",GameScriptVecXform},
	{NULL,NULL}
};

void
CGameScript::Init()
{
	luaopen_math(m_luaState);
	luaopen_string(m_luaState);
	luaL_register(m_luaState,GAM_LIBNAME,GamLib);
	luaL_register(m_luaState,INP_LIBNAME,InpLib);
	luaL_register(m_luaState,MSH_LIBNAME,MshLib);
	luaL_register(m_luaState,OBJ_LIBNAME,ObjLib);
	luaL_register(m_luaState,PAR_LIBNAME,ParLib);
	luaL_register(m_luaState,PHY_LIBNAME,PhyLib);
	luaL_register(m_luaState,SND_LIBNAME,SndLib);
	luaL_register(m_luaState,SPR_LIBNAME,SprLib);
	luaL_register(m_luaState,VEC_LIBNAME,VecLib);
}
/*
void
CGameScript::FreeAll()
{
	while (ScriptList.size() > 0) {
		Script_t *script=(*ScriptList.begin());
		ScriptMem-=script->Size;
		delete script->Code;
		delete script;
		ScriptList.pop_front();
	}
}
*/
char *
CGameScript::LoadFile(const char *file_name,int &size)
{
	char file_to_open[256];
	strcpy(file_to_open,file_name);
	strlwr(file_to_open);
	char *ptr=strstr(file_to_open,".lua");
	if (ptr != NULL) {
		strcpy(ptr,".lcp");
	}
	else {
		strcat(file_to_open,".lcp");
	}
/*
	for (ScriptList_t::iterator s=ScriptList.begin() ; s != ScriptList.end() ; s++) {
		Script_t *script=(*s);
		if (strcmp(script->ScriptFile,file_name) == 0) {
			size=script->ScriptSize;
			return(script->ScriptCode);
		}
	}
*/
	unsigned long buf_size=0;
	char *buf=(char *)g_GameFile->GetFile(file_to_open,&buf_size);
	if (buf == NULL) {
		char *ptr=strstr(file_to_open,".lcp");
		if (ptr != NULL) {
			strcpy(ptr,".lua");
			buf=(char *)g_GameFile->GetFile(file_to_open,&buf_size);
		}
		if (buf == NULL) {
			Log("GameScript->LoadFile(%s): Failed",file_to_open);
		}
	}
/*
	if (buf != NULL) {
		Script_t *script=new Script_t;
		script->ScriptCode=buf;
		script->ScriptSize=buf_size;
		strcpy(script->ScriptFile,file_name);
		strupr(script->ScriptFile);
		ScriptList.push_back(script);
		ScriptMem+=buf_size;
	}
*/
	size=buf_size;
	ScriptMem+=size;
	return(buf);
}

void
CGameScript::FreeScript(char *script_code,int size)
{
	if (script_code != NULL) {
		g_GameFile->FreeFileMem(script_code);
		ScriptMem-=size;
	}
}

void
CGameScript::Update(float delta_time)
{
//	lua_gc(m_luaState,LUA_GCCOLLECT,0);
}

static
void
GameScriptLuaError(lua_State *lua_state,int status)
{
	while (lua_isstring(lua_state,-1)) {
		const char *err_code=lua_tolstring(lua_state,-1,NULL);
		if (err_code != NULL) {
			Log("GAMESCRIPT ERROR: %s",err_code);
		}
		lua_pop(lua_state,1);
	}
}

int
CGameScript::Exec(char *script_code,int script_size)
{
	LARGE_INTEGER script_time=GetTimer();
	int status=luaL_loadbuffer(m_luaState,script_code,script_size,"Exec");
	if (status == 0) {
		status=lua_pcall(m_luaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_luaState,status);
	}
	ScriptUpdateTime+=GetTimerDelta(script_time);
	ScriptExecs++;
	return(status);
}

int
CGameScript::ExecCollisionCallback(char *script_code,int script_size,CGameObject *gobj1,CGameObject *gobj2,float x,float y,float z,float nor_x,float nor_y,float nor_z,float pen)
{
	LARGE_INTEGER script_time=GetTimer();
	int status=luaL_loadbuffer(m_luaState,script_code,script_size,"GameColl");
	if (status == 0) {
		lua_pushlightuserdata(m_luaState,gobj1);
		lua_setglobal(m_luaState,"gobj1");
		lua_pushlightuserdata(m_luaState,gobj2);
		lua_setglobal(m_luaState,"gobj2");
		lua_pushnumber(m_luaState,x);
		lua_setglobal(m_luaState,"hit_x");
		lua_pushnumber(m_luaState,y);
		lua_setglobal(m_luaState,"hit_y");
		lua_pushnumber(m_luaState,z);
		lua_setglobal(m_luaState,"hit_z");
		lua_pushnumber(m_luaState,nor_x);
		lua_setglobal(m_luaState,"nor_x");
		lua_pushnumber(m_luaState,nor_y);
		lua_setglobal(m_luaState,"nor_y");
		lua_pushnumber(m_luaState,nor_z);
		lua_setglobal(m_luaState,"nor_z");
		lua_pushnumber(m_luaState,pen);
		lua_setglobal(m_luaState,"pen");
		status=lua_pcall(m_luaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_luaState,status);
	}
	ScriptUpdateTime+=GetTimerDelta(script_time);
	ScriptExecs++;
	return(status);
}

int
CGameScript::ExecDelta(char *script_code,int script_size,float delta_time)
{
	LARGE_INTEGER script_time=GetTimer();
	int status=luaL_loadbuffer(m_luaState,script_code,script_size,"ExecDelta");
	if (status == 0) {
		lua_pushnumber(m_luaState,delta_time);
		lua_setglobal(m_luaState,"delta_time");
		status=lua_pcall(m_luaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_luaState,status);
	}
	ScriptUpdateTime+=GetTimerDelta(script_time);
	ScriptExecs++;
	return(status);
}

int
CGameScript::ExecParam(char *script_code,int script_size,const char *param)
{
	LARGE_INTEGER script_time=GetTimer();
	int status=luaL_loadbuffer(m_luaState,script_code,script_size,"ExecParam");
	if (status == 0) {
		lua_pushlstring(m_luaState,param,strlen(param));
		lua_setglobal(m_luaState,"param");
		status=lua_pcall(m_luaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_luaState,status);
	}
	ScriptUpdateTime+=GetTimerDelta(script_time);
	ScriptExecs++;
	return(status);
}

int
CGameScript::ExecSoundCallback(char *script_code,int script_size,SND_HANDLE buffer)
{
	LARGE_INTEGER script_time=GetTimer();
	int status=luaL_loadbuffer(m_luaState,script_code,script_size,"GameSnd");
	if (status == 0) {
		lua_pushlightuserdata(m_luaState,buffer);
		lua_setglobal(m_luaState,"handle");
		status=lua_pcall(m_luaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_luaState,status);
	}
	ScriptUpdateTime+=GetTimerDelta(script_time);
	ScriptExecs++;
	return(status);
}

int
CGameScript::ExecTick(char *script_code,int script_size,CGameObject *gobj,float delta_time)
{
	LARGE_INTEGER script_time=GetTimer();
	int status=luaL_loadbuffer(m_luaState,script_code,script_size,"ExecTick");
	if (status == 0) {
		lua_pushlightuserdata(m_luaState,gobj);
		lua_setglobal(m_luaState,"gobj");
		lua_pushnumber(m_luaState,delta_time);
		lua_setglobal(m_luaState,"delta_time");
		status=lua_pcall(m_luaState,0,0,0);
	}
	if (status != 0) {
		GameScriptLuaError(m_luaState,status);
	}
	ScriptUpdateTime+=GetTimerDelta(script_time);
	ScriptExecs++;
	return(status);
}

/*
	-- sample minimum lua script

	function tick(gobj,delta_time)
		-- perform tick stuff here
	end

	tick(gobj,delta_time)
*/

void
InitScript()
{
	g_GameScript=new CGameScript;
}

void
UnInitScript()
{
	delete g_GameScript;
	g_GameScript=NULL;
}
