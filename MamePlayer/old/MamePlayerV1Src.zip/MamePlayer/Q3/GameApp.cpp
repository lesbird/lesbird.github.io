// GameApp.cpp: implementation of the CGameApp class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"

#define	BUMP_SCALE_STEP	0.9f
#define	ENV_SCALE_STEP	0.9f
#define	ENV_OFFSET_STEP	0.9f

#ifdef _DEBUG
bool				g_bWindowedMode=true;
#else
bool				g_bWindowedMode=false;
#endif

bool				g_bCullObjects=true;
bool				g_bFreeCamera=false;
bool				g_bUpdateObjects=true;
bool				g_bUpdatePhysics=true;

bool				g_bSpecialKeys=false;

int					g_StatsMode;

static
bool				bShowStats;

static
float				FreeCameraSpeed=100;

static
D3DXVECTOR3			FreeCameraRotation;

static
float				GammaUpdateTime;
static
const char *		GammaUpdateStr;

static
int					MaxTransObjects;

extern
int					PlayingSoundCount;

CGameApp *			g_GameApp;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameApp::CGameApp()
{
	m_bRenderScene=true;

	m_GameTime=0;

	m_ScriptCode=NULL;
	m_ScriptSize=0;
	m_ScriptStatus=0;

	m_TexXformScript=NULL;
	m_TexXformScriptSize=0;
	m_TexXformScriptStatus=0;

	g_GameApp=this;
}

CGameApp::~CGameApp()
{
	g_GameApp=NULL;
}

void
CGameApp::InitApp()
{
	InitFileSystem();

	GfxSetDisplayMode(g_WindowWidth,g_WindowHeight,g_bWindowedMode);

	InitScript();
	InitInput();
	InitParticles();
	InitPhysics();
	InitSound();

	m_GameTime=0;

	ExecScriptFile("appinit.lua");

	InitGame();
}

void
CGameApp::UnInitApp()
{
	while (GameObjectList.size() != 0) {
		CGameObject *gobj=(*GameObjectList.begin());
		RemoveGameObject(gobj);
	}

	UnInitGame();

	ExecScriptFile("appuninit.lua");

	UnInitSound();
	UnInitPhysics();
	UnInitParticles();
	UnInitInput();
	UnInitScript();

	if (m_TexXformScript != NULL) {
		delete m_TexXformScript;
	}

	GfxFreeTextureList();
	GfxUnInitFontSystem();

	UnInitFileSystem();
}

void
CGameApp::RemoveGameObject(CGameObject *gobj)
{
	DeleteGameObject(gobj);
}

void
CGameApp::ResetDevice()
{
	for (GameObjectList_t::iterator g=GameObjectList.begin() ; g != GameObjectList.end() ; g++) {
		CGameObject *gobj=(*g);
		ResetGameObject(gobj);
	}
}

void
CGameApp::ResetGameObject(CGameObject *gobj)
{
	gobj->ResetObject();
}

void
CGameApp::LostDevice()
{
	for (GameObjectList_t::iterator g=GameObjectList.begin() ; g != GameObjectList.end() ; g++) {
		CGameObject *gobj=(*g);
		LostGameObject(gobj);
	}
}

void
CGameApp::LostGameObject(CGameObject *gobj)
{
	gobj->LostObject();
}

void
CGameApp::KeyPress(unsigned int c)
{
}

void
CGameApp::KeyRelease(unsigned int c)
{
}

void
CGameApp::LoadScriptFile(const char *file_name)
{
	if (g_GameScript != NULL) {
		if (m_ScriptCode != NULL) {
			delete m_ScriptCode;
		}
		m_ScriptCode=g_GameScript->LoadFile(file_name,m_ScriptSize);
		m_ScriptStatus=0;
	}
}

char *
CGameApp::LoadScriptFileCallback(const char *file_name,int &script_size,int &script_status)
{
	script_status=0;
	char *script_code=g_GameScript->LoadFile(file_name,script_size);
	return(script_code);
}

void
CGameApp::ExecScriptFile(const char *file_name)
{
	int script_size;
	if (g_GameScript != NULL) {
		char *script_code=g_GameScript->LoadFile(file_name,script_size);
		if (script_code != NULL) {
			g_GameScript->Exec(script_code,script_size);
			delete script_code;
		}
	}
}

void
CGameApp::InitGame()
{
	//	override this function and load game resources here
	ExecScriptFile("gameinit.lua");
	LoadScriptFile("gametick.lua");

	m_TexXformScript=LoadScriptFileCallback("gamexform.lua",m_TexXformScriptSize,m_TexXformScriptStatus);
}

void
CGameApp::UnInitGame()
{
	//	override this function and unload game resources here
	ExecScriptFile("gameuninit.lua");
}

void
CGameApp::UpdateGame(float delta_time)
{
	//	override this function and update game objects here
	if (g_GameScript != NULL) {
		if (m_ScriptCode != NULL) {
			if (m_ScriptStatus == 0) {
				m_ScriptStatus=g_GameScript->ExecDelta(m_ScriptCode,m_ScriptSize,delta_time);
			}
		}
	}
}

/*
enum {
	UTA_GAME,
	UTA_OBJECTS,
	UTA_PARTICLES,
	UTA_PHYSICS,
	UTA_RAYS,
	UTA_SCRIPTS,
	UTA_SHADOWS,
	UTA_SOUNDS,
	UTA_RENDER,
	UTA_MAX
};

static
int		UpdateTimeFrame;
static
float	UpdateTimeArray[32][UTA_MAX];
*/

static
float	PhysicsUpdateTime;

static
float	ObjectUpdateTime;

static
float	GameUpdateTime;

static
float	ParticleUpdateTime;

static
float	SoundUpdateTime;

extern
float	ScriptUpdateTime;
extern
int		ScriptExecs;
extern
float	PhysicsHitRayTime;

extern
float	RenderUpdateTime;

extern
float	ShadowUpdateTime;
extern
int		ShadowUpdateCount;

void
CGameApp::UpdateApp(float delta_time)
{
	PhysicsHitRayTime=0;
	m_GameTime+=delta_time;
/*
	UpdateInput(delta_time);
	if (GetKey(KEY_TILDE)) {
		g_bSingleStep=(g_bSingleStep ? false : true);
	}
	else if (GetKey(KEY_TAB)) {
		g_bFreeCamera=(g_bFreeCamera ? false : true);
	}
	else if (PeekKey(KEY_BACKSPACE)) {
		delta_time/=10;
	}
	else if (PeekKey(KEY_CTRL)) {
		if (GetKey(KEY_L)) {
			g_bLogEnable=(g_bLogEnable ? false : true);
		}
		else if (GetKey(KEY_F2)) {
			g_bBumpScaleOverride=(g_bBumpScaleOverride ? false : true);
		}
	}
	else if (GetKey(KEY_F1)) {
		g_StatsMode=(g_StatsMode+1)%6;
		if (g_StatsMode != 0) {
			bShowStats=true;
		}
		else {
			bShowStats=false;
		}
	}
	else if (GetKey(KEY_F2)) {
		g_bBumpMapEnable=(g_bBumpMapEnable ? false : true);
	}
	else if (GetKey(KEY_F3)) {
		g_bUseShaders=(g_bUseShaders ? false : true);
	}
	else if (GetKey(KEY_F4)) {
		g_bShowCollision=(g_bShowCollision ? false : true);
	}
	else if (GetKey(KEY_F5)) {
		g_bCullObjects=(g_bCullObjects ? false : true);
	}
	else if (GetKey(KEY_F6)) {
		g_bShadowMapEnable=(g_bShadowMapEnable ? false : true);
	}
//	else if (GetKey(KEY_D)) {
//		g_bDetailMapEnable=(g_bDetailMapEnable ? false : true);
//	}
	else if (GetKey(KEY_PADPLUS)) {
		if (PeekKey(KEY_LSHIFT)) {
			g_EnvOffset/=ENV_OFFSET_STEP;
		}
		else if (PeekKey(KEY_CTRL)) {
			g_BumpScale/=BUMP_SCALE_STEP;
		}
		else {
			g_EnvScale/=ENV_SCALE_STEP;
		}
	}
	else if (GetKey(KEY_PADMINUS)) {
		if (PeekKey(KEY_LSHIFT)) {
			g_EnvOffset*=ENV_OFFSET_STEP;
		}
		else if (PeekKey(KEY_CTRL)) {
			g_BumpScale*=BUMP_SCALE_STEP;
		}
		else {
			g_EnvScale*=ENV_SCALE_STEP;
		}
	}
	if (g_bSingleStep) {
		if (GetKey(KEY_ENTER)) {
			g_bNextStep=true;
		}
	}
	if (g_bFreeCamera) {
		D3DXVECTOR3 mov(0,0,0);
		if (PeekKey(KEY_W)) {
			mov.z=1;
		}
		else if (PeekKey(KEY_S)) {
			mov.z=-1;
		}
		if (PeekKey(KEY_A)) {
			mov.x=-1;
		}
		else if (PeekKey(KEY_D)) {
			mov.x=1;
		}
		FreeCameraSpeed+=g_MouseDelta.z;
		D3DXMATRIX mat;
		D3DXVECTOR3 cam_rot=MatrixToAngleDegree(g_InvViewMatrix);
		cam_rot+=D3DXVECTOR3(g_MouseDelta.y,g_MouseDelta.x,0);
		D3DXMatrixRotationYawPitchRoll(&mat,D3DXToRadian(cam_rot.y),D3DXToRadian(cam_rot.x),0);
		D3DXVec3TransformNormal(&mov,&mov,&mat);
		D3DXVECTOR3 view_pos=g_ViewPos;
		view_pos+=mov*delta_time*FreeCameraSpeed;

		D3DXVECTOR3 look_dir(0,0,1);
		D3DXVec3TransformNormal(&look_dir,&look_dir,&mat);

		GfxSetLookAt(view_pos,view_pos+(look_dir*100),D3DXVECTOR3(0,1,0));
	}
*/

	if (GetKey(KEY_F8)) {
		if (GfxAddGamma(16)) {
			GammaUpdateTime=5;
		}
	}
	else if (GetKey(KEY_F7)) {
		if (GfxAddGamma(-16)) {
			GammaUpdateTime=5;
		}
	}
	if (GammaUpdateTime > 0) {
		GfxPrintTextShadowed(0,0,0,D3DXCOLOR(0,1,0,1),"GAMMA LEVEL %d",(g_GammaLevel+1)/16);
		GammaUpdateTime-=delta_time;
		if (GammaUpdateTime < 0) {
			GammaUpdateTime=0;
		}
	}

	GameUpdateTime=0;
	ParticleUpdateTime=0;
	PhysicsUpdateTime=0;
	ScriptUpdateTime=0;
	ScriptExecs=0;
	if (g_bNextStep) {
		if (g_bUpdatePhysics) {
			LARGE_INTEGER update_physics=GetTimer();
			UpdatePhysics(delta_time*4);
			PhysicsUpdateTime=GetTimerDelta(update_physics);
		}
		LARGE_INTEGER update_game=GetTimer();
		UpdateGame(delta_time);
		GameUpdateTime=GetTimerDelta(update_game);
		if (g_bUpdateObjects) {
			LARGE_INTEGER update_game_objects=GetTimer();
			UpdateGameObjects(delta_time);
			ObjectUpdateTime=GetTimerDelta(update_game_objects);
		}
		LARGE_INTEGER update_particles=GetTimer();
		UpdateParticles(delta_time);
		ParticleUpdateTime=GetTimerDelta(update_particles);
	}
/*
	LARGE_INTEGER update_sound=GetTimer();
	UpdateSound(delta_time);
	SoundUpdateTime=GetTimerDelta(update_sound);
*/
	g_GameScript->Update(delta_time);

	GfxFadeUpdate(delta_time);
	g_bNextStep=!g_bSingleStep;
}

void
CGameApp::UpdateGameObjects(float delta_time)
{
	for (GameObjectList_t::iterator g=GameObjectList.begin() ; g != GameObjectList.end() ; g++) {
		CGameObject *gobj=(*g);
		if (GetBool(gobj,VAR_IS_ACTIVE)) {
			UpdateGameObject(gobj,delta_time);
		}
	}
}

void
CGameApp::UpdateGameObject(CGameObject *gobj,float delta_time)
{
	gobj->UpdateObject(delta_time);
}

static
int					CullCount;

static
GameObjectList_t	RenderPostObjectList;

static
int					NumTransObjects;

static
CGameObject *		RenderTransObjectList[1000];

static
int					NumOrthoObjects;

static
CGameObject *		RenderOrthoObjectList[100];

static
int
GfxSortGameObjects(const void *elem1,const void *elem2)
{
	CGameObject *obj1=(CGameObject *)*((unsigned long *)elem1);
	CGameObject *obj2=(CGameObject *)*((unsigned long *)elem2);
	if (obj1->m_Sort != -1 && obj2->m_Sort != -1) {
		if (obj1->m_Sort < obj2->m_Sort) {
			return(-1);
		}
		else if (obj1->m_Sort > obj2->m_Sort) {
			return(1);
		}
		return(0);
	}
	D3DXVECTOR3 obj1_pos;
	obj1->GetPosition(obj1_pos.x,obj1_pos.y,obj1_pos.z);
	D3DXVECTOR3 obj2_pos;
	obj2->GetPosition(obj2_pos.x,obj2_pos.y,obj2_pos.z);
	D3DXVECTOR3 cam1_dir=AWE_DIR_VEC(g_ViewPos,obj1_pos);
	float obj1_dist=D3DXVec3LengthSq(&cam1_dir);
	D3DXVECTOR3 cam2_dir=AWE_DIR_VEC(g_ViewPos,obj2_pos);
	float obj2_dist=D3DXVec3LengthSq(&cam2_dir);
	if (obj1_dist < obj2_dist) {
		return(1);	//	doing a back-to-front sort
	}
	else if (obj1_dist > obj2_dist) {
		return(-1);
	}
	return(0);
}

bool
CGameApp::CullObject(CGameObject *gobj)
{
	return(false);
}

void
CGameApp::RenderGameObjects()
{
	CullCount=0;
	ShadowUpdateTime=0;
	ShadowUpdateCount=0;
	RenderPostObjectList.clear();
	for (GameObjectList_t::iterator l=LightObjectList.begin() ; l != LightObjectList.end() ; l++) {
		CGameObject *light=(*l);
		RenderGameObject(light);
	}
	for (GameObjectList_t::iterator g=RenderObjectList.begin() ; g != RenderObjectList.end() ; g++) {
		CGameObject *gobj=(*g);
		if (GetInt(gobj,VAR_TYPE) == 'LIGH') {
			continue;
		}
		gobj->PreRenderObject();
		if (GetBool(gobj,VAR_IS_ORTHO)) {
			RenderOrthoObjectList[NumOrthoObjects++]=gobj;
			continue;
		}
		if (GetBool(gobj,VAR_CAN_CULL)) {
			if (CullObject(gobj)) {
				CullCount++;
				continue;
			}
		}
		RenderPostObjectList.push_back(gobj);
		if (GetBool(gobj,VAR_IS_TRANSPARENT)) {
			RenderTransObjectList[NumTransObjects++]=gobj;
			continue;
		}
		RenderGameObject(gobj);
	}
	if (RenderPostObjectList.size() > 0) {	//	post render any shadow volumes
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,false);
		g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,true);
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
#else
		GfxZWriteDisable();
		GfxStencilEnable();
		GfxAlphaBlendEnable();
#endif
		g_D3DDevice->SetRenderState(D3DRS_STENCILFUNC,D3DCMP_ALWAYS);
		g_D3DDevice->SetRenderState(D3DRS_STENCILZFAIL,D3DSTENCILOP_KEEP);
		g_D3DDevice->SetRenderState(D3DRS_STENCILFAIL,D3DSTENCILOP_KEEP);

		g_D3DDevice->SetRenderState(D3DRS_STENCILREF,1);
		g_D3DDevice->SetRenderState(D3DRS_STENCILMASK,0xffffffff);
		g_D3DDevice->SetRenderState(D3DRS_STENCILWRITEMASK,0xffffffff);

		g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_ZERO);
		g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_ONE);
		g_D3DDevice->SetRenderState(D3DRS_SHADEMODE,D3DSHADE_FLAT);

		for (GameObjectList_t::iterator g=RenderPostObjectList.begin() ; g != RenderPostObjectList.end() ; g++) {
			CGameObject *gobj=(*g);
			gobj->PostRenderObject();
		}

		g_D3DDevice->SetRenderState(D3DRS_SHADEMODE,D3DSHADE_GOURAUD);
#if USE_EFFECT_FILE
		g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
		g_D3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
		g_D3DDevice->SetRenderState(D3DRS_STENCILENABLE,false);
		g_D3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,true);
#else
		GfxCullModeCCW();
		GfxStencilDisable();
		GfxZWriteEnable();
#endif
		g_D3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		g_D3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	
		GfxRenderShadowQuad();
	}
	RenderOrthoObjects();
}

void
CGameApp::RenderTransObjects()
{
	MaxTransObjects=NumTransObjects;
	if (NumTransObjects > 0) {
		qsort(RenderTransObjectList,NumTransObjects,sizeof(CGameObject *),GfxSortGameObjects);
		for (int i=0 ; i < NumTransObjects ; i++) {
			RenderGameObject(RenderTransObjectList[i]);
		}
		NumTransObjects=0;
	}
}

void
CGameApp::RenderOrthoObjects()
{
	if (NumOrthoObjects > 0) {
		GfxUpdateOrtho();
		D3DXMATRIX mat;
		D3DXMatrixIdentity(&mat);
		g_D3DDevice->SetTransform(D3DTS_VIEW,&mat);
		for (int i=0 ; i < NumOrthoObjects ; i++) {
			RenderGameObject(RenderOrthoObjectList[i]);
		}
		NumOrthoObjects=0;
		GfxUpdateProjection();
		GfxUpdateView();
	}
}

void
CGameApp::RenderGameObject(CGameObject *gobj)
{
	gobj->RenderObject();
}

void
CGameApp::RenderText(void *text_renderer)
{
}

void
GameAppPauseGame(bool pause_flag)
{
}

extern
void	ComputeFps(float delta_time);

void
GameAppUpdateInput(float delta_time)
{
	UpdateInput(delta_time);
	if (g_bSpecialKeys) {
		if (GetKey(KEY_TILDE)) {
			g_bSingleStep=(g_bSingleStep ? false : true);
		}
		else if (GetKey(KEY_TAB)) {
			g_bFreeCamera=(g_bFreeCamera ? false : true);
		}
		else if (PeekKey(KEY_BACKSPACE)) {
			delta_time/=10;
		}
		else if (PeekKey(KEY_CTRL)) {
			if (GetKey(KEY_L)) {
				g_bLogEnable=(g_bLogEnable ? false : true);
			}
			else if (GetKey(KEY_F2)) {
				g_bBumpScaleOverride=(g_bBumpScaleOverride ? false : true);
			}
		}
	}
	if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F1)) {
		g_StatsMode=(g_StatsMode+1)%7;
		if (g_StatsMode != 0) {
			bShowStats=true;
		}
		else {
			bShowStats=false;
		}
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F2)) {
		g_bBumpMapEnable=(g_bBumpMapEnable ? false : true);
	}
	if (g_bSpecialKeys) {
		if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F3)) {
			g_bUseShaders=(g_bUseShaders ? false : true);
		}
		else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F4)) {
			g_bShowCollision=(g_bShowCollision ? false : true);
		}
		else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F5)) {
			g_bCullObjects=(g_bCullObjects ? false : true);
		}
		else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F6)) {
			g_bShadowMapEnable=(g_bShadowMapEnable ? false : true);
		}
//		else if (GetKey(KEY_D)) {
//			g_bDetailMapEnable=(g_bDetailMapEnable ? false : true);
//		}
		if (GetKey(KEY_PADPLUS)) {
			if (PeekKey(KEY_LSHIFT)) {
				g_EnvOffset/=ENV_OFFSET_STEP;
			}
			else if (PeekKey(KEY_CTRL)) {
				g_BumpScale/=BUMP_SCALE_STEP;
			}
			else {
				g_EnvScale/=ENV_SCALE_STEP;
			}
		}
		else if (GetKey(KEY_PADMINUS)) {
			if (PeekKey(KEY_LSHIFT)) {
				g_EnvOffset*=ENV_OFFSET_STEP;
			}
			else if (PeekKey(KEY_CTRL)) {
				g_BumpScale*=BUMP_SCALE_STEP;
			}
			else {
				g_EnvScale*=ENV_SCALE_STEP;
			}
		}
		if (g_bSingleStep) {
			if (GetKey(KEY_ENTER)) {
				g_bNextStep=true;
			}
		}
		if (g_bFreeCamera) {
			D3DXVECTOR3 mov(0,0,0);
			if (PeekKey(KEY_W)) {
				mov.z=1;
			}
			else if (PeekKey(KEY_S)) {
				mov.z=-1;
			}
			if (PeekKey(KEY_A)) {
				mov.x=-1;
			}
			else if (PeekKey(KEY_D)) {
				mov.x=1;
			}
			FreeCameraSpeed+=g_MouseDelta.z;
			D3DXMATRIX mat;
			D3DXVECTOR3 cam_rot=MatrixToAngleDegree(g_InvViewMatrix);
			cam_rot+=D3DXVECTOR3(g_MouseDelta.y,g_MouseDelta.x,0);
			D3DXMatrixRotationYawPitchRoll(&mat,D3DXToRadian(cam_rot.y),D3DXToRadian(cam_rot.x),0);
			D3DXVec3TransformNormal(&mov,&mov,&mat);
			D3DXVECTOR3 view_pos=g_ViewPos;
			view_pos+=mov*delta_time*FreeCameraSpeed;

			D3DXVECTOR3 look_dir(0,0,1);
			D3DXVec3TransformNormal(&look_dir,&look_dir,&mat);

			GfxSetLookAt(view_pos,view_pos+(look_dir*100),D3DXVECTOR3(0,1,0));
		}
	}
}

void
GameAppUpdateSound(float delta_time)
{
	LARGE_INTEGER update_sound=GetTimer();
	UpdateSound(delta_time);
	SoundUpdateTime=GetTimerDelta(update_sound);
}

void
GameAppUpdateFrame(float delta_time)
{
	bool render_scene=false;
#if LOCKED_RATE
	static float frame_timer;

	frame_timer+=delta_time;
	if (frame_timer >= FRAME_TIME) {
		GameAppUpdateInput(FRAME_TIME);
		while (frame_timer >= FRAME_TIME) {
			GfxResetText();
			g_GameApp->UpdateApp(FRAME_TIME);
			frame_timer-=FRAME_TIME;
		}
		GameAppUpdateSound(FRAME_TIME);
		render_scene=true;
	}
#else
	GfxResetText();
	GameAppUpdateInput(delta_time);
	g_GameApp->UpdateApp(delta_time);
	GameAppUpdateSound(delta_time);
	render_scene=g_GameApp->m_bRenderScene;
#endif
	if (render_scene) {
		if (bShowStats) {
			int polys_sec=0;
			if (delta_time > 0) {
				float psec=float(g_VisiblePolys)/FRAME_TIME;
				FloatToInt(&polys_sec,psec);
			}
			int y=g_DisplayHeight-15;
/*
			if (g_bSingleStep) {
				int f=(UpdateTimeFrame-11);
				if (f < 0) {
					f+=32;
				}
				for (int i=0 ; i < 10 ; i++) {
					float gam_time=UpdateTimeArray[f][UTA_GAME];
					float obj_time=UpdateTimeArray[f][UTA_OBJECTS];
					float par_time=UpdateTimeArray[f][UTA_PARTICLES];
					float phy_time=UpdateTimeArray[f][UTA_PHYSICS];
					float ray_time=UpdateTimeArray[f][UTA_PHYSICS];
					float ren_time=UpdateTimeArray[f][UTA_RENDER];
					float scr_time=UpdateTimeArray[f][UTA_SCRIPTS];
					float sha_time=UpdateTimeArray[f][UTA_SHADOWS];
					float snd_time=UpdateTimeArray[f][UTA_SOUNDS];
					float total_time=obj_time+phy_time+ray_time+gam_time+par_time+snd_time+ren_time+sha_time;
					if (total_time != 0) {
						ComputeFps(total_time);
					}
					int idx=10-i;
					switch (g_StatsMode) {
					case 2:
						GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"LAST_GFX%02d: REN%.04f SHD(%d)%.04f CUL=%d BSCL=%f (F2:Bump %s) (F3:Shader %s)",idx,ren_time,ShadowUpdateCount,sha_time,CullCount,g_BumpScale,g_bBumpMapEnable ? "disable" : "enable",g_bUseShaders ? "disable" : "enable");
						break;
					case 3:
						GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"LAST_TIM%02d: OBJ%.04f PHY%.04f RAY%.04f GAM%.04f PAR%.04f SCR(%d)%.04f SND%.04f REN%.04f TOT%.04f CUL%d",
															idx,obj_time,phy_time,ray_time,gam_time,par_time,ScriptExecs,scr_time,snd_time,ren_time,total_time,CullCount);
						break;
					case 4:
						GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"LAST_PHY%02d: %.04f RAY%.04f CNT%d ENA%d",idx,phy_time,ray_time,PhysicsObjectList.size(),g_BodiesEnabled);
						break;
					case 5:
						GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"CAM: POS=%f,%f,%f FWD=%f,%f,%f FOV=%f CLIP=%f,%f",g_ViewPos.x,g_ViewPos.y,g_ViewPos.z,g_ViewFwdVec.x,g_ViewFwdVec.y,g_ViewFwdVec.z,g_Fov,g_NearClip,g_FarClip);
						break;
					}
					f=(f+1)&0x1F;
					y-=15;
				}
			}
			else {
*/
				float total_time=ObjectUpdateTime+PhysicsUpdateTime+PhysicsHitRayTime+GameUpdateTime+ParticleUpdateTime+SoundUpdateTime+RenderUpdateTime+ShadowUpdateTime;
				if (total_time != 0) {
					ComputeFps(total_time);
				}
				GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"%.02f (%.04f) %d (%d) %d objs %d tobjs %d sprs %d smem",g_FpsAvg,total_time,g_VisiblePolys,polys_sec,GameObjectList.size(),MaxTransObjects,SpriteWorldList.size(),ScriptMem);
				y-=15;
				switch (g_StatsMode) {
				case 2:
					GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"GFX: REN%.04f SHD(%d)%.04f CUL=%d BSCL=%f (F2:Bump %s) (F3:Shader %s)",RenderUpdateTime,ShadowUpdateCount,ShadowUpdateTime,CullCount,g_BumpScale,g_bBumpMapEnable ? "disable" : "enable",g_bUseShaders ? "disable" : "enable");
					y-=15;
					break;
				case 3:
					GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"TIM: OBJ%.04f PHY%.04f RAY: %.04f GAM%.04f PAR%.04f SCR(%d)%.04f SND%.04f REN%.04f TOT%.04f CUL=%d",ObjectUpdateTime,PhysicsUpdateTime,PhysicsHitRayTime,GameUpdateTime,ParticleUpdateTime,ScriptExecs,ScriptUpdateTime,SoundUpdateTime,RenderUpdateTime,total_time,CullCount);
					y-=15;
					break;
				case 4:
					GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"PHY: %.04f RAY: %.04f CNT%d ENA%d",PhysicsUpdateTime,PhysicsHitRayTime,PhysicsObjectList.size(),g_BodiesEnabled);
					y-=15;
					break;
				case 5:
					GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"CAM: POS=%f,%f,%f FWD=%f,%f,%f FOV=%f CLIP=%f,%f",g_ViewPos.x,g_ViewPos.y,g_ViewPos.z,g_ViewFwdVec.x,g_ViewFwdVec.y,g_ViewFwdVec.z,g_Fov,g_NearClip,g_FarClip);
					y-=15;
					break;
				case 6:
					{
						bool envmap=(g_D3DCaps.TextureOpCaps&D3DTOP_BUMPENVMAP) ? true : false;
						bool dot3=(g_D3DCaps.TextureOpCaps&D3DTOP_DOTPRODUCT3) ? true : false;
						GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"CAP: TS=%d TX=%d TW=%d TH=%d EM=%s D3=%s",g_D3DCaps.MaxTextureBlendStages,g_D3DCaps.MaxSimultaneousTextures,g_D3DCaps.MaxTextureWidth,g_D3DCaps.MaxTextureHeight,envmap ? "T" : "F",dot3 ? "T" : "F");
					}
					y-=15;
					break;
				}
				GfxPrintText(0,0,y,D3DXCOLOR(1,1,1,1),"Log: %s",g_LastLog);
//			}
		}
/*
		if (!g_bSingleStep) {
			int f=UpdateTimeFrame&0x1F;
			UpdateTimeArray[f][UTA_GAME]=GameUpdateTime;
			UpdateTimeArray[f][UTA_OBJECTS]=ObjectUpdateTime;
			UpdateTimeArray[f][UTA_PARTICLES]=ParticleUpdateTime;
			UpdateTimeArray[f][UTA_PHYSICS]=PhysicsUpdateTime;
			UpdateTimeArray[f][UTA_RAYS]=PhysicsHitRayTime;
			UpdateTimeArray[f][UTA_SCRIPTS]=ScriptUpdateTime;
			UpdateTimeArray[f][UTA_SHADOWS]=ShadowUpdateTime;
			UpdateTimeArray[f][UTA_SOUNDS]=SoundUpdateTime;
			UpdateTimeArray[f][UTA_RENDER]=RenderUpdateTime;
			UpdateTimeFrame++;
			if (delta_time > 0.017f) {
				g_bSingleStep=true;
			}
		}
*/
		GfxRenderScene();
	}
}

/*	add this function to your app in your CGameApp derived class
void
InitGameApp()
{
	//	if your class is named CGameApp and is derived from CGameApp then use the following code
	CGameApp *app=new CGameApp;
	app->InitApp();
}
*/

void
UnInitGameApp()
{
	if (g_GameApp != NULL) {
		g_GameApp->UnInitApp();
		delete g_GameApp;
	}
}

void
RenderGameObjects()
{
	g_GameApp->RenderGameObjects();
}

void
RenderTransObjects()
{
	g_GameApp->RenderTransObjects();
}
