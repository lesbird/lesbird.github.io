// Gfx.h: interface for the CGfx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GFX_H__3711D85E_137C_4FD3_945A_4D31E3958CB7__INCLUDED_)
#define AFX_GFX_H__3711D85E_137C_4FD3_945A_4D31E3958CB7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <d3dx8.h>
#include "d3dfont.h"

#pragma comment(lib,"d3d8.lib")
#pragma comment(lib,"d3dx8.lib")

#define	USE_EFFECT_FILE	0

typedef struct Texture_s
{
	bool				IsCubeMap;
	char				Filename[128];
	void *				TexturePtr;
} Texture_t;

typedef list<Texture_t *>	TextureList_t;

typedef struct Sprite_s
{
	bool				IsDecal;
	bool				IsTrans;
	bool				IsView;
	bool				IsVis;
	bool				IsWorld;
	D3DXVECTOR3			Pos;
	D3DXVECTOR3			Rot;
	D3DXVECTOR3			Scale;
	D3DXVECTOR2			Size;
	D3DXCOLOR			Color;
	LPDIRECT3DTEXTURE8	Texture;
	char				TextureFile[128];
} Sprite_t;

typedef list<Sprite_t *>	SpriteList_t;

extern
SpriteList_t		SpriteScreenList;
extern
SpriteList_t		SpriteWorldList;

extern
D3DCAPS8			g_D3DCaps;

extern
LPDIRECT3D8			g_D3D;

extern
LPDIRECT3DDEVICE8	g_D3DDevice;

#if USE_EFFECT_FILE
extern
LPD3DXEFFECT		g_D3DXEffect;
#endif

extern
int					CnfDetailLevel;

extern
int					g_GammaLevel;

extern
bool				g_bDeviceLost;

extern
bool				g_bLightingOverride;

extern
bool				g_bBumpMapEnable;
extern
bool				g_bDetailMapEnable;
extern
bool				g_bReflectionMapEnable;
extern
bool				g_bUseShaders;

//	bump mapping parameters
extern
bool				g_bBumpScaleOverride;
extern
float				g_BumpScale;
extern
float				g_EnvScale;
extern
float				g_EnvOffset;

#if USE_EFFECT_FILE
//	effect parameters
extern
bool				g_bHasWorld;
extern
bool				g_bHasWorldTranspose;
extern
bool				g_bHasView;
extern
bool				g_bHasProjection;
extern
bool				g_bHasWorldView;
extern
bool				g_bHasWorldViewTranspose;
extern
bool				g_bHasWorldViewProjection;
extern
bool				g_bHasWorldVector;
extern
bool				g_bHasObjectVector;
extern
bool				g_bHasConstant;
extern
bool				g_bHasNearFar;
extern
bool				g_bHasWorldInverseTranspose;
extern
bool				g_bHasWorldViewInverseTranspose;
extern
bool				g_bHasLight;
extern
bool				g_bHasDirectionalLight;
extern
bool				g_bHasWorldLight;
extern
bool				g_bHasObjectLight;
extern
bool				g_bHasViewLight;
extern
bool				g_bHasTFactor;
extern
bool				g_bHasBumpScale;
extern
bool				g_bHasBase;
extern
bool				g_bHasNormal;
extern
bool				g_bHasEnvironment;
extern
bool				g_bHasNormalizer;
extern
bool				g_bHasGloss;
#else
extern
void				GfxAlphaBlendEnable();
extern
void				GfxAlphaBlendDisable();
extern
void				GfxClipPlaneEnable();
extern
void				GfxClipPlaneDisable();
extern
void				GfxCullModeNone();
extern
void				GfxCullModeCW();
extern
void				GfxCullModeCCW();
extern
void				GfxFogEnable();
extern
void				GfxFogDisable();
extern
void				GfxLightingEnable();
extern
void				GfxLightingDisable();
extern
void				GfxSpecularEnable();
extern
void				GfxSpecularDisable();
extern
void				GfxStencilEnable();
extern
void				GfxStencilDisable();
extern
void				GfxZEnable();
extern
void				GfxZDisable();
extern
void				GfxZWriteEnable();
extern
void				GfxZWriteDisable();
extern
void				GfxSetClipPlane(float a,float b,float c,float d);
#endif

extern
bool				GfxAddGamma(int level);

extern
bool				g_bTextureTransform[];
extern
D3DXMATRIX			g_TextureTransform[];

extern
int					g_DisplayWidth;
extern
int					g_DisplayHeight;

extern
int					g_VisiblePolys;

extern
int					g_Frame;

extern
float				g_Fov;
extern
float				g_Aspect;
extern
float				g_NearClip;
extern
float				g_FarClip;

extern
float				g_FogStart;
extern
float				g_FogEnd;
extern
D3DXCOLOR			g_FogColor;

extern
D3DCOLOR			g_ClearColor;
extern
D3DFORMAT			g_Format;

extern
D3DXVECTOR3			g_ViewPos;
extern
D3DXQUATERNION		g_ViewRot;
extern
D3DXVECTOR3			g_ViewFwdVec;
extern
D3DXVECTOR3			g_ViewRgtVec;
extern
D3DXVECTOR3			g_ViewUpVec;

extern
D3DXMATRIX			g_OrthoMatrix;
extern
D3DXMATRIX			g_ProjectionMatrix;
extern
D3DXMATRIX			g_ViewMatrix;
extern
D3DXMATRIX			g_InvViewMatrix;

extern
DWORD				VectorToRGBA(D3DXVECTOR3 *v,float height);

extern
void				RenderGameObjects();
extern
void				GameAppRenderScene();

extern
int					GameAppGetSelectedDisplayMode();

extern
void				GfxInitDirectX();
extern
void				GfxUnInitDirectX();

extern
void				GfxSetDisplayMode(int width,int height,bool windowed);
extern
void				GfxInitRenderStates();
extern
void				GfxDeviceLost();
extern
void				GfxDeviceReset();

#if USE_EFFECT_FILE
extern
LPD3DXEFFECT		GfxLoadEffect(const char *file_name,const char *technique_name=NULL);
extern
void				GfxSetEffect(LPD3DXEFFECT effect,const char *technique_name=NULL);
#endif

extern
void				GfxInitFontSystem(int font_index,char *font_name,int height,int weight);
extern
void				GfxUnInitFontSystem();
extern
void				GfxResetText();
extern
void				GfxRenderFontSystem();
extern
int					GfxPrintTextLen(int font_index,char *str);
extern
int					GfxPrintTextLen(int font_index);
extern
void				GfxPrintText(int font_index,int x,int y,D3DXCOLOR color_rgba,const char *fmt,...);
extern
void				GfxPrintTextShadowed(int font_index,int x,int y,D3DXCOLOR color_rgba,const char *fmt,...);
extern
void				GfxPrintTextWorld(int font_index,int x,int y,int z,float scale,D3DXCOLOR color_rgba,const char *fmt,...);

extern
void				GfxFreeTextureList();
extern
void				GfxFreeTexture(LPDIRECT3DTEXTURE8 tex);
extern
LPDIRECT3DTEXTURE8	GfxGetTexture(const char *file_name);
extern
LPDIRECT3DCUBETEXTURE8 GfxGetNormalizerTexture();
extern
LPDIRECT3DCUBETEXTURE8 GfxGetCubeTexture(const char *file_name);
extern
const char *		GfxGetTextureFileName(LPDIRECT3DTEXTURE8 tex);
extern
LPDIRECT3DTEXTURE8	GfxLoadTexture(const char *file_name,LPDIRECT3DTEXTURE8 texture_to_add=NULL,bool filter=true,bool mip=true);
extern
LPDIRECT3DCUBETEXTURE8 GfxLoadCubeTexture(const char *file_name);
extern
void				GfxGetTextureSize(LPDIRECT3DTEXTURE8 texture,int &width,int &height);
extern
void				GfxSetTextureStage(int stage,LPDIRECT3DTEXTURE8 texture,bool reflection_map=false,bool bump_map=false,bool bump_dot3=false,bool temp=false);
extern
LPDIRECT3DCUBETEXTURE8 GfxMakeNormalizerMap(int size);
extern
LPDIRECT3DTEXTURE8	GfxMakeTextureBumpFormat(LPDIRECT3DTEXTURE8 tex,D3DFORMAT format);
extern
void				GfxMakeTextureBumpMap(LPDIRECT3DTEXTURE8 texture);

extern
void				GfxSetFogParams(D3DXCOLOR color_rgba,float fog_start,float fog_end);

extern
void				GfxSetOrtho(float width,float height,float near_clip=0,float far_clip=10000);
extern
void				GfxUpdateOrtho();
extern
void				GfxSetProjection(float fov,float aspect,float near_clip,float far_clip);
extern
void				GfxUpdateProjection();

extern
void				GfxSetView(D3DXVECTOR3 pos,D3DXQUATERNION rot);
extern
void				GfxSetView(D3DXVECTOR3 pos,D3DXVECTOR3 rot);
extern
void				GfxSetLookAt(D3DXVECTOR3 pos,D3DXVECTOR3 look_at_pos,D3DXVECTOR3 up_vec);
extern
void				GfxUpdateView();

extern
void				GfxFadeIn(float fade_rate=1,D3DXCOLOR color_argb=D3DXCOLOR(0,0,0,0));
extern
void				GfxFadeOut(float fade_rate=1,D3DXCOLOR color_argb=D3DXCOLOR(0,0,0,0));
extern
bool				GfxIsFadingIn();
extern
void				GfxFadeUpdate(float delta_time);
extern
bool				GfxFadeDone();

extern
void				GfxInitSpriteBuffer();
extern
void				GfxUnInitSpriteBuffer();
extern
Sprite_t *			GfxCreateSprite(LPDIRECT3DTEXTURE8 tex,bool is_world=false);
extern
Sprite_t *			GfxCreateSprite(const char *texture_file,bool is_world=false);
extern
void				GfxSpriteDelete(Sprite_t *spr,bool free_texture=false);
extern
void				GfxFreeWorldSprites();
extern
void				GfxFreeSprites();
extern
void				GfxSetSpriteTexture(Sprite_t *spr,const char *file_name);
extern
void				GfxSetSpritePosition(Sprite_t *spr,float x,float y,float z);
extern
D3DXVECTOR3			GfxGetSpritePosition(Sprite_t *spr);
extern
void				GfxSetSpriteRotation(Sprite_t *spr,float deg);
extern
void				GfxSetSpriteScale(Sprite_t *spr,float scale_x,float scale_y);
extern
D3DXVECTOR3			GfxGetSpriteScale(Sprite_t *spr);
extern
void				GfxSetSpriteColor(Sprite_t *spr,float r,float g,float b,float a);
extern
D3DXCOLOR			GfxGetSpriteColor(Sprite_t *spr);
extern
void				GfxShowSprite(Sprite_t *spr);
extern
void				GfxHideSprite(Sprite_t *spr);

extern
void				GfxRenderShadowQuad();
extern
void				GfxRenderScene();

extern
D3DXVECTOR3			WorldToScreen(D3DXVECTOR3 world_pos);
extern
D3DXVECTOR3			ScreenToWorldRay(float screen_x,float screen_y);

#endif // !defined(AFX_GFX_H__3711D85E_137C_4FD3_945A_4D31E3958CB7__INCLUDED_)
