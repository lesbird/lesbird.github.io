// GameMesh.cpp: implementation of the CGameMesh class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"
#include <io.h>

#define	SHADOW_METHOD	0	//	set to 1 to read from vertex/index buffer, 0 to read from cached vertex/index data

bool				g_bShadowMapEnable=true;
bool				g_bShowCollision;

D3DXVECTOR3			g_ShadowMapScale(1,1,1);
D3DXVECTOR3			g_ShadowMapRot(0,0,0);
D3DXVECTOR3			g_ShadowMapPos(0,0,0);

D3DXVECTOR3			g_ShadowLightPos;

static
MeshList_t			MeshList;

class CShadowVolume
{
public:
	void			Reset() { m_dwNumVertices = 0L; }
#if SHADOW_METHOD == 1
	void			BuildFromMeshPNUV(LPD3DXMESH mesh,D3DXVECTOR3 light);
#else
	void			BuildFromMeshPNUV(CGameMesh *mesh,D3DXVECTOR3 light);
#endif
	void			Render(LPDIRECT3DDEVICE8 pd3dDevice);

public:
	D3DXVECTOR3		m_pVertices[8192];	// Vertex data for rendering shadow volume
	DWORD			m_dwNumVertices;
};

void				MeshManageMeshList();

extern
int					CnfDetailLevel;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameMesh::CGameMesh()
{
	AddInt(this,VAR_TYPE,'MESH');

	for (int t=0 ; t < 4 ; t++) {
		m_TextureTransformPos[t]=D3DXVECTOR3(0,0,0);
		m_TextureTransformRate[t]=0;
		m_TextureTransformRot[t]=D3DXVECTOR3(0,0,0);
		m_TextureTransformScale[t]=D3DXVECTOR3(1,1,1);
		m_TextureTransformType[t]=0;
		m_TexCoordIndex[t]=0;
		D3DXMatrixIdentity(&m_TextureTransform[t]);
	}

	m_Color=D3DXCOLOR(0,0,0,0);

	m_Pos=D3DXVECTOR3(0,0,0);
	m_Rot=D3DXVECTOR3(0,0,0);
	m_Scale=D3DXVECTOR3(1,1,1);

	D3DXMatrixIdentity(&m_ShadowCache);
	m_ShadowVerts=NULL;
	m_ShadowNorms=NULL;
	m_ShadowIndices=NULL;
	m_ShadowNumFaces=0;

	m_OutlineColor=D3DXCOLOR(0,0,0,1);
	m_OutlineThickness=1.1f;

	m_ShadowVolume=NULL;
	m_bHasShadow=false;
	m_bOutline=false;

	D3DXQuaternionIdentity(&m_Quat);

	D3DXMatrixIdentity(&m_WorldMatrix);
}

CGameMesh::~CGameMesh()
{
	DelCollision();
	UnInitGameMesh();
}

void
CGameMesh::UnInitGameMesh()
{
	UnInitShadowVolume();
	LPDIRECT3DTEXTURE8 bump_tex=(LPDIRECT3DTEXTURE8)GetPtr(this,VAR_TEXTURE_BUMP);
	if (bump_tex != NULL) {
		bump_tex->Release();
	}
//	LPDIRECT3DTEXTURE8 cube_tex=(LPDIRECT3DTEXTURE8)GetPtr(this,VAR_TEXTURE_CUBE);
//	if (cube_tex != NULL) {
//		cube_tex->Release();
//	}
//	LPDIRECT3DTEXTURE8 detail_tex=(LPDIRECT3DTEXTURE8)GetPtr(this,VAR_TEXTURE_DET);
//	if (detail_tex != NULL) {
//		detail_tex->Release();
//	}
//	LPDIRECT3DTEXTURE8 ref_tex=(LPDIRECT3DTEXTURE8)GetPtr(this,VAR_TEXTURE_REF);
//	if (ref_tex != NULL) {
//		ref_tex->Release();
//	}
//	LPDIRECT3DTEXTURE8 vol_tex=(LPDIRECT3DTEXTURE8)GetPtr(this,VAR_TEXTURE_VOLUME);
//	if (vol_tex != NULL) {
//		vol_tex->Release();
//	}
#if USE_EFFECT_FILE
	LPD3DXEFFECT effect=(LPD3DXEFFECT)GetPtr(this,VAR_EFFECT);
	if (effect != NULL) {
		AddPtr(this,VAR_EFFECT,0);
		effect->Release();
	}
#endif
	Mesh_t *mesh_cache=(Mesh_t *)GetPtr(this,VAR_MESH);
	if (mesh_cache != NULL) {
		if (mesh_cache->Refs > 0) {
			mesh_cache->Refs--;
			MeshManageMeshList();
		}
		else {
			mesh_cache->Mesh->Release();
			delete mesh_cache->Materials;
			delete mesh_cache->Textures;
		}
	}
}

//
//	Shadow Volume
//
/*
void
CShadowVolume::Render(CGameMesh *mesh_object,LPDIRECT3DDEVICE8 pd3dDevice)
{
	LPD3DXEFFECT effect=(LPD3DXEFFECT)GetPtr(mesh_object,VAR_SHADOW_EFFECT);
	if (effect != NULL) {	//	render using shaders
		D3DXMATRIX mWVP=mesh_object->m_WorldMatrix*g_ViewMatrix*g_ProjectionMatrix;
		effect->SetMatrix("mWVP",&mWVP);
		D3DXMATRIX mWV=mesh_object->m_WorldMatrix*g_ViewMatrix;
		effect->SetMatrix("mWV",&mWV);
		effect->SetMatrix("mP",&g_ProjectionMatrix);
		D3DXMATRIX mWVt;
		D3DXMatrixInverse(&mWVt,NULL,&mWV);
		effect->SetMatrix("mWVt",&mWVt);
		D3DXVECTOR4 cShd(100000,0,0.501f,9999);
		effect->SetVector("cShd",&cShd);
		D3DXVECTOR4 pVL(g_ShadowLightPos.x,g_ShadowLightPos.y,g_ShadowLightPos.z,1);
		effect->SetVector("pVL",&pVL);
		unsigned int passes;
		if (effect->Begin(&passes,0) == D3D_OK) {
			for (unsigned int p=0 ; p < passes ; p++) {
				effect->Pass(p);
				pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST,m_NumVerts/3,m_Vertices,sizeof(PosNor_t));
			}
			effect->End();
		}
	}
}
*/

void
CShadowVolume::Render(LPDIRECT3DDEVICE8 pd3dDevice)
{
	unsigned int num_polys=m_dwNumVertices/3;
	pd3dDevice->SetVertexShader(D3DFVF_XYZ);
	pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST,num_polys,m_pVertices,sizeof(D3DXVECTOR3));
	g_VisiblePolys+=num_polys;
}

WORD pEdges[8192];

void
AddEdge(WORD *edges,DWORD &num_edges,WORD v0,WORD v1)
{
	// Remove interior edges (which appear in the list twice)
	for (DWORD i=0 ; i < num_edges ; i++) {
		if ((edges[2*i+0] == v0 && edges[2*i+1] == v1) || (edges[2*i+0] == v1 && edges[2*i+1] == v0)) {
			if (num_edges > 1) {
				edges[2*i+0]=edges[2*(num_edges-1)+0];
				edges[2*i+1]=edges[2*(num_edges-1)+1];
			}
			num_edges--;
			return;
		}
	}

	edges[2*num_edges+0]=v0;
	edges[2*num_edges+1]=v1;
	num_edges++;
}

#define	SHADOW_VOLUME_LIGHT_RANGE	10000

int	ShadowUpdateCount;

#if SHADOW_METHOD == 1
void
CShadowVolume::BuildFromMeshPNUV(LPD3DXMESH mesh,D3DXVECTOR3 light)
{
	if (m_dwNumVertices != 0) {
		return;
	}

	PosNorTex_t *verts;
	WORD *indices;

    // Lock the geometry buffers
	mesh->LockVertexBuffer(0L,(unsigned char **)&verts);
	mesh->LockIndexBuffer(0L,(unsigned char **)&indices);
	DWORD num_verts=mesh->GetNumVertices();
	DWORD num_faces=mesh->GetNumFaces();

	DWORD num_edges=0;

	WORD face0,face1,face2;
	D3DXVECTOR3 v0,v1,v2,v3;
	D3DXVECTOR3 nor;
	for (int i=0 ; i < num_faces ; i++) {
		face0=indices[3*i+0];
		face1=indices[3*i+1];
		face2=indices[3*i+2];

		v0=verts[face0].pos;
		v1=verts[face1].pos;
		v2=verts[face2].pos;

		D3DXVec3Cross(&nor,&(v2-v1),&(v1-v0));

		if (D3DXVec3Dot(&nor,&light) >= 0.0f) {
			AddEdge(pEdges,num_edges,face0,face1);
			AddEdge(pEdges,num_edges,face1,face2);
			AddEdge(pEdges,num_edges,face2,face0);
		}
	}

	m_dwNumVertices=0;
	for (i=0 ; i < num_edges ; i++) {
		v0=verts[pEdges[2*i+0]].pos;
		v1=verts[pEdges[2*i+1]].pos;
		v2=v0-light*SHADOW_VOLUME_LIGHT_RANGE;
		v3=v1-light*SHADOW_VOLUME_LIGHT_RANGE;

        // Add a quad (two triangles) to the vertex list
		m_pVertices[m_dwNumVertices++]=v0;
		m_pVertices[m_dwNumVertices++]=v1;
		m_pVertices[m_dwNumVertices++]=v2;

		m_pVertices[m_dwNumVertices++]=v1;
		m_pVertices[m_dwNumVertices++]=v3;
		m_pVertices[m_dwNumVertices++]=v2;
	}

	mesh->UnlockVertexBuffer();
	mesh->UnlockIndexBuffer();

	ShadowUpdateCount++;
}
#else
void
CShadowVolume::BuildFromMeshPNUV(CGameMesh *mesh,D3DXVECTOR3 light)
{
	if (m_dwNumVertices != 0) {
		return;
	}

	DWORD num_edges=0;

	DWORD num_faces=mesh->m_ShadowNumFaces;
	WORD *indices=mesh->m_ShadowIndices;
	D3DXVECTOR3 *norms=mesh->m_ShadowNorms;
	WORD face0,face1,face2;
	for (int i=0 ; i < num_faces ; i++) {
		if (D3DXVec3Dot(&norms[i],&light) >= 0.0f) {
			face0=indices[3*i+0];
			face1=indices[3*i+1];
			face2=indices[3*i+2];
			AddEdge(pEdges,num_edges,face0,face1);
			AddEdge(pEdges,num_edges,face1,face2);
			AddEdge(pEdges,num_edges,face2,face0);
		}
	}

	D3DXVECTOR3 *verts=mesh->m_ShadowVerts;
	D3DXVECTOR3 v0,v1,v2,v3;
	for (i=0 ; i < num_edges ; i++) {
		v0=verts[pEdges[2*i+0]];
		v1=verts[pEdges[2*i+1]];
		v2=v0-light*SHADOW_VOLUME_LIGHT_RANGE;
		v3=v1-light*SHADOW_VOLUME_LIGHT_RANGE;

        // Add a quad (two triangles) to the vertex list
		m_pVertices[m_dwNumVertices++]=v0;
		m_pVertices[m_dwNumVertices++]=v1;
		m_pVertices[m_dwNumVertices++]=v2;

		m_pVertices[m_dwNumVertices++]=v1;
		m_pVertices[m_dwNumVertices++]=v3;
		m_pVertices[m_dwNumVertices++]=v2;
	}
	ShadowUpdateCount++;
}
#endif

void
MeshManageMeshList()
{
	for (MeshList_t::iterator m=MeshList.begin() ; m != MeshList.end() ; ) {
		Mesh_t *mesh_cache=(*m);
		if (mesh_cache->Refs == 0) {
			delete mesh_cache->Materials;
			delete mesh_cache->Textures;
			unsigned long refs=mesh_cache->Mesh->Release();
//			Log("MeshManageMeshList(): %s->Refs=%d",mesh_cache->FileName,refs);
			delete mesh_cache;
			m=MeshList.erase(m);
			continue;
		}
		m++;
	}
}

void
MeshComputeBinormals(LPD3DXMESH mesh,int tangent_stage)
{
#if ENV_BUMP == 0
/*
	PosNorTex_t *verts;
	if (mesh->LockVertexBuffer(0,(unsigned char **)&verts) == D3D_OK) {
		int num_verts=mesh->GetNumVertices();
		for (int n=0 ; n < num_verts ; n++) {
			if (tangent_stage == 1) {
				D3DXVECTOR3 tangent(verts[n].tu2,verts[n].tv2,verts[n].tw2);
				D3DXVec3Normalize(&tangent,&tangent);
				verts[n].tu2=tangent.x;
				verts[n].tv2=tangent.y;
				verts[n].tw2=tangent.z;
				D3DXVECTOR3 binormal;
				D3DXVec3Cross(&binormal,&verts[n].nor,&tangent);
				verts[n].tu3=binormal.x;
				verts[n].tv3=binormal.y;
				verts[n].tw3=binormal.z;
			}
			else {
				D3DXVECTOR3 tangent(verts[n].tu3,verts[n].tv3,verts[n].tw3);
				D3DXVec3Normalize(&tangent,&tangent);
				verts[n].tu3=tangent.x;
				verts[n].tv3=tangent.y;
				verts[n].tw3=tangent.z;
				D3DXVECTOR3 binormal;
				D3DXVec3Cross(&binormal,&verts[n].nor,&tangent);
				verts[n].tu2=binormal.x;
				verts[n].tv2=binormal.y;
				verts[n].tw2=binormal.z;
			}
		}
		mesh->UnlockVertexBuffer();
	}
*/
#endif
}

void
MeshCreateMaterials(Mesh_t *mesh_cache,LPD3DXBUFFER material_buffer,int num_materials,bool has_specular=false,bool has_mips=true)
{
	mesh_cache->NumMaterials=num_materials;
	D3DXMATERIAL *xfile_materials=(D3DXMATERIAL *)material_buffer->GetBufferPointer();
	D3DMATERIAL8 *materials=new D3DMATERIAL8[num_materials];
	mesh_cache->Materials=materials;
	LPDIRECT3DTEXTURE8 *textures=new LPDIRECT3DTEXTURE8[num_materials];
	mesh_cache->Textures=textures;
	for (int i=0 ; i < num_materials ; i++) {
		materials[i]=xfile_materials[i].MatD3D;
		if (has_specular) {
			materials[i].Power=50;
			materials[i].Specular=D3DXCOLOR(1,1,1,1);
		}
		textures[i]=NULL;
		if (xfile_materials[i].pTextureFilename != NULL) {
			if (strlen(xfile_materials[i].pTextureFilename) > 0) {
				char name[_MAX_FNAME],ext[_MAX_EXT];
				_splitpath(xfile_materials[i].pTextureFilename,NULL,NULL,name,ext);
				char dir[_MAX_DIR];
				_splitpath(mesh_cache->FileName,NULL,dir,NULL,NULL);
				char file_name[_MAX_PATH];
				sprintf(file_name,"%s%s%s",dir,name,ext);
				textures[i]=GfxLoadTexture(file_name,NULL,true,has_mips);
				strlwr(file_name);
			}
		}
	}
}

Mesh_t *
MeshLoadMesh(const char *file_name,bool has_specular=false)
{
	for (MeshList_t::iterator m=MeshList.begin() ; m != MeshList.end() ; m++) {
		Mesh_t *mesh_cache=(*m);
		if (stricmp(file_name,mesh_cache->FileName) == 0) {
			mesh_cache->Refs++;
			return(mesh_cache);
		}
	}
	Mesh_t *mesh_cache=NULL;
	unsigned long num_materials;
	LPD3DXBUFFER adj_buf=NULL;
	LPD3DXBUFFER material_buffer=NULL;
	LPD3DXMESH mesh;
	unsigned long buf_size;
	void *buf=g_GameFile->GetFile(file_name,&buf_size);
	if (buf != NULL) {
		if (D3DXLoadMeshFromXInMemory((unsigned char *)buf,buf_size,D3DXMESH_MANAGED,g_D3DDevice,&adj_buf,&material_buffer,&num_materials,&mesh) == D3D_OK) {
			mesh->OptimizeInplace(D3DXMESHOPT_COMPACT|D3DXMESHOPT_ATTRSORT,(const DWORD *)adj_buf->GetBufferPointer(),NULL,NULL,NULL);
			LPD3DXMESH cloned_mesh=mesh;
			if (mesh->CloneMeshFVF(D3DXMESH_MANAGED,POSNORTEX_FVF,g_D3DDevice,&cloned_mesh) == D3D_OK) {
				D3DXComputeNormals(cloned_mesh,(const DWORD *)adj_buf->GetBufferPointer());
				if ((POSNORTEX_FVF&D3DFVF_TEX3) != 0) {
					if (D3DXComputeTangent(mesh,0,cloned_mesh,1,2,TRUE,NULL) == D3D_OK) {
//						MeshComputeBinormals(cloned_mesh,1);
					}
					else {
//						Log("MeshLoadMesh(%s): D3DXComputeTangent() failed",file_name);
					}
				}
			}
			if (mesh != cloned_mesh) {
				mesh->Release();
			}
			adj_buf->Release();
			mesh_cache=new Mesh_t;
			ZeroMemory(mesh_cache,sizeof(Mesh_t));
			strcpy(mesh_cache->FileName,file_name);
			strupr(mesh_cache->FileName);
			mesh_cache->Mesh=cloned_mesh;
			bool has_mips=true;
			if (strstr(file_name,"_nomip") != NULL) {
				has_mips=false;
			}
			MeshCreateMaterials(mesh_cache,material_buffer,num_materials,has_specular,has_mips);
			material_buffer->Release();
			MeshList.push_back(mesh_cache);
			mesh_cache->Refs++;
			LogResource("%s",mesh_cache->FileName);
		}
		g_GameFile->FreeFileMem(buf);
	}
	return(mesh_cache);
}

inline DWORD F2DW( FLOAT f ) { return *((DWORD*)&f); }

static
void
SetEffectDWord(LPD3DXEFFECT effect,const char *var,DWORD d)
{
	if (effect->SetDword(var,d) != D3D_OK) {
		Log("SetEffectDWord(%s): failed",var);
	}
}

static
void
SetEffectVector(LPD3DXEFFECT effect,const char *var,D3DXVECTOR4 *v)
{
	if (effect->SetVector(var,v) != D3D_OK) {
		Log("SetEffectVector(%s): failed",var);
	}
}

static
void
SetEffectMatrix(LPD3DXEFFECT effect,const char *var,D3DXMATRIX *m)
{
	if (effect->SetMatrix(var,m) != D3D_OK) {
		Log("SetEffectMatrix(%s): failed",var);
	}
}

void
ComputeLightVectors(CGameMesh *mesh_object)
{
/*
	Mesh_t *mesh_cache=(Mesh_t *)GetPtr(mesh_object,VAR_MESH);
	if (mesh_cache != NULL) {
		D3DXVECTOR3 dir;
		D3DXVECTOR3 light_pos;
		LPD3DXMESH mesh_data=mesh_cache->Mesh;
		PosNorTex_t *vertex_data;
		if (DynamicLight != NULL && GetBool(DynamicLight,VAR_IS_VISIBLE)) {
			D3DXVec3TransformNormal(&light_pos,&DynamicLightPos,&mesh_object->m_WorldMatrix);
			if (mesh_data->LockVertexBuffer(0,(unsigned char **)&vertex_data) == D3D_OK) {
				long num_vertices=mesh_data->GetNumVertices();
				for (int i=0 ; i < num_vertices ; i++) {
					PosNorTex_t *vert=&vertex_data[i];
					dir=AWE_DIR_VEC(light_pos,vert->pos);
					D3DXVec3Normalize(&dir,&dir);
					vert->diffuse=VectorToRGBA(&dir,1);
				}
				mesh_data->UnlockVertexBuffer();
				GfxPrintText(0,0,100,D3DXCOLOR(1,1,1,1),"%d",num_vertices);
			}
		}
		else {
			if (mesh_data->LockVertexBuffer(0,(unsigned char **)&vertex_data) == D3D_OK) {
				long num_vertices=mesh_data->GetNumVertices();
				for (int i=0 ; i < num_vertices ; i++) {
					PosNorTex_t *vert=&vertex_data[i];
					vert->diffuse=VectorToRGBA(&DirectionalLightDir,0);
				}
				mesh_data->UnlockVertexBuffer();
			}
		}
	}
*/
}

void
MeshDrawSubsets(CGameMesh *mesh_object)
{
	Mesh_t *mesh_cache=(Mesh_t *)GetPtr(mesh_object,VAR_MESH);
	if (mesh_cache == NULL) {
		return;
	}

	g_VisiblePolys+=mesh_cache->Mesh->GetNumFaces();

	bool is_unlit=GetBool(mesh_object,VAR_IS_UNLIT);

	LPDIRECT3DDEVICE8 device=g_D3DDevice;
	D3DXVECTOR3 scale;
	mesh_object->GetScale(scale.x,scale.y,scale.z);
	if (g_bLightingOverride == false) {
		if (is_unlit == false && (scale.x != 1 || scale.y != 1 || scale.z != 1)) {
			device->SetRenderState(D3DRS_NORMALIZENORMALS,true);
		}
	}
	D3DXVECTOR3 obj_pos;
	mesh_object->GetPosition(obj_pos.x,obj_pos.y,obj_pos.z);
	LPD3DXMESH mesh=mesh_cache->Mesh;
	int num_materials=__max(mesh_cache->NumMaterials,1);
	D3DMATERIAL8 *materials=mesh_cache->Materials;
	LPDIRECT3DTEXTURE8 *textures=mesh_cache->Textures;

	for (int t=0 ; t < 4 ; t++) {
		if (mesh_object->m_TextureTransformType[t] != 0) {
			g_D3DDevice->SetTextureStageState(t,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
			switch (t) {
			case 0:
				g_D3DDevice->SetTransform(D3DTS_TEXTURE0,&mesh_object->m_TextureTransform[t]);
				break;
			case 1:
				g_D3DDevice->SetTransform(D3DTS_TEXTURE1,&mesh_object->m_TextureTransform[t]);
				break;
			case 2:
				g_D3DDevice->SetTransform(D3DTS_TEXTURE2,&mesh_object->m_TextureTransform[t]);
				break;
			case 3:
				g_D3DDevice->SetTransform(D3DTS_TEXTURE3,&mesh_object->m_TextureTransform[t]);
				break;
			}
		}
		else {
			g_D3DDevice->SetTextureStageState(t,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
		}
		g_D3DDevice->SetTextureStageState(t,D3DTSS_TEXCOORDINDEX,mesh_object->m_TexCoordIndex[t]);
	}

	LPDIRECT3DTEXTURE8 texture_override=(LPDIRECT3DTEXTURE8)GetPtr(mesh_object,VAR_TEXTURE_BASE);

	bool bump_dot3=false;
	float bump_scale=GetFloat(mesh_object,VAR_BUMP_SCALE);
	LPDIRECT3DTEXTURE8 texture_bumpmap=NULL;
	if (g_bBumpMapEnable) {
		const char *technique_name=GetVar(mesh_object,VAR_EFFECT_TECH);
		if (technique_name != NULL) {
			if (g_bBumpMapEnable && strstr(technique_name,"DOT3") != NULL) {
				D3DXVECTOR3 light_dir=DirectionalLightDir;
				DWORD factor=VectorToRGBA(&light_dir,0);
				g_D3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR,factor);
				bump_dot3=true;
			}
		}
		texture_bumpmap=(LPDIRECT3DTEXTURE8)GetPtr(mesh_object,VAR_TEXTURE_BUMP);
		if (bump_scale == 0 || g_bBumpScaleOverride) {
			bump_scale=g_BumpScale;
		}
	}
	LPDIRECT3DTEXTURE8 texture_blendmap=(LPDIRECT3DTEXTURE8)GetPtr(mesh_object,VAR_TEXTURE_BLEND);
	LPDIRECT3DTEXTURE8 texture_cubemap=(LPDIRECT3DTEXTURE8)GetPtr(mesh_object,VAR_TEXTURE_CUBE);
	float translucency=GetFloat(mesh_object,VAR_TRANSLUCENCY);
	if (GetBool(mesh_object,VAR_IS_SKYBOX)) {
		device->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
		device->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_SELECTARG1);
		device->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_MIRROR);
		device->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_MIRROR);
		GfxLightingDisable();
	}
	if (translucency < 1) {
		GfxAlphaBlendEnable();
		GfxZWriteDisable();
		for (int i=0 ; i < num_materials ; i++) {
			LPDIRECT3DTEXTURE8 tex=textures[i];
			if (texture_override != NULL) {
				tex=texture_override;
			}
			D3DMATERIAL8 mat=materials[i];
			if (mesh_object->m_Color.r != 0 || mesh_object->m_Color.g != 0 || mesh_object->m_Color.b != 0) {
				mat.Diffuse=D3DXCOLOR(mesh_object->m_Color.r,mesh_object->m_Color.g,mesh_object->m_Color.b,mat.Diffuse.a);
			}
			mat.Diffuse.a=translucency;
			if (is_unlit) {
				mat.Emissive=mat.Diffuse;
			}
			device->SetMaterial(&mat);
			int stage=0;
			if (texture_bumpmap != NULL) {
				GfxSetTextureStage(stage++,tex,false,false,false,true);
				if (bump_dot3) {
					GfxSetTextureStage(stage++,texture_bumpmap,false,true,true,false);
				}
				else {
					device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT00,F2DW(bump_scale));
					device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT01,F2DW(0));
					device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT10,F2DW(0));
					device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT11,F2DW(bump_scale));
					GfxSetTextureStage(stage++,texture_bumpmap,false,true,false,false);
					if (texture_cubemap != NULL) {
						GfxSetTextureStage(stage++,texture_cubemap,true,false,false,false);
					}
				}
				if (texture_blendmap != NULL) {
					GfxSetTextureStage(stage++,texture_blendmap,false,false,false,false);
				}
				GfxSetTextureStage(stage++,NULL,false,false,true,false);
			}
			else if (texture_cubemap != NULL) {
				if (tex != NULL) {
					GfxSetTextureStage(stage++,tex,false,false,false,false);
				}
				GfxSetTextureStage(stage++,texture_cubemap,true,false,false,false);
			}
			else {
				GfxSetTextureStage(stage++,tex,false,false,false,false);
			}
			mesh->DrawSubset(i);
		}
		GfxSetTextureStage(0,NULL,false,false,false,false);
		GfxAlphaBlendDisable();
		GfxZWriteEnable();
	}
	else {
		bool has_translucency=false;
		for (int pass=0 ; pass < 2 ; pass++) {
			if (pass == 1 && !has_translucency) {
				continue;
			}
			if (pass == 0) {
				GfxAlphaBlendDisable();
				GfxZWriteEnable();
			}
			else {
				GfxAlphaBlendEnable();
				GfxZWriteDisable();
			}
			for (int i=0 ; i < num_materials ; i++) {
				D3DMATERIAL8 mat=materials[i];
				if (mat.Diffuse.a < 1) {
					if (pass == 0) {
						has_translucency=true;
						continue;
					}
				}
				else if (pass == 1) {
					continue;
				}
				if (mesh_object->m_Color.r != 0 || mesh_object->m_Color.g != 0 || mesh_object->m_Color.b != 0) {
					mat.Diffuse=D3DXCOLOR(mesh_object->m_Color.r,mesh_object->m_Color.g,mesh_object->m_Color.b,mat.Diffuse.a);
				}
				if (is_unlit) {
					mat.Emissive=mat.Diffuse;
				}
				device->SetMaterial(&mat);
				LPDIRECT3DTEXTURE8 tex=textures[i];
				int stage=0;
				if (texture_override != NULL) {
					tex=texture_override;
				}
				if (texture_bumpmap != NULL) {
					GfxSetTextureStage(stage++,tex,false,false,false,true);
					if (bump_dot3) {
						GfxSetTextureStage(stage++,texture_bumpmap,false,true,true,false);
					}
					else {
						device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT00,F2DW(bump_scale));
						device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT01,F2DW(0));
						device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT10,F2DW(0));
						device->SetTextureStageState(stage,D3DTSS_BUMPENVMAT11,F2DW(bump_scale));
						GfxSetTextureStage(stage++,texture_bumpmap,false,true,false,false);
						if (texture_cubemap != NULL) {
							GfxSetTextureStage(stage++,texture_cubemap,true,false,false,false);
						}
					}
					if (texture_blendmap != NULL) {
						GfxSetTextureStage(stage++,texture_blendmap,false,false,false,false);
					}
					GfxSetTextureStage(stage++,NULL,false,false,true,false);
				}
				else if (texture_cubemap != NULL) {
					if (tex != NULL) {
						GfxSetTextureStage(stage++,tex,false,false,false,false);
					}
					GfxSetTextureStage(stage++,texture_cubemap,true,false,false,false);
				}
				else {
					GfxSetTextureStage(stage++,tex,false,false,false,false);
				}
				mesh->DrawSubset(i);
			}
			if (pass == 1) {
				GfxAlphaBlendDisable();
				GfxZWriteEnable();
			}
		}
		GfxSetTextureStage(0,NULL,false,false,false,false);
	}
	if (GetBool(mesh_object,VAR_IS_SKYBOX)) {
		device->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_MODULATE);
		device->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
		device->SetTextureStageState(0,D3DTSS_COLORARG2,D3DTA_CURRENT);
		device->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_MODULATE);
		device->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_WRAP);
		device->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_WRAP);
		GfxLightingEnable();
	}
	device->SetRenderState(D3DRS_NORMALIZENORMALS,false);
}

void
MeshDrawSubsetOutline(CGameMesh *mesh_object)
{
	Mesh_t *mesh_cache=(Mesh_t *)GetPtr(mesh_object,VAR_MESH);
	if (mesh_cache == NULL) {
		return;
	}

	g_VisiblePolys+=mesh_cache->Mesh->GetNumFaces();

	LPD3DXMESH mesh=mesh_cache->Mesh;
	GfxSetTextureStage(0,NULL,false,false,false,false);
	int num_materials=__max(mesh_cache->NumMaterials,1);
	D3DMATERIAL8 mat;
	ZeroMemory(&mat,sizeof(D3DMATERIAL8));
	mat.Diffuse=mesh_object->m_OutlineColor;
	g_D3DDevice->SetMaterial(&mat);
	GfxAlphaBlendEnable();
	for (int i=0 ; i < num_materials ; i++) {
		mesh->DrawSubset(i);
	}
	GfxAlphaBlendDisable();
}

void
ComputeBounds(CGameMesh *mesh_object)
{
	Mesh_t *mesh_cache=(Mesh_t *)GetPtr(mesh_object,VAR_MESH);
	if (mesh_cache != NULL) {
		LPD3DXMESH mesh_data=mesh_cache->Mesh;
		void *vertex_data;
		if (mesh_data->LockVertexBuffer(0,(unsigned char **)&vertex_data) == D3D_OK) {
			long num_vertices=mesh_data->GetNumVertices();
			D3DXVECTOR3 bbox_min(0,0,0);
			D3DXVECTOR3 bbox_max(0,0,0);
			D3DXComputeBoundingBox((D3DXVECTOR3 *)vertex_data,num_vertices,mesh_data->GetFVF(),&bbox_min,&bbox_max);
			AddVec3(mesh_object,VAR_BBOX_MIN,bbox_min.x,bbox_min.y,bbox_min.z);
			AddVec3(mesh_object,VAR_BBOX_MAX,bbox_max.x,bbox_max.y,bbox_max.z);
			D3DXVECTOR3 center;
			float radius;
			D3DXComputeBoundingSphere((D3DXVECTOR3 *)vertex_data,num_vertices,mesh_data->GetFVF(),&center,&radius);
			AddFloat(mesh_object,VAR_RADIUS,radius);
			mesh_data->UnlockVertexBuffer();
		}
	}
}

void
CGameMesh::InitShadowVolume()
{
	if (m_ShadowVolume == NULL) {
		PosNorTex_t *verts;
		WORD *indices;

		Mesh_t *mesh_cache=(Mesh_t *)GetPtr(this,VAR_MESH);
		if (mesh_cache != NULL) {
			LPD3DXMESH mesh=mesh_cache->Mesh;

			//	copy the vertices to m_ShadowVerts
			DWORD num_verts=mesh->GetNumVertices();
			m_ShadowVerts=new D3DXVECTOR3[num_verts];
			mesh->LockVertexBuffer(0L,(unsigned char **)&verts);
			for (DWORD i=0 ; i < num_verts ; i++) {
				m_ShadowVerts[i]=verts[i].pos;
			}
			mesh->UnlockVertexBuffer();

			//	copy the indices to m_ShadowIndices
			DWORD num_faces=mesh->GetNumFaces();
			m_ShadowNumFaces=num_faces;
			m_ShadowIndices=new WORD[num_faces*3];
			mesh->LockIndexBuffer(0L,(unsigned char **)&indices);
			int index=0;
			for (DWORD j=0 ; j < num_faces ; j++) {
				m_ShadowIndices[index++]=indices[(j*3)+0];
				m_ShadowIndices[index++]=indices[(j*3)+1];
				m_ShadowIndices[index++]=indices[(j*3)+2];
			}
			mesh->UnlockIndexBuffer();

			//	create the face normals in m_ShadowNorms
			m_ShadowNorms=new D3DXVECTOR3[num_faces];
			for (DWORD k=0 ; k < num_faces ; k++) {
				int a=m_ShadowIndices[3*k+0];
				int b=m_ShadowIndices[3*k+1];
				int c=m_ShadowIndices[3*k+2];
				D3DXVECTOR3 v0=m_ShadowVerts[a];
				D3DXVECTOR3 v1=m_ShadowVerts[b];
				D3DXVECTOR3 v2=m_ShadowVerts[c];
				D3DXVec3Cross(&m_ShadowNorms[k],&(v2-v1),&(v1-v0));
			}

			m_ShadowVolume=new CShadowVolume;
			m_ShadowVolume->Reset();

			AddBool(this,VAR_HAS_SHADOW,true);
			m_bHasShadow=true;
		}
	}
}

void
CGameMesh::UnInitShadowVolume()
{
	CShadowVolume *shadow_volume=m_ShadowVolume;
	if (shadow_volume != NULL) {
		if (m_ShadowVerts != NULL) {
			delete m_ShadowVerts;
			m_ShadowVerts=NULL;
		}
		if (m_ShadowNorms != NULL) {
			delete m_ShadowNorms;
			m_ShadowNorms=NULL;
		}
		if (m_ShadowIndices != NULL) {
			delete m_ShadowIndices;
			m_ShadowIndices=NULL;
		}
		m_ShadowNumFaces=0;

		m_ShadowVolume=NULL;

		AddBool(this,VAR_HAS_SHADOW,false);
		m_bHasShadow=false;

		delete shadow_volume;
	}
}

void
CGameMesh::SetPosition(float x,float y,float z)
{
	m_Pos.x=x;
	m_Pos.y=y;
	m_Pos.z=z;
}

void
CGameMesh::GetPosition(float &x,float &y,float &z)
{
	x=m_Pos.x;
	y=m_Pos.y;
	z=m_Pos.z;
}

void
CGameMesh::SetRotation(float x,float y,float z)
{
	D3DXQuaternionRotationYawPitchRoll(&m_Quat,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
	m_Rot.x=x;
	m_Rot.y=y;
	m_Rot.z=z;
}

void
CGameMesh::GetRotation(float &x,float &y,float &z)
{
	x=m_Rot.x;
	y=m_Rot.y;
	z=m_Rot.z;
}

void
CGameMesh::SetScale(float x,float y,float z)
{
	m_Scale.x=x;
	m_Scale.y=y;
	m_Scale.z=z;
	ComputeBounds(this);
}

void
CGameMesh::GetScale(float &x,float &y,float &z)
{
	x=m_Scale.x;
	y=m_Scale.y;
	z=m_Scale.z;
}

void
CGameMesh::SetQuaternion(float x,float y,float z,float w)
{
	m_Quat.x=x;
	m_Quat.y=y;
	m_Quat.z=z;
	m_Quat.w=w;
}

void
CGameMesh::GetQuaternion(float &x,float &y,float &z,float &w)
{
	x=m_Quat.x;
	y=m_Quat.y;
	z=m_Quat.z;
	w=m_Quat.w;
}

void
CGameMesh::SetColor(float r,float g,float b)
{
	m_Color.r=r;
	m_Color.g=g;
	m_Color.b=b;
}

void
CGameMesh::GetColor(float &r,float &g,float &b)
{
	r=m_Color.r;
	g=m_Color.g;
	b=m_Color.b;
}

void
CGameMesh::SetTextureTransform(int stage,int type,float rate)
{
	unsigned int v1,v2;
	switch (stage) {
	case 0:
		v1=VAR_TEXTURE_XFORM0;
		v2=VAR_TEXTURE_XRATE0;
		break;
	case 1:
		v1=VAR_TEXTURE_XFORM1;
		v2=VAR_TEXTURE_XRATE1;
		break;
	case 2:
		v1=VAR_TEXTURE_XFORM2;
		v2=VAR_TEXTURE_XRATE2;
		break;
	case 3:
		v1=VAR_TEXTURE_XFORM3;
		v2=VAR_TEXTURE_XRATE3;
		break;
	}
	AddInt(this,v1,type);
	AddFloat(this,v2,rate);
	AddBool(this,VAR_IS_ACTIVE,true);
	m_TextureTransformType[stage]=type;
	m_TextureTransformRate[stage]=rate;
	if (type == 8) {
		m_TextureTransformScale[stage]=D3DXVECTOR3(rate,rate,rate);
	}
}

void
CGameMesh::UpdateVars()
{
	CGameObject::UpdateVars();
	CGameObject::SetPosition(m_Pos.x,m_Pos.y,m_Pos.z);
	CGameObject::SetRotation(m_Rot.x,m_Rot.y,m_Rot.z);
	CGameObject::SetQuaternion(m_Quat.x,m_Quat.y,m_Quat.z,m_Quat.w);
	CGameObject::SetScale(m_Scale.x,m_Scale.y,m_Scale.z);
}

void
CGameMesh::MakeBox(D3DXVECTOR3 size,const char *texture_file)
{
	LPD3DXMESH mesh;
	LPD3DXBUFFER adj_buf;
	if (D3DXCreateBox(g_D3DDevice,size.x,size.y,size.z,&mesh,&adj_buf) == D3D_OK) {
		LPD3DXMESH cloned_mesh;
		if (mesh->CloneMeshFVF(D3DXMESH_MANAGED,POSNORTEX_FVF,g_D3DDevice,&cloned_mesh) == D3D_OK) {
			PosNorTex_t *verts;
			if (cloned_mesh->LockVertexBuffer(0,(unsigned char **)&verts) == D3D_OK) {
				int num=cloned_mesh->GetNumVertices();
				for (short n=0 ; n < num ; n++) {
					switch (n) {
					case 0:
					case 5:
					case 8:
					case 15:
					case 16:
					case 21:
						verts[n].tu1=0;
						verts[n].tv1=0;
						break;
					case 1:
					case 6:
					case 9:
					case 12:
					case 17:
					case 22:
						verts[n].tu1=0;
						verts[n].tv1=1;
						break;
					case 2:
					case 7:
					case 10:
					case 13:
					case 18:
					case 23:
						verts[n].tu1=1;
						verts[n].tv1=1;
						break;
					case 3:
					case 4:
					case 11:
					case 14:
					case 19:
					case 20:
						verts[n].tu1=1;
						verts[n].tv1=0;
						break;
					default:
						verts[n].tu1=0;
						verts[n].tv1=0;
						break;
					}
				}
				cloned_mesh->UnlockVertexBuffer();
			}
			D3DXComputeNormals(cloned_mesh,(const DWORD *)adj_buf->GetBufferPointer());
			if ((POSNORTEX_FVF&D3DFVF_TEX3) != 0) {
				if (D3DXComputeTangent(mesh,0,cloned_mesh,1,2,TRUE,NULL) == D3D_OK) {
//					MeshComputeBinormals(cloned_mesh,2);
				}
				else {
//					Log("MakeBox: D3DXComputeTangent() failed");
				}
			}
			Mesh_t *mesh_obj=new Mesh_t;
			memset(mesh_obj,0,sizeof(Mesh_t));
			mesh_obj->Mesh=cloned_mesh;
			int num_materials=1;
			mesh_obj->NumMaterials=num_materials;
			D3DMATERIAL8 *materials=new D3DMATERIAL8;
			memset(materials,0,sizeof(D3DMATERIAL8));
			materials[0].Diffuse=D3DXCOLOR(1,1,1,1);
			mesh_obj->Materials=materials;
			LPDIRECT3DTEXTURE8 *textures=new LPDIRECT3DTEXTURE8;
			mesh_obj->Textures=textures;
			textures[0]=GfxLoadTexture(texture_file);
			AddVar(this,VAR_FILE,"_SYSBOX_");
			AddVar(this,VAR_TEXTURE,texture_file);
			AddVec3(this,VAR_BOX_SIZE,size.x,size.y,size.z);
			AddPtr(this,VAR_MESH,mesh_obj);
			ComputeBounds(this);
		}
		adj_buf->Release();
		mesh->Release();
	}
}

void
CGameMesh::LoadFile(const char *file_name,bool has_specular)
{
	UnInitGameMesh();
	AddVar(this,VAR_FILE,file_name);
	Mesh_t *mesh=MeshLoadMesh(file_name,has_specular);
	AddPtr(this,VAR_MESH,mesh);
	if (mesh != NULL) {
		LoadEffects(file_name);
		LoadScriptFile(file_name);
		ComputeBounds(this);
	}
	else {
		Log("CGameMesh::LoadFile(%s): FAILED",file_name);
	}
}

void
CGameMesh::LoadEffects(const char *file_name)
{
	char file_path[256];
	strcpy(file_path,file_name);
	strupr(file_path);
	char *ptr=strstr(file_path,".X");
	if (ptr != NULL) {
		strcpy(ptr,".EFX");
		if (g_GameFile->Exist(file_path)) {
			DataFile_t *fp=g_GameFile->Open(file_path);
			if (fp != NULL) {
				char buf[256];
				while (!g_GameFile->Eof(fp)) {
					g_GameFile->Gets(buf,256,fp);
					if (strlen(buf) > 0) {
						if (buf[0] == ';' || buf[0] == '*' || buf[0] == '/') {
							continue;
						}
						buf[strlen(buf)-1]=0;
						strupr(buf);
						char *cmd=strtok(buf,"=");
						if (cmd != NULL) {
							if (strcmp(cmd,"SHADER") == 0) {
#if USE_EFFECT_FILE
								char *param1=strtok(NULL,",");
								if (param1 != NULL) {
									char *param2=strtok(NULL,"\0");
									if (param2 != NULL) {
										GfxLoadEffect(param1,param2);
									}
									else {
										GfxLoadEffect(param1);
									}
								}
#endif
							}
							else if (strcmp(cmd,"BLENDMAP") == 0) {
								char *param1=strtok(NULL,"\0");
								if (param1 != NULL) {
									LoadBlendMap(param1);
								}
							}
							else if (strcmp(cmd,"BUMPMAP") == 0) {	// && CnfDetailLevel < 3) {
								char *param1=strtok(NULL,",");
								if (param1 != NULL) {
									char *param2=strtok(NULL,"\0");
									if (param2 != NULL) {
										float bump_scale=atof(param2);
										LoadBumpMap(param1,bump_scale);
									}
									else {
										LoadBumpMap(param1,1);
									}
								}
							}
							else if (strcmp(cmd,"ENVMAP") == 0) {
								char *param1=strtok(NULL,"\0");
								if (param1 != NULL) {
									LoadReflectionMap(param1);
								}
							}
							else if (strcmp(cmd,"TECH") == 0) {
								char *param1=strtok(NULL,"\0");
								if (param1 != NULL) {
									SetEffectTechnique(param1);
								}
							}
							else if (strcmp(cmd,"TRANSLUCENCY") == 0) {
								char *param1=strtok(NULL,"\0");
								if (param1 != NULL) {
									AddBool(this,VAR_IS_TRANSPARENT,true);
									float t=atof(param1);
									AddFloat(this,VAR_TRANSLUCENCY,t);
								}
							}
							else if (strcmp(cmd,"TEX0") == 0) {
								char *param1=strtok(NULL,"\0");
								if (param1 != NULL) {
									LoadTexture(param1);
								}
							}
							else if (strstr(cmd,"XFORM") != NULL) {
								int index=cmd[5]-'0';
								if (index >= 0 && index < 4) {
									bool parsed=false;
									char *param1=strtok(NULL,",");
									if (param1 != NULL) {
										int xform_type=atoi(param1);
										char *param2=strtok(NULL,"\0");
										if (param2 != NULL) {
											float xform_rate=atof(param2);
											if (xform_type != 0) {
												SetTextureTransform(index,xform_type,xform_rate);
												parsed=true;
											}
										}
									}
//									if (!parsed) {
//										AddBool(this,VAR_IS_ACTIVE,false);
//										m_TextureTransformType[index]=0;
//									}
								}
							}
						}
					}
				}
				g_GameFile->Close(fp);
			}
		}
	}
}

void
CGameMesh::LoadScriptFile(const char *file_name)
{
	char file_path[256];
	strcpy(file_path,file_name);
	strupr(file_path);
	char *ptr=strstr(file_path,".X");
	if (ptr != NULL) {
		strcpy(ptr,".LUA");
	}
	CGameObject::LoadScriptFile(file_path);
}

void
CGameMesh::LoadEffect(const char *file_name,const char *technique_name)
{
#if USE_EFFECT_FILE
	LPD3DXEFFECT effect=(LPD3DXEFFECT)GetPtr(this,VAR_EFFECT);
	if (effect != NULL) {
		effect->Release();
	}
	effect=GfxLoadEffect(file_name);
	AddPtr(this,VAR_EFFECT,effect);
#endif
	SetEffectTechnique(technique_name);
	LogResource("%s",file_name);
}

void
CGameMesh::SetEffectTechnique(const char *technique_name)
{
	AddVar(this,VAR_EFFECT_TECH,technique_name);
}

void
CGameMesh::LoadBlendMap(const char *file_name)
{
	LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(file_name);
	if (tex != NULL) {
		AddPtr(this,VAR_TEXTURE_BLEND,tex);
	}
}

void
CGameMesh::LoadBumpMap(const char *file_name,float bump_scale)
{
	LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(file_name,NULL,false);
	if (tex != NULL) {
		D3DSURFACE_DESC desc;
		tex->GetLevelDesc(0,&desc);
		LPDIRECT3DTEXTURE8 normal_map;
		D3DXCreateTexture(g_D3DDevice,desc.Width,desc.Height,0,0,D3DFMT_A8R8G8B8,D3DPOOL_MANAGED,&normal_map);
		D3DXComputeNormalMap(normal_map,tex,NULL,0,D3DX_CHANNEL_RED,bump_scale*25.0f);
		AddPtr(this,VAR_TEXTURE_BUMP,normal_map);
		AddFloat(this,VAR_BUMP_SCALE,bump_scale);
		if (GetPtr(this,VAR_TEXTURE_CUBE) != NULL) {
			SetEffectTechnique("ENVBUMP");
		}
		else {
			SetEffectTechnique("FFDOT3");
		}
	}
}

void
CGameMesh::LoadCubeMap(const char *file_name)
{
	LPDIRECT3DCUBETEXTURE8 tex=GfxLoadCubeTexture(file_name);
	if (tex != NULL) {
		AddPtr(this,VAR_TEXTURE_CUBE,tex);
		if (GetPtr(this,VAR_TEXTURE_BUMP) != NULL) {
			SetEffectTechnique("ENVBUMP");
		}
		else {
			SetEffectTechnique("ENV");
		}
	}
}

void
CGameMesh::LoadDetailMap(const char *file_name)
{
	LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(file_name);
	if (tex != NULL) {
		AddPtr(this,VAR_TEXTURE_DET,tex);
	}
}

void
CGameMesh::LoadReflectionMap(const char *file_name)
{
	if (file_name == NULL) {
		AddPtr(this,VAR_TEXTURE_CUBE,NULL);
		if (GetPtr(this,VAR_TEXTURE_BUMP) != NULL) {
			SetEffectTechnique("FFDOT3");
		}
		else {
			SetEffectTechnique("");
		}
	}
	else {
		LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(file_name);
		if (tex != NULL) {
			AddPtr(this,VAR_TEXTURE_CUBE,tex);
			if (GetPtr(this,VAR_TEXTURE_BUMP) != NULL) {
				SetEffectTechnique("ENVBUMP");
			}
			else {
				SetEffectTechnique("ENV");
			}
		}
	}
}

void
CGameMesh::LoadTexture(const char *file_name)
{
	if (file_name == NULL) {
		AddVar(this,VAR_TEXTURE,"");
		AddPtr(this,VAR_TEXTURE_BASE,NULL);
	}
	else {
		LPDIRECT3DTEXTURE8 tex=GfxLoadTexture(file_name);
		if (tex != NULL) {
			AddVar(this,VAR_TEXTURE,file_name);
			AddPtr(this,VAR_TEXTURE_BASE,tex);
		}
	}
}

void
CGameMesh::LostObject()
{
}

void
CGameMesh::ResetObject()
{
}

void
CGameMesh::UpdateObject(float delta_time)
{
	CGameObject::UpdateObject(delta_time);

	for (int i=0 ; i < 4 ; i++) {
		if (m_TextureTransformType[i] != 0) {
			float rate=m_TextureTransformRate[i];
			if (rate == 0) {
				rate=1;
			}
			GameAppTextureTransform(this,i,m_TextureTransformType[i],rate,delta_time);
		}
	}

	GameAppUpdateMesh(this,delta_time);
}

void
CGameMesh::DelCollision()
{
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(this,VAR_PHYSICS);
	if (phys_obj != NULL) {
		PhyDeletePhysicsObject(phys_obj);
		AddPtr(this,VAR_PHYSICS,0);
	}
	float *vertex_data=(float *)GetPtr(this,VAR_VERTEX_DATA);
	if (vertex_data != NULL) {
		delete vertex_data;
		AddPtr(this,VAR_VERTEX_DATA,0);
	}
	int *index_data=(int *)GetPtr(this,VAR_INDEX_DATA);
	if (index_data != NULL) {
		delete index_data;
		AddPtr(this,VAR_INDEX_DATA,0);
	}
	AddInt(this,VAR_PHYSICS_TYPE,'NONE');
}

void
CGameMesh::AddBoxCollision(bool is_static)
{
	DelCollision();

	D3DXVECTOR3 scale;
	GetScale(scale.x,scale.y,scale.z);
	D3DXVECTOR3 bbox_min;
	GetVec3(this,VAR_BBOX_MIN,bbox_min.x,bbox_min.y,bbox_min.z);
	D3DXVECTOR3 bbox_max;
	GetVec3(this,VAR_BBOX_MAX,bbox_max.x,bbox_max.y,bbox_max.z);
	float width=(bbox_max.x-bbox_min.x)*scale.x;
	float height=(bbox_max.y-bbox_min.y)*scale.y;
	float depth=(bbox_max.z-bbox_min.z)*scale.z;
	PhysicsObject_t *phys_obj=PhyAddBoxCollision(width,height,depth,GetFloat(this,VAR_MASS),is_static);
	if (phys_obj != NULL) {
		AddPtr(this,VAR_PHYSICS,phys_obj);
		AddInt(this,VAR_PHYSICS_TYPE,'BOX');
		PhySetData(phys_obj,this);
	}
}

void
CGameMesh::AddCylinderCollision(bool is_static)
{
	DelCollision();

	D3DXVECTOR3 scale;
	GetScale(scale.x,scale.y,scale.z);
	D3DXVECTOR3 bbox_min;
	GetVec3(this,VAR_BBOX_MIN,bbox_min.x,bbox_min.y,bbox_min.z);
	D3DXVECTOR3 bbox_max;
	GetVec3(this,VAR_BBOX_MAX,bbox_max.x,bbox_max.y,bbox_max.z);
	float radius=(bbox_max.x-bbox_min.x)*scale.x;
	float height=(bbox_max.y-bbox_min.y)*scale.y;
	PhysicsObject_t *phys_obj=PhyAddCylinderCollision(radius/2,height/2,GetFloat(this,VAR_MASS),is_static);
	if (phys_obj != NULL) {
		AddPtr(this,VAR_PHYSICS,phys_obj);
		AddInt(this,VAR_PHYSICS_TYPE,'CYLI');
		PhySetData(phys_obj,this);
	}
}

void
CGameMesh::AddSphereCollision(bool is_static)
{
	DelCollision();

	D3DXVECTOR3 scale;
	GetScale(scale.x,scale.y,scale.z);
	float radius=GetFloat(this,VAR_RADIUS)*scale.x;
	PhysicsObject_t *phys_obj=PhyAddSphereCollision(radius,GetFloat(this,VAR_MASS),is_static);
	if (phys_obj != NULL) {
		AddPtr(this,VAR_PHYSICS,phys_obj);
		AddInt(this,VAR_PHYSICS_TYPE,'SPHE');
		PhySetData(phys_obj,this);
	}
}

void
CGameMesh::AddCompoundCollision(unsigned int col_type,D3DXVECTOR3 offset,D3DXVECTOR3 box_size,bool is_static)
{
	PhysicsObject_t *phys_obj=(PhysicsObject_t *)GetPtr(this,VAR_PHYSICS);
	if (phys_obj == NULL) {
		phys_obj=PhyAddCompoundCollision(col_type,NULL,offset.x,offset.y,offset.z,box_size.x,box_size.y,box_size.z,GetFloat(this,VAR_MASS),is_static);
		if (phys_obj != NULL) {
			AddPtr(this,VAR_PHYSICS,phys_obj);
			AddInt(this,VAR_PHYSICS_TYPE,'COMP');
			PhySetData(phys_obj,this);
		}
	}
	else {
		PhyAddCompoundCollision(col_type,phys_obj,offset.x,offset.y,offset.z,box_size.x,box_size.y,box_size.z,GetFloat(this,VAR_MASS),is_static);
		PhySetData(phys_obj,this);
	}
}

void
CGameMesh::AddTriMeshCollision()
{
	DelCollision();

	Mesh_t *mesh_cache=(Mesh_t *)GetPtr(this,VAR_MESH);
	if (mesh_cache != NULL) {
		D3DXVECTOR3 obj_pos;
		GetVec3(this,VAR_POS,obj_pos.x,obj_pos.y,obj_pos.z);
		LPD3DXMESH mesh_data=mesh_cache->Mesh;
		if (mesh_data != NULL) {
			int *index_data=NULL;
			long num_indices=mesh_data->GetNumFaces()*3;
			short *mesh_index_data;
			if (mesh_data->LockIndexBuffer(0,(unsigned char **)&mesh_index_data) == D3D_OK) {
				index_data=new int[num_indices];
				for (int i=0 ; i < num_indices ; i++) {
					index_data[i]=mesh_index_data[i];
				}
				mesh_data->UnlockIndexBuffer();
			}
			float *vertex_data=NULL;
			long num_vertices=mesh_data->GetNumVertices();
			unsigned char *mesh_vertex_data;
			if (mesh_data->LockVertexBuffer(0,(unsigned char **)&mesh_vertex_data) == D3D_OK) {
				vertex_data=new float[num_vertices*4];
				unsigned long vertex_size=D3DXGetFVFVertexSize(mesh_data->GetFVF());
				long n=0;
				for (long v=0 ; v < num_vertices ; v++) {
					D3DXVECTOR3 *vertex_pos=(D3DXVECTOR3 *)mesh_vertex_data;
					vertex_data[n++]=vertex_pos->x+obj_pos.x;
					vertex_data[n++]=vertex_pos->y+obj_pos.y;
					vertex_data[n++]=vertex_pos->z+obj_pos.z;
					vertex_data[n++]=0;
					mesh_vertex_data+=vertex_size;
				}
				mesh_data->UnlockVertexBuffer();
			}
			if (index_data != NULL && vertex_data != NULL) {
				PhysicsObject_t *phys_obj=PhyAddTriMeshCollision(vertex_data,num_vertices,index_data,num_indices);
				if (phys_obj != NULL) {
					AddPtr(this,VAR_PHYSICS,phys_obj);
					AddPtr(this,VAR_INDEX_DATA,index_data);
					AddInt(this,VAR_INDEX_COUNT,num_indices);
					AddPtr(this,VAR_VERTEX_DATA,vertex_data);
					AddInt(this,VAR_VERTEX_COUNT,num_vertices);
					AddInt(this,VAR_PHYSICS_TYPE,'TRIM');
					PhySetData(phys_obj,this);
				}
				else {
					delete index_data;
					delete vertex_data;
				}
			}
			else {
				if (index_data != NULL) {
					delete index_data;
				}
				if (vertex_data != NULL) {
					delete vertex_data;
				}
			}
		}
	}
}

void
CGameMesh::ResetCollision()
{
	bool is_static=GetBool(this,VAR_IS_STATIC);
	switch (GetInt(this,VAR_PHYSICS_TYPE)) {
	case 'BOX':
		AddBoxCollision(is_static);
		break;
	case 'SPHE':
		AddSphereCollision(is_static);
		break;
	case 'CYLI':
		AddCylinderCollision(is_static);
		break;
	}
}

void
CGameMesh::PreRenderObject()
{
	CGameMesh *mesh_object=this;
	CShadowVolume *shadow_volume=m_ShadowVolume;
	if (shadow_volume != NULL) {
		//	rebuild the shadow volume only if the object's world matrix has changed
		if (m_ShadowCache != m_WorldMatrix) {
			m_ShadowCache=m_WorldMatrix;
			shadow_volume->Reset();
		}
	}
}

void
CGameMesh::RenderObject()
{
	D3DXVECTOR3 pos;
	GetPosition(pos.x,pos.y,pos.z);
	D3DXQUATERNION quat;
	GetQuaternion(quat.x,quat.y,quat.z,quat.w);
	D3DXVECTOR3 scale;
	GetScale(scale.x,scale.y,scale.z);
	if (GetBool(this,VAR_IS_ORTHO)) {
		float w=g_DisplayWidth/2;
		pos.x=pos.x-w;
		float h=g_DisplayHeight/2;
		pos.y=h-pos.y;
		D3DXMatrixTransformation(&m_WorldMatrix,NULL,NULL,&scale,NULL,&quat,&pos);
	}
	else {
		D3DXMatrixTransformation(&m_WorldMatrix,NULL,NULL,&scale,NULL,&quat,&pos);
	}
	g_D3DDevice->SetTransform(D3DTS_WORLD,&m_WorldMatrix);

	if (GetBool(this,VAR_IS_CLIPPED)) {
		GfxClipPlaneEnable();
		GfxCullModeNone();
	}
	else {
		GfxClipPlaneDisable();
		GfxCullModeCCW();
	}

	if (g_bShowCollision) {
		const void *index_data=(const void *)GetPtr(this,VAR_INDEX_DATA);
		if (index_data != NULL) {
			int index_count=GetInt(this,VAR_INDEX_COUNT);
			const void *vertex_data=(const void *)GetPtr(this,VAR_VERTEX_DATA);
			if (vertex_data != NULL) {
				int num_verts=GetInt(this,VAR_VERTEX_COUNT);
				if (num_verts > 0) {
					float c=float(m_ObjectIndex)/GameObjectList.size();
					D3DMATERIAL8 mat;
					memset(&mat,0,sizeof(D3DMATERIAL8));
					mat.Emissive=D3DXCOLOR(c,1,1.0f-c,1);
					g_D3DDevice->SetMaterial(&mat);
					g_D3DDevice->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST,0,num_verts,index_count/3,index_data,D3DFMT_INDEX32,vertex_data,sizeof(float)*4);
//					g_D3DDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
//					g_D3DDevice->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST,0,num_verts,index_count/3,index_data,D3DFMT_INDEX32,vertex_data,sizeof(float)*4);
//					g_D3DDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);
					return;
				}
			}
		}
	}

	MeshDrawSubsets(this);
	if (m_bOutline) {
		D3DXMATRIX outline_mat;
		scale.x*=m_OutlineThickness;
		scale.y*=m_OutlineThickness;
		scale.z=0.0001f;
		D3DXMatrixTransformation(&outline_mat,NULL,NULL,&scale,NULL,&quat,&pos);
		g_D3DDevice->SetTransform(D3DTS_WORLD,&outline_mat);
		MeshDrawSubsetOutline(this);
	}
}

float	ShadowUpdateTime;

void
CGameMesh::PostRenderObject()
{
	if (CnfDetailLevel <= 1) {
		CGameMesh *mesh_object=this;
		LARGE_INTEGER shadow_update_time=GetTimer();
		CShadowVolume *shadow_volume=m_ShadowVolume;
		if (shadow_volume != NULL) {
			D3DXMATRIX m;
			D3DXMatrixInverse(&m,NULL,&mesh_object->m_WorldMatrix);
			D3DXVECTOR3 shadow_light_pos(m_Pos.x,g_ShadowLightPos.y,g_ShadowLightPos.z);
			D3DXVECTOR3 light;
			D3DXVec3TransformCoord(&light,&shadow_light_pos,&m);
			Mesh_t *mesh_cache=(Mesh_t *)GetPtr(mesh_object,VAR_MESH);
			LPD3DXMESH mesh=mesh_cache->Mesh;
			DWORD dwFVF=mesh->GetFVF();
#if SHADOW_METHOD == 1
			shadow_volume->BuildFromMeshPNUV(mesh,light);
#else
			shadow_volume->BuildFromMeshPNUV(mesh_object,light);
#endif
#if USE_EFFECT_FILE
			g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);
#else
			GfxCullModeCCW();
#endif
			g_D3DDevice->SetRenderState(D3DRS_STENCILPASS,D3DSTENCILOP_INCR);

			g_D3DDevice->SetTransform(D3DTS_WORLD,&mesh_object->m_WorldMatrix);
			shadow_volume->Render(g_D3DDevice);
#if USE_EFFECT_FILE
			g_D3DDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CW);
#else
			GfxCullModeCW();
#endif
			g_D3DDevice->SetRenderState(D3DRS_STENCILPASS,D3DSTENCILOP_DECR);

			g_D3DDevice->SetTransform(D3DTS_WORLD,&mesh_object->m_WorldMatrix);
			shadow_volume->Render(g_D3DDevice);
		}
		ShadowUpdateTime+=GetTimerDelta(shadow_update_time);
	}
}
