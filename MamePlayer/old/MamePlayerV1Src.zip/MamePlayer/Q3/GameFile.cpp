// GameFile.cpp: implementation of the CGameFile class.
//
//////////////////////////////////////////////////////////////////////

#include "GameHeader.h"
#include <io.h>

CGameFile *		g_GameFile;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameFile::CGameFile()
{
	m_DataFile=NULL;
	m_DataFilePos=0;
	memset(&m_DataFileHdr,0,sizeof(DataFileHdr_t));

	g_GameFile=this;
}

CGameFile::~CGameFile()
{
	CloseDataFile();

	g_GameFile=NULL;
}

bool
CGameFile::OpenDataFile(const char *data_file_name)
{
	CloseDataFile();
	m_DataFile=fopen(data_file_name,"rb");
	if (m_DataFile != NULL) {
		fread(&m_DataFileHdr,sizeof(DataFileHdr_t),1,m_DataFile);
		return(true);
	}
	else {
		Log("CGameFile::OpenDataFile(%s): failed",data_file_name);
	}
	return(false);
}

void
CGameFile::CloseDataFile()
{
	if (m_DataFile != NULL) {
		fclose(m_DataFile);
	}
}

void *
CGameFile::GetFile(const char *file_name,unsigned long *size)
{
	if (m_DataFile == NULL || m_DataFileHdr.NumFiles == 0) {
		FILE *fp=fopen(file_name,"rb");
		if (fp != NULL) {
			fseek(fp,0,SEEK_END);
			unsigned long file_size=ftell(fp);
			fseek(fp,0,SEEK_SET);
			void *file_mem_ptr=new char[file_size];
			fread(file_mem_ptr,sizeof(char),file_size,fp);
			fclose(fp);
			if (size != NULL) {
				*size=file_size;
			}
			return(file_mem_ptr);
		}
	}
	else {
		for (int i=0 ; i < m_DataFileHdr.NumFiles ; i++) {
			if (stricmp(m_DataFileHdr.Filename[i],file_name) == 0) {
				fseek(m_DataFile,m_DataFileHdr.FilePos[i],SEEK_SET);
				void *file_mem_ptr=new char[m_DataFileHdr.FileSize[i]];
				fread(file_mem_ptr,sizeof(char),m_DataFileHdr.FileSize[i],m_DataFile);
				if (size != NULL) {
					*size=m_DataFileHdr.FileSize[i];
				}
				return(file_mem_ptr);
			}
		}
	}
//	Log("CGameFile::GetFile(%s): failed",file_name);
	return(NULL);
}

void
CGameFile::FreeFileMem(void *file_mem_ptr)
{
	if (file_mem_ptr != NULL) {
		delete file_mem_ptr;
	}
}

bool
CGameFile::Exist(const char *file_name)
{
	if (m_DataFile == NULL || m_DataFileHdr.NumFiles == 0) {
		if (_access(file_name,0) == 0) {
			return(true);
		}
	}
	else {
		for (int i=0 ; i < m_DataFileHdr.NumFiles ; i++) {
			if (stricmp(m_DataFileHdr.Filename[i],file_name) == 0) {
				return(true);
			}
		}
	}
	return(false);
}

DataFile_t *
CGameFile::Open(const char *file_name)
{
	DataFile_t *fp=NULL;
	unsigned long size;
	void *buf=GetFile(file_name,&size);
	if (buf != NULL) {
		fp=new DataFile_t;
		fp->Data=buf;
		fp->Pos=0;
		fp->Size=size;
	}
	return(fp);
}

void
CGameFile::Close(DataFile_t *fp)
{
	if (fp != NULL) {
		FreeFileMem(fp->Data);
		delete fp;
	}
}

bool
CGameFile::Eof(DataFile_t *fp)
{
	if (fp != NULL && fp->Pos >= fp->Size-1) {
		return(true);
	}
	return(false);
}

unsigned long
CGameFile::Gets(char *s,int n,DataFile_t *fp)
{
	if (Eof(fp)) {
		return(0);
	}
	char *ptr=(char *)fp->Data+fp->Pos;
	char *token=strchr(ptr,'\n');
	if (token == NULL) {
		token=strchr(ptr,'\0');
		if (token == NULL) {
			return(0);
		}
	}
	memset(s,0,n);
	unsigned long bytes=0;
	while (ptr != token && fp->Pos < fp->Size && bytes < n) {
		*s++=*ptr++;
		fp->Pos++;
		bytes++;
	}
	fp->Pos++;	//	consume the linefeed character
	return(bytes);
}

unsigned long
CGameFile::Read(void *buf,unsigned long size,unsigned long count,DataFile_t *fp)
{
	if (Eof(fp)) {
		return(0);
	}
	unsigned long bytes=size*count;
	if (fp->Pos+bytes > fp->Size) {
		bytes=fp->Size-fp->Pos;
	}
	void *ptr=(void *)((char *)fp->Data+fp->Pos);
	memcpy(buf,ptr,bytes);
	fp->Pos+=bytes;
	return(bytes);
}

void
CGameFile::Seek(DataFile_t *fp,unsigned long offset,int from)
{
	if (from == SEEK_SET) {
		fp->Pos=offset;
	}
	else if (from == SEEK_CUR) {
		fp->Pos+=offset;
	}
	else if (from == SEEK_END) {
		fp->Pos=fp->Size-offset;
	}
}

unsigned long
CGameFile::Tell(DataFile_t *fp)
{
	return(fp->Pos);
}

void
CGameFile::BuildDataFileList(char *file_path,FILE *out_fp,const char *ignore_list[],int num_ignore_files)
{
	WIN32_FIND_DATA find_data;
	HANDLE h=FindFirstFile("*.*",&find_data);
	if (h != INVALID_HANDLE_VALUE) {
		do {
			if ((find_data.dwFileAttributes&FILE_ATTRIBUTE_SYSTEM) != 0) {
				continue;
			}
			else if ((find_data.dwFileAttributes&FILE_ATTRIBUTE_HIDDEN) != 0) {
				continue;
			}
			else if ((find_data.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) != 0) {
				if (strcmp(find_data.cFileName,".") == 0) {
					continue;
				}
				else if (strcmp(find_data.cFileName,"..") == 0) {
					continue;
				}
				else {
					char file_name[256];
					strcpy(file_name,file_path);
					if (strlen(file_name) > 0) {
						strcat(file_name,"/");
					}
					strcat(file_name,find_data.cFileName);
					SetCurrentDirectory(find_data.cFileName);
					BuildDataFileList(file_name,out_fp,ignore_list,num_ignore_files);
					SetCurrentDirectory("..");
				}
			}
			else {
				char file_name[256];
				strcpy(file_name,file_path);
				if (strlen(file_name) > 0) {
					strcat(file_name,"/");
				}
				strcat(file_name,find_data.cFileName);
				strupr(file_name);
				if (strstr(file_name,".EXE") != NULL) {
					continue;
				}
				bool ignore=false;
				for (int i=0 ; i < num_ignore_files ; i++) {
					if (strstr(file_name,ignore_list[i]) != NULL) {
						ignore=true;
						break;
					}
				}
				if (ignore) {
					continue;
				}
				FILE *fp=fopen(find_data.cFileName,"rb");
				if (fp != NULL) {
					fseek(fp,0,SEEK_END);
					long file_size=ftell(fp);
					fseek(fp,0,SEEK_SET);
					void *file_mem=new char[file_size];
					fread(file_mem,sizeof(char),file_size,fp);
					fclose(fp);
					fwrite(file_mem,sizeof(char),file_size,out_fp);
					strcpy(m_DataFileHdr.Filename[m_DataFileHdr.NumFiles],file_name);
					m_DataFileHdr.FilePos[m_DataFileHdr.NumFiles]=m_DataFilePos;
					m_DataFileHdr.FileSize[m_DataFileHdr.NumFiles]=file_size;
					m_DataFileHdr.NumFiles++;
					m_DataFilePos+=file_size;
				}
			}
		} while (FindNextFile(h,&find_data));
		FindClose(h);
	}
}

void
CGameFile::BuildDataFile(const char *data_file_name,const char *ignore_list[],int num_ignore_files)
{
	CloseDataFile();
	FILE *fp=fopen(data_file_name,"wb");
	memset(&m_DataFileHdr,0,sizeof(DataFileHdr_t));
	fwrite(&m_DataFileHdr,sizeof(DataFileHdr_t),1,fp);
	m_DataFilePos=sizeof(DataFileHdr_t);
	BuildDataFileList("",fp,ignore_list,num_ignore_files);
	fseek(fp,0,SEEK_SET);
	fwrite(&m_DataFileHdr,sizeof(DataFileHdr_t),1,fp);
	fclose(fp);
}

void
InitFileSystem()
{
	CGameFile *file_system=new CGameFile;
	GameAppInitFileSystem();
}

void
UnInitFileSystem()
{
	if (g_GameFile != NULL) {
		delete g_GameFile;
	}
}
