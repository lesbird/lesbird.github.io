// GameEditor.h: interface for the CGameEditor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEEDITOR_H__12C67F2B_8B75_4155_8436_0184511A2CD4__INCLUDED_)
#define AFX_GAMEEDITOR_H__12C67F2B_8B75_4155_8436_0184511A2CD4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameGfx.h"

class CGameEditor  
{
public:
	CGameEditor();
	virtual ~CGameEditor();

	virtual void		Init();
	virtual void		UnInit();
	virtual void		Update(float delta_time);

public:
	GameObjectList_t	EditObjList;

	CGameObject *		SelectedObj;
	Sprite_t *			SelectedSpr;
};

#endif // !defined(AFX_GAMEEDITOR_H__12C67F2B_8B75_4155_8436_0184511A2CD4__INCLUDED_)
