// GameObject.h: interface for the CGameObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEOBJECT_H__937CA648_3F46_43D7_B07B_DD1CAB0E81C4__INCLUDED_)
#define AFX_GAMEOBJECT_H__937CA648_3F46_43D7_B07B_DD1CAB0E81C4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <list>

using namespace std;

#define	CLAMP_360(a)		((a < 0) ? a+360 : (a > 360) ? a-360 : a)

#define	VAR_VALUE_SIZE		128

#define	VAR_BBOX_MIN		'BBMI'
#define	VAR_BBOX_MAX		'BBMA'
#define	VAR_CAN_CULL		'CCUL'
#define	VAR_CAN_DELETE		'CDEL'
#define	VAR_CATEGORY		'CATE'
#define	VAR_EFFECT			'EFFE'
#define	VAR_EFFECT_TECH		'EFFT'
#define	VAR_FILE			'FILE'
#define	VAR_HAS_SHADOW		'HSHA'
#define	VAR_IS_ACTIVE		'IACT'
#define	VAR_IS_ALIVE		'IALI'
#define	VAR_IS_CLIPPED		'ICLI'
#define	VAR_IS_ORTHO		'IORT'
#define	VAR_IS_SKYBOX		'ISKY'
#define	VAR_IS_STATIC		'ISTA'
#define	VAR_IS_TRANSPARENT	'ITRA'
#define	VAR_IS_UNLIT		'IUNL'
#define	VAR_IS_VISIBLE		'IVIS'
#define	VAR_MASS			'MASS'
#define	VAR_NAME			'NAME'
#define	VAR_POS				'POSI'
#define	VAR_QUAT			'QUAT'
#define	VAR_RADIUS			'RADI'
#define	VAR_ROT				'ROTA'
#define	VAR_SCALE			'SCAL'
#define	VAR_TAG				'TAG'
#define	VAR_TRANSLUCENCY	'TRAN'
#define	VAR_TYPE			'TYPE'

typedef struct Var
{
	unsigned int			Name;
	char					Value[VAR_VALUE_SIZE];
} Var_t;

typedef list<Var_t *>		VarList_t;

class CGameObject  
{
public:
	CGameObject();
	virtual ~CGameObject();

	virtual bool			RotateTo(float x,float y,float z,float rotate_rate,float threshold,float delta_time);

	virtual void			SetPosition(float x,float y,float z);
	virtual void			GetPosition(float &x,float &y,float &z);
	virtual void			SetRotation(float x,float y,float z);
	virtual void			GetRotation(float &x,float &y,float &z);
	virtual void			SetQuaternion(float x,float y,float z,float w);
	virtual void			GetQuaternion(float &x,float &y,float &z,float &w);
	virtual void			SetScale(float x,float y,float z);
	virtual void			GetScale(float &x,float &y,float &z);
	virtual void			SetTag(const char *tag);
	virtual const char *	GetTag();

	virtual void			LoadScriptFile(const char *file_name);

	virtual void			ApplyVars();
	virtual void			UpdateVars();

	virtual void			LostObject();
	virtual void			ResetObject();
	virtual void			UpdateObject(float delta_time);

	virtual void			PreRenderObject();
	virtual void			RenderObject();
	virtual void			PostRenderObject();

public:
	bool					m_bCanCull;
	bool					m_bHasShadow;
	bool					m_bIsActive;
	bool					m_bIsAlive;
	bool					m_bIsClipped;
	bool					m_bIsOrtho;
	bool					m_bIsStatic;
	bool					m_bIsTransparent;
	bool					m_bIsUnlit;
	bool					m_bVisible;

	unsigned int			m_Category;
	int						m_ObjectIndex;
	int						m_Sort;
	int						m_State;
	int						m_Type;

	char					m_Tag[128];

	float					m_KillTime;
	float					m_LifeTime;
	float					m_Translucency;

	char *					m_ScriptCode;
	int						m_ScriptSize;
	int						m_ScriptStatus;

	VarList_t				m_VarList;
	Var_t *					m_VarCache;
};

typedef list<CGameObject *>	GameObjectList_t;

extern
GameObjectList_t			GameObjectList;
extern
GameObjectList_t			RenderObjectList;

extern
CGameObject *				CreateGameObject();
extern
void						InsertGameObject(CGameObject *gobj);
extern
void						DeleteGameObject(CGameObject *gobj);

extern
Var_t *						FindVar(CGameObject *gobj,unsigned int name);
extern
unsigned int				StrToVar(const char *str);
extern
void						AddVar(CGameObject *gobj,unsigned int name,const char *val);
extern
const char *				GetVar(CGameObject *gobj,unsigned int name);
extern
void						AddBool(CGameObject *gobj,unsigned int name,bool val);
extern
bool						GetBool(CGameObject *gobj,unsigned int name);
extern
void						AddInt(CGameObject *gobj,unsigned int name,int val);
extern
int							GetInt(CGameObject *gobj,unsigned int name);
extern
void						AddFloat(CGameObject *gobj,unsigned int name,float val);
extern
float						GetFloat(CGameObject *gobj,unsigned int name);
extern
void						AddVec3(CGameObject *gobj,unsigned int name,float x,float y,float z);
extern
void						GetVec3(CGameObject *gobj,unsigned int name,float &x,float &y,float &z);
extern
void						AddVec4(CGameObject *gobj,unsigned int name,float x,float y,float z,float w);
extern
void						GetVec4(CGameObject *gobj,unsigned int name,float &x,float &y,float &z,float &w);
extern
void						AddPtr(CGameObject *gobj,unsigned int name,void *ptr);
extern
void *						GetPtr(CGameObject *gobj,unsigned int name);
extern
CGameObject *				FindTag(const char *tag);
extern
CGameObject *				FindNextTag(const char *tag,CGameObject *start_obj);

extern
void						Hide(CGameObject *gobj);
extern
void						Show(CGameObject *gobj);

#endif // !defined(AFX_GAMEOBJECT_H__937CA648_3F46_43D7_B07B_DD1CAB0E81C4__INCLUDED_)
