// Particle.h: interface for the CParticle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARTICLE_H__FA96CCE0_F210_485C_8BE9_1A8ED207CE9F__INCLUDED_)
#define AFX_PARTICLE_H__FA96CCE0_F210_485C_8BE9_1A8ED207CE9F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct Particle
{
	float		life;
	float		alpha_scale;
	D3DCOLOR	color;
	D3DXVECTOR3	acc;
	D3DXVECTOR3	vel;
	D3DXVECTOR3	pos;
} Particle_t;

typedef list<Particle_t *>		ParticleList_t;

typedef struct ParticleEmitter
{
	char						name[32];
	bool						is_active;
	bool						is_static;
	bool						is_world;
	float						size;
	Particle_t *				particle;
	LPDIRECT3DVERTEXBUFFER8		vertex_buffer;
	LPDIRECT3DTEXTURE8			texture;
	ParticleList_t				active_particles;
	ParticleList_t				inactive_particles;
} ParticleEmitter_t;

typedef list<ParticleEmitter_t *>	ParticleEmitterList_t;

extern
ParticleEmitterList_t	ParticleEmitterList;

class CGameParticles
{
public:
	CGameParticles();
	virtual ~CGameParticles();

	ParticleEmitter_t *	FindEmitter(const char *name);
	void				CreateParticleEmitter(ParticleEmitter_t *particle_emitter,int max_particles,const char *texture_file);
	ParticleEmitter_t *	CreateParticleEmitter(const char *name,int max_particles,const char *texture_file,float size,bool is_static=false,bool is_world=true);
	void				DeleteParticleEmitter(ParticleEmitter_t *particle_emitter);
	void				ResetParticleEmitter(ParticleEmitter_t *particle_emitter);
	void				AddParticle(ParticleEmitter_t *particle_emitter,D3DXVECTOR3 pos,D3DXVECTOR3 vel,D3DXVECTOR3 acc,float life,D3DCOLOR color_argb);
	void				Tick(float delta_time);
	void				Render();
};

extern
CGameParticles *		g_Particles;

extern
void					InitParticles();
extern
void					UnInitParticles();
extern
void					UpdateParticles(float delta_time);
extern
void					RenderParticles();

#endif // !defined(AFX_PARTICLE_H__FA96CCE0_F210_485C_8BE9_1A8ED207CE9F__INCLUDED_)
