// GameSound.h: interface for the CGameSound class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMESOUND_H__4A791E5B_C307_4778_B4CB_FB2D2CE11229__INCLUDED_)
#define AFX_GAMESOUND_H__4A791E5B_C307_4778_B4CB_FB2D2CE11229__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "dsutil.h"

#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"winmm.lib")
/*
#pragma comment(lib,"dxguid.lib")
*/
#ifdef _DEBUG
#pragma comment(lib,"dxerr8.lib")
#endif

typedef struct SndBuffer
{
	char					FileName[128];
	bool					bPlaying;
	float					Timer;
	LPDIRECTSOUNDBUFFER		Sound;
	void *					Object;
} SndBuffer_t;

typedef list<SndBuffer_t *> SndBufferList_t;

class CGameSound  
{
public:
	CGameSound();
	virtual ~CGameSound();

};

typedef SndBuffer_t *		SND_HANDLE;

extern
void		InitSound();
extern
void		UnInitSound();

extern
void		SndRemoveSound(SND_HANDLE buffer);

extern
void		SndSetWorldScale(float scale);
extern
void		SndSetListener(D3DXVECTOR3 pos,D3DXVECTOR3 vel);

extern
SND_HANDLE	SndGetBuffer(char *file_name);

extern
SND_HANDLE	SndPreCache(char *file_name);

extern
SND_HANDLE	SndLoopBuffer(SND_HANDLE buffer,CGameObject *gobj=NULL);
extern
SND_HANDLE	SndLoop(char *file_name,CGameObject *owner=NULL);
extern
SND_HANDLE	SndPlayBuffer(SND_HANDLE buffer,CGameObject *gobj=NULL);
extern
SND_HANDLE	SndPlay(char *file_name,CGameObject *owner=NULL);
extern
SND_HANDLE	SndPlayPos(char *file_name,D3DXVECTOR3 pos,bool loop=false);

extern
bool		SndIsPlaying(SND_HANDLE buffer);

extern
void		SndStop(SND_HANDLE buffer);

extern
void		SndClearPlayList();

extern
void		SndComputeVol(SND_HANDLE buffer);

extern
void		UpdateSound(float delta_time);

extern
void		GameSoundIsDone(SND_HANDLE buffer);

#endif // !defined(AFX_GAMESOUND_H__4A791E5B_C307_4778_B4CB_FB2D2CE11229__INCLUDED_)
