// GameInput.h: interface for the CGameInput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUT_H__F9EC13BB_2463_4AC1_BC24_FA25977DF55A__INCLUDED_)
#define AFX_INPUT_H__F9EC13BB_2463_4AC1_BC24_FA25977DF55A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	DIRECTINPUT_VERSION			0x0800
#include <dinput.h>

#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")

#define	NUM_JOYSTICKS				4
#define	NUM_JOYSTICK_BUTTONS		32
#define	NUM_JOYSTICK_STICKS			2

enum {
	LEFT_MOUSE_BUTTON=1,
	RIGHT_MOUSE_BUTTON=2,
	MIDDLE_MOUSE_BUTTON=4
};

enum {
	JOYBUTTON_RDOWN,
	JOYBUTTON_RLEFT,
	JOYBUTTON_RRIGHT,
	JOYBUTTON_RUP,
	JOYBUTTON_L1,
	JOYBUTTON_L2,
	JOYBUTTON_R1,
	JOYBUTTON_R2,
	JOYBUTTON_SELECT,
	JOYBUTTON_START,
	JOYBUTTON_LSTICK,
	JOYBUTTON_RSTICK,
	JOYBUTTON_LDOWN,
	JOYBUTTON_LLEFT,
	JOYBUTTON_LRIGHT,
	JOYBUTTON_LUP
};

extern
bool						g_bMouseAcquired;
extern
unsigned long				g_MouseFlags;
extern
unsigned long				g_JoystickFlags;
extern
unsigned long				g_MouseButtons;
extern
unsigned long				g_PrevMouseButtons;
extern
D3DXVECTOR3					g_MouseDelta;
extern
int							g_NumJoysticks;
extern
D3DXVECTOR3					g_JoyAxis[NUM_JOYSTICKS][NUM_JOYSTICK_STICKS];
extern
unsigned char				g_JoyButton[NUM_JOYSTICKS][NUM_JOYSTICK_BUTTONS];
extern
unsigned char				g_PrevJoyButton[NUM_JOYSTICKS][NUM_JOYSTICK_BUTTONS];
extern
long						g_JoyPOV[NUM_JOYSTICKS];
extern
long						g_PrevJoyPOV[NUM_JOYSTICKS];
extern
LPDIRECTINPUT8				g_DI;
extern
LPDIRECTINPUTDEVICE8		g_DIJoystick[NUM_JOYSTICKS];
extern
LPDIRECTINPUTDEVICE8		g_DIKeyboard;
extern
LPDIRECTINPUTDEVICE8		g_DIMouse;

extern
void						InitInput();

extern
void						UnInitInput();

extern
void						UpdateInput(float delta_time);

extern
void						AcquireMouse();
extern
void						UnacquireMouse();

extern
bool						GetMouseButton(int mouse_button);

extern
bool						PeekMouseButton(int mouse_button);

extern
bool						GetJoystickButton(int joy_num,int button_num);

extern
bool						PeekJoystickButton(int joy_num,int button_num);

extern
D3DXVECTOR3					GetJoystickAxis(int joy_num,int stick_num);

#endif // !defined(AFX_INPUT_H__F9EC13BB_2463_4AC1_BC24_FA25977DF55A__INCLUDED_)
