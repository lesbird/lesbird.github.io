
Copy all these files to the mame folder so that MamePlayer.exe resides in the same folder as mame.exe.

Dump the game list to an xml file by typing this at the command line:

>mame -listxml >list.xml

Run MamePlayer.exe to start the frontend.
