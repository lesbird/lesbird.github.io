--	insert any additional games into the list
--
--	insertgame() parameters:
--		full path to executable
--		description of game
--		year game was released
--		manufacturer or author
--		full path to screenshot

-- mam.insertgame("d:/games/diamond caves ii/dc2.exe","Diamond Caves 2","2006","Peter Elzner","d:/games/diamond caves ii/screens/dc2.jpg")
