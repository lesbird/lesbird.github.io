Copy the png screenshots from the snap.zip file here
