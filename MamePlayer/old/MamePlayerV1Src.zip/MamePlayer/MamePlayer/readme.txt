Build with Visual Studio 6 or Visual Studio 2005 (this is old code).

Requires the DirectX 8 SDK to compile.

MamePlayer uses the Quantum 3 game engine which was written by me and is included in this archive.
Levitar 3 was written using the Quantum 3 game engine (www.thegameprojects.com)

lesbird@lesbird.com
