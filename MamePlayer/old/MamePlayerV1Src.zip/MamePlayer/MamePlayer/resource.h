//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDI_ICON1                       101
#define IDD_DIALOG1                     102
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_CHECK3                      1002
#define IDC_CHECK4                      1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_RADIO3                      1006
#define IDC_CHECK5                      1007
#define IDC_CHECK6                      1008
#define IDC_CHECK7                      1009
#define IDC_CHECK8                      1010
#define IDC_CHECK10                     1012
#define IDC_CHECK11                     1013
#define IDC_CHECK12                     1014
#define IDC_CHECK13                     1015
#define IDC_CHECK9                      1016
#define IDC_CHECK14                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
