// Game.cpp: implementation of the CGame class.
//
//////////////////////////////////////////////////////////////////////

#include "Game.h"
#include "resource.h"
#include <io.h>
#include <process.h>
#include <time.h>

bool	CnfLeftXInv;
bool	CnfLeftYInv;
bool	CnfLeftSwap;
bool	CnfRightXInv;
bool	CnfRightYInv;
bool	CnfRightSwap;
int		CnfMouseSens=75;
int		CnfDetailLevel=0;

int		MameBuild=0;

char *	g_GameName="MamePlayer";

CGame *	g_Game;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGame::CGame()
{
	g_Game=this;
}

CGame::~CGame()
{
	g_Game=NULL;
}

//	function callbacks

int
GameAppGetSelectedDisplayMode()
{
	return(-1);
}

void
GameAppGetWindowSize(int &width,int &height)
{
	width=width;
	height=height;
}

void
GameAppSetWindowSize(int width,int height)
{
	g_bWindowedMode=true;
}

bool
GameAppCanCollide(CGameObject *gobj1,CGameObject *gobj2)
{
	return(true);
}

float
GameAppCollideCFM(CGameObject *gobj1,CGameObject *gobj2)
{
	return(0);
}

float
GameAppCollideFriction(CGameObject *gobj1,CGameObject *gobj2)
{
	return(1);
}

float
GameAppCollideRestitution(CGameObject *gobj1,CGameObject *gobj2)
{
	return(0.5f);
}

void
GameAppCollision(CGameObject *gobj1,CGameObject *gobj2,float x,float y,float z,float nor_x,float nor_y,float nor_z,float pen)
{
}

void
GameAppInitFileSystem()
{
#if _RETAIL_
	if (!g_GameFile->OpenDataFile(DATA_FILE_NAME)) {
		g_GameFile->BuildDataFile(DATA_FILE_NAME,IgnoreFileList,NUM_IGNORE_FILES);
		g_GameFile->OpenDataFile(DATA_FILE_NAME);
	}
#endif
}

void
GameAppRenderScene()
{
}

void
GameAppUpdateMesh(CGameMesh *mesh_obj,float delta_time)
{
}

void
GameAppTextureTransform(CGameMesh *mesh_obj,int tex_index,int xform_type,float xform_rate,float delta_time)
{
}

void
GameSoundIsDone(SND_HANDLE buffer)
{
}

//
//	MamePlayer related functions start here
//

#define	DEFAULT_TEXTURE		"mameplayer/bitmaps/MameLogoTM_sml.jpg"

typedef struct GameData
{
	char	RomFile[16];
	char	LaunchExe[64];
	char	Desc[48];
	char	Year[16];
	char	Manufacturer[32];
	char	Bitmap[64];
	bool	bClone;
	bool	bFilter;
} GameData_t;

typedef list<GameData_t *>	GameQueue_t;

static
GameQueue_t					GameQueue;
static
GameQueue_t::iterator		SelectedGame;

static
GameData_t *				CurrentGame;

typedef struct FilterData
{
	char	RomFile[16];
} FilterData_t;

typedef list<FilterData_t *> FilterQueue_t;

static
FilterQueue_t				FilterQueue;

static
bool						bBlockClones,
							bFilterGames;
static
bool						bSkipGameInfo=true,
							bCheatEnable=false,
							bAutoFrameSkip=true,
							bSwitchRes=false,
							bThrottle=true,
							bTripleBuffer=true,
							bWaitVSync=true,
							bUseBackdrops=true,
							bUseBezels=false,
							bUseOverlays=true,
							bMouseEnable=true,
							bJoystickEnable=true,
							bJoystickDigital=true,
							bCustomController=true;

static
int							RenderOption=0;

static
unsigned int				MemUsed;

static
bool						bScreenSave;

static
int							GameCount,
							GameIndex;

static
float						Scale_Y;

static
Sprite_t *					BackSpr;
static
Sprite_t *					LogoSpr;
static
Sprite_t *					ScreenSaveSpr;
static
Sprite_t *					MouseInterfaceSpr;

static
FILE *						XmlFP;

static
SND_HANDLE					SndAct;
static
SND_HANDLE					SndFilter;
static
SND_HANDLE					SndUnFilter;
static
SND_HANDLE					SndMen;
static
SND_HANDLE					SndSld;

void
GameLaunchExe(char *exe_name,char *cmd_line);

BOOL CALLBACK
GameDialogProc(HWND hWndDlg,UINT message,WPARAM wparam,LPARAM lparam);

//

bool
GameCopyKeywords(char *dest,char *buf,char *key1,char *key2,int bytes)
{
	bool ampersand=false;
	char *ptr=strstr(buf,key1);
	if (ptr != NULL) {
		char *ptr2=ptr+strlen(key1);
		char *ptr3=strstr(buf,key2);
		if (ptr3 != NULL) {
			int n=0;
			while (ptr2 != ptr3 && n < bytes-1) {
				if (*ptr2 == '(') {
					ptr2--;
					*ptr2=0;
					break;
				}
				else if (*ptr2 == '&' && *(ptr2+1) == 'a' && *(ptr2+2) == 'm' && *(ptr2+3) == 'p' && *(ptr2+4) == ';') {
					dest[n++]='&';
					ptr2+=5;
				}
				else {
					dest[n++]=*ptr2++;
				}
			}
			dest[n++]=0;
			return(true);
		}
	}
	return(false);
}

void
GameLoadFilterData()
{
	while (FilterQueue.size() > 0) {
		FilterData_t *filter_data=(*FilterQueue.begin());
		FilterQueue.pop_front();
		delete filter_data;
	}

	FILE *fp=fopen("filter.dat","rb");
	if (fp != NULL) {
		int n;
		fread(&n,sizeof(int),1,fp);
		for (int i=0 ; i < n ; i++) {
			FilterData_t *filter_data=new FilterData_t;
			fread(filter_data,sizeof(FilterData_t),1,fp);
			FilterQueue.push_back(filter_data);
		}
		fclose(fp);
	}
}

void
GameSaveFilterData()
{
	FILE *fp=fopen("filter.dat","wb");
	if (fp != NULL) {
		int n=FilterQueue.size();
		fwrite(&n,sizeof(int),1,fp);
		for (FilterQueue_t::iterator f=FilterQueue.begin() ; f != FilterQueue.end() ; f++) {
			FilterData_t *filter_data=(*f);
			fwrite(filter_data,sizeof(FilterData_t),1,fp);
		}
		fclose(fp);
	}
}

bool
GameFilterName(char *rom_file)
{
	if (rom_file != NULL && strlen(rom_file) > 0) {
		for (FilterQueue_t::iterator f=FilterQueue.begin() ; f != FilterQueue.end() ; f++) {
			FilterData_t *filter_data=(*f);
			if (strcmp(rom_file,filter_data->RomFile) == 0) {
				return(true);
			}
		}
	}
	return(false);
}

void
GameAddFilter(char *rom_file)
{
	if (rom_file != NULL && strlen(rom_file) > 0) {
		if (GameFilterName(rom_file)) {
			return;
		}
		FilterData_t *filter_data=new FilterData_t;
		ZeroMemory(filter_data,sizeof(FilterData_t));
		strcpy(filter_data->RomFile,rom_file);
		FilterQueue.push_back(filter_data);
		GameSaveFilterData();
	}
}

void
GameDelFilter(char *rom_file)
{
	if (rom_file != NULL && strlen(rom_file) > 0) {
		for (FilterQueue_t::iterator f=FilterQueue.begin() ; f != FilterQueue.end() ; f++) {
			FilterData_t *filter_data=(*f);
			if (strcmp(filter_data->RomFile,rom_file) == 0) {
				FilterQueue.erase(f);
				GameSaveFilterData();
				return;
			}
		}
	}
}

void
GameInsertGame(const char *rom_file,const char *launch_exe,const char *desc,const char *year,const char *manufacturer,const char *bitmap_file,bool clone,bool filter)
{
	if (desc != NULL && strlen(desc) > 0) {
		GameData_t *game_data=new GameData_t;
		ZeroMemory(game_data,sizeof(GameData_t));
		if (rom_file != NULL) {
			strncpy(game_data->RomFile,rom_file,16);
		}
		if (launch_exe != NULL) {
			strncpy(game_data->LaunchExe,launch_exe,64);
		}
		strncpy(game_data->Desc,desc,48);
		if (year != NULL) {
			strncpy(game_data->Year,year,16);
		}
		if (manufacturer != NULL) {
			strncpy(game_data->Manufacturer,manufacturer,32);
		}
		if (bitmap_file != NULL) {
			strncpy(game_data->Bitmap,bitmap_file,64);
		}
		game_data->bClone=clone;
		game_data->bFilter=filter;
		bool insert=false;
		if (GameQueue.size() > 0) {
			for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
				GameData_t *game_data2=(*g);
				if (strcmp(game_data2->Desc,game_data->Desc) > 0) {
					GameQueue.insert(g,game_data);
					insert=true;
					break;
				}
			}
		}
		if (!insert) {
			GameQueue.push_back(game_data);
		}
		MemUsed+=sizeof(GameData_t);
	}
}

void
GameLoadList()
{
	static bool clone,filter;
	char buf[256];
	char bitmap_file[64],desc[64],manufacturer[32],rom_file[16],year[16];
	char search_file[64];
	int lines=10000;

	if (XmlFP == NULL) {
		while (GameQueue.size() > 0) {
			GameData_t *game_data=(*GameQueue.begin());
			GameQueue.pop_front();
			delete game_data;
		}

		GameLoadFilterData();

		XmlFP=fopen("list.xml","rt");
	}

	if (XmlFP != NULL) {
		int parse_key=0;
		do {
			fgets(buf,256,XmlFP);
			if (MameBuild == 0) {
				if (strstr(buf,"<mame build=") != NULL) {
					int mame_hi,mame_lo;
					sscanf(buf,"<mame build=\"%d.%d ",&mame_hi,&mame_lo);
					MameBuild=mame_lo;
				}
			}
			switch (parse_key) {
			case 0:
				if (GameCopyKeywords(rom_file,buf,"<game name=\"","\" sourcefile",sizeof(rom_file))) {
					clone=false;
					filter=false;
					if (strstr(buf,"cloneof=") != NULL) {
						clone=true;
					}
					if (GameFilterName(rom_file)) {
						filter=true;
					}
					parse_key++;
				}
				break;
			case 1:
				if (GameCopyKeywords(desc,buf,"<description>","</description>",sizeof(desc))) {
					parse_key++;
				}
				else {
					parse_key=0;
				}
				break;
			case 2:
				if (GameCopyKeywords(year,buf,"<year>","</year>",sizeof(year))) {
					parse_key++;
				}
				else {
					parse_key=0;
				}
				break;
			case 3:
				if (GameCopyKeywords(manufacturer,buf,"<manufacturer>","</manufacturer>",sizeof(manufacturer))) {
					parse_key++;
				}
				else {
					parse_key=0;
				}
				break;
			}
			if (parse_key == 4) {
				//	add to queue
				sprintf(search_file,"roms/%s.zip",rom_file);
				if (_access(search_file,0) == 0) {
					bitmap_file[0]=0;
					sprintf(search_file,"mameplayer/screens/%s.png",rom_file);
					if (_access(search_file,0) == 0) {
						strcpy(bitmap_file,search_file);
					}
					else {
						sprintf(search_file,"mameplayer/screens/%s.bmp",rom_file);
						if (_access(search_file,0) == 0) {
							strcpy(bitmap_file,search_file);
						}
					}
					GameInsertGame(rom_file,NULL,desc,year,manufacturer,bitmap_file,clone,filter);
				}
				parse_key=0;
			}
			if (feof(XmlFP)) {
				fclose(XmlFP);
				XmlFP=NULL;
				return;
			}
		} while (--lines > 0);
	}
}

void
GameLaunchExe(char *exe_name,char *cmd_line)
{
	STARTUPINFO startup_info;
	ZeroMemory(&startup_info,sizeof(STARTUPINFO));
	startup_info.cb=sizeof(STARTUPINFO);
	startup_info.dwFlags=STARTF_USESHOWWINDOW;
	startup_info.wShowWindow=SW_MINIMIZE;
	PROCESS_INFORMATION process_info;
	ZeroMemory(&process_info,sizeof(PROCESS_INFORMATION));

	GfxDeviceLost();
	if (CreateProcess(exe_name,cmd_line,NULL,NULL,FALSE,0,NULL,NULL,&startup_info,&process_info)) {
		WaitForSingleObject(process_info.hProcess,INFINITE);
		CloseHandle(process_info.hProcess);
		CloseHandle(process_info.hThread);
	}
	GfxDeviceReset();
}

static
char	dir[256],drv[256],exe[256],ext[256];
static
char	launch_exe[256],launch_path[256];

//	default command line:
//		%s -direct3d -noswitchres -triplebuffer -skip_gameinfo -nobezel -nobackdrop -mouse -joystick -ctrlr mame

void
GameLaunchGame(GameData_t *game_data)
{
	float aspect=float(g_DisplayWidth)/float(g_DisplayHeight);

	char cmd_line[256];
	if (strlen(game_data->LaunchExe) > 0) {
		_splitpath(game_data->LaunchExe,drv,dir,exe,ext);
		GetCurrentDirectory(sizeof(cmd_line),cmd_line);
		sprintf(launch_path,"%s%s",drv,dir);
		SetCurrentDirectory(launch_path);
		sprintf(launch_exe,"%s%s",exe,ext);
		UnInitInput();
		GameLaunchExe(launch_exe,NULL);
		InitInput();
		SetCurrentDirectory(cmd_line);
		return;
	}

	sprintf(cmd_line," %s",game_data->RomFile);

	if (MameBuild >= 107) {
		switch (RenderOption) {
		case 0:
			strcat(cmd_line," -video d3d");
			break;
		case 1:
			strcat(cmd_line," -video ddraw");
			break;
		case 2:
			strcat(cmd_line," -video gdi");
			break;
		}
	}
	else {
		switch (RenderOption) {
		case 0:
			strcat(cmd_line," -direct3d");
			break;
		case 1:
			strcat(cmd_line," -ddraw");
			break;
		case 2:
			strcat(cmd_line," -gdi");
			break;
		}
	}
	if (!bSwitchRes) {
		strcat(cmd_line," -noswitchres");
	}
	if (bTripleBuffer) {
		strcat(cmd_line," -triplebuffer");
	}
	if (bSkipGameInfo) {
		strcat(cmd_line," -skip_gameinfo");
	}
	if (!bUseBezels) {
		strcat(cmd_line," -nobezel");
	}
	if (!bUseBackdrops) {
		strcat(cmd_line," -nobackdrop");
	}
	if (!bUseOverlays) {
		strcat(cmd_line," -nooverlay");
	}
//	strcat(cmd_line," -beam 1.5");
	if (bMouseEnable) {
		strcat(cmd_line," -mouse");
	}
	if (bJoystickEnable) {
		strcat(cmd_line," -joystick");
		if (bJoystickDigital) {
			strcat(cmd_line," -digital all");
		}
	}
	if (bCustomController) {
		strcat(cmd_line," -ctrlr mame");
	}
//	if (MameBuild >= 107) {
//		sprintf(cmd_line," %s -video d3d -noswitchres -triplebuffer -skip_gameinfo -nobezel -mouse -joystick -digital all -ctrlr mame",game_data->RomFile);
//	}
//	else {
//		sprintf(cmd_line," %s -direct3d -noswitchres -triplebuffer -skip_gameinfo -nobezel -mouse -joystick -digital all -ctrlr mame",game_data->RomFile);
//	}
	UnInitInput();
	GameLaunchExe("mame.exe",cmd_line);
	InitInput();
}

void
GameScrollUp(int num)
{
	int n=num;
	while (n-- > 0 && GameIndex > 0) {
		GameIndex--;
	}
}

void
GameScrollDown(int num)
{
	int n=num;
	while (n-- > 0 && GameIndex < GameCount-1) {
		GameIndex++;
	}
}

void
GamePlayClickSound()
{
	SndPlayBuffer(SndMen,NULL);
}

void
GamePlaySlideSound()
{
	SndPlayBuffer(SndSld,NULL);
}

void
GamePlayLaunchSound()
{
	SndPlayBuffer(SndAct,NULL);
}

void
GameLoadConfig()
{
	FILE *fp=fopen("MamePlayer.cfg","rb");
	if (fp != NULL) {
		fread(&GameIndex,sizeof(int),1,fp);
		fread(&bBlockClones,sizeof(bool),1,fp);
		fread(&bFilterGames,sizeof(bool),1,fp);

		fread(&bSkipGameInfo,sizeof(bool),1,fp);
		fread(&bCheatEnable,sizeof(bool),1,fp);
		fread(&bAutoFrameSkip,sizeof(bool),1,fp);
		fread(&bSwitchRes,sizeof(bool),1,fp);
		fread(&bThrottle,sizeof(bool),1,fp);
		fread(&bTripleBuffer,sizeof(bool),1,fp);
		fread(&bWaitVSync,sizeof(bool),1,fp);
		fread(&bUseBackdrops,sizeof(bool),1,fp);
		fread(&bUseBezels,sizeof(bool),1,fp);
		fread(&bUseOverlays,sizeof(bool),1,fp);
		fread(&bMouseEnable,sizeof(bool),1,fp);
		fread(&bJoystickEnable,sizeof(bool),1,fp);
		fread(&RenderOption,sizeof(int),1,fp);
		fread(&bCustomController,sizeof(bool),1,fp);
		fread(&bJoystickDigital,sizeof(bool),1,fp);

		fclose(fp);
		return;
	}
	bBlockClones=false;
	bFilterGames=true;
}

void
GameSaveConfig()
{
	FILE *fp=fopen("MamePlayer.cfg","wb");
	if (fp != NULL) {
		fwrite(&GameIndex,sizeof(int),1,fp);
		fwrite(&bBlockClones,sizeof(bool),1,fp);
		fwrite(&bFilterGames,sizeof(bool),1,fp);

		fwrite(&bSkipGameInfo,sizeof(bool),1,fp);
		fwrite(&bCheatEnable,sizeof(bool),1,fp);
		fwrite(&bAutoFrameSkip,sizeof(bool),1,fp);
		fwrite(&bSwitchRes,sizeof(bool),1,fp);
		fwrite(&bThrottle,sizeof(bool),1,fp);
		fwrite(&bTripleBuffer,sizeof(bool),1,fp);
		fwrite(&bWaitVSync,sizeof(bool),1,fp);
		fwrite(&bUseBackdrops,sizeof(bool),1,fp);
		fwrite(&bUseBezels,sizeof(bool),1,fp);
		fwrite(&bUseOverlays,sizeof(bool),1,fp);
		fwrite(&bMouseEnable,sizeof(bool),1,fp);
		fwrite(&bJoystickEnable,sizeof(bool),1,fp);
		fwrite(&RenderOption,sizeof(int),1,fp);
		fwrite(&bCustomController,sizeof(bool),1,fp);
		fwrite(&bJoystickDigital,sizeof(bool),1,fp);
		
		fclose(fp);
	}
}

static
int
GameScriptInsertGame(lua_State *l)
{
	const char *exep=lua_tostring(l,1);
	const char *desc=lua_tostring(l,2);
	const char *year=lua_tostring(l,3);
	const char *manu=lua_tostring(l,4);
	const char *bitm=lua_tostring(l,5);
	GameInsertGame(NULL,exep,desc,year,manu,bitm,false,false);
	return(0);
}

#define	MAM_LIBNAME	"mam"

static const
luaL_reg MamLib[]={
	{"insertgame",GameScriptInsertGame},
	{NULL,NULL}
};

//
//	Quantum 3 engine required functions start here
//

void
CGame::InitGame()
{
	CGameApp::InitGame();

	luaL_register(g_GameScript->m_luaState,MAM_LIBNAME,MamLib);

	GfxInitFontSystem(0,"courier new",10,0);
	GfxInitFontSystem(1,"courier new",16,2);
	GfxInitFontSystem(2,"courier new",24,2);
	GfxInitFontSystem(3,"arial",8,0);

	float aspect=g_DisplayWidth/g_DisplayHeight;
	GfxSetProjection(45,aspect,1,10000);

	GameQueue.clear();
	FilterQueue.clear();

	Scale_Y=float(g_DisplayHeight)/1024.0f;
	LogoSpr=GfxCreateSprite("mameplayer/bitmaps/mamelogotm.jpg",false);
	GfxSetSpriteScale(LogoSpr,g_DisplayWidth,400.0f*Scale_Y);
	GfxSetSpritePosition(LogoSpr,g_DisplayWidth/2,LogoSpr->Scale.y/2,0);
	GfxShowSprite(LogoSpr);

	BackSpr=GfxCreateSprite(DEFAULT_TEXTURE,false);
	GfxSetSpriteScale(BackSpr,g_DisplayWidth/3,(g_DisplayHeight/3)*Scale_Y);
	GfxSetSpritePosition(BackSpr,(g_DisplayWidth/2)-((BackSpr->Scale.x/2)+64),(g_DisplayHeight/2)+(BackSpr->Scale.y/3),0);
	GfxHideSprite(BackSpr);

	ScreenSaveSpr=GfxCreateSprite(DEFAULT_TEXTURE,false);
	GfxSetSpriteScale(ScreenSaveSpr,g_DisplayWidth,g_DisplayHeight);
	GfxSetSpritePosition(ScreenSaveSpr,g_DisplayWidth/2,g_DisplayHeight/2,0);
	GfxHideSprite(ScreenSaveSpr);

	MouseInterfaceSpr=GfxCreateSprite("mameplayer/bitmaps/overlay.tga",false);
	GfxSetSpriteScale(MouseInterfaceSpr,g_DisplayWidth,MouseInterfaceSpr->Scale.y);
	GfxSetSpritePosition(MouseInterfaceSpr,g_DisplayWidth/2,g_DisplayHeight-MouseInterfaceSpr->Size.y/2,0);
	GfxHideSprite(MouseInterfaceSpr);

	SndAct=SndPreCache("mameplayer/audio/activate.wav");
	SndFilter=SndPreCache("mameplayer/audio/pobblegun.wav");
	SndUnFilter=SndPreCache("mameplayer/audio/wubblegun.wav");
	SndMen=SndPreCache("mameplayer/audio/menuclickbeep.wav");
	SndSld=SndPreCache("mameplayer/audio/rotateturret.wav");

	GameLoadConfig();
}

void
CGame::UnInitGame()
{
	CGameApp::UnInitGame();
}

void
CGame::UpdateGame(float delta_time)
{
	static bool filter_games,launch_game,unfilter_games;
	static int last_index;
	static float mouse_travel;
	static float render_scene_time;
	static float screen_saver_time,screen_time;
	static GameQueue_t::iterator filter_iterator;
	static int count;
	static float joy_tmr;

	m_bRenderScene=false;

	CGameApp::UpdateGame(delta_time);

	if (screen_saver_time > 300) {
		if (!bScreenSave) {
			screen_time=0;
			GfxHideSprite(LogoSpr);
			GfxHideSprite(BackSpr);
			GfxShowSprite(ScreenSaveSpr);
			GfxSetSpriteTexture(ScreenSaveSpr,DEFAULT_TEXTURE);
			render_scene_time=0;
			bScreenSave=true;
		}
	}
	else {
		if (bScreenSave) {
			GfxShowSprite(LogoSpr);
			GfxSetSpriteTexture(LogoSpr,LogoSpr->TextureFile);
			GfxShowSprite(BackSpr);
			GfxSetSpriteTexture(BackSpr,BackSpr->TextureFile);
			GfxHideSprite(ScreenSaveSpr);
			render_scene_time=0;
			bScreenSave=false;
		}
	}

	int num=(int)(float(20)*Scale_Y);
	int game_index=GameIndex;

	if (launch_game) {
		GameData_t *game_data=(*SelectedGame);
		if (render_scene_time >= 2) {
			if (MouseInterfaceSpr->IsVis) {
				AppShowCursor(false);
			}
			GameLaunchGame(game_data);
			if (MouseInterfaceSpr->IsVis) {
				AppShowCursor(true);
			}
			GfxSetSpritePosition(BackSpr,(g_DisplayWidth/2)-((BackSpr->Scale.x/2)+64),(g_DisplayHeight/2)+(BackSpr->Scale.y/3),0);
			GfxSetSpriteScale(BackSpr,g_DisplayWidth/3,(g_DisplayHeight/3)*Scale_Y);
			render_scene_time=0;
			screen_saver_time=0;
			launch_game=false;
		}
		else {
			if (BackSpr->IsVis) {
				float target_x=g_DisplayWidth/2;
				float target_y=g_DisplayHeight-(BackSpr->Scale.y)-64;
				float mov_scale=render_scene_time/2.0f;
				float mov_x=(target_x-BackSpr->Pos.x)*mov_scale;
				float mov_y=(target_y-BackSpr->Pos.y)*mov_scale;
				float x=BackSpr->Pos.x+mov_x;
				float y=BackSpr->Pos.y+mov_y;
				GfxSetSpritePosition(BackSpr,x,y,0);
			}
			GfxPrintText(1,-1,-1,D3DXCOLOR(1,1,1,1),"%s",game_data->Desc);
		}
		m_bRenderScene=true;
	}
	else if (filter_games) {
		for ( ; filter_iterator != GameQueue.end() ; filter_iterator++) {
			GameData_t *game_data=(*filter_iterator);
			GameAddFilter(game_data->RomFile);
			game_data->bFilter=true;
			count++;
			if ((count%100) == 0) {
				break;
			}
		}
		if (filter_iterator == GameQueue.end()) {
			SndPlayBuffer(SndFilter,NULL);
			filter_games=false;
		}
		render_scene_time=0;
	}
	else if (unfilter_games) {
		for ( ; filter_iterator != GameQueue.end() ; filter_iterator++) {
			GameData_t *game_data=(*filter_iterator);
			GameDelFilter(game_data->RomFile);
			game_data->bFilter=false;
			count++;
			if ((count%100) == 0) {
				break;
			}
		}
		if (filter_iterator == GameQueue.end()) {
			SndPlayBuffer(SndUnFilter,NULL);
			unfilter_games=false;
		}
		render_scene_time=0;
	}
	else if (bScreenSave) {
		if (GetKey(KEY_SPACE) || GetKey(KEY_ENTER) || GetKey(KEY_ESC)) {
			if (ScreenSaveSpr->Texture != NULL) {
				if (strcmp(ScreenSaveSpr->TextureFile,DEFAULT_TEXTURE) != 0) {
					GfxFreeTexture(ScreenSaveSpr->Texture);
				}
				GfxSetSpriteTexture(ScreenSaveSpr,DEFAULT_TEXTURE);
			}
			screen_saver_time=0;
		}
		else {
			screen_time+=delta_time;
			if (screen_time > 30) {
				screen_time=0;
				int n=RAND(GameCount);
				int i=0;
				for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
					GameData_t *game_data=(*g);
					if (bBlockClones && game_data->bClone) {
						continue;
					}
					if (bFilterGames && game_data->bFilter) {
						continue;
					}
					if (i == n) {
						if (ScreenSaveSpr->Texture != NULL) {
							if (strcmp(ScreenSaveSpr->TextureFile,DEFAULT_TEXTURE) != 0) {
								GfxFreeTexture(ScreenSaveSpr->Texture);
							}
						}
						GfxSetSpriteTexture(ScreenSaveSpr,game_data->Bitmap);
						render_scene_time=0;
						break;
					}
					i++;
				}
			}
		}
	}
	else if (XmlFP == NULL && filter_games == false && unfilter_games == false) {
		if (MouseInterfaceSpr->IsVis) {
			float scale=g_DisplayWidth/640.0f;
			float y_off=g_DisplayHeight-MouseInterfaceSpr->Size.y;
			if (GetMouseButton(LEFT_MOUSE_BUTTON)) {
				if (g_WinMouseY >= y_off+144 && g_WinMouseY < y_off+176) {
					if (g_WinMouseX >= 3*scale && g_WinMouseX < 123*scale) {
						GamePlayClickSound();
						bBlockClones=false;
						render_scene_time=0;
					}
					else if (g_WinMouseX >= 515*scale && g_WinMouseX < 635*scale) {
						GamePlayClickSound();
						bBlockClones=true;
						render_scene_time=0;
					}
				}
				else if (g_WinMouseY >= y_off+208 && g_WinMouseY < y_off+240) {
					if (g_WinMouseX >= 3*scale && g_WinMouseX < 123*scale) {
						//	delete filter
						render_scene_time=0;
						GameData_t *game_data=(*SelectedGame);
						if (game_data->bFilter) {
							GameDelFilter(game_data->RomFile);
							SndPlayBuffer(SndUnFilter,NULL);
							game_data->bFilter=false;
						}
					}
					else if (g_WinMouseX >= 132*scale && g_WinMouseX < 252*scale) {
						//	unfilter all
						GamePlayClickSound();
						unfilter_games=true;
						filter_iterator=GameQueue.begin();
						count=0;
					}
					else if (g_WinMouseX >= 260*scale && g_WinMouseX < 380*scale) {
						//	toggle filtered games
						GamePlayClickSound();
						bFilterGames=(bFilterGames ? false : true);
						GameIndex=0;
						for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
							GameData_t *game_data=(*g);
							if (game_data == CurrentGame) {
								break;
							}
							if (bBlockClones && game_data->bClone) {
								continue;
							}
							if (bFilterGames && game_data->bFilter) {
								continue;
							}
							GameIndex++;
						}
						render_scene_time=0;
					}
					else if (g_WinMouseX >= 388*scale && g_WinMouseX < 508*scale) {
						//	filter all
						GamePlayClickSound();
						filter_games=true;
						filter_iterator=GameQueue.begin();
						count=0;
					}
					else if (g_WinMouseX >= 516*scale && g_WinMouseX < 636*scale) {
						//	add filter
						render_scene_time=0;
						GameData_t *game_data=(*SelectedGame);
						if (!game_data->bFilter) {
							GameAddFilter(game_data->RomFile);
							SndPlayBuffer(SndFilter,NULL);
							game_data->bFilter=true;
						}
					}
				}
				else if (g_WinMouseY >= y_off+32 && g_WinMouseY < y_off+76 && g_WinMouseX >= 15*scale && g_WinMouseX < 35*scale) {
					//	navigate left
					if (CurrentGame != NULL) {
						int last_n=0,n=0;
						char c2=0,last_c=0;
						char c=toupper(CurrentGame->Desc[0]);
						for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
							GameData_t *game_data=(*g);
							if (bBlockClones && game_data->bClone) {
								continue;
							}
							if (bFilterGames && game_data->bFilter) {
								continue;
							}
							char c2=toupper(game_data->Desc[0]);
							if (c2 == c) {
								render_scene_time=0;
								GameIndex=last_n;
								break;
							}
							else if (last_c != c2) {
								last_c=c2;
								last_n=n;
							}
							n++;
						}
					}
					GamePlayClickSound();
				}
				else if (g_WinMouseY >= y_off+32 && g_WinMouseY < y_off+76 && g_WinMouseX >= 92*scale && g_WinMouseX < 112*scale) {
					//	navigate right
					if (CurrentGame != NULL) {
						int n=0;
						char c=toupper(CurrentGame->Desc[0]);
						for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
							GameData_t *game_data=(*g);
							if (bBlockClones && game_data->bClone) {
								continue;
							}
							if (bFilterGames && game_data->bFilter) {
								continue;
							}
							if (toupper(game_data->Desc[0]) > c) {
								render_scene_time=0;
								GameIndex=n;
								break;
							}
							n++;
						}
					}
					GamePlayClickSound();
				}
				else if (g_WinMouseY >= y_off+15 && g_WinMouseY < y_off+35 && g_WinMouseX >= 48*scale && g_WinMouseX < 78*scale) {
					//	navigate up
					GamePlayClickSound();
					int n=num-1;
					GameScrollUp(n);
				}
				else if (g_WinMouseY >= y_off+40 && g_WinMouseY < y_off+55 && g_WinMouseX >= 52*scale && g_WinMouseX < 76*scale) {
					//	launch game
					GamePlayLaunchSound();
					render_scene_time=0;
					launch_game=true;
				}
				else if (g_WinMouseY >= y_off+76 && g_WinMouseY < y_off+106 && g_WinMouseX >= 45*scale && g_WinMouseX < 85*scale) {
					//	navigate down
					GamePlayClickSound();
					int n=num-1;
					GameScrollDown(n);
				}
				else if (g_WinMouseY >= y_off+15 && g_WinMouseY < y_off+48) {
					if (g_WinMouseX >= 592*scale && g_WinMouseX < 625*scale) {
						GamePlayClickSound();
						GameSaveConfig();
						g_bAppActive=false;
					}
				}
			}
		}
		else {
			if (GetMouseButton(LEFT_MOUSE_BUTTON)) {
				GfxShowSprite(MouseInterfaceSpr);
				AppShowCursor(true);
				render_scene_time=0;
			}
		}
		if (PeekKey(KEY_LSHIFT) || PeekJoystickButton(0,4)) {
			if (GetKey(KEY_A) || GetMouseButton(LEFT_MOUSE_BUTTON) || GetJoystickButton(0,1)) {
				render_scene_time=0;
				GameData_t *game_data=(*SelectedGame);
				if (!game_data->bFilter) {
					GameAddFilter(game_data->RomFile);
					SndPlayBuffer(SndFilter,NULL);
					game_data->bFilter=true;
				}
			}
			else if (GetKey(KEY_D) || GetMouseButton(RIGHT_MOUSE_BUTTON) || GetJoystickButton(0,2)) {
				render_scene_time=0;
				GameData_t *game_data=(*SelectedGame);
				if (game_data->bFilter) {
					GameDelFilter(game_data->RomFile);
					SndPlayBuffer(SndUnFilter,NULL);
					game_data->bFilter=false;
				}
			}
			else if (GetKey(KEY_F)) {
				filter_games=true;
				filter_iterator=GameQueue.begin();
				count=0;
			}
			else if (GetKey(KEY_U)) {
				unfilter_games=true;
				filter_iterator=GameQueue.begin();
				count=0;
			}
			else if (GetKey(KEY_Q)) {
				GameSaveConfig();
				g_bAppActive=false;
			}
		}
		joy_tmr+=delta_time;
		int joy_dir=0;
		D3DXVECTOR3 joy_axis=GetJoystickAxis(0,0);
		if (joy_axis.y < -0.2f) {
			if (joy_tmr > (1.0f-fabs(joy_axis.y))) {
				joy_dir=1;
				joy_tmr=0;
			}
		}
		else if (joy_axis.y > 0.2f) {
			if (joy_tmr > (1.0f-joy_axis.y)) {
				joy_dir=2;
				joy_tmr=0;
			}
		}
		if (joy_axis.x < -0.5f && joy_tmr > 0.5f) {
			joy_dir=3;
			joy_tmr=0;
		}
		else if (joy_axis.x > 0.5f && joy_tmr > 0.5f) {
			joy_dir=4;
			joy_tmr=0;
		}
		if (joy_dir > 0 && joy_dir < 3) {
			GamePlaySlideSound();
		}
		if (GetKey(KEY_Z)) {
			bBlockClones=(bBlockClones ? false : true);
			render_scene_time=0;
		}
		else if (GetKey(KEY_X) || GetJoystickButton(0,5)) {
			bFilterGames=(bFilterGames ? false : true);
			GameIndex=0;
			for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
				GameData_t *game_data=(*g);
				if (game_data == CurrentGame) {
					break;
				}
				if (bBlockClones && game_data->bClone) {
					continue;
				}
				if (bFilterGames && game_data->bFilter) {
					continue;
				}
				GameIndex++;
			}
			render_scene_time=0;
		}
		else if (GetKey(KEY_UP) || GetKey(KEY_8) || joy_dir == 1) {
			if (joy_dir == 0) {
				GamePlayClickSound();
			}
			GameScrollUp(1);
		}
		else if (GetKey(KEY_DOWN) || GetKey(KEY_2) || joy_dir == 2) {
			if (joy_dir == 0) {
				GamePlayClickSound();
			}
			GameScrollDown(1);
		}
		else if (GetKey(KEY_LEFT) || GetKey(KEY_4) || joy_dir == 3) {
			if (CurrentGame != NULL) {
				int last_n=0,n=0;
				char c2=0,last_c=0;
				char c=toupper(CurrentGame->Desc[0]);
				for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
					GameData_t *game_data=(*g);
					if (bBlockClones && game_data->bClone) {
						continue;
					}
					if (bFilterGames && game_data->bFilter) {
						continue;
					}
					char c2=toupper(game_data->Desc[0]);
					if (c2 == c) {
						render_scene_time=0;
						GameIndex=last_n;
						break;
					}
					else if (last_c != c2) {
						last_c=c2;
						last_n=n;
					}
					n++;
				}
			}
			GamePlayClickSound();
		}
		else if (GetKey(KEY_RIGHT) || GetKey(KEY_6) || joy_dir == 4) {
			if (CurrentGame != NULL) {
				int n=0;
				char c=toupper(CurrentGame->Desc[0]);
				for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
					GameData_t *game_data=(*g);
					if (bBlockClones && game_data->bClone) {
						continue;
					}
					if (bFilterGames && game_data->bFilter) {
						continue;
					}
					if (toupper(game_data->Desc[0]) > c) {
						render_scene_time=0;
						GameIndex=n;
						break;
					}
					n++;
				}
			}
			GamePlayClickSound();
		}
		else if (GetKey(KEY_PGDN)) {
			GamePlayClickSound();
			int n=num-1;
			GameScrollDown(n);
		}
		else if (GetKey(KEY_PGUP)) {
			GamePlayClickSound();
			int n=num-1;
			GameScrollUp(n);
		}
		else if (GetKey(KEY_HOME) || GetKey(KEY_C)) {
			GamePlayClickSound();
			GameIndex=0;
		}
		else if (GetKey(KEY_END) || GetKey(KEY_5)) {
			GamePlayClickSound();
			GameIndex=GameCount-1;
		}
		else if (GetKey(KEY_ENTER) || GetKey(KEY_CTRL) || GetJoystickButton(0,0)) {
			GamePlayLaunchSound();
			render_scene_time=0;
			launch_game=true;
		}
		else if (GetKey(KEY_ESC)) {
			GameSaveConfig();
			g_bAppActive=false;
		}
		else if (GetKey(KEY_F5)) {
			UnInitInput();
			DialogBox(g_hInstance,MAKEINTRESOURCE(IDD_DIALOG1),g_hWnd,GameDialogProc);
			InitInput();
			ResetTimer();

			render_scene_time=0;
			screen_saver_time=0;
		}

		if (g_MouseDelta.z < 0 || g_WinMouseWheel < 0) {
			GamePlayClickSound();
			GameScrollDown(1);
		}
		else if (g_MouseDelta.z > 0 || g_WinMouseWheel > 0) {
			GamePlayClickSound();
			GameScrollUp(1);
		}
		else {
			mouse_travel+=g_MouseDelta.y;
			if (mouse_travel < -15) {
				GamePlaySlideSound();
				GameScrollUp(1);
				mouse_travel=0;
				joy_tmr=0;
			}
			else if (mouse_travel > 15) {
				GamePlaySlideSound();
				GameScrollDown(1);
				mouse_travel=0;
				joy_tmr=0;
			}
		}
	}

	if (GameIndex != game_index) {
		render_scene_time=0;
		screen_saver_time=0;
	}

	if (render_scene_time < 0.5f) {
		if (GameQueue.size() == 0 && XmlFP == NULL) {
			if (render_scene_time > 0.25f) {
				GameLoadList();
				render_scene_time=0;
			}
		}
		m_bRenderScene=true;
	}

	if (XmlFP != NULL) {
		render_scene_time=0;
		m_bRenderScene=true;
		GameLoadList();
		if (XmlFP == NULL) {
			ExecScriptFile("mameplayer/gamelist.lua");
		}
	}
	else if (PeekKey(KEY_F1)) {
		int start_x=(g_DisplayWidth/2);
		int start_y=LogoSpr->Pos.y+(LogoSpr->Scale.y/2)+64;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"LSHIFT-A        = Add filter for selected game (hide game)");
		start_y+=25;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"LSHIFT-D        = Delete filter for selected game (show game)");
		start_y+=25;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"LSHIFT-F        = Filter all games (hide all)");
		start_y+=25;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"LSHIFT-U        = Unfilter all games (show all)");
		start_y+=25;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"Z               = Toggle cloned games on/off (currently: %s)",bBlockClones ? "OFF" : "ON");
		start_y+=25;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"X               = Toggle filtered games on/off (currently: %s)",bFilterGames ? "ON" : "OFF");
		start_y+=25;
		GfxPrintText(0,start_x,start_y,D3DXCOLOR(0,1,0,1),"F5              = Mame command line options");
		start_y+=25;
		GfxPrintText(0,0,g_DisplayHeight-30,D3DXCOLOR(1,1,1,1),"Memory Used: %u",MemUsed);

		render_scene_time=0;
	}
	else if (!launch_game && !bScreenSave && !filter_games && !unfilter_games) {
		int i=0;
		int top=(GameIndex-5 >= 0) ? GameIndex-5 : 0;
		int bot=top+num;
		int y=0;
		int start_y=LogoSpr->Pos.y+(LogoSpr->Scale.y/2)+64;
		for (GameQueue_t::iterator g=GameQueue.begin() ; g != GameQueue.end() ; g++) {
			GameData_t *game_data=(*g);
			if (bBlockClones && game_data->bClone) {
				continue;
			}
			if (bFilterGames && game_data->bFilter) {
				continue;
			}
			if (i >= top && i < bot) {
				int x=g_DisplayWidth/2;
				if (i == GameIndex) {
					D3DXCOLOR color(1,1,1,1);
					if (GameFilterName(game_data->RomFile)) {
						color=D3DXCOLOR(1,0,0,1);
					}
					SelectedGame=g;
					GfxPrintText(1,x,start_y+y,color,"%s",game_data->Desc);
					y+=22;
					if (game_data->bClone) {
						GfxPrintText(1,x,start_y+y,D3DXCOLOR(1,0,0,1),"%s %s (clone)",game_data->Year,game_data->Manufacturer);
					}
					else {
						GfxPrintText(1,x,start_y+y,D3DXCOLOR(1,0,0,1),"%s %s",game_data->Year,game_data->Manufacturer);
					}
					y+=22;
					if (game_data->Bitmap[0] != 0) {
						if (strcmp(BackSpr->TextureFile,game_data->Bitmap) != 0) {
							if (strcmp(BackSpr->TextureFile,DEFAULT_TEXTURE) != 0) {
								GfxFreeTexture(BackSpr->Texture);
							}
							GfxSetSpriteTexture(BackSpr,game_data->Bitmap);
							GfxShowSprite(BackSpr);
						}
					}
					else {
						if (strcmp(BackSpr->TextureFile,DEFAULT_TEXTURE) != 0) {
							GfxFreeTexture(BackSpr->Texture);
							GfxSetSpriteTexture(BackSpr,DEFAULT_TEXTURE);
							GfxShowSprite(BackSpr);
						}
					}
					CurrentGame=game_data;
				}
				else {
					D3DXCOLOR color(0.5f,0.5f,0.5f,1);
					if (GameFilterName(game_data->RomFile)) {
						color=D3DXCOLOR(0.5f,0,0,1);
					}
					GfxPrintText(0,x,start_y+y,color,"%s",game_data->Desc);
					y+=22;
				}
			}
			i++;
		}
		GameCount=i;
	}

	if (!bScreenSave) {
		if (!bFilterGames) {
			if (!bBlockClones) {
				GfxPrintText(0,0,g_DisplayHeight-15,D3DXCOLOR(0,0,1,1),"(FILTER: OFF) (CLONES)");
			}
			else {
				GfxPrintText(0,0,g_DisplayHeight-15,D3DXCOLOR(0,0,1,1),"(FILTER: OFF)");
			}
		}
		if (XmlFP != NULL) {
			GfxPrintText(2,-1,-1,D3DXCOLOR(1,0,0,1),"LOADING %d",GameQueue.size());
		}
		else if (filter_games || unfilter_games) {
			GfxPrintText(2,-1,-1,D3DXCOLOR(1,1,1,1),"...WORKING %d/%d...",count,GameQueue.size());
		}
		else {
			GfxPrintText(0,-1,g_DisplayHeight-50,D3DXCOLOR(1,1,1,1),"%d GAMES",GameCount);
		}
		GfxPrintText(0,-1,g_DisplayHeight-15,D3DXCOLOR(0,1,0,1),"%s",g_GameName);

		time_t t;
		time(&t);
		struct tm *gmt=localtime(&t);
		char buf[64];
		static char last_time_buf[64];
		strftime(buf,256,"%I:%M %p",gmt);
		if (strcmp(buf,last_time_buf) != 0) {
			strcpy(last_time_buf,buf);
			render_scene_time=0;
		}
		GfxPrintText(1,g_DisplayWidth-GfxPrintTextLen(1,buf)-10,20,D3DXCOLOR(0.5f,0.5f,0.5f,0.5f),buf);
		strftime(buf,256,"%A %B %d, %Y",gmt);
		GfxPrintText(1,10,20,D3DXCOLOR(0.5f,0.5f,0.5f,0.5f),buf);
	}

	render_scene_time+=delta_time;
	screen_saver_time+=delta_time;
}

void
InitGameApp()
{
	g_bLogEnable=false;
//	g_MouseFlags=DISCL_NONEXCLUSIVE|DISCL_FOREGROUND;
//	g_JoystickFlags=DISCL_NONEXCLUSIVE|DISCL_FOREGROUND;

	CGame *app=new CGame;
	app->InitApp();
}

BOOL CALLBACK
GameDialogProc(HWND hWndDlg,UINT message,WPARAM wparam,LPARAM lparam)
{
	switch (message) {
	case WM_INITDIALOG:
		{
			CheckDlgButton(hWndDlg,IDC_CHECK1,bSkipGameInfo ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK2,bCheatEnable ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK3,bAutoFrameSkip ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK7,bSwitchRes ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK4,bThrottle ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK6,bTripleBuffer ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK5,bWaitVSync ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK8,bUseBackdrops ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK11,bUseBezels ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK10,bUseOverlays ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK12,bMouseEnable ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK13,bJoystickEnable ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK14,bJoystickDigital ? BST_CHECKED : BST_UNCHECKED);
			CheckDlgButton(hWndDlg,IDC_CHECK9,bCustomController ? BST_CHECKED : BST_UNCHECKED);
			if (RenderOption == 0) {
				CheckDlgButton(hWndDlg,IDC_RADIO1,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO2,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO3,BST_CHECKED);
			}
			else if (RenderOption == 1) {
				CheckDlgButton(hWndDlg,IDC_RADIO1,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO2,BST_CHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO3,BST_UNCHECKED);
			}
			else {
				CheckDlgButton(hWndDlg,IDC_RADIO1,BST_CHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO2,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO3,BST_UNCHECKED);
			}
			RECT rect;
			GetWindowRect(hWndDlg,&rect);
			int w=rect.right-rect.left;
			int h=rect.bottom-rect.top;
			SetWindowPos(hWndDlg,HWND_TOP,(g_WindowWidth/2)-(w/2),(g_WindowHeight/2)-(h/2),w,h,SWP_NOSIZE|SWP_NOZORDER);
		}
		break;
	case WM_COMMAND:
		if (wparam == IDOK || wparam == IDCANCEL) {
			int result=(wparam != IDCANCEL) ? IDOK : IDCANCEL;
			if (wparam == IDOK) {
				if (IsDlgButtonChecked(hWndDlg,IDC_RADIO1)) {
					RenderOption=2;
				}
				else if (IsDlgButtonChecked(hWndDlg,IDC_RADIO2)) {
					RenderOption=1;
				}
				else if (IsDlgButtonChecked(hWndDlg,IDC_RADIO3)) {
					RenderOption=0;
				}
				bSkipGameInfo=(IsDlgButtonChecked(hWndDlg,IDC_CHECK1) ? true : false);
				bCheatEnable=(IsDlgButtonChecked(hWndDlg,IDC_CHECK2) ? true : false);
				bAutoFrameSkip=(IsDlgButtonChecked(hWndDlg,IDC_CHECK3) ? true : false);
				bSwitchRes=(IsDlgButtonChecked(hWndDlg,IDC_CHECK7) ? true : false);
				bThrottle=(IsDlgButtonChecked(hWndDlg,IDC_CHECK4) ? true : false);
				bTripleBuffer=(IsDlgButtonChecked(hWndDlg,IDC_CHECK6) ? true : false);
				bWaitVSync=(IsDlgButtonChecked(hWndDlg,IDC_CHECK5) ? true : false);
				bUseBackdrops=(IsDlgButtonChecked(hWndDlg,IDC_CHECK8) ? true : false);
				bUseBezels=(IsDlgButtonChecked(hWndDlg,IDC_CHECK11) ? true : false);
				bUseOverlays=(IsDlgButtonChecked(hWndDlg,IDC_CHECK10) ? true : false);
				bMouseEnable=(IsDlgButtonChecked(hWndDlg,IDC_CHECK12) ? true : false);
				bJoystickEnable=(IsDlgButtonChecked(hWndDlg,IDC_CHECK13) ? true : false);
				bJoystickDigital=(IsDlgButtonChecked(hWndDlg,IDC_CHECK14) ? true : false);
				bCustomController=(IsDlgButtonChecked(hWndDlg,IDC_CHECK9) ? true : false);
				GameSaveConfig();
			}
			EndDialog(hWndDlg,result);
			return(TRUE);
		}
		switch (HIWORD(wparam)) {
		case BN_CLICKED:
			switch (LOWORD(wparam)) {
			case IDC_RADIO1:
				CheckDlgButton(hWndDlg,IDC_RADIO1,BST_CHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO2,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO3,BST_UNCHECKED);
				break;
			case IDC_RADIO2:
				CheckDlgButton(hWndDlg,IDC_RADIO1,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO2,BST_CHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO3,BST_UNCHECKED);
				break;
			case IDC_RADIO3:
				CheckDlgButton(hWndDlg,IDC_RADIO1,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO2,BST_UNCHECKED);
				CheckDlgButton(hWndDlg,IDC_RADIO3,BST_CHECKED);
				break;
			}
			return(TRUE);
			break;
		}
		break;
	}
	return(FALSE);
}
