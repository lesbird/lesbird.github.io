// Game.h: interface for the CGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAME_H__5D5C1E01_2909_440B_BF2C_72F058019FEF__INCLUDED_)
#define AFX_GAME_H__5D5C1E01_2909_440B_BF2C_72F058019FEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameHeader.h"

class CGame : public CGameApp  
{
public:
	CGame();
	virtual ~CGame();

	virtual void		InitGame();
	virtual void		UnInitGame();

	virtual void		UpdateGame(float delta_time);
};

#endif // !defined(AFX_GAME_H__5D5C1E01_2909_440B_BF2C_72F058019FEF__INCLUDED_)
