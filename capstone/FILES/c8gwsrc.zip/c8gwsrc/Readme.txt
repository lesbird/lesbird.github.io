This is not the Corridor 7 source code even though the filenames may lead to this conclusion.

Type Corr8 /? for command line options.

To run the editor type "Corr8 /edit" then press ESC and load a level.

To switch to game mode press F10 from the 3D editor (not the 2D editor).

To switch back to edit mode press F10 again.

