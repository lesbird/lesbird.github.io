/***************************************************************************
 *   TEKVER.C  - Version number for TEKWAR game.                           *
 *               Modified by AUTOVER.EXE                                   *
 *                                                                         *
 *                                                     04/27/95 Les Bird   *
 ***************************************************************************/

#define   VERS      "V1.00"
#define   TITLE     "TEKWAR %s Copyright (C) 1995 IntraCorp, Inc."

