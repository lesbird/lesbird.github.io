Eliminator 3D
Developed in 2006 by Les Bird
www.thegameprojects.com
lesbird@lesbird.com

The objective is to survive the onslaught of drones. Use your ship's weapon
and smart bombs to help you survive.

Drones will appear on-screen and approach your ship. They are designed to
collide with your ship thereby destroying it. You begin the simulation with
5 ships and are awarded an extra ship and smart bomb every 1,000 kills.

New levels are achieved every 1,000 kills. At each new level the drones will
start out slow and gain more speed as you accumulate kills. The higher the
level the faster the drones will get. New drones may also be introduced in
some levels.

The game was originally designed to play using a dual analog-stick gamepad
and has been successfully tested with a Thrustmaster Firestorm Dual, Logitech
Dual Action, Xbox 360 USB (Windows XP) and the Logitech Cordless RumblePad 2.
A keyboard may also be used by pressing W, A, S or D to move and the arrow
keys to fire.

By pressing the F1 key options such as gamepad stick inversion and deadzone
sensitivity may be manipulated to improve your ship's control. You may also
press the F2 key to change your display settings such as screen resolution.

After completing a game and typing your name for the local high score chart
you may click the "SUBMIT HIGH SCORE" button to send your score to the online
server. The server will respond by sending back the scores above and below you.
You can then scroll up and down the list using the keyboard or gamepad to see
where you rank compared to other players.

To pause the game press the "PAUSE" key on your keyboard. To resume press
the "PAUSE" key again or any button on the gamepad.

END
