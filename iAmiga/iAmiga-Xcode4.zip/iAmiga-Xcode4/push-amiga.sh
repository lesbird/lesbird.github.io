#!/bin/bash

# variables
DISTRIBUTION_CERTIFICATE='iPhone Distribution: Manomio LLC'
PROVISIONING_PROFILE_PATH='/Users/stuartcarnie/Library/MobileDevice/Provisioning Profiles/iAmiga_Ad_Hoc.mobileprovision'
ARCHIVE_FILENAME='iAmiga.zip'
KEYCHAIN_LOCATION='/Users/stuartcarnie/Library/Keychains/login.keychain'
KEYCHAIN_PASSWORD='sblaster'

. build_ipa_short.sh