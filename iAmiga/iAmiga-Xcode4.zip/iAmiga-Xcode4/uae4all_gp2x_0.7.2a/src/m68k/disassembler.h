/*
 *  disassembler.h
 *  iAmiga
 *
 *  Created by Stuart Carnie on 12/23/10.
 *  Copyright 2010 Manomio LLC. All rights reserved.
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

const char *getDebugFileName();

#ifdef __cplusplus
}
#endif