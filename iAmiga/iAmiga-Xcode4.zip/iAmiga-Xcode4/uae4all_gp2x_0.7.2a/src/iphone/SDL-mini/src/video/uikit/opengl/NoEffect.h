//
//  ScanlinesEffect.h
//  iAmiga
//
//  Created by Stuart Carnie on 1/17/11.
//  Copyright 2011 Manomio LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OGLShaderProgram.h"

@interface NoEffect : OGLShaderProgram {
	
}

@end
