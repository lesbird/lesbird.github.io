/*
 *  SDL_sysvideo.h
 *  iAmiga
 *
 *  Created by Stuart Carnie on 1/2/11.
 *  Copyright 2011 Manomio LLC. All rights reserved.
 *
 */

#ifndef _SDL_sysvideo_h
#define _SDL_sysvideo_h

#include "SDL_mouse.h"
#include "SDL_keysym.h"

struct SDL_Window {
	const void *magic;
};

#endif