//
//  ButtonStates.m
//  TextEditing
//
//  Created by Infinite Sands on 3/25/11.
//

#import <UIKit/UIKit.h>   

@interface iControlPadReaderView : UIView <UIKeyInput> 
{
    UIView *inputView;
}  

@end