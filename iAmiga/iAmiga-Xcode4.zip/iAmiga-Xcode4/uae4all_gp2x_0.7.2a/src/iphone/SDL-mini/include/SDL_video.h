/*
 *  SDL_video.h
 *  iAmiga
 *
 *  Created by Stuart Carnie on 1/3/11.
 *  Copyright 2011 Manomio LLC. All rights reserved.
 *
 */

#ifndef _SDL_video_h
#define _SDL_video_h

#include "SDL_stdinc.h"

typedef struct SDL_Window SDL_Window;

#endif