/*
 *  sdl_internal.h
 *  A2600
 *
 *  Created by Stuart Carnie on 10/10/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#import "SDL.h"

extern int SDL_EventInit();