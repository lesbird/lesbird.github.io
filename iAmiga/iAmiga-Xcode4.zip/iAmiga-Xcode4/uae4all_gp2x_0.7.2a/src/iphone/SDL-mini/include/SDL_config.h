/*
 *  SDL_config.h
 *  iAmiga
 *
 *  Created by Stuart Carnie on 1/2/11.
 *  Copyright 2011 Manomio LLC. All rights reserved.
 *
 */

#define SDL_EVENTS_DISABLED 1

#include "SDL_config_iphoneos.h"