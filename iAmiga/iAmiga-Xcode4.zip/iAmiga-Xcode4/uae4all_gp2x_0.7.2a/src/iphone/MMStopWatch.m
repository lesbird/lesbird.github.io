/*
 *  MMStopWatch.c
 *  iAmiga
 *
 *  Created by Stuart Carnie on 5/29/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "MMStopWatch.h"

