#ifdef GP2X
static char *menu_msg="                         Amiga emulator for GP2X - (critical hack-n-ship port of Chui code)                                   GPL License.                                          ";
#else
static char *menu_msg="                         Amiga emulator for Dreamcast by Chui.                    Beta Version.                               GPL License.                                          ";
#endif

#define MAX_SCROLL_MSG (-1500)
