void volumecontrol_init(void);
void volumecontrol_redraw(void);

extern int show_volumecontrol;
