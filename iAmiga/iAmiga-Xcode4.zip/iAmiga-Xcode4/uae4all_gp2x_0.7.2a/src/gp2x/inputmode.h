void inputmode_init(void);
void inputmode_redraw(void);

extern int show_inputmode;
