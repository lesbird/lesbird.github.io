#include<stdio.h>
#include<SDL.h>


void fade16(SDL_Surface *screen, unsigned short n);
