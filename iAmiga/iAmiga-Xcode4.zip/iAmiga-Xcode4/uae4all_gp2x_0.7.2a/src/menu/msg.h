
static char *menu_msg="                         Amiga emulator for Dreamcast by Chui.                    Release Candidate.                               GPL License.                                          ";

#define MAX_SCROLL_MSG (-1500)
