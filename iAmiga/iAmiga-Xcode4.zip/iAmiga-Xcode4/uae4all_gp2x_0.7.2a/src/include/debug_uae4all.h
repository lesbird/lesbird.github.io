#include <SDL.h>

#ifndef DEBUG_UAE4ALL_H
#define DEBUG_UAE4ALL_H

#ifdef DEBUG_UAE4ALL


#ifdef DEBUG_UAE4ALL_FFLUSH
#define UAE4ALL_FFLUSH fflush(stdout);
#else
#define UAE4ALL_FFLUSH
#endif

extern int DEBUG_AHORA;

#define dbg(TEXTO) \
	if (DEBUG_AHORA) \
	{ \
		puts(TEXTO); \
		UAE4ALL_FFLUSH \
	}


#define dbgf(FORMATO, RESTO...) \
	if (DEBUG_AHORA) \
	{ \
		printf (FORMATO , ## RESTO); \
		UAE4ALL_FFLUSH \
	}


static __inline__ void dbgsum(char *str, void *buff, unsigned len)
{
	if (DEBUG_AHORA)
	{
		unsigned char *p=(unsigned char *)buff;
		unsigned i,ret=0;
		for(i=0;i<len;i++,p++)
			ret+=(*p)*i;
		printf("%s : 0x%X\n",str,ret);
#ifdef DEBUG_UAE4ALL_FFLUSH
		fflush(stdout);
#endif
	}
}


#else

#define dbg(TEXTO)
#define dbgf(FORMATO, RESTO...)
#define debsum(STR)

#endif



#ifndef PROFILER_UAE4ALL

#define uae4all_prof_start(A)
#define uae4all_prof_end(A)

#else

#define UAE4ALL_PROFILER_MAX 32

extern unsigned long long uae4all_prof_initial[UAE4ALL_PROFILER_MAX];
extern unsigned long long uae4all_prof_sum[UAE4ALL_PROFILER_MAX];
extern unsigned long long uae4all_prof_executed[UAE4ALL_PROFILER_MAX];

static __inline__ void uae4all_prof_start(unsigned a)
{
	uae4all_prof_executed[a]++;
#ifndef DREAMCAST
	uae4all_prof_initial[a]=SDL_GetTicks();
#else
	uae4all_prof_initial[a]=timer_us_gettime64();
#endif
}


static __inline__ void uae4all_prof_end(unsigned a)
{
#ifndef DREAMCAST
	uae4all_prof_sum[a]+=SDL_GetTicks()-uae4all_prof_initial[a];
#else
	extern unsigned uae4all_prof_total;
	int i;
	for(i=0;i<uae4all_prof_total;i++)
		uae4all_prof_initial[i]+=6;
	uae4all_prof_sum[a]+=timer_us_gettime64()-uae4all_prof_initial[a]+2;
#endif
}

void uae4all_prof_init(void);
void uae4all_prof_add(const char *msg);
void uae4all_prof_show(void);
void uae4all_prof_show_statistics();

#endif


#endif


