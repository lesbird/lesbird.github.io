 /*
  * No Unix file system handler for AmigaDOS
  */

