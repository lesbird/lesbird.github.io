 /*
  * UAE4ALL NO savestate support
  */
