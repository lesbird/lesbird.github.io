/*
 *  Events2.h
 *  iAmiga
 *
 *  Created by Stuart Carnie on 9/26/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
