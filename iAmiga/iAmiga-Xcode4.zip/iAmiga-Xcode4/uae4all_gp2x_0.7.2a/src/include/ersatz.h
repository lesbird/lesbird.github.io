 /*
  * UAE - The Un*x Amiga Emulator
  *
  * A "replacement" for a missing Kickstart
  *
  * (c) 1995 Bernd Schmidt
  */

extern void init_ersatz_rom (uae_u8 *data);
extern void ersatz_perform (uae_u16);
extern void DISK_ersatz_read (int,int, uaecptr);
