// HighPolyGame.h: interface for the CHighPolyGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HIGHPOLYGAME_H__B40613C3_9B96_4341_84F5_37B7B0B4EE3F__INCLUDED_)
#define AFX_HIGHPOLYGAME_H__B40613C3_9B96_4341_84F5_37B7B0B4EE3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameType.h"

class CHighPolyGame : public CGameType  
{
public:
	CHighPolyGame();
	virtual ~CHighPolyGame();

	virtual void					Init();
	virtual void					Tick(float delta);
};

#endif // !defined(AFX_HIGHPOLYGAME_H__B40613C3_9B96_4341_84F5_37B7B0B4EE3F__INCLUDED_)
