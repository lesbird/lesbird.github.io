// DefaultGame.cpp: implementation of the CDefaultGame class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "Input.h"

#include "DefaultGame.h"
#include "ExperimentalGame.h"
#include "HighPolyGame.h"
#include "MultiObjectGame.h"
#include "TechDemoGame.h"

#include "dmutil.h"

#define	_GAME_
#define	VERSION						"V1.04a"

CHAR								*AppName="FUEL DEPOT 3D";

string								db,sb;

BOOL								bHelpText=FALSE;

CMusicManager						*MusicMgr=NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDefaultGame::CDefaultGame()
{
	Enter("CDefaultGame()");

	SetObjectID('DEFA');
	SetObjectName("CDEFAULTGAME");

	bCanDelete=FALSE;
	bInView=FALSE;
	bCanTouch=FALSE;

	Init();

	Leave();
}

CDefaultGame::~CDefaultGame()
{
	Enter("~CDefaultGame()");

	Leave();
}

void
CDefaultGame::Transform()
{
}

void
CDefaultGame::Init()
{
	Enter("Init()");

	CGameObject::DeleteAllObjects();
#ifdef _TECH_DEMO_
	CTechDemoGame *game=new CTechDemoGame;
#elif defined(_GAME_)
	CExperimentalGame *game=new CExperimentalGame;
#elif defined(_HIGH_POLY_)
	CHighPolyGame *game=new CHighPolyGame;
#endif
	game->Init();

	Leave();
}

void
CDefaultGame::Tick(float delta)
{
	HandleKeys(CGameType::GameType != NULL ? CGameType::GameType->ObjectID : ObjectID,delta);
}

void
CDefaultGame::HandleKeys(DWORD gamestate,float delta)
{
	if (bHelpText) {
		DWORD vx=CGfx::DisplayWidth-(8*strlen(VERSION));
		CGfx::PrintText(vx,CGfx::DisplayHeight-15,D3DXCOLOR(0,1,0,1),"%s",VERSION);
		D3DXCOLOR rgba(1,1,1,1);
		DWORD x=(DWORD)(CGfx::DisplayWidth*0.3f);
		DWORD y=(DWORD)(CGfx::DisplayHeight*0.2f);
		CGfx::PrintText(-1,y,D3DXCOLOR(0,1,0,1),"FUEL DEPOT 3D");
		y+=30;
		CGfx::PrintText(x,y,rgba,"F1: TOGGLE HELP TEXT ON/OFF");
		y+=20;
		CGfx::PrintText(x,y,rgba,"F2: TOGGLE GAMEPAD ON/OFF");
		y+=20;
		CGfx::PrintText(x,y,rgba,"F3: GAMEPAD CAMERA CONTROLS OFF/ON/REVERSED");
		y+=20;
		CGfx::PrintText(x,y,rgba,"F5: RUN GAME");
		y+=20;
		CGfx::PrintText(x,y,rgba,"F6: RUN HIGH POLY TEST");
		y+=20;
		CGfx::PrintText(x,y,rgba,"F7: RUN MULTI-OBJECT TEST");
		y+=20;
		CGfx::PrintText(x,y,rgba,"F8: RUN TECH DEMO TEST");
		y+=20;
		CGfx::PrintText(x,y,rgba,"ENTER: NEXT TEST (TECH DEMO TEST MODE)");
		y+=20;
		CGfx::PrintText(x,y,rgba,"TAB: CYCLE THROUGH STATISTICS TEXT");
		y+=20;
		CGfx::PrintText(x,y,rgba,"LSHIFT-SPACE: TOGGLE SINGLESTEP MODE");
		y+=20;
		CGfx::PrintText(x,y,rgba,"ENTER: IN SINGLE STEP TO ADVANCE TO NEXT FRAME");
		y+=20;
		CGfx::PrintText(x,y,rgba,"LSHIFT-A: TOGGLE FULL SCENE ANTIALIASING ON/OFF");
		y+=20;
		CGfx::PrintText(x,y,rgba,"LSHIFT-B: TOGGLE BOUNDING/COLLISION SPHERE VIEW ON/OFF");
		y+=20;
		CGfx::PrintText(x,y,rgba,"LSHIFT-C: CYCLE CULLMODE CW/CCW/NONE");
		y+=20;
		CGfx::PrintText(x,y,rgba,"LSHIFT-F: CYCLE TEXTURE/POINT/WIREFRAME MODE");
		y+=20;
		CGfx::PrintText(x,y,rgba,"LSHIFT-L: TOGGLE LENS FLARE");
		y+=20;
	}

	if (GetKey(KEY_F1)) {
		bHelpText=bHelpText ? FALSE : TRUE;
	}
	else if (GetKey(KEY_F5)) {
		CGameObject::DeleteAllObjects();
		CExperimentalGame *game=new CExperimentalGame;
		game->Init();
	}
	else if (GetKey(KEY_F6)) {
		CGameObject::DeleteAllObjects();
		CHighPolyGame *game=new CHighPolyGame;
		game->Init();
	}
	else if (GetKey(KEY_F7)) {
		CGameObject::DeleteAllObjects();
		CMultiObjectGame *game=new CMultiObjectGame;
		game->Init();
	}
	else if (GetKey(KEY_F8)) {
		CGameObject::DeleteAllObjects();
		CTechDemoGame *game=new CTechDemoGame;
		game->Init();
	}
	else if (CGfx::ViewFollowObject == NULL) {
		if (PeekKey(KEY_LEFT)) {
			CGfx::AddViewRotation(0,-100*delta,0);
		}
		else if (PeekKey(KEY_RIGHT)) {
			CGfx::AddViewRotation(0, 100*delta,0);
		}
		if (PeekKey(KEY_UP)) {
			CGfx::AddViewPosition(CGfx::TransformVector(0,0,250*delta));
		}
		else if (PeekKey(KEY_DOWN)) {
			CGfx::AddViewPosition(CGfx::TransformVector(0,0,-250*delta));
		}
		if (PeekKey(KEY_PGUP)) {
			CGfx::AddViewRotation(-20*delta,0,0);
		}
		else if (PeekKey(KEY_PGDN)) {
			CGfx::AddViewRotation(20*delta,0,0);
		}
		LONG	x,y,but;
		CInput::GetMouseDelta(x,y,but);
		if (but == 1 && (x != 0 || y != 0)) {
			CGfx::AddViewPosition(CGfx::TransformVector(x*10*delta,0,-y*10*delta));
			CGfx::bMoveTo=FALSE;
		}
		else if (but == 2 && (x != 0 || y != 0)) {
			CGfx::AddViewRotation(y*10*delta,x*10*delta,0);
			CGfx::bLookAt=FALSE;
		}
		else if (but == 3 && y != 0) {
			CGfx::AddViewPosition(0,-y*10*delta,0);
			CGfx::bMoveTo=FALSE;
		}
	}
	switch (gamestate) {
	default:
		break;
	case 'EXPE':
		break;
	case 'HIGH':
		break;
	case 'MULT':
		break;
	}
}

VOID
InitSoundDevice()
{
#ifdef _AUDIO_
	Enter("CMusicManager()");
	MusicMgr=new CMusicManager;
	if (FAILED(MusicMgr->Initialize(hWnd))) {
		SAFE_DELETE(MusicMgr);
	}
	Leave();
#endif
}

VOID
UnInitSoundDevice()
{
#ifdef _AUDIO_
	SAFE_DELETE(MusicMgr);
#endif
}
