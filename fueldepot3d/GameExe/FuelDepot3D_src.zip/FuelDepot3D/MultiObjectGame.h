// MultiObjectGame.h: interface for the CMultiObjectGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MULTIOBJECTGAME_H__025B3DC2_F2B5_411A_98B6_3223CEF1F1F6__INCLUDED_)
#define AFX_MULTIOBJECTGAME_H__025B3DC2_F2B5_411A_98B6_3223CEF1F1F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameType.h"

class CMultiObjectGame : public CGameType  
{
public:
	CMultiObjectGame();
	virtual ~CMultiObjectGame();

	virtual void					Init();
	virtual void					Tick(float delta);
};

#endif // !defined(AFX_MULTIOBJECTGAME_H__025B3DC2_F2B5_411A_98B6_3223CEF1F1F6__INCLUDED_)
