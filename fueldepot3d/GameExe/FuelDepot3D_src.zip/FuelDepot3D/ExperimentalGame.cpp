// ExperimentalGame.cpp: implementation of the CExperimentalGame class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "Input.h"

#include "ExperimentalGame.h"
#include "Resource.h"

#include "dmutil.h"

#include <io.h>

#define	MAXENEMIES					5
#define	MAXKILLS					25
#define	MAXFLAMES					5
#define	MAXCUBES					10
#define	MAXPLAYERPROJECTILES		5
#define	MAXPARTICLESPRITES			500
#define	MAXSMARTBOMBS				5
#define	MAXMISSILEPROJECTILES		5
#define	MAXMISSILES					25
#define	MAXDIFFICULTY				15
#define	MAXBOOSTTIME				10
#define	MAXFLARESPRITES				8

#define	PLAYERFOLLOWDIST			75
#define	PLAYERFOLLOWSPEED			4
#define	PLAYERFOLLOWORIENTATIONX	0
#define	PLAYERFOLLOWORIENTATIONY	0.3f
#define	PLAYERFOLLOWORIENTATIONZ	1

#define	ENEMYFOLLOWDIST				50
#define	ENEMYFOLLOWSPEED			1
#define	ENEMYFOLLOWORIENTATIONX		0.5f
#define	ENEMYFOLLOWORIENTATIONY		0.5f
#define	ENEMYFOLLOWORIENTATIONZ		1
#define	ENEMYSTARTDIST				4000.0f

#define	EFFECTSCHANNEL				(MAXENEMIES+1)

#define	ENEMYPOINTS					100

#define	PODAMBIENTLIGHTING			D3DXCOLOR(0,1,0,1)

static
C3DCube								*FuelPod[MAXCUBES];

static
C3DObject							*Player=NULL,
									*PlayerProj[MAXPLAYERPROJECTILES],
									*Missile[MAXMISSILEPROJECTILES],
									*Enemy[MAXENEMIES],
									*EnemyProj[MAXENEMIES],
									*Target[MAXENEMIES],
									*SpaceStation,
									*Orbiter;

static
C3DPolygon							*SmartBomb;

static
C3DSphere							*PrizeSphere,
									*VortexSphere[MAXENEMIES];

enum {
	PRIZE_NUKE,
	PRIZE_MISSILES
};

static
D3DXVECTOR3							PlayerFollowOrientation;

static
DWORD								PrizeSphereContents;

static
DWORD								BonusPoints,
									CubesLeft=MAXCUBES,
									EnemyKills,TotalKills,
									EnemyState[MAXENEMIES],
									Level=1,
									Missiles=MAXMISSILES,
									Score=0,HighScore=0,
									SmartBombs=MAXSMARTBOMBS;
static
float								BeepSoundDelay=2.0f,
									Difficulty=1,
									EnemyFireDelay[MAXENEMIES],
									EnemyTurnDelay[MAXENEMIES],
									EnemySpawnDelay[MAXENEMIES],
									GameOverDelay=0,
									HelpDelay=10,
									NewLevelTick=0,
									PlayerSpawnDelay,
									PlayerSpeed=0,
									PrizeMessageDelay=0,
									TargetDX[MAXENEMIES],
									TurboBoost=MAXBOOSTTIME;
static
CHAR								NebulaFile[256],
									*PrizeMessage=NULL;

static
DWORD								ControllerSettings=1;

static
float								ControllerSettingTimer=0;

static
DWORD								NebulaNum=0;

static
DWORD								PlaybackDemoNum=0;

static
float								PlaybackDemoDelay=0;

static
C3DParticleEmitter					*PlayerEmitter=NULL;

static
C3DSprite							*PlayerFlame[MAXFLAMES],
									*PlayerFlameBoost[MAXFLAMES],
									*MissileFlame[MAXMISSILEPROJECTILES][MAXFLAMES],
									*EnemyFlame[MAXENEMIES][MAXFLAMES];

static
C3DPermanentSprite					*ParticleSprite[MAXPARTICLESPRITES];

static
DWORD								ParticleSpriteNum;

static
C3DSprite							*Star=NULL;

static
C2DSprite							*FlareSprite[MAXFLARESPRITES];

static
BOOL								bBeepHi=FALSE,
									bGameOver=FALSE,
									bKeyFoward=FALSE,
									bKeyZoom=FALSE,
									bNewLevel=FALSE,
									bPlayerDestroyed=FALSE,
									bShowLensFlare=TRUE;

static
CMusicSegment						*Beep1Sound=NULL,
									*Beep2Sound=NULL,
									*CubeGoneSound=NULL,
									*DockingSound=NULL,
									*DropItemSound=NULL,
									*EnemyGunFireSound=NULL,
									*GunFireSound=NULL,
									*ExplosionSound[3]={NULL,NULL,NULL},
									*HitCubeSound=NULL,
									*HitPrizeSphere=NULL,
									*NukeSound=NULL,
									*PickPrizeSphere=NULL,
									*RespawnSound=NULL,
									*TractorBeamSound=NULL;

enum {
	ENEMYSTATE_SEEK,
	ENEMYSTATE_DOCK,
	ENEMYSTATE_TURN,
	ENEMYSTATE_EVADE,
	ENEMYSTATE_RESPAWN,
	ENEMYSTATE_IDLE
};
//	extern'd resources for Eng1Lib
CHAR								*FontName="Courier";

DWORD								FontSize=12;

INT									LogoRes=IDB_BITMAP1;

extern
CMusicManager						*MusicMgr;

extern
BOOL								bHelpText;

extern
LONG								PrintTextX,PrintTextY;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExperimentalGame::CExperimentalGame()
{
	Enter("CExperimentalGame()");

	SetObjectID('EXPE');
	SetObjectName("CEXPERIMENTALGAME");

	ParticleSpriteNum=0;

	{
		for (DWORD n=0 ; n < MAXPARTICLESPRITES ; n++) {
			ParticleSprite[n]=(C3DPermanentSprite *)SPAWN('3PER');
			ParticleSprite[n]->InitSprite(16);
			ParticleSprite[n]->AddTexture("particle.tga");
			ParticleSprite[n]->bCanTouch=FALSE;
			ParticleSprite[n]->bDoubleSided=TRUE;
			ParticleSprite[n]->bHidden=TRUE;
			ParticleSprite[n]->bTransparency=TRUE;
			ParticleSprite[n]->bUnlit=TRUE;
			ParticleSprite[n]->bEnable=FALSE;
		}
	}

	{
		for (DWORD n=0 ; n < MAXENEMIES ; n++) {
			EnemyState[n]=ENEMYSTATE_SEEK;
		}
	}

	{
		Beep1Sound=NULL;
		Beep2Sound=NULL;
		CubeGoneSound=NULL;
		DockingSound=NULL;
		DropItemSound=NULL;
		EnemyGunFireSound=NULL;
		GunFireSound=NULL;
		HitCubeSound=NULL;
		HitPrizeSphere=NULL;
		NukeSound=NULL;
		PickPrizeSphere=NULL;
		RespawnSound=NULL;
		TractorBeamSound=NULL;
		for (DWORD n=0 ; n < 3 ; n++) {
			ExplosionSound[n]=NULL;
		}
	}

	strcpy(NebulaFile,"");
	NebulaNum=0;

	C3DParticleEmitter::InitSpriteCache();

	CGfx::StatsLevel=0;

	Leave();
}

CExperimentalGame::~CExperimentalGame()
{
	Enter("~CExperimentalGame()");

	C3DParticleEmitter::UnInitSpriteCache();

	Player=NULL;
	{
		for (DWORD n=0 ; n < MAXPARTICLESPRITES ; n++) {
			if (ParticleSprite[n] != NULL) {
				ParticleSprite[n]->bDeleteMe=TRUE;
				ParticleSprite[n]=NULL;
			}
		}
	}
	PrizeSphere=NULL;
	{
		for (DWORD n=0 ; n < MAXCUBES ; n++) {
			FuelPod[n]=NULL;
		}
	}
	{
		for (DWORD n=0 ; n < MAXPLAYERPROJECTILES ; n++) {
			PlayerProj[n]=NULL;
		}
	}
	{
		for (DWORD n=0 ; n < MAXMISSILEPROJECTILES ; n++) {
			Missile[n]=NULL;
			for (DWORD i=0 ; i < MAXFLAMES ; i++) {
				MissileFlame[n][i]=NULL;
			}
		}
	}
	{
		for (DWORD n=0 ; n < MAXENEMIES ; n++) {
			Enemy[n]=NULL;
			EnemyProj[n]=NULL;
			Target[n]=NULL;
			VortexSphere[n]=NULL;
			for (DWORD i=0 ;i < MAXFLAMES ; i++) {
				EnemyFlame[n][i]=NULL;
			}
		}
	}
	{
		for (DWORD n=0 ; n < MAXFLAMES ; n++) {
			PlayerFlame[n]=NULL;
			PlayerFlameBoost[n]=NULL;
		}
	}
	Star=NULL;
	{
		for (DWORD n=0 ; n < MAXFLARESPRITES ; n++) {
			FlareSprite[n]=NULL;
		}
	}
	{
		SAFE_DELETE(Beep1Sound);
		SAFE_DELETE(Beep2Sound);
		SAFE_DELETE(CubeGoneSound);
		SAFE_DELETE(DockingSound);
		SAFE_DELETE(DropItemSound);
		SAFE_DELETE(EnemyGunFireSound);
		SAFE_DELETE(GunFireSound);
		SAFE_DELETE(HitCubeSound);
		SAFE_DELETE(HitPrizeSphere);
		SAFE_DELETE(NukeSound);
		SAFE_DELETE(PickPrizeSphere);
		SAFE_DELETE(RespawnSound);
		SAFE_DELETE(TractorBeamSound);
		for (DWORD n=0 ; n < 3 ; n++) {
			SAFE_DELETE(ExplosionSound[n]);
		}
	}
	if (SmartBomb != NULL) {
		SmartBomb=NULL;
	}
	Orbiter=NULL;
	SpaceStation=NULL;

	Leave();
}

void
CExperimentalGame::Init()
{
	Enter("Init()");

	ReadHighScore();

	DWORD seed=GetTickCount();
	srand(seed);
	InputBufferRandomSeed=seed;

	CGameType::Init();

	CGfx::SetNearFarClip(CGfx::NearClip,75000);

	NebulaNum=0;
	PickNebula();

	Player=SpawnPlayer();

	for (DWORD enemy=0 ; enemy < MAXENEMIES ; enemy++) {
		SpawnEnemy(enemy);
		VortexSphere[enemy]=(C3DSphere *)SPAWN('3SPH');
		VortexSphere[enemy]->SetObjectName("VORTEX");
		VortexSphere[enemy]->InitSphere(Enemy[enemy]->Radius*2);
		VortexSphere[enemy]->Link(Enemy[enemy]);
		VortexSphere[enemy]->AddTexture("shine0.tga");
		VortexSphere[enemy]->bCanTouch=FALSE;
		VortexSphere[enemy]->bDoubleSided=TRUE;
		VortexSphere[enemy]->bHidden=TRUE;
		VortexSphere[enemy]->bTransparency=TRUE;
		VortexSphere[enemy]->bUnlit=TRUE;
	}

	for (DWORD n=0 ; n < MAXMISSILEPROJECTILES ; n++) {
		Missile[n]=(C3DObject *)SPAWN('3OBJ');
		Missile[n]->SetObjectName("MISSILE");
		Missile[n]->SetObjectID('3MIS');
		Missile[n]->LoadMesh("space station 5.x");
//		Missile[n]->CloneNewFVF();
		Missile[n]->SphereMapTexture();
		Missile[n]->AddTexture("tex2.tga",TEXFLAGS_ALLMATERIALS);
		Missile[n]->ScaleX=Missile[n]->ScaleY=Missile[n]->ScaleZ=0.15f;
		Missile[n]->bCanTouch=FALSE;
		Missile[n]->bUnlit=TRUE;
		Missile[n]->bHidden=TRUE;
		C3DObject *obj=Missile[n];
		for (DWORD i=0 ; i < MAXFLAMES ; i++) {
			MissileFlame[n][i]=(C3DSprite *)SPAWN('3SPR');
			MissileFlame[n][i]->Link(Missile[n]);
			MissileFlame[n][i]->InitSprite((5.0f-(float)i)*3.0f);
			MissileFlame[n][i]->AddTexture("particle.tga");
			MissileFlame[n][i]->Transparency=1.0f/(1.0f+i);
			MissileFlame[n][i]->SetPosition(0,0,(obj->Radius*0.75f)+((obj->Radius*0.3f)*i));
			MissileFlame[n][i]->bTransparency=TRUE;
			MissileFlame[n][i]->bDoubleSided=TRUE;
			MissileFlame[n][i]->bCanTouch=FALSE;
			MissileFlame[n][i]->bUnlit=TRUE;
			MissileFlame[n][i]->bHidden=TRUE;
			MissileFlame[n][i]->bEnable=FALSE;
		}
		Missile[n]->FilterObject(Missile[n]->ObjectID);
		Missile[n]->FilterObject(Player);
	}

	SmartBomb=(C3DPolygon *)SPAWN('3POL');
	SmartBomb->SetObjectName("SMARTBOMB");
	SmartBomb->SetObjectID('SMRT');
	SmartBomb->InitPolygon(128,128);
	SmartBomb->AddTexture("flare4.tga");
	SmartBomb->SetRotation(90,0,0);
	SmartBomb->Instigator=Player;
	SmartBomb->bCanTouch=FALSE;
	SmartBomb->bDoubleSided=TRUE;
	SmartBomb->bHidden=TRUE;
	SmartBomb->bTransparency=TRUE;
	SmartBomb->bUnlit=TRUE;
	SmartBomb->bViewClip=FALSE;

	PrizeSphere=(C3DSphere *)SPAWN('3SPH');
	PrizeSphere->SetObjectName("PRIZESPHERE");
	PrizeSphere->SetObjectID('PRIZ');
	PrizeSphere->InitSphere(10);
	PrizeSphere->AddTexture("caust00.tga");
	PrizeSphere->AddTexture(NebulaFile,TEXFLAGS_REFLECTIONMAP);
	PrizeSphere->SetRotationRate(0,90,0);
	PrizeSphere->bCanTouch=FALSE;
	PrizeSphere->bHidden=TRUE;
	PrizeSphere->bTransform=FALSE;

	C3DSphere *Sphere1=(C3DSphere *)SPAWN('3SPH');
	Sphere1->InitSphere(4000,150,150,2,2);
	Sphere1->SetObjectName("PLANET");
	Sphere1->SetPosition(2000,-4100,0);
	Sphere1->SetRotation(0,0,0);
	Sphere1->AddTexture("planets\\jupiter.tga");
	Sphere1->SetRotationRate(0,0.2f,0);
	Sphere1->Mass=0;
	Sphere1->AmbientLighting=D3DXCOLOR(0.2f,0.2f,0.2f,1);

	C3DSphere *Sphere3=(C3DSphere *)SPAWN('3SPH');
	Sphere3->Link(Sphere1);
	Sphere3->InitSphere(1000);
	Sphere3->SetObjectName("MOON1");
	Sphere3->SetPosition(Sphere1->TransformVector(sinf(D3DXToRadian(0))*Sphere1->Radius*5,1500,cosf(D3DXToRadian(0))*Sphere1->Radius*5));
	Sphere3->AddTexture("lava.tga");
	Sphere3->SetRotationRate(0,2,0);
	Sphere3->Mass=0;
	Sphere3->AmbientLighting=D3DXCOLOR(0.1f,0.1f,0.1f,1);

	C3DSphere *Sphere4=(C3DSphere *)SPAWN('3SPH');
	Sphere4->Link(Sphere1);
	Sphere4->InitSphere(1500);
	Sphere4->SetObjectName("MOON2");
	Sphere4->SetPosition(Sphere1->TransformVector(sinf(D3DXToRadian(72))*Sphere1->Radius*5,1500,cosf(D3DXToRadian(72))*Sphere1->Radius*5));
	Sphere4->AddTexture("planets\\neptune.tga");
	Sphere4->SetRotation(0,0,0);
	Sphere4->SetRotationRate(0,4,0);
	Sphere4->Mass=0;
	Sphere4->AmbientLighting=D3DXCOLOR(0.1f,0.1f,0.1f,1);

	C3DPolygon *Rings=(C3DPolygon *)SPAWN('3POL');
	Rings->Link(Sphere4);
	Rings->InitPolygon(64);
	Material_t *mat=Rings->AddTexture("flare4.tga");
	mat->D3DMaterial->Diffuse=D3DXCOLOR(0.2f,0.1f,1,1);
	Rings->SetRotation(90,0,0);
	Rings->ScaleX=Rings->ScaleY=Rings->ScaleZ=150;
	Rings->bCanTouch=FALSE;
	Rings->bDoubleSided=TRUE;
	Rings->bTransparency=TRUE;
	Rings->bUnlit=TRUE;
	Rings->bViewClip=FALSE;

	C3DSphere *Sphere5=(C3DSphere *)SPAWN('3SPH');
	Sphere5->Link(Sphere1);
	Sphere5->InitSphere(750);
	Sphere5->SetObjectName("MOON3");
	Sphere5->SetPosition(Sphere1->TransformVector(sinf(D3DXToRadian(144))*Sphere1->Radius*5,1500,cosf(D3DXToRadian(144))*Sphere1->Radius*5));
	Sphere5->AddTexture("planets\\pluto.tga");
	Sphere5->SetRotationRate(0,2,0);
	Sphere5->Mass=0;
	Sphere5->AmbientLighting=D3DXCOLOR(0.1f,0.1f,0.1f,1);

	C3DSphere *Sphere6=(C3DSphere *)SPAWN('3SPH');
	Sphere6->Link(Sphere1);
	Sphere6->InitSphere(2000);
	Sphere6->SetObjectName("MOON4");
	Sphere6->SetPosition(Sphere1->TransformVector(sinf(D3DXToRadian(216))*Sphere1->Radius*5,1500,cosf(D3DXToRadian(216))*Sphere1->Radius*5));
	Sphere6->AddTexture("planets\\moon.tga");
	Sphere6->SetRotationRate(0,2,0);
	Sphere6->Mass=0;
	Sphere6->AmbientLighting=D3DXCOLOR(0.1f,0.1f,0.1f,1);

	C3DSphere *Sphere7=(C3DSphere *)SPAWN('3SPH');
	Sphere7->Link(Sphere1);
	Sphere7->InitSphere(1250);
	Sphere7->SetObjectName("MOON5");
	Sphere7->SetPosition(Sphere1->TransformVector(sinf(D3DXToRadian(288))*Sphere1->Radius*5,1500,cosf(D3DXToRadian(288))*Sphere1->Radius*5));
	Sphere7->AddTexture("planets\\venus.tga");
	Sphere7->SetRotationRate(0,6,0);
	Sphere7->Mass=0;
	Sphere7->AmbientLighting=D3DXCOLOR(0.1f,0.1f,0.1f,1);

	SpaceStation=(C3DObject *)SPAWN('3OBJ');
	SpaceStation->Link(Sphere3);
	SpaceStation->LoadMesh("space station 7.x");
//	SpaceStation->CloneNewFVF();
	SpaceStation->SphereMapTexture();
	SpaceStation->SetObjectName("SPACESTATION");
	SpaceStation->Mass=0;
	SpaceStation->SetRotation(0,0,0);
	SpaceStation->SetRotationRate(0,16,0);
	SpaceStation->SetPosition(Sphere3->Radius*1.5f,0,0);
	SpaceStation->AddTexture("wall.tga",TEXFLAGS_ALLMATERIALS);
	SpaceStation->AddTexture(NebulaFile,TEXFLAGS_REFLECTIONMAP|TEXFLAGS_ALLMATERIALS);
	SpaceStation->AmbientLighting=D3DXCOLOR(0.4f,0.4f,0.4f,1);

	Orbiter=(C3DObject *)SPAWN('3OBJ');
	Orbiter->Link(Sphere3);
	Orbiter->LoadMesh("Orbiter.x");
//	Orbiter->CloneNewFVF();
	Orbiter->SphereMapTexture();
	Orbiter->SetObjectName("ORBITER");
	Orbiter->Mass=0;
	Orbiter->ScaleX=Orbiter->ScaleY=Orbiter->ScaleZ=4;
	Orbiter->SetRotationRate(0,0,16);
	Orbiter->SetPosition(-Sphere3->Radius*1.5f,0,0);
	Orbiter->AddTexture("wall.tga",TEXFLAGS_ALLMATERIALS);
	Orbiter->AddTexture(NebulaFile,TEXFLAGS_REFLECTIONMAP|TEXFLAGS_ALLMATERIALS);
	Orbiter->AmbientLighting=D3DXCOLOR(0.4f,0.4f,0.4f,1);

	D3DXVECTOR3 p(0,1000,29000);
	SpawnSpriteSun(p);
	C3DLight *light=(C3DLight *)SPAWN('3LIG');
	light->Link(Star);
	light->D3DLight.Range=60000;

	C3DSphere *Sky=(C3DSphere *)SPAWN('3SPH');
	Sky->InitSphere(30000);
	Sky->SetObjectName("SKY");
	Sky->AddTexture(NebulaFile);
	Sky->SetRotation(0,0,0);
	Sky->AmbientLighting=D3DXCOLOR(0.3f,0.3f,0.3f,1);
	Sky->bCanTouch=FALSE;
	Sky->bInvertPolys=TRUE;
	Sky->bNoFog=TRUE;

//	bClearDisplay=FALSE;	// since we have a sky box, no need to clear the target buffer

	for (short i=0 ; i < MAXCUBES ; i++) {
		FuelPod[i]=(C3DCube *)SPAWN('3CUB');
		FuelPod[i]->InitCube(50,50,50,1,1);
		FuelPod[i]->Mass=50;
		FuelPod[i]->SetPosition(sinf(D3DXToRadian(36*i))*500,0,cosf(D3DXToRadian(36*i))*500);
		FuelPod[i]->SetRotation(0,0,0);
		Material_t *mat=FuelPod[i]->AddTexture("wall.tga");
		mat->D3DMaterial->Diffuse=D3DXCOLOR(0,0,0,1);
		FuelPod[i]->AddTexture("floor.tga",TEXFLAGS_ADD);
		FuelPod[i]->AmbientLighting=PODAMBIENTLIGHTING;
		FuelPod[i]->SpecularLighting=D3DXCOLOR(0,0,0,1);
	}

	CGfx::ViewFollowOrientation=D3DXVECTOR3(PLAYERFOLLOWORIENTATIONX,PLAYERFOLLOWORIENTATIONY,PLAYERFOLLOWORIENTATIONZ);
	CGfx::ViewFollowDist=PLAYERFOLLOWDIST;
	CGfx::ViewFollowSpeedFactor=PLAYERFOLLOWSPEED;
	PlayerFollowOrientation=CGfx::ViewFollowOrientation;

	if (MusicMgr != NULL) {
		MusicMgr->CreateSegmentFromFile(&Beep1Sound,"wav/beep1.wav");
		MusicMgr->CreateSegmentFromFile(&Beep2Sound,"wav/beep2.wav");
		MusicMgr->CreateSegmentFromFile(&CubeGoneSound,"wav/cubegone.wav");
		MusicMgr->CreateSegmentFromFile(&DockingSound,"wav/docking.wav");
		MusicMgr->CreateSegmentFromFile(&DropItemSound,"wav/dropitem.wav");
		MusicMgr->CreateSegmentFromFile(&EnemyGunFireSound,"wav/bfire.wav");
		MusicMgr->CreateSegmentFromFile(&GunFireSound,"wav/gunfire.wav");
		MusicMgr->CreateSegmentFromFile(&ExplosionSound[0],"wav/d_bang.wav");
		MusicMgr->CreateSegmentFromFile(&ExplosionSound[1],"wav/p_bang.wav");
		MusicMgr->CreateSegmentFromFile(&ExplosionSound[2],"wav/bangbang.wav");
		MusicMgr->CreateSegmentFromFile(&HitCubeSound,"wav/sbounce.wav");
		MusicMgr->CreateSegmentFromFile(&HitPrizeSphere,"wav/c_bang.wav");
		MusicMgr->CreateSegmentFromFile(&NukeSound,"wav/nuke.wav");
		MusicMgr->CreateSegmentFromFile(&PickPrizeSphere,"wav/sstart.wav");
		MusicMgr->CreateSegmentFromFile(&RespawnSound,"wav/level.wav");
		MusicMgr->CreateSegmentFromFile(&TractorBeamSound,"wav/bounce.wav");
	}

	InitGame();

	Leave();
}

void
CExperimentalGame::RestartGame()
{
	Enter("RestartGame()");

	if (bPlayback) {
		srand(InputBufferRandomSeed);
	}
	else {
		DWORD seed=GetTickCount();
		srand(seed);
		InputBufferRandomSeed=seed;
		InputBufferCount=0;
		if (bRecordDemo) {
			HelpDelay=0;
		}
		else {
			HelpDelay=10;
		}
	}

	Player->SetPosition(0,0,0);
	Player->SetRotation(0,0,0);
	Player->SetRotationRate(0,0,0);
	Player->SetVelocity(0,0,0);
	Player->Impulse=D3DXVECTOR3(0,0,0);
	Player->bCanTouch=TRUE;
	Player->bHidden=FALSE;
	PlayerSpawnDelay=0;
	bPlayerDestroyed=FALSE;

	{
		for (DWORD n=0 ; n < MAXPLAYERPROJECTILES ; n++) {
			if (PlayerProj[n] != NULL) {
				PlayerProj[n]->DeleteMe();
				PlayerProj[n]=NULL;
			}
		}
	}

	{
		for (DWORD n=0 ; n < MAXENEMIES ; n++) {
			Enemy[n]->SetPosition(0,0,0);
			Enemy[n]->SetRotation(0,0,0);
			Enemy[n]->SetRotationRate(0,0,0);
			Enemy[n]->SetVelocity(0,0,0);
			Enemy[n]->Acceleration=D3DXVECTOR3(0,0,0);
			Enemy[n]->Impulse=D3DXVECTOR3(0,0,0);
			Enemy[n]->bCanTouch=FALSE;
			Enemy[n]->bHidden=TRUE;
			Enemy[n]->bUnlit=TRUE;
			for (DWORD i=0 ; i < MAXFLAMES ; i++) {
				EnemyFlame[n][i]->bHidden=TRUE;
			}
			EnemyState[n]=ENEMYSTATE_RESPAWN;
			EnemySpawnDelay[n]=1;
			if (EnemyProj[n] != NULL) {
				EnemyProj[n]->DeleteMe();
			}
			Target[n]=NULL;
		}
	}
	{
		for (short i=0 ; i < MAXCUBES ; i++) {
			FuelPod[i]->UnLink();
			FuelPod[i]->SetPosition(sinf(D3DXToRadian(36*i))*500,0,cosf(D3DXToRadian(36*i))*500);
			FuelPod[i]->SetRotation(0,0,0);
			FuelPod[i]->SetRotationRate(0,0,0);
			FuelPod[i]->SetVelocity(0,0,0);
			FuelPod[i]->AmbientLighting=PODAMBIENTLIGHTING;
			FuelPod[i]->Acceleration=D3DXVECTOR3(0,0,0);
			FuelPod[i]->Impulse=D3DXVECTOR3(0,0,0);
			FuelPod[i]->bCanTouch=TRUE;
			FuelPod[i]->bHidden=FALSE;
		}
	}
	{
		for (DWORD n=0 ; n < MAXMISSILEPROJECTILES ; n++) {
			Missile[n]->bCanTouch=FALSE;
			Missile[n]->bHidden=TRUE;
			Missile[n]->SetVelocity(0,0,0);
			for (DWORD i=0 ; i < MAXFLAMES ; i++) {
				MissileFlame[n][i]->bHidden=TRUE;
			}
		}
	}

	C3DParticleEmitter::ResetSpriteCache();

	PrizeSphere->bCanTouch=FALSE;
	PrizeSphere->bHidden=TRUE;
	PrizeSphere->bTransform=FALSE;

	NebulaNum=0;
	PickNewNebula();

	SmartBomb->bHidden=TRUE;

	BonusPoints=0;
	CubesLeft=MAXCUBES;
	TurboBoost=MAXBOOSTTIME;
	Missiles=MAXMISSILES;
	SmartBombs=MAXSMARTBOMBS;
	Difficulty=1;
	EnemyKills=0;
	PlayerSpeed=0;
	TotalKills=0;
	Level=1;
	Score=0;

	BeepSoundDelay=2.0f/Difficulty;
	bBeepHi=FALSE;

	bGameOver=FALSE;

	CGfx::ResetDelta();

	CGameObject::TransformGameObjects(GameObjectList.begin());

	Leave();
}

void
CExperimentalGame::RecordDemo()
{
	if (bRecordDemo) {
		bSaveDemo=TRUE;
		bRecordDemo=FALSE;
	}
	else {
		bPlayback=FALSE;
		bRecordDemo=TRUE;
		RestartGame();
	}
}

void
CExperimentalGame::PlaybackDemo()
{
	if (CGfx::LoadDemo(PlaybackDemoNum++)) {
		bPlayback=TRUE;
		RestartGame();
	}
	else {
		PlaybackDemoNum=0;
	}
}

void
CExperimentalGame::PickNebula()
{
	sprintf(NebulaFile,"nebulas/nebula%02ld.tga",NebulaNum+1);
	NebulaNum=(NebulaNum+1)%17;
}

void
CExperimentalGame::PickNewNebula()
{
	CHAR curneb[256];
	strcpy(curneb,NebulaFile);
	PickNebula();
	if (stricmp(curneb,NebulaFile) == 0) {
		return;
	}
	for (GameObjectList_t::iterator o=CGameObject::GameObjectList.begin() ; o != CGameObject::GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->IsA("C3DOBJECT")) {
			C3DObject *gobj3d=(C3DObject *)gobj;
			DWORD flags=-1;
			gobj3d->RemoveTexture(curneb,flags);
			if (flags != -1) {
				gobj3d->AddTexture(NebulaFile,flags);
			}
		}
	}
}

void
CExperimentalGame::Tick(float delta)
{
	static BOOL	bHelpOn=FALSE;

	if (!bGameOver) {
		if (bPlayback) {
			if (bKeyPressed) {
				bPlayback=FALSE;
				RestartGame();
				return;
			}
			if (Player != NULL) {
				if (PlaybackBufferCount < InputBufferCount) {
					CInput::diJoystickState[0].lX=InputBuffer[PlaybackBufferCount].JoyX;
					CInput::diJoystickState[0].lY=InputBuffer[PlaybackBufferCount].JoyY;
					for (DWORD n=0 ; n < 32 ; n++) {
						if (InputBuffer[PlaybackBufferCount].JoyButtonFlag&(1<<n)) {
							CInput::diJoystickState[0].rgbButtons[n]=1;
						}
						else {
							CInput::diJoystickState[0].rgbButtons[n]=0;
						}
					}
					CInput::UpdateButtons();
					PlaybackBufferCount++;
				}
				else {
					bPlayback=FALSE;
					bGameOver=TRUE;
				}
			}
			D3DXCOLOR rgba(fabsf(sinf(GameTime)),fabsf(cosf(GameTime)),1,1);
			CGfx::PrintText(-1,CGfx::DisplayHeight-30,rgba,"== D E M O ==");
			CGfx::PrintText(-1,CGfx::DisplayHeight-15,rgba,"== PRESS A KEY TO PLAY ==");
		}
		else {
			CInput::GetJoystickData();
			if (bRecordDemo) {
				if (Player != NULL) {
					if (InputBufferCount < MAXINPUTCOUNT) {
						InputBuffer[InputBufferCount].JoyX=CInput::diJoystickState[0].lX;
						InputBuffer[InputBufferCount].JoyY=CInput::diJoystickState[0].lY;
						InputBuffer[InputBufferCount].JoyButtonFlag=0;
						for (DWORD n=0 ; n < 32 ; n++) {
							if (CInput::diJoystickState[0].rgbButtons[n]) {
								InputBuffer[InputBufferCount].JoyButtonFlag|=(1<<n);
							}
						}
						CGfx::PrintText(CGfx::DisplayWidth-15,CGfx::DisplayHeight-15,D3DXCOLOR(1,0,0,1),"R");
						InputBufferCount++;
					}
					else {
						CGfx::PrintText(CGfx::DisplayWidth-15,CGfx::DisplayHeight-15,D3DXCOLOR(0,0,1,1),"*");
						bSaveDemo=TRUE;
						bRecordDemo=FALSE;
					}
				}
			}
		}
	}
	else {
		CInput::GetJoystickData();
	}

	CGameType::Tick(delta);

	if (bHelpText && HelpDelay <= 0) {
		bHelpOn=TRUE;
		HelpDelay=0;
	}
	else if (bHelpOn) {
		HelpDelay=8;
		bHelpOn=FALSE;
	}
	else if (bHelpText) {
		bHelpText=FALSE;
		HelpDelay=0;
	}
	if (!bGameOver) {
		if (GetKey(KEY_P) || CInput::GetJoystickButton(8)) {
			bPause=(bPause ? FALSE : TRUE);
		}
		if (bPause) {
			D3DXCOLOR rgba(fabsf(sinf(GameTime)),fabsf(cosf(GameTime)),1,1);
			CGfx::PrintText(-1,(LONG)(CGfx::DisplayHeight*0.1f),rgba,"P A U S E D");
			return;
		}
	}
	if (CGfx::ViewFollowObject == NULL || CGfx::ViewFollowObject->bHidden == TRUE) {
		if (CGfx::ViewFollowObject == Player) {
			if (bPlayerDestroyed && PlayerSpawnDelay < 4) {
				FollowInstigator();
			}
		}
		else {
			float dx=FLT_MAX;
			for (DWORD n=0 ; n < MAXENEMIES ; n++) {
				if (Enemy[n] != NULL && Enemy[n]->bHidden == FALSE && Target[n] != NULL && Target[n]->bHidden == FALSE) {
					if (TargetDX[n] < dx) {
						CGfx::ViewFollowObject=Enemy[n];
						dx=TargetDX[n];
					}
				}
			}
		}
	}

	D3DXCOLOR rgba(1,1,1,1);
	CGfx::PrintText(-1,8,rgba,"FUEL PODS: %ld  NUKES: %ld  MISSILES: %ld BOOST=%.02f",CubesLeft,SmartBombs,Missiles,TurboBoost);
	CGfx::PrintText(-1,24,rgba,"LEVEL: %ld  DIFFICULTY: %.02f",Level,Difficulty);
	CGfx::PrintText(-1,40,rgba,"SCORE: %ld",Score);
	if (HighScore > 0) {
		if (bGameOver) {
			rgba=D3DXCOLOR(1,fabsf(sinf(GameTime)),1,1);
		}
		if (Score > HighScore) {
			HighScore=Score;
			WriteHighScore();
		}
		CGfx::PrintText(-1,56,rgba,"HIGHSCORE: %ld",HighScore);
	}
	if (bGameOver) {
		GameOverDelay+=delta;
		D3DXCOLOR rgba(fabsf(sinf(GameTime)),1,fabsf(cosf(GameTime)),1);
		CGfx::PrintText(-1,(LONG)(CGfx::DisplayHeight*0.25f),rgba,"G A M E   O V E R");
		rgba=D3DXCOLOR(fabsf(cosf(GameTime)),1,fabsf(sinf(GameTime)),1);
		if (GameOverDelay >= 5) {
			CGfx::PrintText(-1,PrintTextY+20,rgba,"PRESS FIRE TO PLAY AGAIN");
			if (GetKey(KEY_CTRL) || CInput::GetJoystickButton(0)) {
				RestartGame();
				return;
			}
			CGfx::PrintText(-1,(LONG)(CGfx::DisplayHeight*0.7f),D3DXCOLOR(1,1,1,1),"Coded in 2001,2002 by Les Bird using Direct3D and D3DX");
			CGfx::PrintText(-1,PrintTextY+20,D3DXCOLOR(1,1,1,0.7f),"Some art and sounds from the DirectX 8 SDK");
		}
/*
		PlaybackDemoDelay+=delta;
		if (PlaybackDemoDelay >= 10) {
			CGfx::PlaybackDemo();
			PlaybackDemoDelay=0;
			return;
		}
*/
	}
	if (Player != NULL && Player->bCanTouch == TRUE) {
		float TurboAccel=0;
		CGfx::ViewFollowObject=Player;
		CGfx::ViewFollowSpeedFactor=PLAYERFOLLOWSPEED;
		D3DXVECTOR3	pos=Player->GetPosition();
		Player->SetPosition(pos.x,0,pos.z);
		if (!bGameOver) {
			if (CInput::diJoystickState[0].lX != 0) {
				Player->AddRotation(0,CInput::diJoystickState[0].lX*0.1f*delta,0);
			}
			if (PeekKey(KEY_LEFT)) {
				Player->AddRotation(0,-100*delta,0);
			}
			else if (PeekKey(KEY_RIGHT)) {
				Player->AddRotation(0, 100*delta,0);
			}
			if (CInput::diJoystickState[0].lY != 0) {
				PlayerSpeed+=(CInput::diJoystickState[0].lY*delta);
				for (short n=0 ; n < MAXFLAMES ; n++) {
					if (PlayerFlame[n] != NULL) {
						if (CInput::diJoystickState[0].lY < 0) {
							PlayerFlame[n]->bHidden=FALSE;
							PlayerFlame[n]->Transparency=abs(CInput::diJoystickState[0].lY)/1000.0f;
						}
						else {
							PlayerFlame[n]->bHidden=TRUE;
						}
					}
				}
			}
			if (PeekKey(KEY_UP)) {
				PlayerSpeed-=(1000*delta);
				for (short n=0 ; n < MAXFLAMES ; n++) {
					if (PlayerFlame[n] != NULL) {
						PlayerFlame[n]->bHidden=FALSE;
						PlayerFlame[n]->Transparency=1;
					}
				}
				bKeyFoward=TRUE;
			}
			else if (PeekKey(KEY_DOWN)) {
				PlayerSpeed+=(1000*delta);
				for (short n=0 ; n < MAXFLAMES ; n++) {
					if (PlayerFlame[n] != NULL) {
						PlayerFlame[n]->bHidden=TRUE;
					}
				}
			}
			else if (bKeyFoward) {
				for (short n=0 ; n < MAXFLAMES ; n++) {
					if (PlayerFlame[n] != NULL) {
						PlayerFlame[n]->bHidden=TRUE;
					}
				}
				bKeyFoward=FALSE;
			}
			if (GetKey(KEY_F3)) {
				ControllerSettings=(ControllerSettings+1)%3;
				ControllerSettingTimer=3;
			}
			if (ControllerSettingTimer > 0) {
				ControllerSettingTimer-=delta;
				if (ControllerSettingTimer < 0) {
					ControllerSettingTimer=0;
				}
				CGfx::PrintText("CAMERA CONTROLS %s",ControllerSettings == 0 ? "OFF" : ControllerSettings == 1 ? "ON" : "REVERSED");
			}
			if (PeekKey(KEY_LSHIFT)) {
				if (GetKey(KEY_G)) {
					CGfx::SetFogMode(CGfx::bFogMode ? FALSE : TRUE);
				}
				if (GetKey(KEY_L)) {
					bShowLensFlare=(bShowLensFlare ? FALSE : TRUE);
				}
				if (GetKey(KEY_N)) {
					PickNewNebula();
				}
				if (GetKey(KEY_O)) {
					GameOverDelay=0;
					bGameOver=TRUE;
					if (Score > HighScore) {
						HighScore=Score;
						WriteHighScore();
					}
				}
			}
			TurboAccel=(CInput::diJoystickState[0].rgbButtons[3] || PeekKey(KEY_X)) ? Difficulty*2 : 1;
		}
		if (PlayerSpeed < 0 && TurboAccel > 1.0f) {
			TurboBoost-=delta;
			if (TurboBoost > 0) {
				for (DWORD n=0 ; n < MAXFLAMES ; n++) {
					if (PlayerFlame[n] != NULL) {
						PlayerFlame[n]->Transparency=1.0f;
						PlayerFlame[n]->bHidden=FALSE;
						PlayerFlameBoost[n]->bHidden=FALSE;
					}
				}
				PlayerSpeed=-1000.0f;
			}
			else {
				for (DWORD n=0 ; n < MAXFLAMES ; n++) {
					if (PlayerFlameBoost[n] != NULL) {
						PlayerFlameBoost[n]->bHidden=TRUE;
					}
				}
				TurboAccel=1;
				TurboBoost=0;
			}
		}
		else {
			for (DWORD n=0 ; n < MAXFLAMES ; n++) {
				if (PlayerFlameBoost[n] != NULL) {
					PlayerFlameBoost[n]->bHidden=TRUE;
				}
			}
			TurboBoost+=(delta*0.5f);
			if (TurboBoost > MAXBOOSTTIME) {
				TurboBoost=MAXBOOSTTIME;
			}
		}
		if (PlayerSpeed > 0) {
			PlayerSpeed=__min(PlayerSpeed,100);
		}
		else {
			PlayerSpeed=__max(PlayerSpeed,-250*TurboAccel);
		}
		PlayerSpeed-=(PlayerSpeed*delta);
		D3DXVECTOR3	v=Player->TransformVector(0,0,PlayerSpeed);
		Player->SetVelocity(v);
		if (!bGameOver) {
			if (GetKey(KEY_CTRL) || CInput::GetJoystickButton(0)) {
				for (DWORD n=0 ; n < MAXPLAYERPROJECTILES ; n++) {
					if (PlayerProj[n] == NULL) {
						D3DXVECTOR3 p=Player->TransformPoint(0,0,-Radius*0.5f);
						float s=D3DXVec3Length(&Player->Velocity);
						D3DXVECTOR3 v=Player->TransformVector(0,0,-1000-s);
						PlayerProj[n]=SpawnProjectile(p,v);
						PlayerProj[n]->Instigator=Player;
						PlayerProj[n]->FilterObject(Player);
						PlayerProj[n]->Notify(GameType);
						if (GunFireSound != NULL) {
							GunFireSound->Play();
						}
						break;
					}
				}
			}
			if (GetKey(KEY_ENTER) || CInput::GetJoystickButton(2)) {
				if (Missiles > 0) {
					for (DWORD n=0 ; n < MAXMISSILEPROJECTILES ; n++) {
						if (Missiles > 0 && Missile[n] != NULL) {
							if (Missile[n]->bHidden == TRUE) {
								C3DObject *obj=Player;
								Missile[n]->Instigator=Player;
								Missile[n]->SetPosition(obj->GetPosition());
								float spd=D3DXVec3Length(&obj->Velocity);
								D3DXVECTOR3 v=obj->TransformVector(0,0,-spd-100);
								Missile[n]->Rotation=obj->Rotation;
								Missile[n]->SetVelocity(v);
								Missile[n]->Timer=0;
								Missile[n]->bCanTouch=TRUE;
								Missile[n]->bHidden=FALSE;
								Missiles--;
							}
						}
					}
				}
			}
			if (GetKey(KEY_BKSP) || CInput::GetJoystickButton(1)) {
				if (SmartBombs > 0 && SmartBomb != NULL) {
					if (NukeSound != NULL) {
						NukeSound->Play();
					}
					SmartBomb->SetPosition(pos);
					SmartBomb->bHidden=FALSE;
					SmartBomb->ScaleRate=10;
					SmartBomb->ScaleX=SmartBomb->ScaleY=SmartBomb->ScaleZ=0.1f;
					SmartBomb->Timer=0;
					SmartBombs--;
				}
			}
			if (!bNewLevel) {
				if (BeepSoundDelay > 0) {
					BeepSoundDelay-=delta;
					if (BeepSoundDelay <= 0) {
						BeepSoundDelay+=2.0f/Difficulty;
						if (bBeepHi) {
							if (Beep1Sound != NULL) {
								Beep1Sound->Play();
							}
						}
						else {
							if (Beep2Sound != NULL) {
								Beep2Sound->Play();
							}
						}
						bBeepHi=(bBeepHi ? FALSE : TRUE);
					}
				}
			}
		}
		float speed=D3DXVec3Length(&Player->Velocity);
		float xadj=0;
		float zadj=0;
		if (ControllerSettings > 0) {
			if (CInput::diJoystickState[0].lRz < -200 || CInput::diJoystickState[0].lRz > 200) {
				xadj=float(CInput::diJoystickState[0].lRz)/500.0f;
			}
			if (CInput::diJoystickState[0].rglSlider[0] < -250 || CInput::diJoystickState[0].rglSlider[0] > 250) {
				zadj=float(CInput::diJoystickState[0].rglSlider[0])/250.0f;
			}
			if (ControllerSettings == 2) {
				xadj=-xadj;
				zadj=-zadj;
			}
		}
		if (GetKey(KEY_PGDN)) {
			CGfx::ViewFollowDist*=1.1f;
			PlayerFollowOrientation.y*=1.1f;
		}
		else if (GetKey(KEY_PGUP)) {
			CGfx::ViewFollowDist*=0.9f;
			PlayerFollowOrientation.y*=0.9f;
		}
		CGfx::ViewFollowOrientation=D3DXVECTOR3(PlayerFollowOrientation.x-xadj,PlayerFollowOrientation.y,PlayerFollowOrientation.z+zadj);
	}
	else if (Player != NULL) {
		PlayerSpawnDelay-=delta;
		if (PlayerSpawnDelay <= 0) {
			Player->SetVelocity(0,0,0);
			Player->SetPosition(0,0,0);
			Player->bHidden=FALSE;
			Player->bCanTouch=TRUE;
			CGfx::ViewFollowDist=PLAYERFOLLOWDIST;
			CGfx::ViewFollowOrientation=PlayerFollowOrientation;
			if (RespawnSound != NULL) {
				RespawnSound->Play();
			}
			bPlayerDestroyed=FALSE;
		}
		else {
			CGfx::ViewFollowSpeedFactor=ENEMYFOLLOWSPEED;
		}
	}
	if (HelpDelay > 0) {
		HelpDelay-=delta;
		float a=HelpDelay > 1 ? 1 : HelpDelay;
		CGfx::PrintText(-1,(LONG)(CGfx::DisplayHeight*0.2f),D3DXCOLOR(0.2f,1,0.2f,a),"MISSION: PROTECT THE CUBES FROM THE PIRATE SHIPS");
		CGfx::PrintText(-1,PrintTextY+40,D3DXCOLOR(0.2f,1,0.2f,a)," CTRL = FIRE PULSE LASER");
		CGfx::PrintText(PrintTextX,PrintTextY+20,D3DXCOLOR(0.2f,1,0.2f,a)," BKSP = FIRE NUKE");
		CGfx::PrintText(PrintTextX,PrintTextY+20,D3DXCOLOR(0.2f,1,0.2f,a),"ENTER = FIRE MISSILES");
		CGfx::PrintText(PrintTextX,PrintTextY+20,D3DXCOLOR(0.2f,1,0.2f,a),"    X = ENGAGE TURBO BOOST");
		CGfx::PrintText(-1,PrintTextY+40,D3DXCOLOR(0.2f,1,0.2f,a),"OR USE A GAMEPAD/JOYSTICK");
	}
	if (PrizeMessageDelay > 0) {
		PrizeMessageDelay-=delta;
		if (PrizeMessageDelay < 0) {
			PrizeMessageDelay=0;
		}
		else {
			float a=PrizeMessageDelay > 1 ? 1 : PrizeMessageDelay;
			float y=(CGfx::DisplayHeight*0.4f)-((5-PrizeMessageDelay)*20);
			CGfx::PrintText(-1,(LONG)y,D3DXCOLOR(0,1,0,a),PrizeMessage);
			float a2=__max(a-0.2f,0);
			CGfx::PrintText(-1,(LONG)y+1,D3DXCOLOR(0,1,0,a2),PrizeMessage);
			float a3=__max(a-0.5f,0);
			CGfx::PrintText(-1,(LONG)y+2,D3DXCOLOR(0,1,0,a3),PrizeMessage);
			float a4=__max(a-0.8f,0);
			CGfx::PrintText(-1,(LONG)y+3,D3DXCOLOR(0,1,0,a4),PrizeMessage);
		}
	}
	if (SmartBomb != NULL && SmartBomb->bHidden == FALSE) {
		D3DXVECTOR3 pos1=SmartBomb->GetPosition();
		for (DWORD n=0 ; n < MAXENEMIES ; n++) {
			if (Enemy[n] != NULL && Enemy[n]->bHidden == FALSE) {
				D3DXVECTOR3 pos2=Enemy[n]->GetPosition();
				D3DXVECTOR3	dist;
				D3DXVec3Subtract(&dist,&pos1,&pos2);
				float dx=D3DXVec3Length(&dist);
				if (dx <= (SmartBomb->Width*SmartBomb->GetScale()*0.5f)) {
					Difficulty+=0.25f;
					Score+=(DWORD)(ENEMYPOINTS*Difficulty*Level);
					EnemyKills++;
					TotalKills++;
					if (EnemyKills >= MAXKILLS) {
						bNewLevel=TRUE;
						NewLevelTick=0;
					}
					DestroyEnemy(SmartBomb,Enemy[n]);
					SpawnExplosion(Enemy[n],Enemy[n]);
					DWORD s=CGfx::RandomInt()%3;
					if (ExplosionSound[s] != NULL) {
						ExplosionSound[s]->Play();
					}
				}
			}
			if (SmartBomb->Timer >= 5) {
				SmartBomb->bHidden=TRUE;
				SmartBomb->ScaleRate=0;
				SmartBomb->ScaleX=SmartBomb->ScaleY=SmartBomb->ScaleZ=0.1f;
			}
			else {
				SmartBomb->Transparency=__min(__max(5.0f-SmartBomb->Timer,0),1.0f);
			}
		}
	}
	if (PrizeSphere != NULL && PrizeSphere->bHidden == FALSE) {
		float s=__min(fabsf(sinf(GameTime)+0.5f),1.0f);
		PrizeSphere->AmbientLighting=D3DXCOLOR(s,s,s,1);
		D3DXVec3Scale(&PrizeSphere->Impulse,&PrizeSphere->Velocity,-delta);
	}
	for (DWORD n=0 ; n < MAXCUBES ; n++) {
		if (FuelPod[n] != NULL && FuelPod[n]->bCanTouch) {
			if (FuelPod[n]->ParentObject == NULL) {
				D3DXVec3Scale(&FuelPod[n]->Impulse,&FuelPod[n]->Velocity,-delta);
				D3DXVECTOR3 pos=FuelPod[n]->GetPosition();
				FuelPod[n]->SetPosition(pos.x,0,pos.z);
			}
		}
	}
	if (bNewLevel) {
		for (DWORD n=0 ; n < MAXENEMIES ; n++) {
			if (Enemy[n] != NULL && Enemy[n]->bHidden == FALSE) {
				break;
			}
		}
		if (n == MAXENEMIES) {
			if (NewLevelTick == 0) {
				BonusPoints=(DWORD)(CubesLeft*Level*1000);
				Score+=BonusPoints;
				Level++;
				Difficulty=float(Level)/2.0f;
				EnemyKills=0;
			}
			NewLevelTick+=delta;
			if (NewLevelTick > 10) {
				bNewLevel=FALSE;
				PickNewNebula();
			}
			else {
				float a=__min(10.0f-NewLevelTick,1);
				D3DXCOLOR rgba(fabsf(sinf(GameTime)),1,fabsf(cosf(GameTime)),a);
				CGfx::PrintText(-1,(LONG)(CGfx::DisplayHeight*0.3f),rgba,"L E V E L  %ld",Level);
				CGfx::PrintText(-1,(LONG)(CGfx::DisplayHeight*0.3f)+20,rgba,"%ld PODS x LEVEL %ld x 1000 = %ld BONUS POINTS",CubesLeft,Level-1,BonusPoints);
			}
		}
		BeepSoundDelay=2.0f/Difficulty;
		bBeepHi=FALSE;
	}
	TickEnemyAI(delta);
	MissileAI(delta);
	TickSpriteSun(delta);
}

void
CExperimentalGame::TickEnemyAI(float delta)
{
	for (DWORD n=0 ; n < MAXENEMIES ; n++) {
		C3DObject *obj=Enemy[n];
		if (obj == NULL) {
			continue;
		}
		D3DXVECTOR3	pos=obj->GetPosition();
		obj->SetPosition(pos.x,0,pos.z);
		if (bGameOver) {
			if (EnemyState[n] != ENEMYSTATE_IDLE) {
				EnemyState[n]=ENEMYSTATE_IDLE;
			}
			if (Target[n] != NULL) {
				if (Target[n] != Player) {
					Target[n]->UnLink();
				}
				Target[n]=NULL;
			}
		}
		else {
			if (obj->bCanTouch && Target[n] == NULL) {
				float closest=FLT_MAX;
				for (DWORD n2=0 ; n2 < MAXCUBES ; n2++) {
					if (FuelPod[n2]->bCanTouch == FALSE) {
						continue;
					}
					if (FuelPod[n2]->ParentObject != NULL) {
						continue;
					}
					D3DXVECTOR3 dxv,pos2;
					pos2=FuelPod[n2]->GetPosition();
					D3DXVec3Subtract(&dxv,&pos,&pos2);
					float dx=D3DXVec3Length(&dxv);
					if (dx < closest) {
						closest=dx;
						Target[n]=FuelPod[n2];
					}
				}
				for (DWORD n3=0 ; n3 < MAXENEMIES ; n3++) {
					if (n3 != n) {
						if (Target[n3] == Target[n]) {
							if (Player->bCanTouch) {
								Target[n]=Player;
							}
							else {
								Target[n]=NULL;
							}
						}
					}
				}
//				if (Player->bCanTouch) {
//					if (Target[n] != Player) {
//						if (CGfx::Random() > 0.8f) {
//							Target[n]=Player;
//						}
//					}
//				}
			}
		}
		float DiffMax=Difficulty > MAXDIFFICULTY ? MAXDIFFICULTY : Difficulty;
		switch (EnemyState[n]) {
		case ENEMYSTATE_RESPAWN:
			{
				if (!bNewLevel) {
					EnemySpawnDelay[n]-=delta;
					if (EnemySpawnDelay[n] <= 0) {
						Enemy[n]->SetPosition(0,0,0);
						Enemy[n]->SetRotation(0,(float)(CGfx::RandomInt()%360),0);
						Enemy[n]->Transform();
						D3DXVECTOR3 p=Enemy[n]->TransformPoint(-ENEMYSTARTDIST,0,-ENEMYSTARTDIST);
						Enemy[n]->SetPosition(p);
						Enemy[n]->SetRotation(0,0,0);
						Enemy[n]->bCanTouch=TRUE;
						Enemy[n]->bHidden=FALSE;
						for (DWORD i=0 ; i < MAXFLAMES ; i++) {
							EnemyFlame[n][i]->bHidden=FALSE;
						}
						EnemyState[n]=ENEMYSTATE_SEEK;
					}
				}
			}
			break;
		case ENEMYSTATE_SEEK:
			{
				for (DWORD i=0 ; i < MAXENEMIES ; i++) {
					if (i != n) {
						if (Target[i] != Player) {
							if (Target[n] == Target[i]) {
								Target[n]=NULL;
								break;
							}
						}
					}
				}
				if (Target[n] != NULL) {
					if (Target[n]->ParentObject == NULL && Target[n]->bCanTouch) {
						D3DXVECTOR3 pos1=obj->GetPosition();
						D3DXVECTOR3 pos2=Target[n]->GetPosition();
						D3DXVECTOR3	dir1;
						D3DXVec3Subtract(&dir1,&pos1,&pos2);
						TargetDX[n]=D3DXVec3Length(&dir1);
						D3DXVECTOR3 dir2=obj->TransformVector(1,0,0);
						D3DXVECTOR3 dir3,dir4;
						D3DXVec3Normalize(&dir3,&dir1);
						float dot=D3DXVec3Dot(&dir2,&dir3);

						dir4=obj->GetRotation();
						obj->SetRotation(dir4.x,dir4.y+(D3DXToDegree(dot)*Difficulty*delta),dir4.z);

						D3DXVECTOR3 v=obj->Velocity;
						D3DXVECTOR3 acc=obj->TransformVector(0,0,-10.0f*DiffMax);
						D3DXVec3Add(&v,&v,&acc);
						if (D3DXVec3Length(&v) >= 50.0f*DiffMax) {
							D3DXVec3Normalize(&v,&v);
							D3DXVec3Scale(&v,&v,(50.0f*DiffMax));
						}
						if (Target[n] == Player) {
							EnemyFireDelay[n]-=delta;
							if (TargetDX[n] < 1000.0f) {
								if (EnemyProj[n] == NULL) {
									if (EnemyFireDelay[n] <= 0) {
										float spd=D3DXVec3Length(&obj->Velocity);
										EnemyProj[n]=SpawnProjectile(obj->TransformPoint(0,0,-obj->Radius),obj->TransformVector(0,0,-spd-500));
										EnemyProj[n]->LifeSpan=1;
										EnemyProj[n]->Notify(GameType);
										EnemyProj[n]->Instigator=obj;
										obj->FilterObject(EnemyProj[n]);
										if (EnemyGunFireSound != NULL) {
											EnemyGunFireSound->Play();
										}
										EnemyFireDelay[n]=1.0f;
									}
								}
							}
						}
						D3DXVec3Scale(&v,&v,__min(TargetDX[n]/((obj->Radius+Target[n]->Radius)*5),1.0f));
						float spd=D3DXVec3Length(&v);
						for (DWORD i=0 ; i < MAXFLAMES ; i++) {
							if (EnemyFlame[n][i]->bHidden == FALSE) {
								EnemyFlame[n][i]->Transparency=spd/(50.0f*DiffMax);
							}
						}
						obj->SetVelocity(v);
					}
					else {
						D3DXVECTOR3 v=obj->Velocity;
						D3DXVec3Scale(&v,&v,-delta);
						D3DXVec3Add(&v,&v,&obj->Velocity);
						obj->SetVelocity(v);
						Target[n]=NULL;
					}
				}
			}
			break;
		case ENEMYSTATE_DOCK:
			{
				Target[n]->AmbientLighting=D3DXCOLOR(1,1,0,1);
				Target[n]->SetVelocity(0,0,0);
				obj->FilterObject(Target[n]);
				obj->SetVelocity(0,0,0);
				obj->SetRotationRate(0,45,0);
				EnemyState[n]=ENEMYSTATE_TURN;
				for (DWORD i=0 ; i < MAXFLAMES ; i++) {
					if (EnemyFlame[n][i]->bHidden == FALSE) {
						EnemyFlame[n][i]->Transparency=0;
					}
				}
				if (DockingSound != NULL) {
					DockingSound->Play(DSBPLAY_LOOPING,NULL);
				}
			}
			break;
		case ENEMYSTATE_TURN:
			{
				D3DXVECTOR3 dir1=obj->TransformVector(0,0,-1);
				D3DXVECTOR3 dir2;
				D3DXVec3Subtract(&dir2,&pos,&Target[n]->GetPosition());
				D3DXVec3Normalize(&dir2,&dir2);
				float d=D3DXVec3Dot(&dir1,&dir2);
				if (d > 0.9f) {
					obj->SetRotationRate(0,0,0);
					Target[n]->Link(Enemy[n]);
					Target[n]->SetPosition(0,0,Enemy[n]->Radius+Target[n]->Radius);
					Target[n]->SetRotation(0,0,0);
					EnemyTurnDelay[n]=CGfx::Random()*4;
					obj->SetRotationRate(0,(CGfx::Random()*90)-45,0);
					EnemyState[n]=ENEMYSTATE_EVADE;
					if (TractorBeamSound != NULL) {
						TractorBeamSound->Play();
					}
					if (DockingSound != NULL) {
						DockingSound->Stop();
					}
				}
			}
			break;
		case ENEMYSTATE_EVADE:
			{
				if (EnemyTurnDelay[n] > 0) {
					EnemyTurnDelay[n]-=delta;
					if (EnemyTurnDelay[n] <= 0) {
						obj->SetRotationRate(0,0,0);
					}
				}
				Target[n]->AmbientLighting=D3DXCOLOR(1,0,0,1);
				D3DXVECTOR3 p1=Target[n]->GetPosition();
				float dx=D3DXVec3Length(&p1);
				if (dx > (ENEMYSTARTDIST-1000)+Target[n]->Radius) {
					VortexSphere[n]->bHidden=FALSE;
					VortexSphere[n]->Transparency=__min(dx/ENEMYSTARTDIST,1.0f);
					VortexSphere[n]->ScaleX=CGfx::Random()+(VortexSphere[n]->Transparency*0.5f);
					VortexSphere[n]->ScaleY=VortexSphere[n]->ScaleZ=VortexSphere[n]->ScaleX;
				}
				else {
					VortexSphere[n]->bHidden=TRUE;
					VortexSphere[n]->ScaleX=VortexSphere[n]->ScaleY=VortexSphere[n]->ScaleZ=1;
				}
				if (dx > ENEMYSTARTDIST+Target[n]->Radius) {
					Target[n]->UnLink();
					Target[n]->SetRotation(0,0,0);
					Target[n]->SetRotationRate(0,0,0);
					Target[n]->AmbientLighting=PODAMBIENTLIGHTING;
					Target[n]->bHidden=TRUE;
					Target[n]->bCanTouch=FALSE;
					Target[n]=NULL;
					VortexSphere[n]->bHidden=TRUE;
					if (CubeGoneSound != NULL) {
						CubeGoneSound->Play();
					}
					if (CubesLeft > 0) {
						if (--CubesLeft == 0) {
							for (short n=0 ; n < MAXFLAMES ; n++) {
								PlayerFlame[n]->bHidden=TRUE;
								PlayerFlameBoost[n]->bHidden=TRUE;
							}
							GameOverDelay=0;
							if (Score > HighScore) {
								HighScore=Score;
								WriteHighScore();
							}
							bGameOver=TRUE;
						}
					}
					Enemy[n]->bCanTouch=FALSE;
					Enemy[n]->bHidden=TRUE;
					EnemyState[n]=ENEMYSTATE_RESPAWN;
					EnemySpawnDelay[n]=2;
					for (DWORD i=0 ; i < MAXFLAMES ; i++) {
						EnemyFlame[n][i]->bHidden=TRUE;
					}
				}
				else {
					float spd=D3DXVec3Length(&obj->Velocity);
					D3DXVECTOR3 v=obj->TransformVector(0,0,-spd);
					D3DXVECTOR3 acc=obj->TransformVector(0,0,-DiffMax*2.0f);
					D3DXVec3Add(&v,&v,&acc);
					if (D3DXVec3Length(&v) >= 30.0f*DiffMax) {
						D3DXVec3Normalize(&v,&v);
						D3DXVec3Scale(&v,&v,30.0f*DiffMax);
					}
					spd=D3DXVec3Length(&v);
					for (DWORD i=0 ; i < MAXFLAMES ; i++) {
						if (EnemyFlame[n][i]->bHidden == FALSE) {
							EnemyFlame[n][i]->Transparency=spd/(30.0f*DiffMax);
						}
					}
					obj->SetVelocity(v);
				}
			}
			break;
		case ENEMYSTATE_IDLE:
			D3DXVec3Scale(&obj->Impulse,&obj->Velocity,-delta);
			break;
		}
	}
}

void
CExperimentalGame::MissileAI(float delta)
{
	for (DWORD n=0 ; n < MAXMISSILEPROJECTILES ; n++) {
		if (Missile[n] != NULL && Missile[n]->bHidden == FALSE) {
			if (Missile[n]->Timer >= 1) {
				for (DWORD i=0 ; i < MAXFLAMES ; i++) {
					if (MissileFlame[n][i]->bHidden == TRUE) {
						MissileFlame[n][i]->bHidden=FALSE;
					}
				}
				if (Enemy[n] != NULL && Enemy[n]->bHidden == FALSE) {
					D3DXVECTOR3 pos1=Missile[n]->GetPosition();
					D3DXVECTOR3 pos2=Enemy[n]->GetPosition();
					D3DXVECTOR3	dir1;
					D3DXVec3Subtract(&dir1,&pos1,&pos2);
					D3DXVECTOR3 r1=Missile[n]->TransformVector(1,0,0);
					D3DXVec3Normalize(&dir1,&dir1);
					float dot=D3DXVec3Dot(&r1,&dir1);
					Missile[n]->AddRotation(0,D3DXToDegree(dot),0);
					float spd=4000.0f*(1.0f-fabsf(dot));
					D3DXVECTOR3 v=Missile[n]->TransformVector(0,0,-spd);
					Missile[n]->SetVelocity(v);
					C3DSprite *spr=GetParticleSprite();
					if (spr != NULL) {
						spr->ScaleX=spr->ScaleY=spr->ScaleZ=0.3f;
						spr->ScaleRate=-0.5f;
						spr->SetPosition(pos1.x,pos1.y,pos1.z);
						spr->SetVelocity(0,0,0);
						spr->LifeSpan=1;
					}
				}
				else {
					for (DWORD i=0 ; i < MAXFLAMES ; i++) {
						if (MissileFlame[n][i]->bHidden == FALSE) {
							MissileFlame[n][i]->bHidden=TRUE;
						}
					}
					D3DXVec3Scale(&Missile[n]->Impulse,&Missile[n]->Velocity,-delta);
				}
			}
		}
	}
}

C3DObject *
CExperimentalGame::SpawnPlayer()
{
	C3DObject *obj=(C3DObject *)SPAWN('3OBJ');
	if (obj != NULL) {
		obj->LoadMesh("bigship1.x",FALSE);
		obj->SetObjectName("SHIP");
		obj->Mass=25;
		obj->SetRotation(0,0,0);
		obj->SetRotationRate(0,0,0);
		obj->SetVelocity(0,0,0);
		obj->AddTexture(NebulaFile,TEXFLAGS_REFLECTIONMAP);
		obj->AmbientLighting=D3DXCOLOR(0.25f,0.25f,0.25f,1);
		for (DWORD n=0 ; n < MAXFLAMES ; n++) {
			if (PlayerFlame[n] == NULL) {
				PlayerFlame[n]=(C3DSprite *)SPAWN('3SPR');
				PlayerFlame[n]->Link(obj);
				PlayerFlame[n]->InitSprite((5-(float)n)*4);
				PlayerFlame[n]->AddTexture("particle.tga");
				PlayerFlame[n]->Transparency=1.0f/(1.0f+n);
				PlayerFlame[n]->SetPosition(0,0,(obj->Radius*0.75f)+((obj->Radius*0.3f)*n));
				PlayerFlame[n]->bTransparency=TRUE;
				PlayerFlame[n]->bDoubleSided=TRUE;
				PlayerFlame[n]->bCanTouch=FALSE;
				PlayerFlame[n]->bUnlit=TRUE;
				PlayerFlame[n]->bHidden=TRUE;
				PlayerFlame[n]->bEnable=FALSE;
				PlayerFlameBoost[n]=(C3DSprite *)SPAWN('3SPR');
				PlayerFlameBoost[n]->Link(obj);
				PlayerFlameBoost[n]->InitSprite((5-(float)n)*4);
				PlayerFlameBoost[n]->AddTexture("blueparticle.tga");
				PlayerFlameBoost[n]->Transparency=1.0f;
				PlayerFlameBoost[n]->SetPosition(0,0,(obj->Radius*2.0f)+((obj->Radius*0.5f)*n));
				PlayerFlameBoost[n]->bTransparency=TRUE;
				PlayerFlameBoost[n]->bDoubleSided=TRUE;
				PlayerFlameBoost[n]->bCanTouch=FALSE;
				PlayerFlameBoost[n]->bUnlit=TRUE;
				PlayerFlameBoost[n]->bHidden=TRUE;
				PlayerFlameBoost[n]->bEnable=FALSE;
			}
		}
		return(obj);
	}
	return(NULL);
}

C3DObject *
CExperimentalGame::SpawnEnemy(DWORD enemy)
{
	Enemy[enemy]=(C3DObject *)SPAWN('3OBJ');
	Enemy[enemy]->LoadMesh("spaceship 8.x");
//	Enemy[enemy]->CloneNewFVF();
	Enemy[enemy]->SphereMapTexture();
	Enemy[enemy]->SetObjectName("PIRATE");
	Enemy[enemy]->AddTexture("wall.tga",TEXFLAGS_ALLMATERIALS);
	Enemy[enemy]->AddTexture(NebulaFile,TEXFLAGS_REFLECTIONMAP|TEXFLAGS_ALLMATERIALS);
	Enemy[enemy]->Mass=25;
	Enemy[enemy]->SetPosition(0,0,0);
	Enemy[enemy]->SetRotation(0,0,0);
	Enemy[enemy]->bCanTouch=FALSE;
	Enemy[enemy]->bHidden=TRUE;
	Enemy[enemy]->bUnlit=TRUE;
	for (DWORD n=0 ; n < MAXFLAMES ; n++) {
		if (EnemyFlame[enemy][n] == NULL) {
			EnemyFlame[enemy][n]=(C3DSprite *)SPAWN('3SPR');
			EnemyFlame[enemy][n]->Link(Enemy[enemy]);
			EnemyFlame[enemy][n]->InitSprite((5-(float)n)*5);
			EnemyFlame[enemy][n]->AddTexture("particle.tga");
			EnemyFlame[enemy][n]->Transparency=1.0f/(1.0f+n);
			EnemyFlame[enemy][n]->SetPosition(0,0,(Enemy[enemy]->Radius*0.75f)+((Enemy[enemy]->Radius*0.1f)*n));
			EnemyFlame[enemy][n]->bTransparency=TRUE;
			EnemyFlame[enemy][n]->bDoubleSided=TRUE;
			EnemyFlame[enemy][n]->bCanTouch=FALSE;
			EnemyFlame[enemy][n]->bHidden=TRUE;
			EnemyFlame[enemy][n]->bUnlit=TRUE;
			EnemyFlame[enemy][n]->bEnable=FALSE;
		}
	}
	EnemyState[enemy]=ENEMYSTATE_RESPAWN;
	EnemySpawnDelay[enemy]=1;
	EnemyFireDelay[enemy]=1;
	Target[enemy]=NULL;
	return(Enemy[enemy]);
}

C3DObject *
CExperimentalGame::SpawnProjectile(D3DXVECTOR3 p,D3DXVECTOR3 v)
{
	C3DProjectile *proj=(C3DProjectile *)SPAWN('3PRJ');
	if (proj != NULL) {
		proj->InitSprite(10);
		proj->AddTexture("SHINE0.tga");
		proj->SetPosition(p);
		proj->SetVelocity(v);
		proj->SetRotationRate(0,0,180);
		proj->CollisionRadius=0.5f;
		proj->LifeSpan=5;
		proj->Mass=1;
//		C3DLight *light=(C3DLight *)SPAWN('3LIG');
//		light->D3DLight.Range=100;
//		light->Link(proj);
		C3DParticleEmitter *projemit=(C3DParticleEmitter *)SPAWN('3PAR');
		projemit->Link(proj);
		projemit->AddParticle("SHINE0.tga",0.5f,10,0,30,-0.5f,0);
		return(proj);
	}
	return(NULL);
}

C3DPermanentSprite *
CExperimentalGame::GetParticleSprite()
{
	for (DWORD n=0 ; n < MAXPARTICLESPRITES ; n++) {
		C3DPermanentSprite *spr=ParticleSprite[ParticleSpriteNum];
		if (spr != NULL && spr->bHidden == TRUE) {
			spr->bEnable=TRUE;
			spr->bHidden=FALSE;
			spr->bTransform=TRUE;
			return(spr);
		}
		ParticleSpriteNum=(ParticleSpriteNum+1)%MAXPARTICLESPRITES;
	}
	return(NULL);
}

void
CExperimentalGame::PostObjectCollision(CGameObject *gobj1,CGameObject *gobj2)
{
	switch (gobj1->ObjectID) {
	case '3PRJ':
	case '3MIS':
		if (gobj2->IsA("SHIP")) {
			Difficulty=__max(Difficulty-0.25f,1);
			DestroyPlayer(gobj1->Instigator,gobj2);
			SpawnExplosion(gobj2,gobj2);
			DWORD s=CGfx::RandomInt()%3;
			if (ExplosionSound[s] != NULL) {
				ExplosionSound[s]->Play();
			}
		}
		else if (gobj2->IsA("PIRATE")) {
			if (gobj2->bHidden == FALSE) {
				if (gobj1->Instigator == Player) {
					Difficulty+=0.25f;
					Score+=(DWORD)(ENEMYPOINTS*Difficulty*Level);
					EnemyKills++;
					TotalKills++;
					if (EnemyKills >= MAXKILLS) {
						bNewLevel=TRUE;
						NewLevelTick=0;
					}
				}
				for (DWORD n=0 ; n < MAXENEMIES ; n++) {
					if (Enemy[n] != NULL && Enemy[n] == gobj2) {
						DestroyEnemy(gobj1,gobj2);
						SpawnExplosion(gobj2,gobj2);
						DWORD s=CGfx::RandomInt()%3;
						if (ExplosionSound[s] != NULL) {
							ExplosionSound[s]->Play();
						}
						break;
					}
				}
			}
		}
		else if (gobj2->IsA("PRIZESPHERE")) {
			PrizeSphere->bCanTouch=FALSE;
			PrizeSphere->bHidden=TRUE;
			PrizeSphere->bTransform=FALSE;
			SpawnExplosion(gobj2,gobj2);
			if (HitPrizeSphere != NULL) {
				HitPrizeSphere->Play();
			}
		}
		else {
			if (HitCubeSound != NULL) {
				HitCubeSound->Play();
			}
		}
		if (gobj1->ObjectID == '3MIS') {
			for (DWORD n=0 ; n < MAXMISSILEPROJECTILES ; n++) {
				if (gobj1 == Missile[n] && Enemy[n] != NULL) {
					Missile[n]->bCanTouch=FALSE;
					Missile[n]->bHidden=TRUE;
					for (DWORD i=0 ; i < MAXFLAMES ; i++) {
						MissileFlame[n][i]->bHidden=TRUE;
					}
					D3DXVECTOR3 pos1=gobj1->GetPosition();
					D3DXVECTOR3 pos2=Enemy[n]->GetPosition();
					D3DXVECTOR3	dx;
					D3DXVec3Subtract(&dx,&pos1,&pos2);
					if (D3DXVec3Length(&dx) < 200) {
						DestroyEnemy(gobj1,Enemy[n]);
						SpawnExplosion(Enemy[n],Enemy[n]);
						DWORD s=CGfx::RandomInt()%3;
						if (ExplosionSound[s] != NULL) {
							ExplosionSound[s]->Play();
						}
					}
					break;
				}
			}
		}
		break;
	case '3OBJ':
		switch (gobj2->ObjectID) {
		case '3CUB':
			if (gobj1->IsA("PIRATE")) {
				for (DWORD n=0 ; n < MAXENEMIES ; n++) {
					if (Enemy[n] == gobj1 && (Target[n] == NULL || Target[n]->ParentObject == NULL)) {
						if (Target[n] == gobj2) {
							EnemyState[n]=ENEMYSTATE_DOCK;
						}
						else if (gobj2->ParentObject == NULL) {
							for (DWORD n2=0 ; n2 < MAXENEMIES ; n2++) {
								if (n2 != n && Target[n2] == gobj2) {
									Enemy[n2]->SetRotationRate(0,0,0);
									EnemyState[n2]=ENEMYSTATE_SEEK;
									Target[n2]=Target[n];
									break;
								}
							}
							Target[n]=(C3DObject *)gobj2;
							EnemyState[n]=ENEMYSTATE_DOCK;
						}
						break;
					}
				}
			}
			break;
		case 'PRIZ':
			if (gobj1 == Player) {
				switch (PrizeSphereContents) {
				case PRIZE_NUKE:
					SmartBombs++;
					PrizeMessage="N U K E S";
					break;
				case PRIZE_MISSILES:
					Missiles+=5;
					PrizeMessage="M I S S I L E S";
					break;
				}
				PrizeMessageDelay=5;
			}
			PrizeSphere->bCanTouch=FALSE;
			PrizeSphere->bHidden=TRUE;
			PrizeSphere->bTransform=FALSE;
			if (PickPrizeSphere != NULL) {
				PickPrizeSphere->Play();
			}
			break;
		default:
			if (gobj2 == Player) {
				DestroyPlayer(gobj1,gobj2);
				SpawnExplosion(gobj2,gobj2);
				DWORD s=CGfx::RandomInt()%3;
				if (ExplosionSound[s] != NULL) {
					ExplosionSound[s]->Play();
				}
			}
			else {
				for (DWORD n=0 ; n < MAXENEMIES ; n++) {
					if (Enemy[n] == gobj2) {
						DestroyEnemy(gobj1,gobj2);
						SpawnExplosion(gobj2,gobj2);
						DWORD s=CGfx::RandomInt()%3;
						if (ExplosionSound[s] != NULL) {
							ExplosionSound[s]->Play();
						}
						break;
					}
				}
			}
			break;
		}
		break;
	}
}

void
CExperimentalGame::DestroyEnemy(CGameObject *gobj1,CGameObject *gobj2)
{
	for (DWORD n=0 ; n < MAXENEMIES ; n++) {
		if (Enemy[n] == gobj2) {
			if (Target[n] != NULL) {
				if (Target[n]->ObjectID == '3CUB') {
					if (Target[n]->ParentObject == Enemy[n]) {
						Target[n]->UnLink();
						Target[n]->Velocity=gobj2->Velocity;
						Target[n]->SetPosition(Target[n]->GetPosition());
						D3DXVECTOR3 tr=Target[n]->GetRotation();
						Target[n]->SetRotation(tr.x,tr.y,tr.z);
					}
					Target[n]->AmbientLighting=PODAMBIENTLIGHTING;
					Enemy[n]->UnFilterObject(Target[n]);
				}
				Target[n]=NULL;
			}
			VortexSphere[n]->bHidden=TRUE;
			for (DWORD i=0 ; i < MAXFLAMES ; i++) {
				EnemyFlame[n][i]->bHidden=TRUE;
			}
			EnemyState[n]=ENEMYSTATE_RESPAWN;
			Enemy[n]->bCanTouch=FALSE;
			Enemy[n]->bHidden=TRUE;
			EnemySpawnDelay[n]=5;
			if (CGfx::Random() > 0.9f) {
				if (PrizeSphere->bHidden == TRUE) {
					PrizeSphere->SetPosition(gobj2->GetPosition());
					PrizeSphere->SetVelocity(gobj2->Velocity);
					PrizeSphere->bCanTouch=TRUE;
					PrizeSphere->bHidden=FALSE;
					PrizeSphere->bTransform=TRUE;
					PrizeSphereContents=CGfx::RandomInt()&1;
					if (DropItemSound != NULL) {
						DropItemSound->Play();
					}
				}
			}
			return;
		}
	}
}

void
CExperimentalGame::DestroyPlayer(CGameObject *gobj1,CGameObject *gobj2)
{
	if (Player == NULL) {
		return;
	}
	for (DWORD n=0 ; n < MAXENEMIES ; n++) {
		if (Target[n] == Player) {
			Target[n]=NULL;
		}
	}
	for (DWORD i=0 ; i < MAXFLAMES ; i++) {
		PlayerFlame[i]->bHidden=TRUE;
		PlayerFlameBoost[i]->bHidden=TRUE;
	}
	Player->Instigator=gobj1;
	Player->bHidden=TRUE;
	Player->bCanTouch=FALSE;
	PlayerSpawnDelay=5;
	bPlayerDestroyed=TRUE;
}

void
CExperimentalGame::FollowInstigator()
{
	CGfx::ViewFollowDist=ENEMYFOLLOWDIST;
	CGfx::ViewFollowOrientation=D3DXVECTOR3((CGfx::RandomInt()&1) != 0 ? -ENEMYFOLLOWORIENTATIONX : ENEMYFOLLOWORIENTATIONX,ENEMYFOLLOWORIENTATIONY,ENEMYFOLLOWORIENTATIONZ);
	CGfx::ViewFollowObject=Player->Instigator;
}

void
CExperimentalGame::SpawnExplosion(CGameObject *gobj1,CGameObject *gobj2)
{
	Enter("SpawnExplosion()");

	D3DXVECTOR3	pos1=gobj1->GetPosition();
	D3DXVECTOR3 pos2=gobj2->GetPosition();
	D3DXVECTOR3	v;
	D3DXVec3Subtract(&v,&pos2,&pos1);
	D3DXVec3Normalize(&v,&v);
	D3DXVECTOR3 vel=gobj1->Velocity;
	D3DXVec3Scale(&vel,&vel,0.1f);
	for (short n=0 ; n < 25 ; n++) {
		C3DSprite *spr=GetParticleSprite();
		if (spr != NULL) {
			spr->ScaleX=spr->ScaleY=spr->ScaleZ=CGfx::Random();
			spr->SetPosition(pos1.x+(v.x*gobj1->CollisionRadius),pos1.y+(v.y*gobj1->CollisionRadius),pos1.z+(v.z*gobj1->CollisionRadius));
			spr->Impulse=D3DXVECTOR3((CGfx::Random()*80)-40+vel.x,(CGfx::Random()*80)-40+vel.y,(CGfx::Random()*80)-40+vel.z);
			spr->LifeSpan=CGfx::Random()*10;
		}
	}

	Leave();
}

void
CExperimentalGame::SpawnSpriteSun(const D3DXVECTOR3 p)
{
	Enter("SpawnSpriteSun()");

	Star=(C3DSprite *)SPAWN('3SPR');
	Star->InitSprite(256);
	Star->ScaleX=Star->ScaleY=Star->ScaleZ=15;
	Star->AddTexture("planets\\sun.tga");
	Star->SetPosition(p);
	Star->SetRotationRate(0,0,10);
	Star->bCanTouch=FALSE;
	Star->bTransparency=TRUE;
	Star->bUnlit=TRUE;
	for (short n=0 ; n < MAXFLARESPRITES ; n++) {
		FlareSprite[n]=(C2DSprite *)SPAWN('2SPR');
		char	sname[256];
		sprintf(sname,"flare%d.tga",n%5);
		FlareSprite[n]->InitSprite(sname);
		float s=2-(n/(float)MAXFLARESPRITES);
		FlareSprite[n]->ScaleX=FlareSprite[n]->ScaleY=FlareSprite[n]->ScaleZ=s;
		FlareSprite[n]->SpriteMaterial->D3DMaterial->Diffuse=D3DXCOLOR(1,0.3f,0.1f,1);
		FlareSprite[n]->bCanTouch=FALSE;
		FlareSprite[n]->bTransparency=TRUE;
		FlareSprite[n]->bHidden=TRUE;
		FlareSprite[n]->bUnlit=TRUE;
	}

	Leave();
}

void
CExperimentalGame::TickSpriteSun(float delta)
{
	if (Star != NULL) {
		D3DXVECTOR3 p=Star->GetPosition();
		float dx2=CGfx::DisplayWidth*0.5f;
		float dy2=CGfx::DisplayHeight*0.5f;
		float	sx,sy;
		if (bShowLensFlare && CGfx::WorldToScreen(p,sx,sy,Star->Radius)) {
			float s=1.0f/MAXFLARESPRITES;
			float stepx=((sx-dx2)*1.7f)*s;
			float stepy=((sy-dy2)*1.7f)*s;
			for (short n=0 ; n < MAXFLARESPRITES ; n++) {
				if (FlareSprite[n] != NULL) {
					float x=sx-(stepx*(n+1));
					float y=sy-(stepy*(n+1));
					float dx=fabsf(sx-x);
					FlareSprite[n]->Transparency=0.7f-__min(dx/(CGfx::DisplayWidth*0.5f),0.7f);
					FlareSprite[n]->SetPosition(x,y);
					FlareSprite[n]->bHidden=FALSE;
				}
			}
		}
		else {
			for (short n=0 ; n < MAXFLARESPRITES ; n++) {
				if (FlareSprite[n] != NULL) {
					FlareSprite[n]->bHidden=TRUE;
				}
			}
		}
	}
}

void
CExperimentalGame::RemoveSpriteSun()
{
	if (Star != NULL) {
		Star->DeleteMe();
	}
	for (short n=0 ; n < MAXFLARESPRITES ; n++) {
		if (FlareSprite[n] != NULL) {
			FlareSprite[n]->DeleteMe();
			FlareSprite[n]=NULL;
		}
	}
}

void
CExperimentalGame::NotifyDelete(CGameObject *gobj)
{
	if (gobj->ObjectID == '3PRJ') {
		for (GameObjectList_t::iterator o=gobj->ChildObjectList.begin() ; o != gobj->ChildObjectList.end() ; o++) {
			CGameObject *gobj=(*o);
			if (gobj->ObjectID == '3LIG') {
				gobj->DeleteMe();
			}
		}
		CGameType::NotifyDelete(gobj);
		for (DWORD n=0 ; n < MAXENEMIES ; n++) {
			if (EnemyProj[n] == gobj) {
				EnemyProj[n]=NULL;
				return;
			}
		}
		for (n=0 ; n < MAXPLAYERPROJECTILES ; n++) {
			if (PlayerProj[n] == gobj) {
				PlayerProj[n]=NULL;
				return;
			}
		}
	}
}

void
CExperimentalGame::BringToStop(D3DXVECTOR3 *v,float delta)
{
	if (v->x > 0) {
		v->x-=delta;
		if (v->x < 0) {
			v->x=0;
		}
	}
	else if (v->x < 0) {
		v->x+=delta;
		if (v->x > 0) {
			v->x=0;
		}
	}
	if (v->y > 0) {
		v->y-=delta;
		if (v->y < 0) {
			v->y=0;
		}
	}
	else if (v->y < 0) {
		v->y+=delta;
		if (v->y > 0) {
			v->y=0;
		}
	}
	if (v->z > 0) {
		v->z-=delta;
		if (v->z < 0) {
			v->z=0;
		}
	}
	else if (v->z < 0) {
		v->z+=delta;
		if (v->z > 0) {
			v->z=0;
		}
	}
}

void
CExperimentalGame::WriteHighScore()
{
/*
	FILE *fp=fopen("FUELDEPOT.DAT","wb");
	if (fp != NULL) {
		char	buf[256],len;
		sprintf(buf,"%ld",HighScore);
		len=(char)strlen(buf);
		for (DWORD n=0 ; n < (DWORD)len ; n++) {
			buf[n]^=37;
		}
		len^=37;
		fwrite(&len,sizeof(char),1,fp);
		fwrite(buf,sizeof(char),len^37,fp);
		sprintf(buf,"%ld",HighScore);
		len=(char)strlen(buf);
		for (DWORD o=0 ; o < (DWORD)len ; o++) {
			buf[o]^=5;
		}
		len^=5;
		fwrite(&len,sizeof(char),1,fp);
		fwrite(buf,sizeof(char),len^5,fp);
		fclose(fp);
	}
*/
	FILE *fp=fopen("HIGHSCORE.TXT","wa");
	if (fp != NULL) {
		char	buf[256],out[256],len;
		sprintf(buf,"%ld",HighScore);
		len=(char)strlen(buf);
		for (DWORD n=0,o=2 ; n < (DWORD)len ; n++) {
			buf[n]^=37;
			out[o++]=((buf[n]&0xF0)>>4)+0x40;
			out[o++]=(buf[n]&0x0F)+0x40;
		}
		len^=37;
		out[0]=((len&0xF0)>>4)+0x40;
		out[1]=(len&0x0F)+0x40;
		fwrite(out,sizeof(char),o,fp);
		sprintf(buf,"%ld",HighScore);
		len=(char)strlen(buf);
		for (n=0,o=2 ; n < (DWORD)len ; n++) {
			buf[n]^=5;
			out[o++]=((buf[n]&0xF0)>>4)+0x40;
			out[o++]=(buf[n]&0x0F)+0x40;
		}
		len^=5;
		out[0]=((len&0xF0)>>4)+0x40;
		out[1]=(len&0x0F)+0x40;
		fwrite(out,sizeof(char),o,fp);
		fclose(fp);
	}
}

void
CExperimentalGame::ReadHighScore()
{
/*
	FILE *fp=fopen("FUELDEPOT.DAT","rb");
	if (fp != NULL) {
		char	buf[256],len;
		fread(&len,sizeof(char),1,fp);
		len^=37;
		fread(buf,sizeof(char),len,fp);
		for (DWORD n=0 ; n < (DWORD)len ; n++) {
			buf[n]^=37;
		}
		buf[len]=0;
		HighScore=atoi(buf);
		fread(&len,sizeof(char),1,fp);
		len^=5;
		fread(buf,sizeof(char),len,fp);
		for (DWORD o=0 ; o < (DWORD)len ; o++) {
			buf[o]^=5;
		}
		buf[len]=0;
		if (atoi(buf) != HighScore) {
			HighScore=0;
		}
		fclose(fp);
	}
*/
	FILE *fp=fopen("HIGHSCORE.TXT","ra");
	if (fp != NULL) {
		char	buf[256],out[256],len;
		fread(out,sizeof(char),2,fp);
		len=((out[0]-0x40)<<4)|(out[1]-0x40);
		len^=37;
		fread(out,sizeof(char),len*2,fp);
		for (DWORD n=0,o=0 ; n < (DWORD)len ; n++) {
			buf[n]=(out[o++]-0x40)<<4;
			char c=out[o++]-0x40;
			buf[n]|=c;
			buf[n]^=37;
		}
		buf[len]=0;
		HighScore=atoi(buf);
		fread(out,sizeof(char),2,fp);
		len=((out[0]-0x40)<<4)|(out[1]-0x40);
		len^=5;
		fread(out,sizeof(char),len*2,fp);
		for (n=0,o=0 ; n < (DWORD)len ; n++) {
			buf[n]=(out[o++]-0x40)<<4;
			char c=out[o++]-0x40;
			buf[n]|=c;
			buf[n]^=5;
		}
		buf[len]=0;
		if (atoi(buf) != HighScore) {
			HighScore=0;
		}
		fclose(fp);
	}
}
