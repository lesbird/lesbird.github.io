// MultiObjectGame.cpp: implementation of the CMultiObjectGame class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "MultiObjectGame.h"

C3DSprite							*Sprite=NULL,
									*Star=NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMultiObjectGame::CMultiObjectGame()
{
	SetObjectID('MULT');
	SetObjectName("CMULTIOBJECTGAME");

	CGfx::StatsLevel=3;
}

CMultiObjectGame::~CMultiObjectGame()
{
	Sprite=NULL;
	Star=NULL;
}

void
CMultiObjectGame::Init()
{
//	Multiple objects/high poly test

	CGameType::Init();

	C3DSphere *Sphere=(C3DSphere *)SPAWN('3SPH');
	Sphere->InitSphere(200);
	Sphere->SetPosition(0,0,0);
	Sphere->AddTexture("planets\\jupiter.tga");
	Sphere->AddTexture("nebulas\\nebula17.tga",TEXFLAGS_REFLECTIONMAP);
	Sphere->SetRotationRate(0,10,0);
	Sphere->bFarClip=FALSE;
	Sphere->bNoFog=TRUE;
	Sphere->bUnlit=TRUE;

	C3DSphere *SphereBox=(C3DSphere *)SPAWN('3SPH');
	SphereBox->InitSphere(10000,128,128,1,1);
	SphereBox->SetPosition(0,0,0);
	SphereBox->AddTexture("nebulas\\nebula17.tga");
	SphereBox->bInvertPolys=TRUE;
	SphereBox->bFarClip=FALSE;
	SphereBox->bUnlit=TRUE;

	short columns=10;
	short rows=10;
	short levels=10;
	for (short i=-columns/2 ; i < columns/2 ; i++) {
		float x=i*300.0f;
		for (short j=-rows/2 ; j < rows/2 ; j++) {
			float z=j*300.0f;
			for (short k=-levels/2 ; k < levels/2 ; k++) {
				float y=k*300.0f;
				if (i == 0 && j == 0 && k == 0) {
					continue;
				}
				C3DCube *Cube=(C3DCube *)SPAWN('3CUB');
				Cube->InitCube(100);
				CGameObject *gobj=(CGameObject *)Cube;
				gobj->SetPosition(x,y,z);
				Cube->SetRotationRate(CGfx::Random()*100,0,CGfx::Random()*100);
				Cube->AddTexture("wall.tga");
				Cube->bCanTouch=FALSE;
				Cube->bUnlit=TRUE;
			}
		}
	}

	Star=(C3DSprite *)SPAWN('3SPR');
	Star->InitSprite(750);
	Star->AddTexture("shine0.tga");
	Star->SetPosition(2000,0,0);
	Star->SetRotationRate(0,0,10);
	Star->bCanTouch=FALSE;
	Star->bFarClip=FALSE;
	Star->bNoFog=TRUE;
	Star->bTransparency=TRUE;
	Star->bUnlit=TRUE;

	Sprite=(C3DSprite *)SPAWN('3SPR');
	Sprite->InitSprite(500);
	Sprite->AddTexture("shine1.tga");
	Sprite->SetPosition(2000,0,0);
	Sprite->SetRotationRate(0,0,25);
	Sprite->bCanTouch=FALSE;
	Sprite->bTransparency=TRUE;
	Sprite->bUnlit=TRUE;

	Sprite=(C3DSprite *)SPAWN('3SPR');
	Sprite->InitSprite(250);
	Sprite->AddTexture("shine2.tga");
	Sprite->SetPosition(2000,0,0);
	Sprite->SetRotationRate(0,0,50);
	Sprite->bCanTouch=FALSE;
	Sprite->bTransparency=TRUE;
	Sprite->bUnlit=TRUE;

	Sprite=(C3DSprite *)SPAWN('3SPR');
	Sprite->InitSprite(750);
	Sprite->AddTexture("flare4.tga");
	Sprite->SetPosition(2000,0,0);
	Sprite->SetRotationRate(0,0,0);
	Sprite->bCanTouch=FALSE;
	Sprite->bTransparency=TRUE;
	Sprite->bUnlit=TRUE;

	CGfx::ViewFollowObject=NULL;

	CGfx::LookAt(0,0,0);

	InitGame();
}

C2DSprite	*FlareSprite[5]={NULL,NULL,NULL,NULL,NULL};

void
CMultiObjectGame::Tick(float delta)
{
	static BOOL bFlares=FALSE;

	CGfx::PrintText(-1,0,D3DXCOLOR(1,1,1,1),"%ld POLYGONS",CGfx::NumPolys);

	CGameType::Tick(delta);

	if (PeekKey(KEY_CTRL) && GetKey(KEY_A)) {
		bFlares=(bFlares ? FALSE : TRUE);
	}

	float	x,y;
	if (bFlares && Star != NULL && CGfx::WorldToScreen(Star->Position,x,y,0)) {
		float stepx=(((x-(CGfx::DisplayWidth*0.5f))*2)/4);
		float stepy=(((y-(CGfx::DisplayHeight*0.5f))*2)/4);
		for (short n=0 ; n < 4 ; n++) {
			if (FlareSprite[n] == NULL) {
				FlareSprite[n]=(C2DSprite *)SPAWN('2SPR');
				char	fname[20];
				sprintf(fname,"flare%d.tga",n+1);
				FlareSprite[n]->InitSprite(fname);
				FlareSprite[n]->bTransparency=TRUE;
				FlareSprite[n]->bUnlit=TRUE;
			}
			if (FlareSprite[n] != NULL) {
				float nx=x-(stepx*(n+1));
				float ny=y-(stepy*(n+1));
				FlareSprite[n]->SetPosition(nx,ny);
				FlareSprite[n]->bHidden=FALSE;
			}
		}
	}
	else {
		for (short n=0 ; n < 4 ; n++) {
			if (FlareSprite[n] != NULL) {
				FlareSprite[n]->bHidden=TRUE;
			}
		}
	}

	if (!bPause) {
		if (Sprite != NULL) {
			Sprite->ScaleX=Sprite->ScaleY=Sprite->ScaleZ=0.75f+(sinf(GameTime)*0.25f);
		}
		CGfx::SetViewPosition(-3000*sinf(GameTime*0.1f),2000*cosf(GameTime*0.05f),-500*cosf(GameTime*0.1f));
		CGfx::LookAt(0,0,0);
	}
}
