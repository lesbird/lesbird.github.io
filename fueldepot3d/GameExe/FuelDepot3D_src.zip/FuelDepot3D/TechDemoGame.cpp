// TechDemoGame.cpp: implementation of the CTechDemoGame class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "TechDemoGame.h"

static
C3DCube								*cube=NULL;

static
C3DObject							*model=NULL;

static
C3DParticleEmitter					*pemitter=NULL;

static
C3DPolygon							*poly=NULL;

static
C3DSphere							*sphere=NULL;

static
C3DLight							*light=NULL,
									*light2=NULL,
									*light3=NULL,
									*light4=NULL;

static
C3DSprite							*sprite=NULL;

static
C2DSprite							*flare[5]={NULL,NULL,NULL,NULL,NULL};

static
D3DXVECTOR3							SunPosDefault(0,0,-300);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTechDemoGame::CTechDemoGame()
{
	SetObjectID('TECH');
	SetObjectName("CTECHDEMOGAME");

	C3DParticleEmitter::InitSpriteCache();
}

CTechDemoGame::~CTechDemoGame()
{
	C3DParticleEmitter::UnInitSpriteCache();
}

void
CTechDemoGame::Init()
{
	CGameType::Init();

	InitGame();

	CGfx::SetViewPosition(0,0,0);
	D3DXQuaternionIdentity(&CGfx::ViewRotation);
}

void
CTechDemoGame::Tick(float delta)
{
	CGameType::Tick(delta);

	switch (GameState) {
	case 'INIT':
		switch (GameSubState) {
		case 'INIT':
			if (light == NULL) {
				light=(C3DLight *)SPAWN('3LIG');
			}
			CGfx::MoveTo(0,0,-200);
			CGfx::LookAt(0,0,0);
			CGfx::StatsLevel=3;
			GameState='POLY';
			break;
		}
		break;
	case 'POLY':
		switch (GameSubState) {
		case 'INIT':
			if (sphere != NULL) {
				sphere->DeleteMe();
				sphere=NULL;
			}
			poly=(C3DPolygon *)SPAWN('3POL');
			poly->InitPolygon(50,50);
			poly->AddTexture("bumpmap.bmp");
			poly->bCanTouch=FALSE;
			GameSubState='1';
			break;
		case '1':
			CGfx::PrintText(-1,150,D3DXCOLOR(1,1,1,1),"TEXTURED POLY");
			if (GetKey(KEY_ENTER)) {
				poly->AddTexture("skybox_top.tga",TEXFLAGS_REFLECTIONMAP);
				GameSubState='2';
			}
			break;
		case '2':
			CGfx::PrintText(-1,150,D3DXCOLOR(1,1,1,1),"REFLECTION MAP");
			if (GetKey(KEY_ENTER)) {
//				GameState='CUBE';
//				GameSubState='INIT';
				GameState='SPHE';
				GameSubState='INIT';
			}
			break;
		}
		if (poly != NULL) {
			poly->SetRotation(0,180+sinf(GameTime)*45,0);
		}
		break;
/*
	case 'CUBE':
		switch (GameSubState) {
		case 'INIT':
			if (poly != NULL) {
				poly->DeleteMe();
				poly=NULL;
			}
			cube=(C3DCube *)SPAWN('3CUB');
			cube->InitCube(50,50,50,1,1);
			cube->AddTexture("wall.tga");
			cube->SetRotationRate(0,45,0);
			cube->bCanTouch=FALSE;
			GameSubState='2';
			break;
		case '2':
			CGfx::PrintText(-1,150,D3DXCOLOR(1,1,1,1),"TEXTURED CUBE");
			if (GetKey(KEY_ENTER)) {
				C3DParticleEmitter *pemitter=(C3DParticleEmitter *)SPAWN('3PAR');
				pemitter->Link(cube);
				pemitter->SetPosition(0,cube->Radius*0.5f,0);
				pemitter->SetRotation(270,0,0);
				pemitter->AddParticle("particle.tga");

				pemitter=(C3DParticleEmitter *)SPAWN('3PAR');
				pemitter->Link(cube);
				pemitter->SetPosition(0,0,cube->Radius*0.5f);
				pemitter->AddParticle("particle.tga",2,15,100);
				GameSubState='3';
			}
			break;
		case '3':
			CGfx::PrintText(-1,150,D3DXCOLOR(1,1,1,1),"PARTICLE SYSTEM");
			if (GetKey(KEY_ENTER)) {
				GameState='SPHE';
				GameSubState='INIT';
			}
			break;
		}
		break;
*/
	case 'SPHE':
		switch (GameSubState) {
		case 'INIT':
			if (poly != NULL) {
				poly->DeleteMe();
				poly=NULL;
			}
/*
			if (cube != NULL) {
				cube->DeleteMe();
				cube=NULL;
			}
*/
			sphere=(C3DSphere *)SPAWN('3SPH');
			sphere->InitSphere(50,175,175,1,1);
			sphere->AddTexture("planets\\jupiter.tga");
			sphere->SetRotationRate(0,45,0);
			sphere->bCanTouch=FALSE;
			sphere->bUnlit=TRUE;
			GameSubState='2';
			break;
		case '2':
			CGfx::PrintText(-1,90,D3DXCOLOR(1,1,1,1),"%ld POLY TEXTURED SPHERE",sphere->D3DXMesh->GetNumFaces());
			if (GetKey(KEY_ENTER)) {
				GameState='3MOD';
				GameSubState='INIT';
			}
			break;
		}
		break;
	case '3MOD':
		switch (GameSubState) {
		case 'INIT':
			if (sphere != NULL) {
				sphere->DeleteMe();
				sphere=NULL;
			}
			sphere=(C3DSphere *)SPAWN('3SPH');
			sphere->InitSphere(400);
			sphere->AddTexture("nebulas/nebula05.tga");
			sphere->SetRotationRate(1,1,0);
			sphere->bCanTouch=FALSE;
			sphere->bInvertPolys=TRUE;
			sphere->bUnlit=TRUE;
			SpawnSpriteSun(SunPosDefault);
			model=(C3DObject *)SPAWN('3OBJ');
			model->LoadMesh("bigship1.x");
			model->AddTexture("nebulas/nebula05.tga",TEXFLAGS_REFLECTIONMAP);
			model->SetRotationRate(0,45,10);
			model->bCanTouch=FALSE;
			model->bUnlit=TRUE;
			CGfx::MoveTo(0,0,-28);
			GameSubState='1';
			break;
		case '1':
			CGfx::PrintText(-1,90,D3DXCOLOR(1,1,1,1),"%ld POLY MESH",model->D3DXMesh->GetNumFaces());
			TickSpriteSun(delta);
			if (GetKey(KEY_ENTER)) {
				light2=(C3DLight *)SPAWN('3LIG');
				light2->Link(model);
				light2->D3DLight.Diffuse=D3DXCOLOR(1,0,0,0);
				light2->bShowPosition=TRUE;
				light3=(C3DLight *)SPAWN('3LIG');
				light3->Link(model);
				light3->D3DLight.Diffuse=D3DXCOLOR(0,1,0,0);
				light3->bShowPosition=TRUE;
				light4=(C3DLight *)SPAWN('3LIG');
				light4->Link(model);
				light4->D3DLight.Diffuse=D3DXCOLOR(0,0,1,0);
				light4->bShowPosition=TRUE;
				model->bUnlit=FALSE;
				CGfx::MoveTo(0,0,-40);
				GameSubState='2';
			}
			break;
		case '2':
			CGfx::PrintText(-1,90,D3DXCOLOR(1,1,1,1),"%ld POLY MESH 4 LIGHTS",model->D3DXMesh->GetNumFaces());
			TickSpriteSun(delta);
			if (light2 != NULL) {
				light2->SetPosition(sinf(GameTime)*15,0,cosf(GameTime)*15);
			}
			if (light3 != NULL) {
				light3->SetPosition(-(sinf(GameTime)*15),0,cosf(GameTime)*15);
			}
			if (light4 != NULL) {
				light4->SetPosition(sinf(GameTime)*15,cosf(GameTime)*15,0);
			}
			if (GetKey(KEY_ENTER)) {
				GameSubState='3';
			}
			break;
		case '3':
			CGfx::PrintText(-1,90,D3DXCOLOR(1,1,1,1),"%ld POLY MESH TRANSLUCENT 4 LIGHTS",model->D3DXMesh->GetNumFaces());
			if (light2 != NULL) {
				light2->SetPosition(sinf(GameTime)*15,0,cosf(GameTime)*15);
			}
			if (light3 != NULL) {
				light3->SetPosition(-(sinf(GameTime)*15),0,cosf(GameTime)*15);
			}
			if (light4 != NULL) {
				light4->SetPosition(sinf(GameTime)*15,cosf(GameTime)*15,0);
			}
			model->Transparency=fabsf(sinf(GameTime));
			TickSpriteSun(delta);
			if (GetKey(KEY_ENTER)) {
				if (model != NULL) {
					light2->DeleteMe();
					light2=NULL;
					light3->DeleteMe();
					light3=NULL;
					light4->DeleteMe();
					light4=NULL;
					RemoveSpriteSun();
					sphere->DeleteMe();
					sphere=NULL;
					model->DeleteMe();
					model=NULL;
					GameState='INIT';
					GameSubState='INIT';
				}
			}
			break;
		}
		break;
	}

	if (light != NULL) {
		light->SetPosition(CGfx::ViewPosition);
	}
	if (GetKey(KEY_PGDN)) {
		switch (GameState) {
		case 'POLY':
			GameState='CUBE';
			break;
		case 'CUBE':
			GameState='SPHE';
			break;
		case 'SPHE':
			GameState='POLY';
			break;
		}
		GameSubState='INIT';
	}
}

void
CTechDemoGame::SpawnSpriteSun(const D3DXVECTOR3 p)
{
	sprite=(C3DSprite *)SPAWN('3SPR');
	sprite->InitSprite(256);
	sprite->AddTexture("env0.tga");
	sprite->SetPosition(p);
	sprite->bTransparency=TRUE;
	sprite->bUnlit=TRUE;
	for (short n=0 ; n < 5 ; n++) {
		flare[n]=(C2DSprite *)SPAWN('2SPR');
		char	sname[16];
		sprintf(sname,"flare%d.tga",n);
		flare[n]->InitSprite(sname);
		flare[n]->ScaleX=flare[n]->ScaleY=flare[n]->ScaleZ=2.0f-(n/3.0f);
		flare[n]->bTransparency=TRUE;
		flare[n]->bHidden=TRUE;
		flare[n]->bUnlit=TRUE;
	}
}

void
CTechDemoGame::TickSpriteSun(float delta)
{
	if (sphere != NULL) {
		D3DXVECTOR3 p=sphere->TransformPoint(SunPosDefault);
		sprite->SetPosition(p);
		float dx2=CGfx::DisplayWidth*0.5f;
		float dy2=CGfx::DisplayHeight*0.5f;
		float	sx,sy;
		if (CGfx::WorldToScreen(p,sx,sy,sprite->Radius)) {
			float s=1.0f/5;
			float stepx=((sx-dx2)*2)*s;
			float stepy=((sy-dy2)*2)*s;
			float hw=(float)CGfx::DisplayWidth+(float)CGfx::DisplayHeight;
			for (short n=0 ; n < 5 ; n++) {
				float x=sx-(stepx*(n+1));
				float y=sy-(stepy*(n+1));
				float t=fabsf((x+y)/hw);
				flare[n]->Transparency=t;
				flare[n]->SetPosition(x,y);
				flare[n]->bHidden=FALSE;
			}
		}
		else {
			for (short n=0 ; n < 5 ; n++) {
				flare[n]->bHidden=TRUE;
			}
		}
	}
}

void
CTechDemoGame::RemoveSpriteSun()
{
	sprite->DeleteMe();
	for (short n=0 ; n < 3 ; n++) {
		flare[n]->DeleteMe();
		flare[n]=NULL;
	}
}
