// TechDemoGame.h: interface for the CTechDemoGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TECHDEMOGAME_H__DB91B091_609E_473F_89AF_B4D77C326DAC__INCLUDED_)
#define AFX_TECHDEMOGAME_H__DB91B091_609E_473F_89AF_B4D77C326DAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameType.h"

class CTechDemoGame : public CGameType  
{
public:
	CTechDemoGame();
	virtual ~CTechDemoGame();

	virtual void					Init();
	virtual void					Tick(float delta);
	virtual void					SpawnSpriteSun(const D3DXVECTOR3 p);
	virtual void					TickSpriteSun(float delta);
	virtual void					RemoveSpriteSun();
};

#endif // !defined(AFX_TECHDEMOGAME_H__DB91B091_609E_473F_89AF_B4D77C326DAC__INCLUDED_)
