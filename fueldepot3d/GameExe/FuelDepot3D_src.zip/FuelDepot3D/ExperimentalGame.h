// ExperimentalGame.h: interface for the CExperimentalGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPERIMENTALGAME_H__4008730D_462E_49EC_95D5_8C2F637CA384__INCLUDED_)
#define AFX_EXPERIMENTALGAME_H__4008730D_462E_49EC_95D5_8C2F637CA384__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameType.h"

class CExperimentalGame : public CGameType  
{
public:
	CExperimentalGame();
	virtual ~CExperimentalGame();

	virtual void					Init();
	virtual void					RestartGame();
	virtual void					RecordDemo();
	virtual void					PlaybackDemo();
	virtual void					PickNebula();
	virtual void					PickNewNebula();

	virtual void					Tick(float delta);
	virtual void					TickEnemyAI(float delta);
	virtual void					MissileAI(float delta);

	virtual C3DObject				*SpawnProjectile(D3DXVECTOR3 p,D3DXVECTOR3 v);
	virtual C3DObject				*SpawnEnemy(DWORD enemy);
	virtual C3DObject				*SpawnPlayer();
	virtual C3DPermanentSprite		*GetParticleSprite();

	virtual void					PostObjectCollision(CGameObject *gobj1,CGameObject *gobj2);
	virtual void					DestroyEnemy(CGameObject *gobj1,CGameObject *gobj2);
	virtual void					DestroyPlayer(CGameObject *gobj1,CGameObject *gobj2);
	virtual void					SpawnExplosion(CGameObject *gobj1,CGameObject *gobj2);
	virtual void					FollowInstigator();

	virtual void					SpawnSpriteSun(const D3DXVECTOR3 p);
	virtual void					TickSpriteSun(float delta);
	virtual void					RemoveSpriteSun();

	virtual void					NotifyDelete(CGameObject *gobj);

//	virtual void					PlayAudioSegment(CMusicSegment *seg,CGameObject *gobj,DWORD chan,BOOL bLoop=FALSE);

	virtual void					BringToStop(D3DXVECTOR3 *v,float delta);

	virtual void					WriteHighScore();
	virtual void					ReadHighScore();
};

#endif // !defined(AFX_EXPERIMENTALGAME_H__4008730D_462E_49EC_95D5_8C2F637CA384__INCLUDED_)
