// HighPolyGame.cpp: implementation of the CHighPolyGame class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "HighPolyGame.h"

static
C3DLight							*RedLight=NULL,
									*GreenLight=NULL,
									*BlueLight=NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHighPolyGame::CHighPolyGame()
{
	SetObjectID('HIGH');
	SetObjectName("CHIGHPOLYGAME");

	CGfx::StatsLevel=3;
}

CHighPolyGame::~CHighPolyGame()
{
	RedLight=NULL;
	GreenLight=NULL;
	BlueLight=NULL;
}

void
CHighPolyGame::Init()
{
	CGameType::Init();

	CGfx::bMoveTo=FALSE;

	for (short i=-3 ; i < 3 ; i++) {
		float x=(i*200.0f)+100;
		for (short j=-2 ; j < 2 ; j++) {
			float y=(j*200.0f)+100;
			C3DSphere *Sphere=(C3DSphere *)SPAWN('3SPH');
			Sphere->InitSphere(100,100,100,1,1);
			Sphere->SetPosition(x,y,0);
			Sphere->AddTexture("wall.tga");
			Sphere->SetRotationRate(0,36,0);
			Sphere->AmbientLighting=D3DXCOLOR(0.1f,0.1f,0.1f,0);
		}
	}

/*
	C3DSphere *sphere=(C3DSphere *)SPAWN('3SPH');
	sphere->bOptimizeMesh=FALSE;
	sphere->InitSphere(300);
	sphere->AddTexture("tex2.tga");
	sphere->SetRotationRate(0,36,0);
	sphere->bUnlit=TRUE;
*/
/*
	C3DCube *cube=(C3DCube *)SPAWN('3CUB');
	cube->InitCube(100);
	cube->SphereMapTexture();
	cube->AddTexture("wall.tga");
	cube->SetRotationRate(0,36,0);
*/
/*
	C3DCube *cube=(C3DCube *)SPAWN('3CUB');
	cube->InitCube(250);
	cube->AddEnvMapTexture();
	cube->SetRotationRate(0,36,0);
	cube->bCanTouch=FALSE;
	cube->bUnlit=TRUE;

	cube=(C3DCube *)SPAWN('3CUB');
	cube->InitCube(250);
	cube->AddTexture("wall.tga");
	cube->SetPosition(250,0,-1000);
	cube->bCanTouch=FALSE;
	cube->bUnlit=TRUE;

	cube=(C3DCube *)SPAWN('3CUB');
	cube->InitCube(250);
	cube->AddTexture("wall.tga");
	cube->SetPosition(-250,0,-1000);
	cube->bCanTouch=FALSE;
	cube->bUnlit=TRUE;

	C3DSphere *sphere=(C3DSphere *)SPAWN('3SPH');
	sphere->InitSphere(5000,64,64,1,1);
	sphere->AddTexture("nebulas/nebula1.tga");
	sphere->bInvertPolys=TRUE;
	sphere->bUnlit=TRUE;
*/
	CGfx::SetViewPosition(0,0,-1200);
	CGfx::SetViewRotation(0,0,0);

	RedLight=(C3DLight *)SPAWN('3LIG');
	RedLight->SetPosition(0,0,-250);
	RedLight->D3DLight.Diffuse=D3DXCOLOR(1,0,0,0);
	RedLight->D3DLight.Specular=D3DXCOLOR(0.2f,0,0,0);

	GreenLight=(C3DLight *)SPAWN('3LIG');
	GreenLight->SetPosition(0,0,-500);
	GreenLight->D3DLight.Diffuse=D3DXCOLOR(0,1,0,0);
	GreenLight->D3DLight.Specular=D3DXCOLOR(0,0.2f,0,0);

	BlueLight=(C3DLight *)SPAWN('3LIG');
	BlueLight->SetPosition( 500,0,-250);
	BlueLight->D3DLight.Diffuse=D3DXCOLOR(0,0,1,0);
	BlueLight->D3DLight.Specular=D3DXCOLOR(0,0,0.2f,0);

	InitGame();
}

void
CHighPolyGame::Tick(float delta)
{
	CGfx::PrintText(-1,0,D3DXCOLOR(1,1,1,1),"%ld POLYGONS",CGfx::NumPolys);

	CGameType::Tick(delta);

	if (!bPause) {
		if (RedLight != NULL) {
			RedLight->SetPosition(sinf(GameTime)*500,0,cosf(GameTime)*500);
		}
		if (BlueLight != NULL) {
			BlueLight->SetPosition(cosf(GameTime)*500,0,sinf(GameTime)*500);
		}
	}
}
