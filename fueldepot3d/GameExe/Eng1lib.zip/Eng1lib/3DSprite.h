// 3DSprite.h: interface for the C3DSprite class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DSPRITE_H__DA88937D_EABD_4BA6_AACA_D1F7B06D36D3__INCLUDED_)
#define AFX_3DSPRITE_H__DA88937D_EABD_4BA6_AACA_D1F7B06D36D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DPolygon.h"

class C3DSprite : public C3DPolygon  
{
public:
	C3DSprite();
	virtual ~C3DSprite();

	virtual void					InitSprite(FLOAT size);
	virtual void					Tick(FLOAT delta);

	virtual void					Transform();
};

#endif // !defined(AFX_3DSPRITE_H__DA88937D_EABD_4BA6_AACA_D1F7B06D36D3__INCLUDED_)
