// Gfx.cpp: implementation of the CGfx class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "Input.h"
#include "Physics.h"

#include "d3dfont.h"

#include <stdio.h>
#include <io.h>

DWORD								CGfx::DisplayWidth=800;
DWORD								CGfx::DisplayHeight=600;

DWORD								CGfx::NumPolys=0;
DWORD								CGfx::NumVerts=0;

DWORD								CGfx::RenderPass=0;

DWORD								CGfx::StatsLevel=0;

LPDIRECT3D8							CGfx::lpD3D8=NULL;
LPDIRECT3DDEVICE8					CGfx::lpD3DDevice8=NULL;

D3DVIEWPORT8						CGfx::D3DViewPort;

CD3DFont							*CGfx::lpD3DXFont=NULL;

D3DFORMAT							CGfx::BackBufferFormat;

D3DXVECTOR3							CGfx::LookAtPoint(0,0,0);
D3DXVECTOR3							CGfx::ViewDirVec(0,0,0);
D3DXVECTOR3							CGfx::ViewPosition(0,0,0);
D3DXQUATERNION						CGfx::ViewRotation;

D3DXMATRIX							CGfx::IdentityMatrix;
D3DXMATRIX							CGfx::OrthoMatrix;
D3DXMATRIX							CGfx::ProjectionMatrix;
D3DXMATRIX							CGfx::ViewMatrix;

D3DCOLOR							CGfx::ClearColor=D3DCOLOR_ARGB(0,0,0,0);

PeakStats_t							CGfx::Peak;

PrintTextLines_t					CGfx::PrintTextLines;
PrintTextBuf_t						CGfx::PrintTextLine[256];
LONG								CGfx::PrintTextLineCount=0;
D3DXCOLOR							CGfx::PrintTextColor(255,255,255,255);

LONG								PrintTextNum=0;
LONG								PrintTextX,PrintTextY;

D3DFORMAT							D3DBumpMapFmt;
D3DCAPS8							D3DCaps;
D3DPRESENT_PARAMETERS				D3DParams;
D3DMULTISAMPLE_TYPE					MultiSampleType;

ULONG								FrameNum=0;
FLOAT								FPS=0,
									FpsAvg=0,
									FpsSum=0,
									PolysSec=0;

LARGE_INTEGER						Freq;
LARGE_INTEGER						LastTick;

BOOL								CGfx::bLookAt=FALSE;
BOOL								CGfx::bMoveTo=FALSE;
BOOL								CGfx::bSingleStep=FALSE;
BOOL								CGfx::bSingleTick=FALSE;
BOOL								CGfx::bResetDelta=TRUE;

BOOL								bAlphaMode=FALSE;
BOOL								bAntiAlias=TRUE;
BOOL								bCanBump=FALSE;
BOOL								bClearDisplay=TRUE;
BOOL								bEnvironmentMap[8]={FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE};
BOOL								bFade=FALSE;
BOOL								bLightMode=TRUE;
BOOL								bOrthoMode=TRUE;
BOOL								bReflectionMap[8]={FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE};
BOOL								bWireFrame=FALSE;
BOOL								bZBufferWrite=TRUE;
BOOL								bZCompareNormal=TRUE;
BOOL								bZComparePass=FALSE;

DWORD								CullMode=0;

BOOL								CGfx::bFogMode=FALSE;

FLOAT								CGfx::NearClip=1,
									CGfx::FarClip=10000;
FLOAT								CGfx::AspectRatio=0,
									CGfx::FieldOfView=D3DX_PI/4;
DWORD								CGfx::FogColor=D3DCOLOR_ARGB(0,0,0,0);
FLOAT								CGfx::FogEnd,
									CGfx::FogStart;
FLOAT								CGfx::GlobalTime;

C2DSprite							*AweLogo=NULL;
extern
INT									LogoRes;

D3DXVECTOR3							CGfx::ViewFollowOrientation;
D3DXVECTOR3							CGfx::ViewFollowPosition;
CGameObject							*CGfx::ViewFollowObject=NULL;
FLOAT								CGfx::ViewFollowDist=100;
FLOAT								CGfx::ViewFollowSpeedFactor=1;

EnvMapTextureList_t					CGfx::EnvMapTextureList;

BOOL								bPlayback=FALSE;
BOOL								bRecordDemo=FALSE;
BOOL								bSaveDemo=FALSE;

DWORD								InputBufferCount=0,
									PlaybackBufferCount=0;

DWORD								InputBufferRandomSeed;

InputBuffer_t						InputBuffer[MAXINPUTCOUNT];

typedef struct FadeTo_tag
{
	WORD							red;
	WORD							green;
	WORD							blue;
} FadeTo_t;

FadeTo_t							FadeToColor;

extern
BOOL								bAppAlive;

extern
HWND								hWnd;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGfx::CGfx()
{

}

CGfx::~CGfx()
{

}

void
CGfx::Init()
{
	Enter("CGfx::Init()");

	QueryPerformanceFrequency(&Freq);
	QueryPerformanceCounter(&LastTick);

	D3DXMatrixIdentity(&IdentityMatrix);

	Log("Direct3DCreate8()");

	if ((lpD3D8=Direct3DCreate8(D3D_SDK_VERSION)) != NULL) {
		ZeroMemory(&D3DCaps,sizeof(D3DCaps));
		lpD3D8->GetDeviceCaps(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,&D3DCaps);
		ZeroMemory(&D3DParams,sizeof(D3DParams));
		MultiSampleType=D3DMULTISAMPLE_NONE;
		if (bAntiAlias) {
			if (SUCCEEDED(lpD3D8->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,D3DFMT_A8R8G8B8,FALSE,D3DMULTISAMPLE_4_SAMPLES))) {
				MultiSampleType=D3DMULTISAMPLE_4_SAMPLES;
			}
			else if (SUCCEEDED(lpD3D8->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,D3DFMT_A8R8G8B8,FALSE,D3DMULTISAMPLE_3_SAMPLES))) {
				MultiSampleType=D3DMULTISAMPLE_3_SAMPLES;
			}
			else if (SUCCEEDED(lpD3D8->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,D3DFMT_A8R8G8B8,FALSE,D3DMULTISAMPLE_2_SAMPLES))) {
				MultiSampleType=D3DMULTISAMPLE_2_SAMPLES;
			}
		}

		Log("MultiSampleType=%X",MultiSampleType);

		D3DParams.MultiSampleType=MultiSampleType;
#ifdef _FULLSCREEN_MODE_
/*
		D3DFORMAT	bbfmt;
		if (lpD3D8->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,D3DFMT_A8R8G8B8,0,D3DRTYPE_SURFACE,D3DFMT_A8R8G8B8) == D3D_OK) {
			bbfmt=D3DFMT_A8R8G8B8;
		}
		else if (lpD3D8->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,D3DFMT_R5G6B5,0,D3DRTYPE_SURFACE,D3DFMT_R5G6B5) == D3D_OK) {
			bbfmt=D3DFMT_R5G6B5;
		}
		else if (lpD3D8->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,D3DFMT_X1R5G5B5,0,D3DRTYPE_SURFACE,D3DFMT_X1R5G5B5) == D3D_OK) {
			bbfmt=D3DFMT_X1R5G5B5;
		}
		else {
			MessageBox(hWnd,"Direct3D format not supported by your video card","D3D FORMAT ERROR",MB_OK);
			SAFE_RELEASE(lpD3D8);
			Leave();
			return;
		}
*/
		D3DFORMAT bbfmt=D3DFMT_A8R8G8B8;
		D3DParams.BackBufferWidth=DisplayWidth;
		D3DParams.BackBufferHeight=DisplayHeight;
		D3DParams.BackBufferFormat=bbfmt;
		D3DParams.BackBufferCount=2;
		D3DParams.hDeviceWindow=hWnd;
		D3DParams.Windowed=FALSE;
		D3DParams.FullScreen_PresentationInterval=D3DPRESENT_INTERVAL_ONE;
//		D3DParams.FullScreen_PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE;
		D3DParams.SwapEffect=(D3DParams.MultiSampleType == D3DMULTISAMPLE_NONE) ? D3DSWAPEFFECT_FLIP : D3DSWAPEFFECT_DISCARD;
#else
		D3DDISPLAYMODE	D3DDisplayMode;
		if ((lpD3D8->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&D3DDisplayMode)) == D3D_OK) {
			D3DParams.BackBufferFormat=D3DDisplayMode.Format;
		}
		D3DParams.Windowed=TRUE;
		D3DParams.SwapEffect=D3DSWAPEFFECT_DISCARD;
#endif
		D3DParams.EnableAutoDepthStencil=TRUE;
		D3DParams.AutoDepthStencilFormat=D3DFMT_D24X8;
		D3DParams.Flags=0;

		BackBufferFormat=D3DParams.BackBufferFormat;
/*
		if (D3DCaps.TextureOpCaps&(D3DTEXOPCAPS_BUMPENVMAP|D3DTEXOPCAPS_BUMPENVMAPLUMINANCE)) {
			bCanBump=TRUE;
			if (SUCCEEDED(lpD3D8->CheckDeviceFormat(D3DCaps.AdapterOrdinal,D3DCaps.DeviceType,D3DParams.BackBufferFormat,0,
													D3DRTYPE_TEXTURE,D3DFMT_V8U8)) &&
													D3DCaps.TextureOpCaps&D3DTEXOPCAPS_BUMPENVMAP)
			{
				D3DBumpMapFmt=D3DFMT_V8U8;
			}
			if (SUCCEEDED(lpD3D8->CheckDeviceFormat(D3DCaps.AdapterOrdinal,D3DCaps.DeviceType,D3DParams.BackBufferFormat,0,
													D3DRTYPE_TEXTURE,D3DFMT_L6V5U5)) &&
													D3DCaps.TextureOpCaps&D3DTEXOPCAPS_BUMPENVMAPLUMINANCE)
			{
				D3DBumpMapFmt=D3DFMT_L6V5U5;
			}
			if (SUCCEEDED(lpD3D8->CheckDeviceFormat(D3DCaps.AdapterOrdinal,D3DCaps.DeviceType,D3DParams.BackBufferFormat,0,
													D3DRTYPE_TEXTURE,D3DFMT_X8L8V8U8)) &&
													D3DCaps.TextureOpCaps&D3DTEXOPCAPS_BUMPENVMAPLUMINANCE)
			{
				D3DBumpMapFmt=D3DFMT_X8L8V8U8;
			}
		}
*/
#ifdef SOFTWARE_MODE
		Log("CreateDevice(): D3DDEVTYPE_REF,D3DCREATE_SOFTWARE_VERTEXPROCESSING");
		if (lpD3D8->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_REF,hWnd,D3DCREATE_SOFTWARE_VERTEXPROCESSING,&D3DParams,&lpD3DDevice8) == D3D_OK) {
#else
		DWORD	vertexmode;
		if (D3DCaps.DevCaps&D3DDEVCAPS_HWTRANSFORMANDLIGHT) {
			vertexmode=D3DCREATE_HARDWARE_VERTEXPROCESSING;
		}
		else {
			vertexmode=D3DCREATE_SOFTWARE_VERTEXPROCESSING;
		}
		Log("CreateDevice(): %s",(vertexmode == D3DCREATE_HARDWARE_VERTEXPROCESSING) ? "D3DCREATE_HARDWARE_VERTEXPROCESSING" :
																						"D3DCREATE_SOFTWARE_VERTEXPROCESSING");
		if (lpD3D8->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,hWnd,vertexmode,&D3DParams,&lpD3DDevice8) == D3D_OK) {
#endif
			Enter("CreateDevice()");

			ZeroMemory(&D3DViewPort,sizeof(D3DViewPort));
			D3DViewPort.X=0;
			D3DViewPort.Y=0;
			D3DViewPort.Width=DisplayWidth;
			D3DViewPort.Height=DisplayHeight;
			D3DViewPort.MinZ=0;
			D3DViewPort.MaxZ=1;
			lpD3DDevice8->SetViewport(&D3DViewPort);
			lpD3DDevice8->SetRenderState(D3DRS_AMBIENT,D3DXCOLOR(255,255,255,255));
			lpD3DDevice8->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_LINEAR);
			lpD3DDevice8->SetRenderState(D3DRS_MULTISAMPLEANTIALIAS,D3DParams.MultiSampleType == D3DMULTISAMPLE_NONE ? FALSE : TRUE);
			lpD3DDevice8->SetRenderState(D3DRS_SHADEMODE,D3DSHADE_GOURAUD);
			lpD3DDevice8->SetRenderState(D3DRS_SPECULARENABLE,TRUE);
			SetLightMode(bLightMode);
			SetAlphaMode(bAlphaMode);
			SetCullMode(CullMode);
			for (short n=0 ; n < 8 ; n++) {
				SetEnvironmentMapMode(n,bEnvironmentMap[n]);
				SetReflectionMapMode(n,bReflectionMap[n]);
				lpD3DDevice8->SetTextureStageState(n,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
				lpD3DDevice8->SetTextureStageState(n,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
				lpD3DDevice8->SetTextureStageState(n,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
			}

			Enter("CreateFont()");

			lpD3DXFont=new CD3DFont(_T(FontName),FontSize,D3DFONT_BOLD);
			lpD3DXFont->InitDeviceObjects(lpD3DDevice8);
			lpD3DXFont->RestoreDeviceObjects();

			Leave();

			AspectRatio=FLOAT(DisplayWidth)/FLOAT(DisplayHeight);

			D3DXMatrixOrthoLH(&OrthoMatrix,(FLOAT)DisplayWidth,(FLOAT)DisplayHeight,0,100);
			SetNearFarClip(NearClip,FarClip);
			lpD3DDevice8->SetTransform(D3DTS_PROJECTION,&ProjectionMatrix);

			FogColor=D3DCOLOR_ARGB(0,0,0,0);
			FogStart=1;
			FogEnd=10000;
			SetFogRange(FogStart,FogEnd);

			D3DXQuaternionIdentity(&ViewRotation);

			SetViewPosition(ViewPosition);

			srand(timeGetTime());

			bLookAt=FALSE;

			Leave();
		}
		else {
			Log("CreateDevice(): FAILED");
		}
	}
	if (lpD3D8 == NULL || lpD3DDevice8 == NULL) {
		if (lpD3D8 == NULL) {
			Log("lpD3D8 == NULL");
		}
		else if (lpD3DDevice8 == NULL) {
			SAFE_RELEASE(lpD3D8);
		}

		Leave();

		return;
	}
	PrintTextLines.clear();

	PrintText(-1,-1,D3DXCOLOR(1,1,1,1),"...INITIALIZING...");
	Render();

	Leave();
}

void
CGfx::UnInit()
{
	Enter("CGfx::UnInit()");

	if (AweLogo != NULL) {
		SAFE_DELETE(AweLogo);
	}
	CTexMan::UnInit();
	
	SAFE_DELETE(lpD3DXFont);
	SAFE_RELEASE(lpD3DDevice8);
	SAFE_RELEASE(lpD3D8);
	
	Log("PEAK: FPS=%f POLYS=%ld PSEC=%f",Peak.FPS,Peak.Polys,Peak.PolysSec);

	DestroyWindow(hWnd);

	Leave();
}

BOOL
CGfx::CheckDXVersion()
{
	HINSTANCE hDPNHPASTDLL=LoadLibrary("dpnhpast.dll");
	if (hDPNHPASTDLL == NULL) {
		FreeLibrary(hDPNHPASTDLL);
		return(FALSE);
	}
	FreeLibrary(hDPNHPASTDLL);
	return(TRUE);
}

void
CGfx::ActivateApp()
{
	Enter("ActivateApp()");

#ifdef _FULLSCREEN_MODE_
	ResetDevice();
	lpD3DXFont->RestoreDeviceObjects();
#endif
	CGameObject::ActivateAllObjects();

	Leave();
}

void
CGfx::DeActivateApp()
{
	Enter("DeActivateApp()");

#ifdef _FULLSCREEN_MODE_
	lpD3DXFont->InvalidateDeviceObjects();
#endif
	CGameObject::DeActivateAllObjects();

	Leave();
}

void
CGfx::ResetDevice()
{
	Enter("ResetDevice()");

#ifdef _FULLSCREEN_MODE_
	ZeroMemory(&D3DParams,sizeof(D3DParams));
	D3DParams.BackBufferWidth=DisplayWidth;
	D3DParams.BackBufferHeight=DisplayHeight;
	D3DParams.BackBufferFormat=D3DFMT_A8R8G8B8;
	D3DParams.BackBufferCount=2;
	D3DParams.MultiSampleType=(bAntiAlias ? MultiSampleType : D3DMULTISAMPLE_NONE);
	D3DParams.hDeviceWindow=hWnd;
	D3DParams.Windowed=FALSE;
	D3DParams.FullScreen_PresentationInterval=D3DPRESENT_INTERVAL_ONE;
	D3DParams.SwapEffect=(D3DParams.MultiSampleType == D3DMULTISAMPLE_NONE) ? D3DSWAPEFFECT_FLIP : D3DSWAPEFFECT_DISCARD;
	D3DParams.EnableAutoDepthStencil=TRUE;
	D3DParams.AutoDepthStencilFormat=D3DFMT_D16;
	D3DParams.Flags=0;
	lpD3DDevice8->Reset(&D3DParams);
	lpD3DDevice8->SetRenderState(D3DRS_AMBIENT,D3DXCOLOR(255,255,255,255));
	lpD3DDevice8->SetRenderState(D3DRS_FOGTABLEMODE,D3DFOG_LINEAR);
	lpD3DDevice8->SetRenderState(D3DRS_MULTISAMPLEANTIALIAS,D3DParams.MultiSampleType == D3DMULTISAMPLE_NONE ? FALSE : TRUE);
	lpD3DDevice8->SetRenderState(D3DRS_SHADEMODE,D3DSHADE_GOURAUD);
	lpD3DDevice8->SetRenderState(D3DRS_SPECULARENABLE,TRUE);
	SetLightMode(bLightMode);
//	SetAlphaMode(bAlphaMode);
	for (short n=0 ; n < 8 ; n++) {
//		SetEnvironmentMapMode(n,bEnvironmentMap[n]);
//		SetReflectionMapMode(n,bReflectionMap[n]);
		lpD3DDevice8->SetTextureStageState(n,D3DTSS_MAGFILTER,D3DTEXF_LINEAR);
		lpD3DDevice8->SetTextureStageState(n,D3DTSS_MINFILTER,D3DTEXF_LINEAR);
		lpD3DDevice8->SetTextureStageState(n,D3DTSS_MIPFILTER,D3DTEXF_LINEAR);
	}
#endif

	Leave();
}

void
CGfx::SetAlphaMode(BOOL bEnable)
{
	if (bEnable) {
		if (!bAlphaMode) {
			lpD3DDevice8->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
			lpD3DDevice8->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
			lpD3DDevice8->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_ONE);
			bAlphaMode=TRUE;
		}
	}
	else if (bAlphaMode) {
		lpD3DDevice8->SetRenderState(D3DRS_ALPHABLENDENABLE,FALSE);
		bAlphaMode=FALSE;
	}
}

void
CGfx::SetCullMode(DWORD m)
{
	if (m != CullMode) {
		lpD3DDevice8->SetRenderState(D3DRS_CULLMODE,(m == 1) ? D3DCULL_NONE : (m == 2) ? D3DCULL_CW : D3DCULL_CCW);
		CullMode=m;
	}
}

void
CGfx::SetClearColor(D3DXCOLOR color)
{
	DWORD r=(DWORD)(color.r*255.0f);
	DWORD g=(DWORD)(color.g*255.0f);
	DWORD b=(DWORD)(color.b*255.0f);
	ClearColor=D3DCOLOR_XRGB(r,g,b);
}

void
CGfx::SetEnvironmentMapMode(DWORD stage,BOOL bEnable)
{
	if (bEnable) {
		D3DXMATRIX mat=ViewMatrix;
		switch (stage) {
		case 0:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE0,&mat);
			break;
		case 1:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE1,&mat);
			break;
		case 2:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE2,&mat);
			break;
		case 3:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE3,&mat);
			break;
		case 4:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE4,&mat);
			break;
		case 5:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE5,&mat);
			break;
		case 6:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE6,&mat);
			break;
		case 7:
			lpD3DDevice8->SetTransform(D3DTS_TEXTURE7,&mat);
			break;
		}
		if (!bEnvironmentMap[stage]) {
			lpD3DDevice8->SetTextureStageState(stage,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
			bEnvironmentMap[stage]=TRUE;
		}
	}
	else if (bEnvironmentMap[stage]) {
		lpD3DDevice8->SetTextureStageState(stage,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
		bEnvironmentMap[stage]=FALSE;
	}
}

void
CGfx::SetFogColor(FLOAT r,FLOAT g,FLOAT b)
{
	FogColor=D3DXCOLOR(0,r*255,g*255,b*255);
	lpD3DDevice8->SetRenderState(D3DRS_FOGCOLOR,FogColor);
}

void
CGfx::SetFogMode(BOOL bEnable)
{
	if (bEnable) {
		if (!bFogMode) {
			lpD3DDevice8->SetRenderState(D3DRS_FOGENABLE,TRUE);
			bFogMode=TRUE;
		}
	}
	else if (bFogMode) {
		lpD3DDevice8->SetRenderState(D3DRS_FOGENABLE,FALSE);
		bFogMode=FALSE;
	}
}

void
CGfx::SetFogRange(FLOAT start,FLOAT end)
{
	FogStart=start;
	lpD3DDevice8->SetRenderState(D3DRS_FOGSTART,*((DWORD *)(&FogStart)));
	FogEnd=end;
	lpD3DDevice8->SetRenderState(D3DRS_FOGEND,*((DWORD *)(&FogEnd)));
}

void
CGfx::SetLightMode(BOOL bEnable)
{
	if (bEnable) {
		if (!bLightMode) {
			lpD3DDevice8->SetRenderState(D3DRS_LIGHTING,TRUE);
			bLightMode=TRUE;
		}
	}
	else if (bLightMode) {
		lpD3DDevice8->SetRenderState(D3DRS_LIGHTING,FALSE);
		bLightMode=FALSE;
	}
}

void
CGfx::SetNearFarClip(FLOAT nclip,FLOAT fclip)
{
	NearClip=nclip;
	FarClip=fclip;
	D3DXMatrixPerspectiveFovLH(&ProjectionMatrix,FieldOfView,AspectRatio,NearClip,FarClip);
}

void
CGfx::SetOrthoMode(BOOL bEnable)
{
	if (bEnable) {
		if (!bOrthoMode) {
			lpD3DDevice8->SetTransform(D3DTS_PROJECTION,&OrthoMatrix);
			lpD3DDevice8->SetTransform(D3DTS_VIEW,&IdentityMatrix);
			bOrthoMode=TRUE;
		}
	}
	else if (bOrthoMode) {
		lpD3DDevice8->SetTransform(D3DTS_PROJECTION,&ProjectionMatrix);
		lpD3DDevice8->SetTransform(D3DTS_VIEW,&ViewMatrix);
		bOrthoMode=FALSE;
	}
}

void
CGfx::SetReflectionMapMode(DWORD stage,BOOL bEnable)
{
	if (bEnable) {
		if (!bReflectionMap[stage]) {
			lpD3DDevice8->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR);
			bReflectionMap[stage]=TRUE;
		}
	}
	else if (bReflectionMap[stage]) {
		lpD3DDevice8->SetTextureStageState(stage,D3DTSS_TEXCOORDINDEX,D3DTSS_TCI_PASSTHRU);
		bReflectionMap[stage]=FALSE;
	}
}

void
CGfx::SetWireFrame(BOOL bEnable)
{
	if (bEnable) {
		if (!bWireFrame) {
			lpD3DDevice8->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
			bWireFrame=TRUE;
		}
	}
	else if (bWireFrame) {
		lpD3DDevice8->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);
		bWireFrame=FALSE;
	}
}

void
CGfx::SetZBufferWrite(BOOL bEnable)
{
	if (bEnable) {
		if (!bZBufferWrite) {
			lpD3DDevice8->SetRenderState(D3DRS_ZWRITEENABLE,TRUE);
			bZBufferWrite=TRUE;
		}
	}
	else if (bZBufferWrite) {
		lpD3DDevice8->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);
		bZBufferWrite=FALSE;
	}
}

void
CGfx::SetZCompareNormal()
{
	if (!bZCompareNormal) {
		lpD3DDevice8->SetRenderState(D3DRS_ZFUNC,D3DCMP_LESSEQUAL);
		bZCompareNormal=TRUE;
		bZComparePass=FALSE;
	}
}

void
CGfx::SetZComparePass()
{
	if (!bZComparePass) {
		lpD3DDevice8->SetRenderState(D3DRS_ZFUNC,D3DCMP_ALWAYS);
		bZCompareNormal=FALSE;
		bZComparePass=TRUE;
	}
}

void
CGfx::ResetDelta()
{
	bResetDelta=TRUE;
}

FLOAT
CGfx::GetDelta()
{
	FLOAT delta;
	if (bPlayback && PlaybackBufferCount < InputBufferCount) {
		delta=InputBuffer[PlaybackBufferCount].TickDelta;
	}
	else {
		LARGE_INTEGER	t;
		QueryPerformanceCounter(&t);
		if (bResetDelta) {
			LastTick.QuadPart=t.QuadPart;
			bResetDelta=FALSE;
		}
		delta=FLOAT(t.QuadPart-LastTick.QuadPart)/FLOAT(Freq.QuadPart);
		if (delta != 0) {
			FPS=(1.0f/delta);
			FpsSum+=FPS;
			FpsAvg=FpsSum*0.05f;
			FpsSum-=FpsAvg;
			PolysSec=FpsAvg*NumPolys;
			LastTick.QuadPart=t.QuadPart;
		}
		if (InputBufferCount < MAXINPUTCOUNT) {
			InputBuffer[InputBufferCount].TickDelta=delta;
		}
	}
	GlobalTime+=delta;
	return(delta);
}

void
CGfx::RecordDemo()
{
	CGameObject::RecordDemoAllObjects();
}

void
CGfx::PlaybackDemo()
{
	CGameObject::PlaybackDemoAllObjects();
}

BOOL
CGfx::LoadDemo(DWORD num)
{
	Enter("LoadDemo(%ld)",num);

	CHAR fname[256];
	sprintf(fname,"DEMO%ld",num);
	if (_access(fname,0) == 0) {
		FILE *fp=fopen(fname,"r");
		if (fp != NULL) {
			fread(&InputBufferCount,sizeof(DWORD),1,fp);
			fread(&InputBufferRandomSeed,sizeof(DWORD),1,fp);
			for (DWORD n=0 ; n < InputBufferCount ; n++) {
				fread(&InputBuffer[n],sizeof(InputBuffer_t),1,fp);
			}
			fclose(fp);

//			DumpDemoContents(TRUE);

			PlaybackBufferCount=0;

			Leave();

			return(TRUE);
		}
	}

	Leave();

	return(FALSE);
}

void
CGfx::SaveDemo()
{
	Enter("SaveDemo()");

	DWORD num=0;
	CHAR fname[256];
	do {
		sprintf(fname,"DEMO%ld",num++);
	} while (_access(fname,0) == 0);
	FILE *fp=fopen(fname,"w");
	if (fp != NULL) {
		fwrite(&InputBufferCount,sizeof(DWORD),1,fp);
		fwrite(&InputBufferRandomSeed,sizeof(DWORD),1,fp);
		for (DWORD n=0 ; n < InputBufferCount ; n++) {
			fwrite(&InputBuffer[n],sizeof(InputBuffer_t),1,fp);
		}
		fclose(fp);

//		DumpDemoContents(FALSE);
	}

	Leave();
}

void
CGfx::DumpDemoContents(BOOL bLoaded)
{
	char *fname=(bLoaded ? "DEMOIN.TXT" : "DEMOOUT.TXT");
	FILE *fp=fopen(fname,"w");
	if (fp != NULL) {
		fprintf(fp,"COUNT=%ld SEED=%ld\n",InputBufferCount,InputBufferRandomSeed);
		for (DWORD n=0 ; n < InputBufferCount ; n++) {
			fprintf(fp,"TICK=%f JOYX=%ld JOYY=%ld JOYB=%X\n",InputBuffer[n].TickDelta,InputBuffer[n].JoyX,
				InputBuffer[n].JoyY,InputBuffer[n].JoyButtonFlag);
		}
	}
}

void
CGfx::Render()
{
	if (lpD3D8 == NULL || lpD3DDevice8 == NULL) {
		return;
	}
	if (GetKey(KEY_TAB)) {
		StatsLevel=(StatsLevel+1)%6;
	}
	else if (bSingleStep && GetKey(KEY_ENTER)) {
		if (bSingleStep) {
			bSingleTick=TRUE;
		}
	}
	else if (GetKey(KEY_ESC)) {
		bAppAlive=FALSE;
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_SPACE)) {
		bSingleStep=(bSingleStep ? FALSE : TRUE);
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_A)) {
		bAntiAlias=(bAntiAlias ? FALSE : TRUE);
		DeActivateApp();
		ActivateApp();
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_C)) {
		DWORD	cullmode;
		lpD3DDevice8->GetRenderState(D3DRS_CULLMODE,&cullmode);
		switch (cullmode) {
		case D3DCULL_NONE:
			cullmode=D3DCULL_CW;
			break;
		case D3DCULL_CW:
			cullmode=D3DCULL_CCW;
			break;
		case D3DCULL_CCW:
			cullmode=D3DCULL_NONE;
			break;
		}
		lpD3DDevice8->SetRenderState(D3DRS_CULLMODE,cullmode);
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_F)) {
		DWORD	rstate;
		lpD3DDevice8->GetRenderState(D3DRS_FILLMODE,&rstate);
		switch (rstate) {
		case D3DFILL_POINT:
			lpD3DDevice8->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
			break;
		case D3DFILL_WIREFRAME:
			lpD3DDevice8->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);
			break;
		case D3DFILL_SOLID:
			lpD3DDevice8->SetRenderState(D3DRS_FILLMODE,D3DFILL_POINT);
			break;
		}
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_R)) {
		RecordDemo();
	}
	else if (PeekKey(KEY_LSHIFT) && GetKey(KEY_X)) {
		switch (CGameObject::SortMethod) {
		case 0:
			CGameObject::SortMethod=1;
			break;
		case 1:
			CGameObject::SortMethod=2;
			break;
		case 2:
		default:
			CGameObject::SortMethod=0;
			break;
		}
	}
	if (lpD3DDevice8 != NULL) {
		CGameObject::ResetStatData();
		FLOAT delta=GetDelta();
		if (!bSingleStep || bSingleTick) {
			if (delta > 0) {
				DoGammaRamp(delta);
				CGameObject::TickAllObjects(delta);
				if (!bPause) {
					if (Physics != NULL) {
						Physics->DoCollideAllObjects(delta);
						Physics->DoMoveAllObjects(delta);
					}
					bSingleTick=FALSE;
				}
			}
		}
		else {
			PrintText("SINGLE STEP MODE");
		}

		TexCacheLoad=0;

		RenderEnvMaps();

		CGameObject::PreRenderAllObjects();

		lpD3DDevice8->Clear(0,NULL,bClearDisplay ? (D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER) : D3DCLEAR_ZBUFFER,ClearColor,1.0f,0);

		if (lpD3DDevice8->BeginScene() == D3D_OK) {
			NumPolys=0;
			NumVerts=0;
			if (ViewFollowObject != NULL) {
				D3DXVECTOR3	v=ViewFollowObject->TransformVector(0,1,0);
				D3DXVec3Scale(&v,&ViewFollowOrientation,ViewFollowDist);
				ViewFollowPosition=ViewFollowObject->TransformPoint(v);
				LookAt(ViewFollowObject->GetPosition());
			}
			if ((ViewFollowObject != NULL || bMoveTo) && ViewPosition != ViewFollowPosition) {
				D3DXVECTOR3	v;
				D3DXVec3Subtract(&v,&ViewFollowPosition,&ViewPosition);
				FLOAT dist=D3DXVec3Length(&v);
				if (dist < FLT_EPSILON) {
					bMoveTo=FALSE;
				}
				else {
					if (dist > delta*ViewFollowSpeedFactor) {
						D3DXVec3Scale(&v,&v,delta*ViewFollowSpeedFactor);
					}
					D3DXVec3Add(&ViewPosition,&ViewPosition,&v);
				}
			}
			if (bLookAt) {
				D3DXMatrixLookAtLH(&ViewMatrix,&ViewPosition,&LookAtPoint,&D3DXVECTOR3(0,1,0));
				D3DXQuaternionRotationMatrix(&ViewRotation,&ViewMatrix);
				D3DXQuaternionInverse(&ViewRotation,&ViewRotation);
				bLookAt=FALSE;
			}
			else {
				D3DXMATRIX		matrx;
				D3DXMatrixRotationQuaternion(&matrx,&ViewRotation);
				D3DXMatrixTranspose(&matrx,&matrx);
				D3DXMATRIX		mattx;
				D3DXMatrixTranslation(&mattx,-ViewPosition.x,-ViewPosition.y,-ViewPosition.z);
				D3DXMatrixMultiply(&ViewMatrix,&mattx,&matrx);
			}
			lpD3DDevice8->SetTransform(D3DTS_VIEW,&ViewMatrix);
			
			ViewDirVec=TransformVector(0,0,1);

			CGameObject::RenderAllObjects();

			UpdateEnvMapViews();

			ShowPrintTextList();

			lpD3DDevice8->EndScene();
		}

		UpdateStats();

		switch (StatsLevel) {
		default:
			break;
		case 1:
			PrintText("%03d",long(FpsAvg));
			break;
		case 2:
			PrintText("%03d P%ld",long(FpsAvg),NumPolys);
			break;
		case 3:
			PrintText("%03d P%ld %ld O%ld M=%ld",long(FpsAvg),NumPolys,long(FpsAvg*NumPolys),CGameObject::GameObjectList.size(),CMeshManager::MeshList.size());
			break;
		case 4:
			PrintText("DO=%ld GO=%ld RO=%ld TO=%ld TX=%ld",CGameObject::DeleteObjectCount,CGameObject::GarbageObjectCount,
				CGameObject::RenderObjectCount,CGameObject::TickObjectCount,CGameObject::TransformObjectCount);
			break;
		case 5:
			CInput::ShowJoystickData();
			break;
		}

		if (AweLogo == NULL) {
			AweLogo=new C2DSprite;
			AweLogo->InitSprite(LogoRes);
			AweLogo->SetPosition(AweLogo->Width*0.5f,CGfx::DisplayHeight-(AweLogo->Height*0.5f));
			AweLogo->bCanDelete=FALSE;
			AweLogo->bCanTouch=FALSE;
			AweLogo->bTransparency=TRUE;
			AweLogo->bUnlit=TRUE;
		}

		lpD3DDevice8->Present(NULL,NULL,NULL,NULL);

		CGameObject::PostRenderAllObjects();

		FrameNum++;

		if (bSaveDemo) {
			SaveDemo();
			bSaveDemo=FALSE;
		}

		CGameObject::GarbageCleanUp();
	}
}

void
CGfx::RenderSceneToEnvMap(D3DXVECTOR3 pos,LPDIRECT3DTEXTURE8 lpEnvMap,LPDIRECT3DSURFACE8 lpDepth)
{
	if (lpEnvMap != NULL) {
		LPDIRECT3DSURFACE8	lpSurf;
		if (lpEnvMap->GetSurfaceLevel(0,&lpSurf) == D3D_OK) {
			D3DXMATRIX matView=ViewMatrix;
			D3DXMatrixLookAtLH(&ViewMatrix,&pos,&ViewPosition,&D3DXVECTOR3(0,1,0));
			D3DXVECTOR3 viewpos=ViewPosition;
			ViewPosition=pos;
			D3DXQUATERNION viewrot=ViewRotation;
			D3DXQuaternionRotationMatrix(&ViewRotation,&ViewMatrix);
			D3DXQuaternionInverse(&ViewRotation,&ViewRotation);
			ViewDirVec=TransformVector(0,0,1);
			lpD3DDevice8->SetRenderTarget(lpSurf,lpDepth);
			lpD3DDevice8->SetTransform(D3DTS_VIEW,&ViewMatrix);
			lpD3DDevice8->Clear(0,NULL,D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,ClearColor,1.0f,0);
			if (lpD3DDevice8->BeginScene() == D3D_OK) {
				CGameObject::RenderAllObjects();
				lpD3DDevice8->EndScene();
			}
			ViewRotation=viewrot;
			ViewPosition=viewpos;
			ViewMatrix=matView;
			SAFE_RELEASE(lpSurf);
		}
	}
}

void
CGfx::RenderEnvMaps()
{
	if (EnvMapTextureList.size() != 0) {
		LPDIRECT3DSURFACE8	lpSurf,lpDepth;
		if (lpD3DDevice8->GetRenderTarget(&lpSurf) == D3D_OK) {
			if (lpD3DDevice8->GetDepthStencilSurface(&lpDepth) == D3D_OK) {
				for (EnvMapTextureList_t::iterator o=EnvMapTextureList.begin() ; o != EnvMapTextureList.end() ; o++) {
					EnvMapTextureObject_t *envmapobj=(*o);
					if (envmapobj->bInView) {
						D3DXVECTOR3 p=envmapobj->Object->GetPosition();
						D3DXVECTOR3 pos;
						D3DXVec3Subtract(&pos,&ViewPosition,&p);
						D3DXVec3Normalize(&pos,&pos);
						D3DXVec3Scale(&pos,&pos,envmapobj->Object->CollisionRadius);
						D3DXVec3Add(&pos,&pos,&p);
						RenderSceneToEnvMap(pos,envmapobj->lpEnvMapTexture,envmapobj->lpEnvMapDepth);
					}
				}
				lpD3DDevice8->SetRenderTarget(lpSurf,lpDepth);
				SAFE_RELEASE(lpDepth);
			}
			SAFE_RELEASE(lpSurf);
		}
	}
}

void
CGfx::UpdateEnvMapViews()
{
	for (EnvMapTextureList_t::iterator o=EnvMapTextureList.begin() ; o != EnvMapTextureList.end() ; o++) {
		EnvMapTextureObject_t *envmapobj=(*o);
		envmapobj->bInView=envmapobj->Object->bInView;
	}
}

void
CGfx::MoveTo(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXVECTOR3 p(x,y,z);
	MoveTo(p);
}

void
CGfx::MoveTo(const D3DXVECTOR3 p)
{
	ViewFollowPosition=p;
	bMoveTo=TRUE;
}

void
CGfx::FadeTo(FLOAT r,FLOAT g,FLOAT b)
{
	FadeToColor.red=(WORD)(r*65535.0f);
	FadeToColor.green=(WORD)(g*65535.0f);
	FadeToColor.blue=(WORD)(b*65535.0f);
	bFade=TRUE;
}

void
CGfx::DoGammaRamp(FLOAT delta)
{
/*
	D3DGAMMARAMP	ramp;
	if (bFade) {
		BOOL bRedDone=FALSE;
		BOOL bGreenDone=FALSE;
		BOOL bBlueDone=FALSE;
		lpD3DDevice8->GetGammaRamp(&ramp);
		WORD i=1;
		for (short n=0 ; n < 256 ; n++) {
			DWORD r=ramp.red[n];
			if (r < FadeToColor.red) {
				r=__min(r+i,FadeToColor.red);
			}
			else if (r > FadeToColor.red) {
				r=__max(r-i,FadeToColor.red);
			}
			else {
				bRedDone=TRUE;
			}
			DWORD g=ramp.green[n];
			if (g < FadeToColor.green) {
				g=__min(g+i,FadeToColor.green);
			}
			else if (g > FadeToColor.green) {
				g=__max(ramp.green[n]-i,FadeToColor.green);
			}
			else {
				bGreenDone=TRUE;
			}
			DWORD b=ramp.blue[n];
			if (b < FadeToColor.blue) {
				b=__min(b+i,FadeToColor.blue);
			}
			else if (b > FadeToColor.blue) {
				b=__max(b-i,FadeToColor.blue);
			}
			else {
				bBlueDone=TRUE;
			}
			ramp.red[n]=r;
			ramp.green[n]=g;
			ramp.blue[n]=b;
		}
		lpD3DDevice8->SetGammaRamp(D3DSGR_NO_CALIBRATION,&ramp);
		if (bRedDone && bGreenDone && bBlueDone) {
			bFade=FALSE;
		}
	}
*/
}

void
CGfx::UpdateStats()
{
	if (FPS > Peak.FPS) {
		Peak.FPS=FPS;
	}
	if (NumPolys > Peak.Polys) {
		Peak.Polys=NumPolys;
	}
	if (NumPolys*FPS > Peak.PolysSec) {
		Peak.PolysSec=NumPolys*FPS;
	}
	if (NumVerts > Peak.Verts) {
		Peak.Verts=NumVerts;
	}
}

void
CGfx::SetViewPosition(FLOAT x,FLOAT y,FLOAT z)
{
	ViewPosition=D3DXVECTOR3(x,y,z);
}

void
CGfx::SetViewPosition(D3DXVECTOR3 &p)
{
	SetViewPosition(p.x,p.y,p.z);
}

void
CGfx::AddViewPosition(FLOAT x,FLOAT y,FLOAT z)
{
	ViewPosition+=D3DXVECTOR3(x,y,z);
}

void
CGfx::AddViewPosition(D3DXVECTOR3 &p)
{
	AddViewPosition(p.x,p.y,p.z);
}

void
CGfx::SetViewRotation(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXQuaternionRotationYawPitchRoll(&ViewRotation,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
}

void
CGfx::SetViewRotation(D3DXVECTOR3 &r)
{
	SetViewRotation(r.x,r.y,r.z);
}

D3DXVECTOR3
CGfx::GetViewRotation()
{
	D3DXVECTOR3 r=CGameObject::GetRotation(ViewRotation);
	r.x=D3DXToDegree(r.x);
	r.y=D3DXToDegree(r.y);
	r.z=D3DXToDegree(r.z);
	return(r);
}

void
CGfx::AddViewRotation(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXQUATERNION q1;
	D3DXQuaternionRotationYawPitchRoll(&q1,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
	D3DXQuaternionMultiply(&ViewRotation,&ViewRotation,&q1);
}

void
CGfx::AddViewRotation(D3DXVECTOR3 &r)
{
	AddViewRotation(r.x,r.y,r.z);
}

void
CGfx::LookAt(FLOAT x,FLOAT y,FLOAT z)
{
	LookAtPoint=D3DXVECTOR3(x,y,z);
	bLookAt=TRUE;
}

void
CGfx::LookAt(D3DXVECTOR3 &p)
{
	LookAt(p.x,p.y,p.z);
}

D3DXVECTOR3
CGfx::TransformVector(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXMATRIX	mat;
	D3DXMatrixRotationQuaternion(&mat,&CGfx::ViewRotation);
	D3DXVECTOR3 v(x,y,z);
	D3DXVec3TransformCoord(&v,&v,&mat);
	return(v);
}

BOOL
CGfx::WorldToScreen(FLOAT x,FLOAT y,FLOAT z,FLOAT &vx,FLOAT &vy,FLOAT radius)
{
	D3DXVECTOR3	v(x,y,z);
	D3DXVECTOR3 v1=v;
	D3DXVec3Project(&v,&v,&D3DViewPort,&ProjectionMatrix,&ViewMatrix,&IdentityMatrix);
	vx=v.x;
	vy=v.y;
	if (vx >= -radius && vx <= DisplayWidth+radius && vy >= -radius && vy <= DisplayHeight+radius) {
		D3DXVec3Subtract(&v1,&v1,&ViewPosition);
		D3DXVec3Normalize(&v1,&v1);
		if (D3DXVec3Dot(&ViewDirVec,&v1) > 0) {
			return(TRUE);
		}
	}
	return(FALSE);
}

BOOL
CGfx::WorldToScreen(D3DXVECTOR3 pos,FLOAT &vx,FLOAT &vy,FLOAT radius)
{
	return(WorldToScreen(pos.x,pos.y,pos.z,vx,vy,radius));
}

void
CGfx::ScreenToWorld(FLOAT x,FLOAT y,FLOAT &wx,FLOAT &wy,FLOAT &wz)
{
	D3DXVECTOR3 v(x,y,0);
	D3DXVec3Unproject(&v,&v,&D3DViewPort,&ProjectionMatrix,&ViewMatrix,&IdentityMatrix);
	wx=v.x;
	wy=v.y;
	wz=v.z;
}

FLOAT
CGfx::Random()
{
	return((FLOAT)RandomInt()/(FLOAT)RAND_MAX);
}

DWORD
CGfx::RandomInt()
{
	DWORD r=rand();
	return(r);
}

void
CGfx::PrintText(char *fmt,...)
{
	va_list	argptr;
	char	buf[256];

	if (lpD3DXFont != NULL) {
		va_start(argptr,fmt);
		vsprintf(buf,fmt,argptr);
		va_end(argptr);
		PrintText(0,PrintTextNum*10,1.0f,1.0f,PrintTextColor,buf);
		PrintTextNum++;
	}
}

void
CGfx::PrintText(LONG x,LONG y,D3DXCOLOR color,char *fmt,...)
{
	va_list	argptr;
	char	buf[256];

	if (lpD3DXFont != NULL) {
		va_start(argptr,fmt);
		vsprintf(buf,fmt,argptr);
		va_end(argptr);
		PrintText(x,y,1.0f,1.0f,color,buf);
	}
}

void
CGfx::PrintText(LONG x,LONG y,FLOAT scalex,FLOAT scaley,D3DXCOLOR color,char *fmt,...)
{
	va_list	argptr;

	if (lpD3DXFont != NULL) {
		LONG n=PrintTextLineCount++;
		va_start(argptr,fmt);
		vsprintf(PrintTextLine[n].buf,fmt,argptr);
		va_end(argptr);
		if (x == -1) {
			SIZE textsize;
			lpD3DXFont->GetTextExtent(PrintTextLine[n].buf,&textsize);
			x=(DisplayWidth>>1)-(textsize.cx>>1);
		}
		PrintTextLine[n].x=x;
		if (y == -1) {
			y=(DisplayHeight>>1);
		}
		PrintTextLine[n].y=y;
		PrintTextLine[n].scalex=scalex;
		PrintTextLine[n].scaley=scaley;
		PrintTextLine[n].color=color;
		PrintTextX=x;
		PrintTextY=y;
	}
}

void
CGfx::ShowPrintTextList()
{
	if (bSaveDemo) {
		PrintText(CGfx::DisplayWidth-15,CGfx::DisplayHeight-15,D3DXCOLOR(0,0,1,1),"*");
	}
	if (lpD3DXFont != NULL) {
		for (short n=0 ; n < PrintTextLineCount ; n++) {
			if (PrintTextLine[n].scalex != 1.0f || PrintTextLine[n].scaley != 1.0f) {
				FLOAT x=((FLOAT)PrintTextLine[n].x/(DisplayWidth*0.5f))-1.0f;
				FLOAT y=((FLOAT)PrintTextLine[n].y/(DisplayHeight*0.5f))-1.0f;
				lpD3DXFont->DrawTextScaled(x,y,1,PrintTextLine[n].scalex,PrintTextLine[n].scaley,PrintTextLine[n].color,
											PrintTextLine[n].buf);
			}
			else {
				lpD3DXFont->DrawText((FLOAT)PrintTextLine[n].x,(FLOAT)PrintTextLine[n].y,PrintTextLine[n].color,PrintTextLine[n].buf);
			}
		}
	}
	PrintTextLineCount=0;
	PrintTextNum=0;
}
