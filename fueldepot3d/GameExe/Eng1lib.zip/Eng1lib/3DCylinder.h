// 3DCylinder.h: interface for the C3DCylinder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DCYLINDER_H__DE020805_5B23_4BEE_9472_5CE5AA6B20A2__INCLUDED_)
#define AFX_3DCYLINDER_H__DE020805_5B23_4BEE_9472_5CE5AA6B20A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DObject.h"

class C3DCylinder : public C3DObject  
{
public:
	C3DCylinder();
	virtual ~C3DCylinder();

	virtual void					InitCylinder(FLOAT radiusx,FLOAT radiusz,FLOAT length,UINT slices=16,UINT stacks=16);
	virtual void					CloneNewFVF(BOOL bComputeNormals=TRUE);
};

#endif // !defined(AFX_3DCYLINDER_H__DE020805_5B23_4BEE_9472_5CE5AA6B20A2__INCLUDED_)
