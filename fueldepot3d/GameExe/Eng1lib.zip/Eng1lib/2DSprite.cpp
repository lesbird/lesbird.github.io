// 2DSprite.cpp: implementation of the C2DSprite class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "2DSprite.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C2DSprite::C2DSprite()
{
	SetObjectName("C2DSPRITE");
	SetObjectID('2SPR');

	bCanTouch=FALSE;
	bOrtho=TRUE;
	bViewClip=FALSE;
}

C2DSprite::~C2DSprite()
{

}

void
C2DSprite::InitSprite(FLOAT sizew,FLOAT sizeh)
{
	InitPolygon(sizew,sizeh);
}

void
C2DSprite::InitSprite(string texname)
{
	SpriteMaterial=AddTexture(texname);
	InitSpriteSize();
}

void
C2DSprite::InitSprite(INT resid)
{
	SpriteMaterial=AddTexture(resid);
	InitSpriteSize();
}

void
C2DSprite::InitSpriteSize()
{
	SpriteTexture=GetTexture(SpriteMaterial,0);
	if (SpriteTexture != NULL) {
		LPDIRECT3DTEXTURE8 tex8=SpriteTexture->D3DTexture;
		if (tex8 != NULL) {
			D3DSURFACE_DESC	sd;
			tex8->GetLevelDesc(0,&sd);
			InitSprite(sd.Width,sd.Height);
		}
	}
}

void
C2DSprite::CloneNewFVF(BOOL bComputeNormals)
{
	if (D3DXMesh != NULL) {
		C3DObject::CloneNewFVF(bComputeNormals);
		FVFVertex_t *verts;
		D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
		if (verts != NULL) {
			for (short n=0 ; n < D3DXMesh->GetNumVertices() ; n++) {
				FLOAT	x,y;
				switch (n) {
				case 0:
					x=verts[n].pos.x;
					y=verts[n].pos.y;
					break;
				case 1:
					x=-Width*0.5f;
					y=-Height*0.5f;
					break;
				case 4:
					x=-Width*0.5f;
					y=Height*0.5f;
					break;
				case 3:
					x=Width*0.5f;
					y=Height*0.5f;
					break;
				case 2:
					x=Width*0.5f;
					y=-Height*0.5f;
					break;
				}
				verts[n].pos.x=x;
				verts[n].pos.y=y;
				if (Width != 0 && Height != 0) {
					verts[n].tu1=__min(__max((x/Width)+0.5f,0),1.0f);
					verts[n].tv1=__min(__max((-y/Height)+0.5f,0),1.0f);
				}
				else {
					verts[n].tu1=0;
					verts[n].tv1=0;
				}
				verts[n].tu1*=TextureScaleU;
				verts[n].tv1*=TextureScaleV;
				verts[n].tu2=verts[n].tu1;
				verts[n].tv2=verts[n].tv1;
				verts[n].tu3=verts[n].tu1;
				verts[n].tv3=verts[n].tv1;
			}
		}
		D3DXMesh->UnlockVertexBuffer();
	}
}

void
C2DSprite::SetPosition(FLOAT x,FLOAT y)
{
	FLOAT nx=x-(CGfx::DisplayWidth*0.5f);
	FLOAT ny=(CGfx::DisplayHeight*0.5f)-y;
	C3DPolygon::SetPosition(nx,ny,0);
}

void
C2DSprite::Transform()
{
	D3DXVECTOR3	pos;
	if (ParentObject == NULL) {
		D3DXVECTOR3	ScaleVector(ScaleX,ScaleY,ScaleZ);
		D3DXMatrixTransformation(&WorldMatrix,NULL,NULL,&ScaleVector,NULL,&Rotation,&Position);
		pos=Position;
	}
	else {
		D3DXMatrixScaling(&WorldMatrix,ScaleX,ScaleY,ScaleZ);
		D3DXMATRIX	m;
		D3DXMatrixRotationQuaternion(&m,&Rotation);
		D3DXMatrixMultiply(&WorldMatrix,&WorldMatrix,&m);
		D3DXVec3TransformCoord(&pos,&Position,&ParentObject->WorldMatrix);
	}
	WorldMatrix._41=pos.x;
	WorldMatrix._42=pos.y;
	WorldMatrix._43=pos.z;
	ViewDist=pos.z;
	bInView=TRUE;
}
