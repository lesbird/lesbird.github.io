// Eng1.cpp : Defines the entry point for the application.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "stdafx.h"
#include "stdarg.h"
#include "io.h"

#include "DefaultGame.h"
#include "Gfx.h"
#include "Input.h"
#include "Physics.h"

#include "d3dfont.h"

HWND								hWnd=NULL;
HINSTANCE							hInst=NULL;

BOOL								bAppActive=TRUE;
BOOL								bAppAlive=FALSE;
BOOL								bKey[256];
BOOL								bKeyPressed=FALSE;

DWORD								LogLevel=0;

extern
VOID								InitSoundDevice();

extern
VOID								UnInitSoundDevice();

LRESULT CALLBACK
WndProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	switch (uMsg) {
	case WM_CREATE:
//		Log("WM_CREATE");
		break;
	case WM_DESTROY:
//		Log("WM_DESTROY");
		PostQuitMessage(0);
		break;
	case WM_KEYDOWN:
		{
			WORD c=(lParam>>16)&0xFF;
			Log("KEYDOWN: %ld",c);
			bKey[c]=TRUE;
			bKeyPressed=TRUE;
		}
		break;
	case WM_KEYUP:
		{
			WORD c=(lParam>>16)&0xFF;
			bKey[c]=FALSE;
			bKeyPressed=FALSE;
		}
		break;
	case WM_SYSCOMMAND:
//		Log("WM_SYSCOMMAND wParam=%X lParam=%X",wParam,lParam);
		return(0);
		break;
	case WM_ACTIVATEAPP:
//		Log("WM_ACTIVATEAPP %d bAppActive=%d",wParam,bAppActive);
		if (bAppAlive) {
			if (bAppActive) {
				if (!wParam) {
					bPause=TRUE;
#ifndef _FULLSCREEN_MODE_
					CGfx::Render();
#endif
					CGfx::DeActivateApp();
					bAppActive=FALSE;
				}
			}
			else if (wParam) {
				CGfx::ActivateApp();
				CGfx::ResetDelta();
				bAppActive=TRUE;
				bPause=FALSE;
			}
		}
		break;
	default:
//		Log("uMsg=%X wParam=%X lParam=%X",uMsg,wParam,lParam);
		break;
	}
	return(DefWindowProc(hWnd,uMsg,wParam,lParam));
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	MSG			msg;
	WNDCLASSEX	wc={sizeof(WNDCLASSEX),CS_CLASSDC,WndProc,0,0,GetModuleHandle(NULL),NULL,NULL,NULL,NULL,AppName,NULL};

	remove("debug.log");

	Log("PROGRAM BEGIN");

	if (!CGfx::CheckDXVersion()) {
		MessageBox(NULL,"DIRECTX 8.1 OR LATER IS REQUIRED TO PLAY","DX VERSION",MB_OK|MB_ICONERROR);
		Log("WRONG VERSION OF DIRECTX");
		return(0);
	}

	hInst=hInstance;
	if (RegisterClassEx(&wc) != 0) {
		HWND hDesktopWnd=GetDesktopWindow();
		RECT	r;
		GetWindowRect(hDesktopWnd,&r);
		DWORD x=((r.right-r.left)/2)-(CGfx::DisplayWidth/2);
		DWORD y=((r.bottom-r.top)/2)-(CGfx::DisplayHeight/2);
		hWnd=CreateWindow(AppName,AppName,WS_DLGFRAME,x,y,CGfx::DisplayWidth,CGfx::DisplayHeight,NULL,NULL,hInstance,NULL);
		if (hWnd != NULL) {
			ShowWindow(hWnd,SW_SHOWDEFAULT);
			ShowCursor(FALSE);
			UpdateWindow(hWnd);
			bAppAlive=true;
			CGfx::Init();
			if (CGfx::lpD3DDevice8 != NULL) {
				InitSoundDevice();
				CInput::Init(hInstance);
				CPhysics *phys=new CPhysics;
				SPAWN('DEFA');
				do {
					while (PeekMessage(&msg,hWnd,0,0,PM_REMOVE)) {
						TranslateMessage(&msg);
						DispatchMessage(&msg);
					}
					if (bAppActive) {
						CGfx::Render();
					}
				} while (bAppAlive);
				CGameObject::DeleteAllObjects();
				CGameObject::GarbageCleanUp();
				Log("Objects Remaining: %ld",CGameObject::GameObjectList.size());
				SAFE_DELETE(phys);
				CInput::UnInit();
				UnInitSoundDevice();
			}
			CMeshManager::UnInit();
			CGfx::UnInit();
		}
		else {
			Log("CreateWindow() failed");
		}
	}

	Log("PROGRAM END");

	return 0;
}

BOOL
PeekKey(short key)
{
	return(bKey[key]);
}

BOOL
GetKey(short key)
{
	if (bKey[key]) {
		bKey[key]=FALSE;
		return(TRUE);
	}
	return(FALSE);
}

void
InitKeys()
{
	for (DWORD n=0 ; n < 256 ; n++) {
		bKey[n]=FALSE;
	}
}

void
Log(char *fmt,...)
{
#ifdef _LOG_
	va_list	argptr;

	FILE *fp=fopen("debug.log","a");
	if (fp != NULL) {
		va_start(argptr,fmt);
		for (short n=0 ; n < LogLevel ; n++) {
			fprintf(fp,"..");
		}
		vfprintf(fp,fmt,argptr);
		fprintf(fp,"\n");
		va_end(argptr);
		fclose(fp);
	}
#endif
}

void
Enter(char *fmt,...)
{
#ifdef _LOG_
	char	buf[256];
	va_list	argptr;

	va_start(argptr,fmt);
	vsprintf(buf,fmt,argptr);
	va_end(argptr);
	Log("+%s",buf);
	LogLevel++;
#endif
}

void
Leave()
{
#ifdef _LOG_
	LogLevel--;
	Log("-");
#endif
}

void
LogExit(char *file,DWORD line)
{
	Log("QUICKEXIT: %s: %ld",file,line);
	bAppAlive=FALSE;
}
