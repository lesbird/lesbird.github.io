// Gfx.h: interface for the CGfx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GFX_H__06AF3058_C5EB_4410_B4B0_7DC5736657E4__INCLUDED_)
#define AFX_GFX_H__06AF3058_C5EB_4410_B4B0_7DC5736657E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "d3dx8.h"

#include <list>

using namespace std;

typedef struct PeakStats_tag
{
	FLOAT							FPS;
	DWORD							Polys;
	FLOAT							PolysSec;
	DWORD							Verts;
} PeakStats_t;

typedef struct PrintTextBuf_tag
{
	LONG							x,y;
	FLOAT							scalex,scaley;
	D3DXCOLOR						color;
	char							buf[256];
} PrintTextBuf_t;

typedef list<PrintTextBuf_t *>		PrintTextLines_t;

typedef enum {
	CAMMODE_BEHINDFIXED,
	CAMMODE_BEHINDFLOAT,
	CAMMODE_CUSTOMFIXED,
	CAMMODE_CUSTOMFLOAT,
	CAMMODE_MAX
} CamMode_t;

typedef struct EnvMapTextureObject_tag
{
	BOOL							bInView;
	class C3DObject					*Object;
	LPDIRECT3DTEXTURE8				lpEnvMapTexture;
	LPDIRECT3DSURFACE8				lpEnvMapDepth;
} EnvMapTextureObject_t;

#define	MAXINPUTCOUNT				8192

typedef struct InputBuffer_tag
{
	LONG		JoyX,JoyY;
	CHAR		JoyButtonFlag;
	FLOAT		TickDelta;
} InputBuffer_t;

typedef list<EnvMapTextureObject_t *>	EnvMapTextureList_t;

class	CGameObject;
class	CD3DFont;

class CGfx  
{
public:
	CGfx();
	virtual ~CGfx();

	static void						Init();
	static void						UnInit();

	static BOOL						CheckDXVersion();

	static void						ActivateApp();
	static void						DeActivateApp();
	static void						ResetDevice();

	static void						SetAlphaMode(BOOL bEnable);
	static void						SetCullMode(DWORD m);
	static void						SetClearColor(D3DXCOLOR color);
	static void						SetEnvironmentMapMode(DWORD stage,BOOL bEnable);
	static void						SetFogColor(FLOAT r,FLOAT g,FLOAT b);
	static void						SetFogMode(BOOL bEnable);
	static void						SetFogRange(FLOAT start,FLOAT end);
	static void						SetLightMode(BOOL bEnable);
	static void						SetNearFarClip(FLOAT nclip,FLOAT fclip);
	static void						SetOrthoMode(BOOL bEnable);
	static void						SetReflectionMapMode(DWORD stage,BOOL bEnable);
	static void						SetWireFrame(BOOL bEnable);
	static void						SetZBufferWrite(BOOL bEnable);
	static void						SetZCompareNormal();
	static void						SetZComparePass();

	static void						ResetDelta();
	static FLOAT					GetDelta();

	static void						RecordDemo();
	static void						PlaybackDemo();
	static BOOL						LoadDemo(DWORD num);
	static void						SaveDemo();
	static void						DumpDemoContents(BOOL bLoaded);

	static void						Render();
	static void						RenderSceneToEnvMap(D3DXVECTOR3 pos,LPDIRECT3DTEXTURE8 lpEnvMap,LPDIRECT3DSURFACE8 lpDepth);
	static void						RenderEnvMaps();
	static void						UpdateEnvMapViews();

	static void						MoveTo(FLOAT x,FLOAT y,FLOAT z);
	static void						MoveTo(const D3DXVECTOR3 p);

	static void						FadeTo(FLOAT r,FLOAT g,FLOAT b);
	static void						DoGammaRamp(FLOAT delta);

	static void						UpdateStats();

	static void						SetViewPosition(FLOAT x,FLOAT y,FLOAT z);
	static void						SetViewPosition(D3DXVECTOR3 &p);
	static void						AddViewPosition(FLOAT x,FLOAT y,FLOAT z);
	static void						AddViewPosition(D3DXVECTOR3 &p);

	static void						SetViewRotation(FLOAT x,FLOAT y,FLOAT z);
	static void						SetViewRotation(D3DXVECTOR3 &r);
	static D3DXVECTOR3				GetViewRotation();
	static void						AddViewRotation(FLOAT x,FLOAT y,FLOAT z);
	static void						AddViewRotation(D3DXVECTOR3 &r);

	static void						LookAt(FLOAT x,FLOAT y,FLOAT z);
	static void						LookAt(D3DXVECTOR3 &p);

	static D3DXVECTOR3				TransformVector(FLOAT x,FLOAT y,FLOAT z);

	static BOOL						WorldToScreen(FLOAT x,FLOAT y,FLOAT z,FLOAT &vx,FLOAT &vy,FLOAT radius);
	static BOOL						WorldToScreen(D3DXVECTOR3 pos,FLOAT &vx,FLOAT &vy,FLOAT radius);
	static void						ScreenToWorld(FLOAT x,FLOAT y,FLOAT &wx,FLOAT &wy,FLOAT &wz);

	static FLOAT					Random();
	static DWORD					RandomInt();

	static void						PrintText(char *fmt,...);
	static void						PrintText(LONG x,LONG y,D3DXCOLOR color,char *fmt,...);
	static void						PrintText(LONG x,LONG y,FLOAT scalex,FLOAT scaley,D3DXCOLOR color,char *fmt,...);
	static void						ShowPrintTextList();

public:
	static BOOL						bResetDelta;

	static BOOL						bFogMode;
	static BOOL						bLookAt;
	static BOOL						bMoveTo;
	static BOOL						bSingleStep;
	static BOOL						bSingleTick;

	static DWORD					DisplayHeight;
	static DWORD					DisplayWidth;

	static DWORD					NumPolys;
	static DWORD					NumVerts;

	static DWORD					RenderPass;

	static DWORD					StatsLevel;

	static LPDIRECT3D8				lpD3D8;
	static LPDIRECT3DDEVICE8		lpD3DDevice8;

	static D3DVIEWPORT8				D3DViewPort;

	static CD3DFont					*lpD3DXFont;

	static D3DFORMAT				BackBufferFormat;

	static D3DXVECTOR3				LookAtPoint;
	static D3DXVECTOR3				ViewDirVec;
	static D3DXVECTOR3				ViewPosition;
	static D3DXQUATERNION			ViewRotation;

	static D3DXMATRIX				IdentityMatrix;
	static D3DXMATRIX				OrthoMatrix;
	static D3DXMATRIX				ProjectionMatrix;
	static D3DXMATRIX				ViewMatrix;

	static D3DCOLOR					ClearColor;

	static D3DXVECTOR3				ViewFollowOrientation;
	static D3DXVECTOR3				ViewFollowPosition;
	static CGameObject				*ViewFollowObject;
	static FLOAT					ViewFollowDist;
	static FLOAT					ViewFollowSpeedFactor;

	static FLOAT					AspectRatio;
	static FLOAT					FieldOfView;
	static DWORD					FogColor;
	static FLOAT					FogEnd;
	static FLOAT					FogStart;
	static FLOAT					NearClip;
	static FLOAT					FarClip;

	static FLOAT					GlobalTime;

	static PeakStats_t				Peak;

	static PrintTextLines_t			PrintTextLines;
	static PrintTextBuf_t			PrintTextLine[256];
	static LONG						PrintTextLineCount;
	static D3DXCOLOR				PrintTextColor;

	static EnvMapTextureList_t		EnvMapTextureList;
};

extern
class C2DSprite						*AweLogo;

extern
CHAR								*FontName;

extern
DWORD								FontSize;

extern
BOOL								bAntiAlias,
									bCanBump,
									bClearDisplay;

extern
BOOL								bPlayback,
									bRecordDemo,
									bSaveDemo;

extern
DWORD								InputBufferCount,
									PlaybackBufferCount;

extern
DWORD								InputBufferRandomSeed;

extern
InputBuffer_t						InputBuffer[MAXINPUTCOUNT];

extern
D3DFORMAT							D3DBumpMapFmt;

extern
LONG								PrintTextX,PrintTextY;

#endif // !defined(AFX_GFX_H__06AF3058_C5EB_4410_B4B0_7DC5736657E4__INCLUDED_)
