// 3DSphere.h: interface for the C3DSphere class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DSPHERE_H__2CF08D81_A049_4E58_9B6F_8C591A46DFA6__INCLUDED_)
#define AFX_3DSPHERE_H__2CF08D81_A049_4E58_9B6F_8C591A46DFA6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DObject.h"

class C3DSphere : public C3DObject  
{
public:
	C3DSphere();
	virtual ~C3DSphere();

	virtual void					InitSphere(FLOAT size);
	virtual void					InitSphere(FLOAT size,FLOAT slices,FLOAT stacks,FLOAT scaleu,FLOAT scalev);
	virtual void					CloneNewFVF(BOOL bComputeNormals=TRUE);
};

#endif // !defined(AFX_3DSPHERE_H__2CF08D81_A049_4E58_9B6F_8C591A46DFA6__INCLUDED_)
