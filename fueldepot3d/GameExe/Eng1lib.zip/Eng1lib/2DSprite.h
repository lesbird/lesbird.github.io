// 2DSprite.h: interface for the C2DSprite class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_2DSPRITE_H__CFFD19D6_75E5_45E3_9C7B_3D5B3ABDD7E8__INCLUDED_)
#define AFX_2DSPRITE_H__CFFD19D6_75E5_45E3_9C7B_3D5B3ABDD7E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DSprite.h"

class C2DSprite : public C3DSprite
{
public:
	C2DSprite();
	virtual ~C2DSprite();

	virtual void					InitSprite(string texname);
	virtual void					InitSprite(INT resid);
	virtual void					InitSprite(FLOAT sizew,FLOAT sizeh);
	virtual void					InitSpriteSize();
	virtual void					CloneNewFVF(BOOL bComputeNormals=TRUE);

	virtual void					SetPosition(FLOAT x,FLOAT y);

	virtual void					Transform();

public:
	Material_t						*SpriteMaterial;
	Texture_t						*SpriteTexture;
};

#endif // !defined(AFX_2DSPRITE_H__CFFD19D6_75E5_45E3_9C7B_3D5B3ABDD7E8__INCLUDED_)
