// Input.h: interface for the CInput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUT_H__D0B406A2_2307_11D5_9332_0010B505D77B__INCLUDED_)
#define AFX_INPUT_H__D0B406A2_2307_11D5_9332_0010B505D77B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	DIRECTINPUT_VERSION			0x800

#include "dinput.h"

class CInput  
{
public:
	CInput();
	virtual ~CInput();

	static void						Init(HINSTANCE hInstance);
	static void						UnInit();

	static void						GetMouseDelta(LONG &x,LONG &y,LONG &but);
	static void						GetJoystickData();
	static void						UpdateButtons();
	static BOOL						GetJoystickButton(DWORD num,DWORD joynum=0);
	static void						ShowJoystickData();

public:
	static LPDIRECTINPUT8			lpDirectInput8;
	static LPDIRECTINPUTDEVICE8		lpDirectInputKey;
	static LPDIRECTINPUTDEVICE8		lpDirectInputMouse;
	static LPDIRECTINPUTDEVICE8		lpDirectInputJoystick[4];

	static DIMOUSESTATE				diMouseState;
	static DIJOYSTATE2				diJoystickState[4];

	static BOOL						bButtonPressed[4];

	static DWORD					NumJoysticks;
};

extern
DWORD								MouseButton;

extern
BOOL								bControllerEnable;

#endif // !defined(AFX_INPUT_H__D0B406A2_2307_11D5_9332_0010B505D77B__INCLUDED_)
