// 3DLight.cpp: implementation of the C3DLight class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "3DLight.h"
#include "3DSphere.h"

DWORD								C3DLight::GlobalLightIndex=0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DLight::C3DLight()
{
	SetObjectID('3LIG');
	SetObjectName("C3DLIGHT");

	ZeroMemory(&D3DLight,sizeof(D3DLight));
	D3DLight.Type=D3DLIGHT_POINT;
	D3DLight.Diffuse=D3DXCOLOR(1,1,1,0);
	D3DLight.Specular=D3DXCOLOR(1,1,1,0);
	D3DLight.Ambient=D3DXCOLOR(1,1,1,0);
	D3DLight.Range=2500;
	D3DLight.Attenuation0=1;
	LightIndex=GlobalLightIndex++;

	bShowPosition=FALSE;
	PosSphere=NULL;

	bCanTouch=FALSE;
	bViewClip=FALSE;

	Mass=0;
}

C3DLight::~C3DLight()
{
	CGfx::lpD3DDevice8->LightEnable(LightIndex,FALSE);
	if (PosSphere != NULL) {
		PosSphere->DeleteMe();
		PosSphere=NULL;
	}
}

void
C3DLight::Transform()
{
	CGameObject::Transform();
	if (bShowPosition) {
		if (PosSphere == NULL) {
			PosSphere=(C3DSphere *)SPAWN('3SPH');
			PosSphere->InitSphere(1);
			PosSphere->Transparency=0.5f;
			PosSphere->bUnlit=TRUE;
			Material_t *mat=PosSphere->AddDefaultMaterial();
			mat->D3DMaterial->Diffuse=D3DLight.Diffuse;
		}
		if (PosSphere != NULL) {
			PosSphere->SetPosition(D3DXVECTOR3(WorldMatrix._41,WorldMatrix._42,WorldMatrix._43));
		}
	}
	else if (PosSphere != NULL) {
		PosSphere->DeleteMe();
		PosSphere=NULL;
	}
}

void
C3DLight::Render()
{
	CGameObject::Render();

	D3DLight.Position=D3DXVECTOR3(WorldMatrix._41,WorldMatrix._42,WorldMatrix._43);
	D3DLight.Direction=D3DXVECTOR3(D3DXToRadian(Rotation.x),D3DXToRadian(Rotation.y),D3DXToRadian(Rotation.z));
	CGfx::lpD3DDevice8->SetLight(LightIndex,&D3DLight);
	CGfx::lpD3DDevice8->LightEnable(LightIndex,TRUE);
}
