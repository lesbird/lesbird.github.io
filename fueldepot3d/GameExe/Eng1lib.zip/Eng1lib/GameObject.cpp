// GameObject.cpp: implementation of the CGameObject class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "GameObject.h"
#include "Physics.h"

#include "CollisionDetection.hpp"

DWORD								CGameObject::ActiveObjects=0;
DWORD								CGameObject::GameObjectCount=0,
									CGameObject::DeleteObjectCount=0,
									CGameObject::GarbageObjectCount=0,
									CGameObject::RenderObjectCount=0,
									CGameObject::TickObjectCount=0,
									CGameObject::TransformObjectCount=0;

GameObjectList_t					CGameObject::GameObjectList;
//	sort method 1
GameObjectList_t					CGameObject::SecondPassObjectList;
GameObjectList_t					CGameObject::SortedObjectList;
//	sort method 2
static
void								*SecondPassObjectArray[4096];
DWORD								CGameObject::SecondPassObjectCount=0;

DWORD								CGameObject::SortMethod=2;

BOOL								CGameObject::bSortObjects=TRUE;

real front_to_z_top_to_y[3][3]={{0,0,1},{0,1,0},{-1,0,0}};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameObject::CGameObject()
{
	ObjectID='GAME';
	ObjectName="CGAMEOBJECT";
	ObjectNum=GameObjectCount++;

	bActive=FALSE;
	bCanDelete=TRUE;
	bCanTouch=TRUE;
	bDeleteMe=FALSE;
	bEnable=TRUE;
	bFarClip=TRUE;
	bHidden=FALSE;
	bInView=TRUE;
	bNoFog=FALSE;
	bOnGround=FALSE;
	bStatic=FALSE;
	bTransform=TRUE;
	bViewClip=TRUE;

	BoundingBoxMax=D3DXVECTOR3(0,0,0);
	BoundingBoxMin=D3DXVECTOR3(0,0,0);
	BoundingSpherePoint=D3DXVECTOR3(0,0,0);
	LastPosition=D3DXVECTOR3(0,0,0);
	Position=D3DXVECTOR3(0,0,0);
	RotationRateVec=D3DXVECTOR3(0,0,0);
	D3DXQuaternionIdentity(&Rotation);
	D3DXQuaternionIdentity(&RotationRate);

	D3DXMatrixIdentity(&WorldMatrix);

	BoundingSphereRadius=0;
	CollisionRadius=0;
	LifeSpan=0;
	Radius=BoundingSphereRadius;
	ScaleX=ScaleY=ScaleZ=1;
	Timer=0;
	ViewDist=0;

	Acceleration=D3DXVECTOR3(0,0,0);
	Gravity=D3DXVECTOR3(0,0,0);
	Impulse=D3DXVECTOR3(0,0,0);
	Velocity=D3DXVECTOR3(0,0,0);

	CollisionType=COLLTYPE_SPHERE;
	CollisionGridIndex=-1;
	CollisionGridX=-1;
	CollisionGridY=-1;

	SetMass(1.0f);

	Thrust=0;

	Instigator=NULL;
	ParentObject=NULL;
	ChildObjectList.clear();
	NotifyList.clear();
	TouchedObjectList.clear();
	TouchFilterList.clear();

	RigidBody=NULL;

	GameObjectList.push_back(this);
}

CGameObject::~CGameObject()
{
	if (CGfx::ViewFollowObject == this) {
		CGfx::ViewFollowObject=NULL;
	}
	if (ChildObjectList.size() != 0) {
		for (GameObjectList_t::iterator o=ChildObjectList.begin() ; o != ChildObjectList.end() ; o++) {
			CGameObject *gobj=(*o);
			gobj->ParentDeleted();
		}
		ChildObjectList.clear();
	}
	if (ParentObject != NULL) {
		ParentObject->ChildObjectList.remove(this);
	}
	if (TouchedObjectList.size() != 0) {
		for (GameObjectList_t::iterator o=TouchedObjectList.begin() ; o != TouchedObjectList.end() ; o++) {
			CGameObject *gobj=(*o);
			gobj->UnTouch(this);
		}
		TouchedObjectList.clear();
	}
	while (TouchFilterList.size() != 0) {
		CGameObject *gobj=(*TouchFilterList.begin());
		gobj->UnFilterObject(this);
	}
	if (NotifyList.size() != 0) {
		for (GameObjectList_t::iterator o=NotifyList.begin() ; o != NotifyList.end() ; o++) {
			CGameObject *gobj=(*o);
			gobj->NotifyDelete(this);
		}
		NotifyList.clear();
	}
}

void
CGameObject::ParentDeleted()
{
	ParentObject=NULL;
	DeleteMe();
}

void
CGameObject::SetObjectID(DWORD id)
{
	ObjectID=id;
}

void
CGameObject::SetObjectName(string name)
{
	ObjectName.append("_"+name);
}

BOOL
CGameObject::IsA(string name)
{
	if (ObjectName.find(name) != -1) {
		return(TRUE);
	}
	return(FALSE);
}

void
CGameObject::Init()
{
}

void
CGameObject::UnInit()
{
}

void
CGameObject::ActivateApp()
{
}

void
CGameObject::DeActivateApp()
{
}

void
CGameObject::InitRigidBody()
{
	UnInitRigidBody();
	RigidBody=new CRigidBody;
}

void
CGameObject::UnInitRigidBody()
{
	SAFE_DELETE(RigidBody);
}

void
CGameObject::BuildCubeRigidBody(FLOAT x,FLOAT y,FLOAT z,FLOAT mass,BOOL bIsStatic)
{
	FLOAT	toi[3];

	if (RigidBody == NULL) {
		InitRigidBody();
	}
	CuboidMomentsOfInertia(toi,mass,x,y,z);
	D3DXVECTOR3 grav=(bIsStatic) ? D3DXVECTOR3(0,0,0) : Physics->Gravity;
	RigidBody->Build(grav,toi,mass);
	RigidBody->SetOrientation(front_to_z_top_to_y);
	bStatic=bIsStatic;
	SetMass(mass);
}

void
CGameObject::BuildSphereRigidBody(FLOAT radius,FLOAT mass,BOOL bIsStatic)
{
	FLOAT	toi[3];

	if (RigidBody == NULL) {
		InitRigidBody();
	}
	toi[0]=toi[1]=toi[2]=2.0f/5.0f*pow(radius,4.0f)*mass;
	D3DXVECTOR3 grav=(bIsStatic) ? D3DXVECTOR3(0,0,0) : Physics->Gravity;
	RigidBody->Build(grav,toi,pow(radius,2)*mass);
	RigidBody->SetOrientation(front_to_z_top_to_y);
	bStatic=bIsStatic;
	SetMass(mass);
}

void
CGameObject::BuildCylinderRigidBody(FLOAT radius,FLOAT height,FLOAT mass,BOOL bIsStatic)
{
	FLOAT	toi[3];

	if (RigidBody == NULL) {
		InitRigidBody();
	}
	CylinderMomentsOfInertia(toi,mass,radius,height);
	D3DXVECTOR3 grav=(bIsStatic) ? D3DXVECTOR3(0,0,0) : Physics->Gravity;
	RigidBody->Build(grav,toi,mass);
	RigidBody->SetOrientation(front_to_z_top_to_y);
	bStatic=bIsStatic;
	SetMass(mass);
}

void
CGameObject::BuildPlaneRigidBody(FLOAT width,FLOAT height,FLOAT mass,BOOL bIsStatic)
{
	FLOAT	toi[3];

	if (RigidBody == NULL) {
		InitRigidBody();
	}
	toi[0]=1;
	toi[1]=height;
	toi[2]=width;
	D3DXVECTOR3 grav=(bIsStatic) ? D3DXVECTOR3(0,0,0) : Physics->Gravity;
	RigidBody->Build(grav,toi,mass);
	RigidBody->SetOrientation(front_to_z_top_to_y);
	bStatic=bIsStatic;
	SetMass(mass);
}

void
CGameObject::RigidBodyTransform()
{
	FLOAT	p[3];
	RigidBody->GetPosition(p);
	Position=D3DXVECTOR3(p[0],p[1],p[2]);
	FLOAT	q[4];
	RigidBody->GetQuaternion(q);
	Rotation=D3DXQUATERNION(q[1],q[2],q[3],q[0]);
}

void
CGameObject::Link(CGameObject *gobj)
{
	if (gobj != NULL) {
		if (ParentObject != NULL) {
			UnLink();
		}
		ParentObject=gobj;
		gobj->ChildObjectList.push_back(this);
	}
}

void
CGameObject::UnLink()
{
	if (ParentObject != NULL) {
		ParentObject->ChildObjectList.remove(this);
	}
	ParentObject=NULL;
}

void
CGameObject::SetMass(FLOAT m)
{
	Mass=m;
	MassFraction=1.0f/Mass;
}

void
CGameObject::SetPosition(FLOAT x,FLOAT y,FLOAT z)
{
	if (ParentObject != NULL) {
		Position=D3DXVECTOR3(x,y,z);
	}
	else {
		if (RigidBody != NULL) {
			RigidBody->SetPosition(x,y,z);
		}
		else {
			WorldMatrix._41=x;
			WorldMatrix._42=y;
			WorldMatrix._43=z;
			Position=D3DXVECTOR3(WorldMatrix._41,WorldMatrix._42,WorldMatrix._43);
		}
	}
}

void
CGameObject::SetPosition(const D3DXVECTOR3 p)
{
	SetPosition(p.x,p.y,p.z);
}

void
CGameObject::AddPosition(FLOAT x,FLOAT y,FLOAT z)
{
	if (ParentObject != NULL) {
		ParentObject->AddPosition(x,y,z);
	}
	else {
		if (RigidBody != NULL) {
			FLOAT	p[3];
			RigidBody->GetPosition(p);
			RigidBody->SetPosition(p[0]+x,p[1]+y,p[2]+z);
		}
		else {
			WorldMatrix._41+=x;
			WorldMatrix._42+=y;
			WorldMatrix._43+=z;
			Position=D3DXVECTOR3(WorldMatrix._41,WorldMatrix._42,WorldMatrix._43);
		}
	}
	bActive=TRUE;
}

void
CGameObject::AddPosition(const D3DXVECTOR3 p)
{
	AddPosition(p.x,p.y,p.z);
}

D3DXVECTOR3
CGameObject::GetPosition()
{
	D3DXVECTOR3	v;
	if (RigidBody != NULL) {
		FLOAT	p[3];
		RigidBody->GetPosition(p);
		v=D3DXVECTOR3(p[0],p[1],p[2]);
	}
	else {
		v=D3DXVECTOR3(WorldMatrix._41,WorldMatrix._42,WorldMatrix._43);
	}
	return(v);
}

void
CGameObject::SetRotation(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXQuaternionRotationYawPitchRoll(&Rotation,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
	if (RigidBody != NULL) {
		RigidBody->SetQuaternion(Rotation.w,Rotation.x,Rotation.y,Rotation.z);
	}
}

void
CGameObject::SetRotation(const D3DXVECTOR3 r)
{
	SetRotation(r.x,r.y,r.z);
}

void
CGameObject::AddRotation(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXQUATERNION q1;
	D3DXQuaternionRotationYawPitchRoll(&q1,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
	D3DXQuaternionMultiply(&Rotation,&Rotation,&q1);
	if (RigidBody != NULL) {
		RigidBody->SetQuaternion(Rotation.w,Rotation.x,Rotation.y,Rotation.z);
	}
}

void
CGameObject::AddRotation(const D3DXVECTOR3 r)
{
	AddRotation(r.x,r.y,r.z);
}

D3DXVECTOR3
CGameObject::GetRotation()
{
	D3DXVECTOR3	r;
	r.x=D3DXToDegree(asinf(WorldMatrix._32));
	if (cosf(D3DXToRadian(r.x)) == 0) {
		r.y=0;
		r.z=D3DXToDegree(atan2f(WorldMatrix._21,WorldMatrix._11));
	}
	else {
		r.y=D3DXToDegree(atan2f(-WorldMatrix._31,WorldMatrix._33));
		r.z=D3DXToDegree(atan2f(-WorldMatrix._12,WorldMatrix._22));
	}
	r.x=(r.x > 0) ? 360-r.x : fabsf(r.x);
	if (r.x == 360.0f) {
		r.x=0;
	}
	r.y=(r.y > 0) ? 360-r.y : fabsf(r.y);
	if (r.y == 360.0f) {
		r.y=0;
	}
	r.z=(r.z > 0) ? 360-r.z : fabsf(r.z);
	if (r.z == 360.0f) {
		r.z=0;
	}
	return(r);
}

D3DXVECTOR3
CGameObject::GetRotation(D3DXQUATERNION qrot)
{
	D3DXMATRIX	mat;
	D3DXMatrixRotationQuaternion(&mat,&qrot);
	D3DXVECTOR3	r;
	r.x=D3DXToDegree(asinf(mat._32));
	if (cosf(D3DXToRadian(r.x)) == 0) {
		r.y=0;
		r.z=D3DXToDegree(atan2f(mat._21,mat._11));
	}
	else {
		r.y=D3DXToDegree(atan2f(-mat._31,mat._33));
		r.z=D3DXToDegree(atan2f(-mat._12,mat._22));
	}
	r.x=(r.x > 0) ? 360-r.x : fabsf(r.x);
	if (r.x == 360.0f) {
		r.x=0;
	}
	r.y=(r.y > 0) ? 360-r.y : fabsf(r.y);
	if (r.y == 360.0f) {
		r.y=0;
	}
	r.z=(r.z > 0) ? 360-r.z : fabsf(r.z);
	if (r.z == 360.0f) {
		r.z=0;
	}
	return(r);
}

void
CGameObject::SetRotationRate(FLOAT x,FLOAT y,FLOAT z)
{
	if (RigidBody != NULL) {
		RigidBody->SetAngularVelocity(D3DXToRadian(x),D3DXToRadian(y),D3DXToRadian(z));
	}
	else {
		RotationRateVec=D3DXVECTOR3(x,y,z);
		D3DXQuaternionRotationYawPitchRoll(&RotationRate,D3DXToRadian(y),D3DXToRadian(x),D3DXToRadian(z));
	}
}

void
CGameObject::SetRotationRate(const D3DXVECTOR3 r)
{
	SetRotationRate(r.x,r.y,r.z);
}

void
CGameObject::SetVelocity(FLOAT x,FLOAT y,FLOAT z)
{
	if (RigidBody != NULL) {
		RigidBody->SetVelocity(x,y,z);
	}
	else {
		Velocity=D3DXVECTOR3(x,y,z);
	}
}

void
CGameObject::SetVelocity(const D3DXVECTOR3 v)
{
	SetVelocity(v.x,v.y,v.z);
}

FLOAT
CGameObject::GetScale()
{
	return(__max(__max(ScaleX,ScaleY),ScaleZ));
}

D3DXVECTOR3
CGameObject::TransformPoint(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXVECTOR3 v=TransformVector(x,y,z);
	v+=GetPosition();
	return(v);
}

D3DXVECTOR3
CGameObject::TransformPoint(const D3DXVECTOR3 p)
{
	return(TransformPoint(p.x,p.y,p.z));
}

D3DXVECTOR3
CGameObject::TransformVector(FLOAT x,FLOAT y,FLOAT z)
{
	D3DXVECTOR3 v(x,y,z);
	D3DXVec3TransformNormal(&v,&v,&WorldMatrix);
	return(v);
}

D3DXVECTOR3
CGameObject::TransformVector(const D3DXVECTOR3 v)
{
	return(TransformVector(v.x,v.y,v.z));
}

void
CGameObject::Transform()
{
	if (bTransform) {
		D3DXVECTOR3	dx;
		D3DXVECTOR3	ScaleVector(ScaleX,ScaleY,ScaleZ);
		if (ParentObject == NULL) {
			if (RigidBody != NULL) {
				RigidBodyTransform();
			}
			D3DXMatrixTransformation(&WorldMatrix,NULL,NULL,&ScaleVector,NULL,&Rotation,&Position);
			D3DXVec3Subtract(&dx,&Position,&CGfx::ViewPosition);
		}
		else {
			D3DXMATRIX mat;
			D3DXMatrixRotationQuaternion(&mat,&ParentObject->Rotation);
			D3DXVECTOR3	pos;
			D3DXVec3TransformNormal(&pos,&Position,&mat);
			pos+=ParentObject->GetPosition();
			D3DXQUATERNION	parrot;
			D3DXQuaternionRotationMatrix(&parrot,&mat);
			D3DXQUATERNION	rot;
			D3DXQuaternionMultiply(&rot,&Rotation,&parrot);
			D3DXMatrixTransformation(&WorldMatrix,NULL,NULL,&ScaleVector,NULL,&rot,&pos);
			D3DXVec3Subtract(&dx,&pos,&CGfx::ViewPosition);
		}
		bInView=IsInView(dx);
		TransformObjectCount++;
		return;
	}
	bInView=FALSE;
}

BOOL
CGameObject::IsInView(const D3DXVECTOR3 dx)
{
	if (bHidden) {
		return(FALSE);
	}
	BOOL bIn=TRUE;
	ViewDist=D3DXVec3Length(&dx);
	if (bViewClip) {
		bIn=FALSE;
		FLOAT Scale=GetScale();
		if (ViewDist < (BoundingSphereRadius*Scale)) {
			bIn=TRUE;
		}
		else {
			if (ViewDist != 0) {
				D3DXVECTOR3 dxz(dx.x,0,dx.z);
				FLOAT ViewDistZ=D3DXVec3Length(&dxz);
				if (!bFarClip || ViewDistZ < CGfx::FarClip+(BoundingSphereRadius*Scale)) {
					D3DXVECTOR3	dxn;
					D3DXVec3Normalize(&dxn,&dx);
					FLOAT d=D3DXVec3Dot(&CGfx::ViewDirVec,&dxn)+((BoundingSphereRadius*Scale)/ViewDist);
					if (d > CGfx::FieldOfView) {
						bIn=TRUE;
					}
				}
			}
		}
	}
	else {
		bIn=TRUE;
	}
	return(bIn);
}

void
CGameObject::PreRender()
{
}

void
CGameObject::Render()
{
	if (!bHidden) {
		RenderObjectCount++;
	}
}

void
CGameObject::PostRender()
{
}

DWORD
CGameObject::RenderPass()
{
	return(0);
}

void
CGameObject::DeleteMe()
{
	bHidden=TRUE;
	bDeleteMe=TRUE;
	DeleteObjectCount++;
}

BOOL
CGameObject::IntersectTest(CGameObject *gobj)
{
	if (RigidBody == NULL) {
		D3DXVECTOR3 pos1=GetPosition();
		D3DXVECTOR3 pos2=gobj->GetPosition();
		D3DXVECTOR3	v;
		D3DXVec3Subtract(&v,&pos1,&pos2);
		FLOAT dist=D3DXVec3Length(&v);
		if (dist < (CollisionRadius*GetScale())+(gobj->CollisionRadius*gobj->GetScale())) {
			return(TRUE);
		}
	}
	else {
		CBox	box1,box2;
		RigidBody->GetPosition(box1.center);
		RigidBody->GetOrientation(box1.axis);
		box1.extent[0]=(BoundingBoxMax.x-BoundingBoxMin.x)/2;
		box1.extent[1]=(BoundingBoxMax.y-BoundingBoxMin.y)/2;
		box1.extent[2]=(BoundingBoxMax.z-BoundingBoxMin.z)/2;
		if (gobj->RigidBody != NULL) {
			gobj->RigidBody->GetPosition(box2.center);
			gobj->RigidBody->GetOrientation(box2.axis);
			box2.extent[0]=(gobj->BoundingBoxMax.x-gobj->BoundingBoxMin.x)/2;
			box2.extent[1]=(gobj->BoundingBoxMax.y-gobj->BoundingBoxMin.y)/2;
			box2.extent[2]=(gobj->BoundingBoxMax.z-gobj->BoundingBoxMin.z)/2;
			FLOAT n[3],p[3],pen;
			if (BoxBoxCollisionDetection(n,p,pen,box1,box2)) {
				Physics->AddContact(this,gobj,D3DXVECTOR3(n[0],n[1],n[2]),D3DXVECTOR3(p[0],p[1],p[2]),pen);
				return(TRUE);
			}
		}
	}
	return(FALSE);
}

void
CGameObject::IntersectPassed(CGameObject *gobj)
{
	BOOL bIsTouching=IsTouching(gobj);
	if (bIsTouching) {
		Touching(gobj);
		gobj->Touching(this);
		return;
	}
	Touch(gobj);
	gobj->Touch(this);
}

void
CGameObject::IntersectFailed(CGameObject *gobj)
{
	BOOL bIsTouching=IsTouching(gobj);
	if (bIsTouching) {
		UnTouch(gobj);
		gobj->UnTouch(this);
	}
}

void
CGameObject::Touch(CGameObject *gobj)
{
	TouchedObjectList.push_back(gobj);
	CGameType::GameType->PreObjectCollision(this,gobj);

	if (RigidBody == NULL) {
		if (Mass != 0) {
			D3DXVECTOR3 pos1=GetPosition();
			D3DXVECTOR3 pos2=gobj->GetPosition();
			D3DXVECTOR3 v;
			D3DXVec3Subtract(&v,&pos1,&pos2);
			FLOAT dist=D3DXVec3Length(&v);
			FLOAT Scale=GetScale();
			FLOAT r1=CollisionRadius*Scale;
			FLOAT r2=gobj->CollisionRadius*gobj->GetScale();
			FLOAT d=((r1+r2)-dist);
			D3DXVec3Normalize(&v,&v);
			D3DXVECTOR3	v1;
			if (d > 0) {
				if (gobj->Mass != 0) {
					D3DXVec3Scale(&v1,&v,d*0.5f);
				}
				else {
					D3DXVec3Scale(&v1,&v,d);
				}
				AddPosition(v1);
			}
			v1=gobj->Velocity;
			FLOAT s2=D3DXVec3Length(&v1);
			FLOAT m2=s2*gobj->Mass;
			if (m2 > 0) {
				D3DXVec3Scale(&v1,&v,(m2/Mass));
				D3DXVec3Add(&Impulse,&Impulse,&v1);
			}
		}
	}

	CGameType::GameType->PostObjectCollision(this,gobj);
}

void
CGameObject::UnTouch(CGameObject *gobj)
{
	TouchedObjectList.remove(gobj);
}

void
CGameObject::Touching(CGameObject *gobj)
{
	if (RigidBody == NULL) {
		if (Mass != 0) {
			D3DXVECTOR3 pos1=GetPosition();
			D3DXVECTOR3 pos2=gobj->GetPosition();
			D3DXVECTOR3 v;
			D3DXVec3Subtract(&v,&pos1,&pos2);
			FLOAT dist=D3DXVec3Length(&v);
			FLOAT r1=CollisionRadius;
			FLOAT r2=gobj->CollisionRadius;
			FLOAT d=((r1+r2)-dist);
			D3DXVec3Normalize(&v,&v);
			D3DXVECTOR3	v1;
			if (d > 0) {
				if (gobj->Mass != 0) {
					D3DXVec3Scale(&v1,&v,d*0.5f);
				}
				else {
					D3DXVec3Scale(&v1,&v,d);
				}
				AddPosition(v1);
			}
		}
	}
}

void
CGameObject::FilterObject(CGameObject *gobj)
{
	TouchFilterList.push_back(gobj);
	gobj->TouchFilterList.push_back(this);
}

void
CGameObject::FilterObject(DWORD objid)
{
	FilterObjectID=objid;
}

void
CGameObject::UnFilterObject(CGameObject *gobj)
{
	TouchFilterList.remove(gobj);
	gobj->TouchFilterList.remove(this);
}

BOOL
CGameObject::IsFiltered(CGameObject *gobj)
{
	if (FilterObjectID == gobj->ObjectID) {
		return(TRUE);
	}
	for (GameObjectList_t::iterator o=TouchFilterList.begin() ; o != TouchFilterList.end() ; o++) {
		CGameObject *fobj=(*o);
		if (fobj == gobj) {
			return(TRUE);
		}
	}
	return(FALSE);
}

BOOL
CGameObject::IsTouching(CGameObject *gobj)
{
	for (GameObjectList_t::iterator o=TouchedObjectList.begin() ; o != TouchedObjectList.end() ; o++) {
		CGameObject *tobj=(*o);
		if (tobj == gobj) {
			return(TRUE);
		}
	}
	return(FALSE);
}

BOOL
CGameObject::CanTouch(CGameObject *gobj)
{
	if (ParentObject == gobj || gobj->ParentObject == this) {
		return(FALSE);
	}
	return(IsFiltered(gobj) ? FALSE : TRUE);
}

void
CGameObject::Notify(CGameObject *gobj)
{
	NotifyList.push_back(gobj);
	gobj->NotifyList.push_back(this);
}

void
CGameObject::NotifyDelete(CGameObject *gobj)
{
	NotifyList.remove(gobj);
}

void
CGameObject::Tick(FLOAT delta)
{
	Timer+=delta;
	if (!bPause) {
		DoLifeSpan(delta);
		if (bDeleteMe) {
			return;
		}
		DoRotationRate(delta);
		DoPhysics(delta);
	}
	TickObjectCount++;
}

void
CGameObject::DoLifeSpan(FLOAT delta)
{
	if (LifeSpan != 0) {
		LifeSpan-=delta;
		if (LifeSpan <= 0) {
			LifeSpan=0;
			DeleteMe();
		}
	}
}

void
CGameObject::DoRotationRate(FLOAT delta)
{
	if (RigidBody == NULL) {
		if (!D3DXQuaternionIsIdentity(&RotationRate)) {
			D3DXQUATERNION	quat;
			D3DXQuaternionMultiply(&quat,&Rotation,&RotationRate);
			D3DXQuaternionSlerp(&Rotation,&Rotation,&quat,delta);
		}
	}
}

void
CGameObject::DoPhysics(FLOAT delta)
{
	if (RigidBody != NULL) {
		if (!bStatic) {
			RigidBody->RungeKuttaEvolve(delta);
		}
	}
	else if (Physics != NULL) {
		Physics->DoPhysics(this,delta);
	}
}

void
CGameObject::RecordDemo()
{
}

void
CGameObject::PlaybackDemo()
{
}

void
CGameObject::TransformChildObjects(CGameObject *gobj,GameObjectList_t::iterator c)
{
	if (c == gobj->ChildObjectList.end()) {
		return;
	}
	CGameObject *cobj=(*c++);
	if (!cobj->bDeleteMe) {
		cobj->Transform();
		TransformChildObjects(cobj,cobj->ChildObjectList.begin());
		TransformChildObjects(gobj,c);
	}
}

void
CGameObject::TransformGameObjects(GameObjectList_t::iterator o)
{
	if (o == GameObjectList.end()) {
		return;
	}
	CGameObject *gobj=(*o++);
	if (!gobj->bDeleteMe) {
		if (gobj->ParentObject == NULL) {
			gobj->Transform();
			TransformChildObjects(gobj,gobj->ChildObjectList.begin());
		}
	}
	TransformGameObjects(o);
}

void
CGameObject::PreRenderAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			continue;
		}
		gobj->PreRender();
	}
}

void
CGameObject::PostRenderAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			continue;
		}
		gobj->PostRender();
	}
}

void
CGameObject::RenderAllObjects()
{
	TransformGameObjects(GameObjectList.begin());
	for (CGfx::RenderPass=0 ; CGfx::RenderPass < 2 ; CGfx::RenderPass++) {
		switch (CGfx::RenderPass) {
		case 0:
			{
				CGfx::SetZBufferWrite(TRUE);
				if (SortMethod == 1) {
					SecondPassObjectList.clear();
				}
				else {
					SecondPassObjectCount=0;
				}
				for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
					CGameObject *gobj=(*o);
					if (gobj->bDeleteMe) {
						continue;
					}
					if (gobj->bInView) {
						if (gobj->RenderPass() == CGfx::RenderPass) {
							gobj->Render();
						}
						else {
							if (SortMethod == 1) {
								SecondPassObjectList.push_back(gobj);
							}
							else {
								SecondPassObjectArray[SecondPassObjectCount++]=gobj;
							}
						}
					}
				}
			}
			break;
		case 1:
			{
				CGfx::SetZBufferWrite(FALSE);
				if (SortMethod != 0) {
					SortSecondPassObjects();
					if (SortMethod == 1) {
						for (GameObjectList_t::iterator o=SortedObjectList.begin() ; o != SortedObjectList.end() ; o++) {
							CGameObject *gobj=(*o);
							RenderSecondPassObject(gobj);
						}
					}
					else if (SortMethod == 2) {
						for (DWORD n=0 ; n < SecondPassObjectCount ; n++) {
							CGameObject *gobj=(CGameObject *)SecondPassObjectArray[n];
							RenderSecondPassObject(gobj);
						}
					}
				}
				else {
					for (DWORD n=0 ; n < SecondPassObjectCount ; n++) {
						CGameObject *gobj=(CGameObject *)SecondPassObjectArray[n];
						RenderSecondPassObject(gobj);
					}
				}
			}
			break;
		}
	}
}

void
CGameObject::RenderSecondPassObject(CGameObject *gobj)
{
	if (gobj->bDeleteMe) {
		return;
	}
	gobj->Render();
}

void
CGameObject::TickAllObjects(FLOAT delta)
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			continue;
		}
		if (gobj->bEnable) {
			gobj->Tick(delta);
		}
	}
}

int
SecondPassObjectComp(const void *elem1,const void *elem2)
{
	CGameObject *gobj1=(CGameObject *)elem1;
	CGameObject *gobj2=(CGameObject *)elem2;
	if (gobj1->ViewDist < gobj2->ViewDist) {
		return(1);
	}
	else if (gobj1->ViewDist > gobj2->ViewDist) {
		return(-1);
	}
	return(0);
}

void
CGameObject::SortSecondPassObjects()
{
	if (SortMethod == 1) {
		SortedObjectList.clear();
		for (GameObjectList_t::iterator o1=SecondPassObjectList.begin() ; o1 != SecondPassObjectList.end() ; o1++) {
			CGameObject *gobj1=(*o1);
			if (gobj1->bDeleteMe) {
				continue;
			}
			if (gobj1->bInView) {
				for (GameObjectList_t::iterator o2=SortedObjectList.begin() ; o2 != SortedObjectList.end() ; o2++) {
					CGameObject *gobj2=(*o2);
					if (gobj2->bDeleteMe) {
						continue;
					}
					if (gobj1->ViewDist > gobj2->ViewDist) {
						SortedObjectList.insert(o2,gobj1);
						break;
					}
				}
				if (o2 == SortedObjectList.end()) {
					SortedObjectList.push_back(gobj1);
				}
			}
		}
	}
	else {
		qsort(&SecondPassObjectArray[0],SecondPassObjectCount,sizeof(void *),SecondPassObjectComp);
	}
}

void
CGameObject::GarbageCleanUp()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; ) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			GarbageObjectCount++;
			GameObjectList_t::iterator i=GameObjectList.erase(o);
			SAFE_DELETE(gobj);
			o=i;
		}
		else {
			o++;
		}
	}
}

void
CGameObject::RecordDemoAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			continue;
		}
		gobj->RecordDemo();
	}
}

void
CGameObject::PlaybackDemoAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			continue;
		}
		gobj->PlaybackDemo();
	}
}

void
CGameObject::DeleteAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bCanDelete) {
			gobj->DeleteMe();
		}
	}
	GarbageCleanUp();
}

void
CGameObject::DeleteAllObjects(string objname)
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bCanDelete) {
			if (gobj->IsA(objname)) {
				gobj->DeleteMe();
			}
		}
	}
}

void
CGameObject::ActivateAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (!gobj->bDeleteMe) {
			gobj->ActivateApp();
		}
	}
}

void
CGameObject::DeActivateAllObjects()
{
	for (GameObjectList_t::iterator o=GameObjectList.begin() ; o != GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (!gobj->bDeleteMe) {
			gobj->DeActivateApp();
		}
	}
}

void
CGameObject::ResetStatData()
{
	DeleteObjectCount=0;
	GarbageObjectCount=0;
	RenderObjectCount=0;
	TickObjectCount=0;
	TransformObjectCount=0;
}

void
CGameObject::Enter(char *fmt,...)
{
	char	buf[256];
	va_list	argptr;

	va_start(argptr,fmt);
	vsprintf(buf,fmt,argptr);
	va_end(argptr);
	Log("+%s->%s",ObjectName.c_str(),buf);
	LogLevel++;
}
