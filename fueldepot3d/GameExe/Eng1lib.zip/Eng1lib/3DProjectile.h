// 3DProjectile.h: interface for the C3DProjectile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DPROJECTILE_H__EA79A813_17A6_403E_8DBF_561C3CE499E6__INCLUDED_)
#define AFX_3DPROJECTILE_H__EA79A813_17A6_403E_8DBF_561C3CE499E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DSprite.h"

class C3DProjectile : public C3DSprite  
{
public:
	C3DProjectile();
	virtual ~C3DProjectile();

	virtual BOOL					CanTouch(CGameObject *gobj);
	virtual void					Touch(CGameObject *gobj);

	virtual void					Tick(FLOAT delta);
};

#endif // !defined(AFX_3DPROJECTILE_H__EA79A813_17A6_403E_8DBF_561C3CE499E6__INCLUDED_)
