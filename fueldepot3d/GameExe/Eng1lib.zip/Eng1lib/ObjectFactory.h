// ObjectFactory.h: interface for the CObjectFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OBJECTFACTORY_H__D563E5C9_10A5_4AF1_B626_05BD8F253DF5__INCLUDED_)
#define AFX_OBJECTFACTORY_H__D563E5C9_10A5_4AF1_B626_05BD8F253DF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class	CGameObject;

class CObjectFactory  
{
public:
	CObjectFactory();
	virtual ~CObjectFactory();

	static CGameObject				*SpawnObject(unsigned long id);
};

#define	SPAWN(id)					(CObjectFactory::SpawnObject(id))

#endif // !defined(AFX_OBJECTFACTORY_H__D563E5C9_10A5_4AF1_B626_05BD8F253DF5__INCLUDED_)
