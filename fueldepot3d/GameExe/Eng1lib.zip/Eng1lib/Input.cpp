// Input.cpp: implementation of the CInput class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "Input.h"

LPDIRECTINPUT8						CInput::lpDirectInput8=NULL;
LPDIRECTINPUTDEVICE8				CInput::lpDirectInputKey=NULL;
LPDIRECTINPUTDEVICE8				CInput::lpDirectInputMouse=NULL;
LPDIRECTINPUTDEVICE8				CInput::lpDirectInputJoystick[4]={NULL,NULL,NULL,NULL};

DIMOUSESTATE						CInput::diMouseState;
DIJOYSTATE2							CInput::diJoystickState[4];

BOOL								CInput::bButtonPressed[4];

DWORD								CInput::NumJoysticks;

LPDIRECTINPUTDEVICE8				CurrentJoystick=NULL;

DWORD								MouseButton;

DIDEVCAPS							diJoystickCaps;
BYTE								JoystickButtons[4][128];

extern
HWND								hWnd;

BOOL								bControllerEnable=TRUE;

static
BOOL CALLBACK
EnumJoysticksCallback(const DIDEVICEINSTANCE *pdidInstance,VOID *pContext);

static
BOOL CALLBACK
EnumObjectsCallback(LPCDIDEVICEOBJECTINSTANCE lpddoi,LPVOID pvref);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInput::CInput()
{

}

CInput::~CInput()
{

}

void
CInput::Init(HINSTANCE hInstance)
{
	Enter("CInput::Init()");

	HRESULT hr=DirectInput8Create(hInstance,DIRECTINPUT_VERSION,IID_IDirectInput8,(void **)&lpDirectInput8,NULL);
	if (FAILED(hr)) {
		Log("DirectInput8Create() FAILED");
		Leave();
		return;
	}
/*
	hr=lpDirectInput8->CreateDevice(GUID_SysMouse,&lpDirectInputMouse,NULL);
	if (FAILED(hr)) {
		Log("lpDirectInput8->CreateDevice() FAILED");
		UnInit();
		return;
	}
	if (lpDirectInputMouse != NULL) {
		hr=lpDirectInputMouse->SetCooperativeLevel(hWnd,DISCL_EXCLUSIVE|DISCL_FOREGROUND);
		if (FAILED(hr)) {
			Log("lpDirectInputMouse->SetCooperativeLevel() FAILED");
			UnInit();
			return;
		}
		hr=lpDirectInputMouse->SetDataFormat(&c_dfDIMouse);
		if (FAILED(hr)) {
			Log("lpDirectInputMouse->SetDataFormat() FAILED");
			UnInit();
			return;
		}
		DIPROPDWORD		diPropDWord;
		diPropDWord.diph.dwSize=sizeof(DIPROPDWORD);
		diPropDWord.diph.dwHeaderSize=sizeof(DIPROPHEADER);
		diPropDWord.diph.dwHow=0;
		diPropDWord.diph.dwObj=0;
		diPropDWord.dwData=DIPROPAXISMODE_REL;
		hr=lpDirectInputMouse->SetProperty(DIPROP_AXISMODE,&diPropDWord.diph);
		if (FAILED(hr)) {
			Log("lpDirectInputMouse->SetProperty() FAILED");
			UnInit();
			return;
		}
		else {
			hr=lpDirectInputMouse->Acquire();
			if (FAILED(hr)) {
				Log("lpDirectInputMouse->Acquire() FAILED");
				UnInit();
				return;
			}
		}
	}
*/
	NumJoysticks=0;
	lpDirectInput8->EnumDevices(DI8DEVCLASS_GAMECTRL,EnumJoysticksCallback,NULL,DIEDFL_ATTACHEDONLY);
	for (DWORD joynum=0 ; joynum < NumJoysticks ; joynum++) {
		bButtonPressed[joynum]=FALSE;
		if (lpDirectInputJoystick[joynum] != NULL) {
			CurrentJoystick=lpDirectInputJoystick[joynum];
			lpDirectInputJoystick[joynum]->SetDataFormat(&c_dfDIJoystick2);
			lpDirectInputJoystick[joynum]->SetCooperativeLevel(hWnd,DISCL_EXCLUSIVE|DISCL_FOREGROUND);
			diJoystickCaps.dwSize=sizeof(DIDEVCAPS);
			lpDirectInputJoystick[joynum]->GetCapabilities(&diJoystickCaps);
			lpDirectInputJoystick[joynum]->EnumObjects(EnumObjectsCallback,(VOID *)hWnd,DIDFT_ALL);
		}
	}

	Leave();
}

void
CInput::UnInit()
{
	Enter("CInput::UnInit()");

	for (DWORD n=0 ; n < 4 ; n++) {
		if (lpDirectInputJoystick[n] != NULL) {
			lpDirectInputJoystick[n]->Unacquire();
			SAFE_RELEASE(lpDirectInputJoystick[n]);
		}
	}
	if (lpDirectInputMouse != NULL) {
		lpDirectInputMouse->Unacquire();
		SAFE_RELEASE(lpDirectInputMouse);
	}
	if (lpDirectInput8 != NULL) {
		SAFE_RELEASE(lpDirectInput8);
	}

	Leave();
}

void
CInput::GetMouseDelta(LONG &x,LONG &y,LONG &but)
{
	x=0;
	y=0;
	but=0;
	if (lpDirectInputMouse != NULL) {
		HRESULT hr=lpDirectInputMouse->GetDeviceState(sizeof(DIMOUSESTATE),&diMouseState);
		if (hr == DIERR_INPUTLOST) {
			lpDirectInputMouse->Acquire();
		}
		else {
			x=diMouseState.lX;
			y=diMouseState.lY;
			for (short n=0 ; n < 4 ; n++) {
				if (diMouseState.rgbButtons[n] != 0) {
					but|=(1<<n);
				}
			}
		}
	}
	MouseButton=but;
}

void
CInput::GetJoystickData()
{
	for (DWORD joynum=0 ; joynum < NumJoysticks ; joynum++) {
		if (!bControllerEnable) {
			memset(&diJoystickState[joynum],0,sizeof(DIJOYSTATE2));
			return;
		}
		if (lpDirectInputJoystick[joynum] == NULL) {
			return;
		}
		HRESULT hr=lpDirectInputJoystick[joynum]->Poll();
		if (FAILED(hr)) {
			hr=lpDirectInputJoystick[joynum]->Acquire();
			while (hr == DIERR_INPUTLOST) {
				lpDirectInputJoystick[joynum]->Acquire();
			}
			return;
		}
		lpDirectInputJoystick[joynum]->GetDeviceState(sizeof(DIJOYSTATE2),&diJoystickState[joynum]);
	}
	UpdateButtons();
}

void
CInput::UpdateButtons()
{
	for (DWORD joynum=0 ; joynum < NumJoysticks ; joynum++) {
		bButtonPressed[joynum]=FALSE;
		for (DWORD n=0 ; n < 128 ; n++) {
			if (JoystickButtons[joynum][n] != 0 && diJoystickState[joynum].rgbButtons[n] == 0) {
				JoystickButtons[joynum][n]=0;
			}
			if (diJoystickState[joynum].rgbButtons[n] != 0) {
				bButtonPressed[joynum]=TRUE;
			}
		}
	}
}

BOOL
CInput::GetJoystickButton(DWORD num,DWORD joynum)
{
	if (joynum < NumJoysticks) {
		if (JoystickButtons[joynum][num] == 0 && diJoystickState[joynum].rgbButtons[num] != 0) {
			JoystickButtons[joynum][num]=1;
			return(TRUE);
		}
	}
	return(FALSE);
}

void
CInput::ShowJoystickData()
{
/*
	CGfx::PrintText("   X,Y,Z: %ld,%ld,%ld",diJoystickState.lX,diJoystickState.lY,diJoystickState.lZ);
	CGfx::PrintText("lARx,y,z: %ld,%ld,%ld",diJoystickState.lARx,diJoystickState.lARy,diJoystickState.lARz);
	CGfx::PrintText("lAX,Y,Z:  %ld,%ld,%ld",diJoystickState.lAX,diJoystickState.lAY,diJoystickState.lAZ);
	CGfx::PrintText("lFRx,y,z: %ld,%ld,%ld",diJoystickState.lFRx,diJoystickState.lFRy,diJoystickState.lFRz);
	CGfx::PrintText("lFX,Y,Z:  %ld,%ld,%ld",diJoystickState.lFX,diJoystickState.lFY,diJoystickState.lFZ);
	CGfx::PrintText("lRx,y,z:  %ld,%ld,%ld",diJoystickState.lRx,diJoystickState.lRy,diJoystickState.lRz);
	CGfx::PrintText("lVRx,y,z: %ld,%ld,%ld",diJoystickState.lVRx,diJoystickState.lVRy,diJoystickState.lVRz);
	CGfx::PrintText("lVX,Y,Z:  %ld,%ld,%ld",diJoystickState.lVX,diJoystickState.lVY,diJoystickState.lVZ);
	CGfx::PrintText("SLIDER0,1:%ld,%ld",diJoystickState.rglSlider[0],diJoystickState.rglSlider[1]);
	char	buf[256];
	buf[0]=0;
	DWORD i=0;
	for (LONG n=63 ; n >= 0 ; n--) {
		if (diJoystickState.rgbButtons[n]) {
			strcat(buf,"1");
		}
		else {
			strcat(buf,"0");
		}
		i++;
		if ((i%8) == 0) {
			strcat(buf,".");
		}
	}
	CGfx::PrintText("BUTTONS:  %s",buf);
*/
}

BOOL CALLBACK
EnumJoysticksCallback(const DIDEVICEINSTANCE *pdidInstance,VOID *pContext)
{
	DWORD NumJoysticks=CInput::NumJoysticks;
	if (NumJoysticks < 4 && CInput::lpDirectInputJoystick[NumJoysticks] == NULL) {
		CInput::lpDirectInput8->CreateDevice(pdidInstance->guidInstance,&CInput::lpDirectInputJoystick[NumJoysticks],NULL);
		CInput::NumJoysticks++;
		return(DIENUM_CONTINUE);
	}
	return(DIENUM_STOP);
}

BOOL CALLBACK
EnumObjectsCallback(LPCDIDEVICEOBJECTINSTANCE lpddoi,LPVOID pvref)
{
	Log("JOYOBJECT: %s",lpddoi->tszName);

	if (lpddoi->guidType == GUID_XAxis || lpddoi->guidType == GUID_YAxis || lpddoi->guidType == GUID_ZAxis ||
		lpddoi->guidType == GUID_RxAxis || lpddoi->guidType == GUID_RyAxis || lpddoi->guidType == GUID_RzAxis ||
		lpddoi->guidType == GUID_Slider) {
			DIPROPRANGE	proprange;
			proprange.diph.dwSize=sizeof(DIPROPRANGE);
			proprange.diph.dwHeaderSize=sizeof(DIPROPHEADER);
			proprange.diph.dwHow=DIPH_BYID;
			proprange.diph.dwObj=lpddoi->dwType;
			proprange.lMin=-1000;
			proprange.lMax= 1000;
			CurrentJoystick->SetProperty(DIPROP_RANGE,&proprange.diph);
	}
	return(DIENUM_CONTINUE);
}
