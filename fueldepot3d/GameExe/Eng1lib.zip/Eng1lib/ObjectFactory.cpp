// ObjectFactory.cpp: implementation of the CObjectFactory class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "ObjectFactory.h"
#include "DefaultGame.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CObjectFactory::CObjectFactory()
{

}

CObjectFactory::~CObjectFactory()
{

}

CGameObject *
CObjectFactory::SpawnObject(unsigned long id)
{
	CGameObject *gobj=NULL;
	switch (id) {
	case '2SPR':
		gobj=new C2DSprite;
		break;
	case '3CUB':
		gobj=new C3DCube;
		break;
	case '3CYL':
		gobj=new C3DCylinder;
		break;
	case '3LIG':
		gobj=new C3DLight;
		break;
	case '3OBJ':
		gobj=new C3DObject;
		break;
	case '3PAR':
		gobj=new C3DParticleEmitter;
		break;
	case '3PER':
		gobj=new C3DPermanentSprite;
		break;
	case '3POL':
		gobj=new C3DPolygon;
		break;
	case '3PRJ':
		gobj=new C3DProjectile;
		break;
	case '3SPH':
		gobj=new C3DSphere;
		break;
	case '3SPR':
		gobj=new C3DSprite;
		break;
	case 'DEFA':
		gobj=new CDefaultGame;
		break;
	}
	return(gobj);
}
