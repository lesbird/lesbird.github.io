// TexMan.cpp: implementation of the CTexMan class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "TexMan.h"

#include "dxerr8.h"

TextureManagerList_t				CTexMan::TextureManagerList;

DWORD								TexCacheLoad=0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTexMan::CTexMan()
{

}

CTexMan::~CTexMan()
{

}

void
CTexMan::UnInit()
{
	for (TextureManagerList_t::iterator t=TextureManagerList.begin() ; t != TextureManagerList.end() ; t++) {
		TexManList_t *texlist=(*t);
		SAFE_RELEASE(texlist->D3DTexture);
		SAFE_DELETE(texlist);
	}
	TextureManagerList.clear();
}

LPDIRECT3DTEXTURE8
CTexMan::LoadTexture(string filename,DWORD filter,BOOL bBump)
{
	Log("LoadTexture(%s)",filename.c_str());
	for (TextureManagerList_t::iterator t=TextureManagerList.begin() ; t != TextureManagerList.end() ; t++) {
		TexManList_t *texlist=(*t);
		if (strcmp(texlist->FileName,filename.c_str()) == 0) {
			return(texlist->D3DTexture);
		}
	}

	TexCacheLoad++;

	LPDIRECT3DTEXTURE8 tex=NULL;
	string texfile="BMP\\"+filename;
	D3DFORMAT D3DFmt=D3DFMT_UNKNOWN;
	HRESULT hr=D3DXCreateTextureFromFileEx(CGfx::lpD3DDevice8,texfile.c_str(),D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,0,
											D3DFmt,D3DPOOL_MANAGED,filter,filter,0xFF000000,NULL,NULL,&tex);
	if (FAILED(hr)) {
		Log("TEXTURE %s NOT FOUND",filename.c_str());
	}
	else {
		TexManList_t *texlist=new TexManList_t;
		texlist->D3DTexture=tex;
		strcpy(texlist->FileName,filename.c_str());
		TextureManagerList.push_back(texlist);
	}
	return(tex);
}

LPDIRECT3DTEXTURE8
CTexMan::LoadTexture(INT resid,DWORD filter,BOOL bBump)
{
	Log("LoadTexture(%ld)",resid);
	for (TextureManagerList_t::iterator t=TextureManagerList.begin() ; t != TextureManagerList.end() ; t++) {
		TexManList_t *texlist=(*t);
		if (texlist->ResourceID == resid) {
			return(texlist->D3DTexture);
		}
	}

	TexCacheLoad++;

	LPDIRECT3DTEXTURE8 tex=NULL;
	D3DFORMAT D3DFmt=D3DFMT_UNKNOWN;
	HRESULT hr=D3DXCreateTextureFromResourceEx(CGfx::lpD3DDevice8,NULL,MAKEINTRESOURCE(resid),D3DX_DEFAULT,D3DX_DEFAULT,D3DX_DEFAULT,0,
											D3DFmt,D3DPOOL_MANAGED,filter,filter,0xFF000000,NULL,NULL,&tex);
	if (FAILED(hr)) {
		Log("%s: %s",DXGetErrorString8(hr),DXGetErrorDescription8(hr));
	}
	else {
		TexManList_t *texlist=new TexManList_t;
		texlist->D3DTexture=tex;
		texlist->ResourceID=resid;
		TextureManagerList.push_back(texlist);
	}
	return(tex);
}
