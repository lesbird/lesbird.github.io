// 3DObject.cpp: implementation of the C3DObject class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "3DObject.h"

#define	METHOD						6
#define PI_INVERSE					0.318309886184

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DObject::C3DObject()
{
	SetObjectID('3OBJ');
	SetObjectName("C3DOBJECT");

	D3DXVB8=NULL;
	D3DXMesh=NULL;

	MaterialList.clear();

	BoundingSphereObject=NULL;
	CollisionSphereObject=NULL;

	dwNumVertices=0;

	ScaleRate=0;

	TextureScaleU=1.0f;
	TextureScaleV=1.0f;

	Transparency=1.0f;

	AmbientLighting=D3DXCOLOR(0,0,0,0);
	SpecularLighting=D3DXCOLOR(0.5f,0.5f,0.5f,1);

	bDoubleSided=FALSE;
	bEnvironmentMap=FALSE;
	bFadeOut=FALSE;
	bInvertPolys=FALSE;
	bOptimizeMesh=TRUE;
	bOrtho=FALSE;
	bReflectionMap=FALSE;
	bShowBoundingSphere=FALSE;
	bShowCollisionSphere=FALSE;
	bShowVertexInfo=FALSE;
	bTransparency=FALSE;
	bUnlit=FALSE;
	bWireFrame=FALSE;
}

C3DObject::~C3DObject()
{
	Enter("~C3DObject()");

	SAFE_RELEASE(D3DXVB8);
	SAFE_RELEASE(D3DXMesh);
	DeleteResources();

	Leave();
}

void
C3DObject::DeleteResources()
{
	while (MaterialList.size() != 0) {
		Material_t *mat=(*MaterialList.begin());
		while (mat->TextureList.size() != 0) {
			Texture_t *tex=(*mat->TextureList.begin());
			SAFE_DELETE(tex);
			mat->TextureList.pop_front();
		}
		SAFE_DELETE(mat->D3DMaterial);
		SAFE_DELETE(mat);
		MaterialList.pop_front();
	}
}

void
C3DObject::CloneNewFVF(BOOL bComputeNormals)
{
	Enter("CloneNewFVF()");

    LPD3DXBUFFER	D3DXAdjacencyBuffer=NULL;

	if (D3DXMesh != NULL) {
		LPD3DXMESH	mesh;
		D3DXMesh->CloneMeshFVF(D3DXMESH_MANAGED,FVF_FLAGS,CGfx::lpD3DDevice8,&mesh);
		SAFE_RELEASE(D3DXMesh);
		D3DXMesh=mesh;
		if (bOptimizeMesh) {
			if (D3DXMesh->GetNumVertices() > 5) {
				D3DXCreateBuffer(D3DXMesh->GetNumFaces()*sizeof(DWORD)*3,&D3DXAdjacencyBuffer);
				D3DXMesh->GenerateAdjacency(FLT_EPSILON,(DWORD *)D3DXAdjacencyBuffer->GetBufferPointer());
				if (D3DXAdjacencyBuffer != NULL) {
					D3DXMesh->OptimizeInplace(D3DXMESHOPT_COMPACT|D3DXMESHOPT_ATTRSORT|D3DXMESHOPT_VERTEXCACHE,(DWORD *)D3DXAdjacencyBuffer->GetBufferPointer(),NULL,NULL,NULL);
					SAFE_RELEASE(D3DXAdjacencyBuffer);
				}
			}
		}
		if (bComputeNormals) {
			D3DXComputeNormals(D3DXMesh,NULL);
		}
	}

	Leave();
}

void
C3DObject::SphereMapTexture(FLOAT scaleu,FLOAT scalev)
{
	Enter("SphereMapTexture()");

	if (D3DXMesh != NULL) {
		FVFVertex_t *verts;
		D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
		if (verts != NULL) {
			TextureScaleU=scaleu;
			TextureScaleV=scalev;

			LONG num=D3DXMesh->GetNumVertices();

			Log("NumVerts=%ld",num);

#if (METHOD == 3)
			D3DXVECTOR3 xv(0,0,1);
			D3DXVECTOR3 yv(1,0,0);
			D3DXVECTOR3 zv(0,1,0);
#elif (METHOD == 4)
			D3DXVECTOR3 p1(0,0,0);
			D3DXVECTOR3 p2(0,-BoundingSphereRadius,0);
			D3DXVECTOR3 pl(-BoundingSphereRadius,-BoundingSphereRadius,-BoundingSphereRadius);
			D3DXVECTOR3 zv;
			D3DXVec3Subtract(&zv,&p1,&p2);
			D3DXVECTOR3 yv;
			D3DXVec3Subtract(&yv,&pl,&p1);
			D3DXVec3Cross(&yv,&yv,&zv);
			D3DXVECTOR3 xv;
			D3DXVec3Cross(&xv,&yv,&zv);
			D3DXVec3Normalize(&xv,&xv);
			D3DXVec3Normalize(&yv,&yv);
			D3DXVec3Normalize(&zv,&zv);
#elif (METHOD == 5)
			D3DXVECTOR3 np(0,1,0);
			D3DXVECTOR3 eq(0,0,1);
			D3DXVECTOR3 npoeq;
			D3DXVec3Cross(&npoeq,&np,&eq);
#endif
			for (DWORD n=0 ; n < num ; n++) {
#if (METHOD == 1)
				FLOAT nx=(verts[n].nor.x);
				FLOAT ny=(verts[n].nor.y);
				FLOAT u=(asinf(nx)/D3DX_PI)+0.5f;
				FLOAT v=(asinf(ny)/D3DX_PI)+0.5f;
#elif (METHOD == 2)
				FLOAT u=(verts[n].nor.x/2.0f)+0.5f;
				FLOAT v=(verts[n].nor.y/2.0f)+0.5f;
#elif (METHOD == 3)
				FLOAT x=verts[n].pos.x;
				FLOAT y=verts[n].pos.y;
				FLOAT z=verts[n].pos.z;
				D3DXVECTOR3 rv(x,y,z);
				D3DXVec3Normalize(&rv,&rv);
				FLOAT a1=atan2f(D3DXVec3Dot(&rv,&xv),D3DXVec3Dot(&rv,&yv));
				FLOAT a2=acosf(D3DXVec3Dot(&rv,&zv));
				FLOAT u=((a1 >= 0) ? (a1/(D3DX_PI*2)) : (((D3DX_PI*2)+a1)/(D3DX_PI*2)));
				FLOAT v=(a2/D3DX_PI);
#elif (METHOD == 4)
				FLOAT x=verts[n].pos.x;
				FLOAT y=verts[n].pos.y;
				FLOAT z=verts[n].pos.z;
				D3DXVECTOR3 r(x,y,z);
				D3DXVec3Subtract(&r,&r,&p1);
				D3DXVec3Normalize(&r,&r);
				FLOAT a1=atan2f(D3DXVec3Dot(&r,&xv),D3DXVec3Dot(&r,&yv));
				FLOAT a2=acosf(D3DXVec3Dot(&r,&zv));

				FLOAT u=((a1 >= 0) ? (a1/(D3DX_PI*2)) : (((D3DX_PI*2)+a1)/(D3DX_PI*2)));
				FLOAT v=a2/D3DX_PI;
#elif (METHOD == 5)
				D3DXVECTOR3 center2pt=verts[n].pos;
				D3DXVec3Normalize(&center2pt,&center2pt);
				FLOAT phi,theta;
				phi=acosf(-D3DXVec3Dot(&np,&center2pt));
				FLOAT u,v=phi*PI_INVERSE;
				if (v == 0 || v == 1) {
					u=0;
				}
				else {
					theta=acosf((D3DXVec3Dot(&eq,&center2pt))/sinf(phi))*0.5*PI_INVERSE;
					u=(D3DXVec3Dot(&npoeq,&center2pt) > 0) ? theta : 1-theta;
				}
#elif (METHOD == 6)
				FLOAT x=verts[n].pos.x;
				FLOAT y=verts[n].pos.y;
				FLOAT z=verts[n].pos.z;
				FLOAT r=BoundingSphereRadius;
				FLOAT u,v=acosf(y/r)/D3DX_PI;
//				if (z >= 0) {
					u=(acosf(x/(r*sinf(D3DX_PI*v)))/(D3DX_PI*2.0f))*2;
//				}
//				else {
//					u=(D3DX_PI+acosf(x/(r*sinf(D3DX_PI*v))))/(D3DX_PI*2.0f);
//				}
#endif
//				Log("V%ld: U=%f V=%f",n,u,v);

				verts[n].tu1=u*TextureScaleU;
				verts[n].tv1=v*TextureScaleV;
				verts[n].tu2=verts[n].tu1;
				verts[n].tv2=verts[n].tv1;
				verts[n].tu3=verts[n].tu1;
				verts[n].tv3=verts[n].tv1;
			}
			D3DXMesh->UnlockVertexBuffer();
		}
	}

	Leave();
}

D3DXVECTOR3
C3DObject::GetVertex(DWORD n)
{
	D3DXVECTOR3	p;
	if (D3DXMesh != NULL) {
		FVFVertex_t *verts;
		D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
		if (verts != NULL) {
			p=verts[n].pos;
		}
		D3DXMesh->UnlockVertexBuffer();
	}
	return(p);
}

void
C3DObject::ComputeBoundingSphere()
{
	DWORD numverts=0;
	FVFVertex_t *verts=NULL;
	if (D3DXMesh != NULL) {
		numverts=D3DXMesh->GetNumVertices();
		D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
		D3DXComputeBoundingSphere(verts,numverts,D3DXMesh->GetFVF(),&BoundingSpherePoint,&BoundingSphereRadius);
		Radius=BoundingSphereRadius*((ScaleX+ScaleY+ScaleZ)/3.0f);
		CollisionRadius=Radius*0.7f*((ScaleX+ScaleY+ScaleZ)/3.0f);
		D3DXMesh->UnlockVertexBuffer();
	}
}

void
C3DObject::ComputeBoundingBox()
{
	DWORD numverts=0;
	FVFVertex_t *verts=NULL;
	if (D3DXMesh != NULL) {
		numverts=D3DXMesh->GetNumVertices();
		D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
		D3DXComputeBoundingBox(verts,numverts,D3DXMesh->GetFVF(),&BoundingBoxMin,&BoundingBoxMax);
		D3DXMesh->UnlockVertexBuffer();

		BoundingBoxMin.x*=ScaleX;
		BoundingBoxMin.y*=ScaleY;
		BoundingBoxMin.z*=ScaleZ;
		BoundingBoxMax.x*=ScaleX;
		BoundingBoxMax.y*=ScaleY;
		BoundingBoxMax.z*=ScaleZ;
	}
}

void
C3DObject::LoadMesh(string filename,BOOL bComputeNormals)
{
	Enter("LoadMesh(%s)",filename.c_str());
/*
	DWORD			NumMaterials;
	LPD3DXBUFFER	D3DXMaterialBuffer;
	LPD3DXBUFFER	D3DXAdjacencyBuffer;

	string xfile="X\\"+filename;
	HRESULT hr=D3DXLoadMeshFromX((char *)xfile.c_str(),D3DXMESH_MANAGED,CGfx::lpD3DDevice8,&D3DXAdjacencyBuffer,&D3DXMaterialBuffer,&NumMaterials,&D3DXMesh);
	if (hr == D3D_OK) {
	    hr=D3DXMesh->OptimizeInplace(D3DXMESHOPT_COMPACT|D3DXMESHOPT_ATTRSORT|D3DXMESHOPT_VERTEXCACHE,(DWORD*)D3DXAdjacencyBuffer->GetBufferPointer(),NULL,NULL,NULL);
		if (hr == D3D_OK) {
			D3DXMATERIAL *matlist=(D3DXMATERIAL *)D3DXMaterialBuffer->GetBufferPointer();
			for (short n=0 ; n < NumMaterials ; n++) {
				Material_t *mat=AddMaterial(&matlist[n].MatD3D);
				if (matlist[n].pTextureFilename != NULL) {
					AddTexture(mat,matlist[n].pTextureFilename);
				}
			}
			if (bComputeNormals) {
				D3DXComputeNormals(D3DXMesh,NULL);
			}
			SAFE_RELEASE(D3DXAdjacencyBuffer);
		}
		SAFE_RELEASE(D3DXMaterialBuffer);
	}
*/
	CMeshManager::LoadMesh(filename,bComputeNormals,this);
	ComputeBoundingSphere();

	Leave();
}

Material_t *
C3DObject::AddDefaultMaterial()
{
	D3DMATERIAL8	d3dmat;

	ZeroMemory(&d3dmat,sizeof(D3DMATERIAL8));
	d3dmat.Diffuse=D3DXCOLOR(1,1,1,1);
	d3dmat.Specular=SpecularLighting;
	d3dmat.Power=50;
	return(AddMaterial(&d3dmat));
}

Material_t *
C3DObject::AddMaterial(D3DMATERIAL8 *d3dmat)
{
	Material_t *mat=new Material_t;
	mat->D3DMaterial=new D3DMATERIAL8;
	CopyMemory(mat->D3DMaterial,d3dmat,sizeof(D3DMATERIAL8));
	mat->TextureList.clear();
	mat->bUnlit=FALSE;
	MaterialList.push_back(mat);
	return(mat);
}

Material_t *
C3DObject::AddTexture(Material_t *mat,LPDIRECT3DTEXTURE8 d3dtex,DWORD flags)
{
	if (mat == NULL) {
		if (MaterialList.size() == 0) {
			mat=AddDefaultMaterial();
		}
		else {
			mat=(*MaterialList.begin());
		}
	}
	if (d3dtex != NULL) {
		if (flags&TEXFLAGS_ALLMATERIALS) {
			for (MaterialList_t::iterator m=MaterialList.begin() ; m != MaterialList.end() ; m++) {
				Material_t *allmat=*m;
				allmat->D3DMaterial->Diffuse=D3DXCOLOR(1,1,1,1);
				allmat->D3DMaterial->Specular=SpecularLighting;
				allmat->D3DMaterial->Power=50;
				Texture_t *tex=new Texture_t;
				tex->D3DTexture=d3dtex;
				tex->Flags=flags;
				allmat->TextureList.push_back(tex);
			}
		}
		else {
			Texture_t *tex=new Texture_t;
			tex->D3DTexture=d3dtex;
			tex->Flags=flags;
			mat->TextureList.push_back(tex);
		}
	}
	return(mat);
}

Material_t *
C3DObject::AddTexture(Material_t *mat,string filename,DWORD flags)
{
	LPDIRECT3DTEXTURE8 D3DTexture=NULL;
	if (filename.length() > 0) {
		D3DTexture=CTexMan::LoadTexture(filename,(flags&TEXFLAGS_NOFILTERING) ? D3DX_FILTER_NONE : D3DX_DEFAULT,(flags&TEXFLAGS_ENVBUMPMAP) != 0 ? TRUE : FALSE);
	}
	return(AddTexture(mat,D3DTexture,flags));
}

Material_t *
C3DObject::AddTexture(string filename,DWORD flags)
{
	return(AddTexture(NULL,filename,flags));
}

Material_t *
C3DObject::AddTexture(Material_t *mat,INT resid,DWORD flags)
{
	LPDIRECT3DTEXTURE8 D3DTexture=NULL;
	D3DTexture=CTexMan::LoadTexture(resid,(flags&TEXFLAGS_NOFILTERING) ? D3DX_FILTER_NONE : D3DX_DEFAULT,(flags&TEXFLAGS_ENVBUMPMAP) != 0 ? TRUE : FALSE);
	return(AddTexture(mat,D3DTexture,flags));
}

Material_t *
C3DObject::AddTexture(INT resid,DWORD flags)
{
	return(AddTexture(NULL,resid,flags));
}

Material_t *
C3DObject::AddEnvMapTexture(Material_t *mat,DWORD flags)
{
	LPDIRECT3DTEXTURE8 lpEnvMapTexture=NULL;
	if (D3DXCreateTexture(CGfx::lpD3DDevice8,256,256,1,D3DUSAGE_RENDERTARGET,CGfx::BackBufferFormat,D3DPOOL_DEFAULT,&lpEnvMapTexture) == D3D_OK) {
		Material_t *retmat=AddTexture(mat,lpEnvMapTexture,flags);
		EnvMapTextureObject_t *envmapobj=new EnvMapTextureObject_t;
		envmapobj->lpEnvMapTexture=lpEnvMapTexture;
		CGfx::lpD3DDevice8->CreateDepthStencilSurface(256,256,D3DFMT_D16,D3DMULTISAMPLE_NONE,&envmapobj->lpEnvMapDepth);
		envmapobj->Object=this;
		CGfx::EnvMapTextureList.push_back(envmapobj);
		return(retmat);
	}
	return(NULL);
}

Texture_t *
C3DObject::GetTexture(Material_t *mat,short texnum)
{
	short n=0;
	for (TextureList_t::iterator tlist=mat->TextureList.begin() ; tlist != mat->TextureList.end() ; tlist++) {
		Texture_t *tex=(*tlist);
		if (texnum == n) {
			return(tex);
		}
		n++;
	}
	return(NULL);
}

void
C3DObject::RemoveTexture(LPDIRECT3DTEXTURE8 D3DTexture,DWORD &flags)
{
	if (D3DTexture != NULL) {
		for (MaterialList_t::iterator mlist=MaterialList.begin() ; mlist != MaterialList.end() ; mlist++) {
			Material_t *m=(*mlist);
			for (TextureList_t::iterator tlist=m->TextureList.begin() ; tlist != m->TextureList.end() ; ) {
				Texture_t *t=(*tlist);
				if (t->D3DTexture == D3DTexture) {
					flags=t->Flags;
					tlist=m->TextureList.erase(tlist);
				}
				else {
					tlist++;
				}
			}
		}
	}
}

void
C3DObject::RemoveTexture(string texname,DWORD &flags)
{
	RemoveTexture(CTexMan::LoadTexture(texname),flags);
}

BOOL
C3DObject::IntersectTest(CGameObject *gobj)
{
	if (CGameObject::IntersectTest(gobj)) {
		return(TRUE);
	}
	return(FALSE);
}

void
C3DObject::Tick(FLOAT delta)
{
	if (GetKey(KEY_PERIOD)) {
		ScanMeshes();
	}

	CGameObject::Tick(delta);

	if (!bPause) {
		if (bFadeOut) {
			if (LifeSpan != 0) {
				Transparency=__max(LifeSpan,0);
			}
		}
		ScaleX+=ScaleRate*delta;
		if (ScaleX <= 0) {
			ScaleX=0;
		}
		ScaleY+=ScaleRate*delta;
		if (ScaleY <= 0) {
			ScaleY=0;
		}
		ScaleZ+=ScaleRate*delta;
		if (ScaleZ <= 0) {
			ScaleZ=0;
		}
	}

	if (bShowBoundingSphere) {
		if (BoundingSphereObject == NULL) {
			BoundingSphereObject=(C3DSphere *)SPAWN('3SPH');
			BoundingSphereObject->Link(this);
			BoundingSphereObject->SetObjectName("BOUNDINGSPHERE");
			BoundingSphereObject->InitSphere(BoundingSphereRadius,16,16,1,1);
			BoundingSphereObject->AddDefaultMaterial();
			BoundingSphereObject->Transparency=0.1f;
			BoundingSphereObject->bCanTouch=FALSE;
			BoundingSphereObject->bUnlit=TRUE;
			BoundingSphereObject->bWireFrame=TRUE;
		}
	}
	else if (BoundingSphereObject != NULL) {
		BoundingSphereObject->DeleteMe();
		BoundingSphereObject=NULL;
	}
	if (bShowCollisionSphere) {
		if (CollisionSphereObject == NULL) {
			CollisionSphereObject=(C3DSphere *)SPAWN('3SPH');
			CollisionSphereObject->Link(this);
			CollisionSphereObject->SetObjectName("COLLISIONSPHERE");
			CollisionSphereObject->InitSphere(CollisionRadius,16,16,1,1);
			Material_t *mat=CollisionSphereObject->AddDefaultMaterial();
			mat->D3DMaterial->Diffuse=D3DXCOLOR(1,0,0,1);
			CollisionSphereObject->Transparency=0.1f;
			CollisionSphereObject->bCanTouch=FALSE;
			CollisionSphereObject->bUnlit=TRUE;
			CollisionSphereObject->bWireFrame=TRUE;
		}
	}
	else if (CollisionSphereObject != NULL) {
		CollisionSphereObject->DeleteMe();
		CollisionSphereObject=NULL;
	}
}

void
C3DObject::ScanMeshes()
{
	for (GameObjectList_t::iterator o=CGameObject::GameObjectList.begin() ; o != CGameObject::GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (!gobj->IsA("C3DOBJECT")) {
			continue;
		}
	}
}

inline DWORD
F2DW(FLOAT f)
{
	return(*((DWORD *)&f));
}

void
C3DObject::Render()
{
	CGameObject::Render();
	if ((D3DXVB8 != NULL || D3DXMesh != NULL) && !bHidden) {
		CGfx::lpD3DDevice8->SetTransform(D3DTS_WORLD,&WorldMatrix);
		CGfx::SetCullMode(bDoubleSided ? 1 : bInvertPolys ? 2 : 0);
		CGfx::SetOrthoMode(bOrtho);
		CGfx::SetWireFrame(bWireFrame);
		BOOL bFogMode=CGfx::bFogMode;
		CGfx::SetFogMode(bNoFog ? FALSE : bFogMode);
		DWORD subset=0;
		for (MaterialList_t::iterator m=MaterialList.begin() ; m != MaterialList.end() ; m++) {
			Material_t *mat=(*m);
			D3DMATERIAL8	mat8;
			memcpy(&mat8,mat->D3DMaterial,sizeof(D3DMATERIAL8));
			if (bUnlit || mat->bUnlit) {
				mat8.Ambient=mat8.Diffuse;
				mat8.Specular=D3DXCOLOR(0,0,0,0);
			}
			else {
				mat8.Ambient=AmbientLighting;
				mat8.Specular=SpecularLighting;
			}
			mat8.Diffuse.a=Transparency;
			CGfx::lpD3DDevice8->SetMaterial(&mat8);
			CGfx::SetAlphaMode(Transparency != 1.0f ? TRUE : bTransparency);
			TextureList_t::iterator t=mat->TextureList.begin();
			for (short n=0 ; n < 8 ; n++) {
				if (t != mat->TextureList.end()) {
					Texture_t *tex=(*t);
					BOOL bEnv=(bEnvironmentMap || ((tex->Flags&TEXFLAGS_ENVIRONMENTMAP) != 0 ? TRUE : FALSE));
					CGfx::SetEnvironmentMapMode(n,bEnv);
					BOOL bRef=(bReflectionMap || ((tex->Flags&TEXFLAGS_REFLECTIONMAP) != 0 ? TRUE : FALSE));
					CGfx::SetReflectionMapMode(n,bRef);
					CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
					switch (n) {
					case 0:
						CGfx::lpD3DDevice8->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_MODULATE);
						CGfx::lpD3DDevice8->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
						CGfx::lpD3DDevice8->SetTextureStageState(0,D3DTSS_COLORARG2,D3DTA_DIFFUSE);
						break;
					default:
						if (tex->Flags&TEXFLAGS_MODULATE) {
							CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLOROP,D3DTOP_MODULATE);
						}
						else if (tex->Flags&TEXFLAGS_MODULATE2X) {
							CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLOROP,D3DTOP_MODULATE2X);
						}
						else if (tex->Flags&TEXFLAGS_ADD) {
							CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLOROP,D3DTOP_ADD);
						}
						else {
							CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLOROP,D3DTOP_ADDSIGNED);
						}
						CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLORARG1,D3DTA_TEXTURE);
						CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLORARG2,D3DTA_CURRENT);
						break;
					}
					LPDIRECT3DTEXTURE8 d3dtex=tex->D3DTexture;
					if (d3dtex == NULL) {
						LogExit(__FILE__,__LINE__);
					}
					CGfx::lpD3DDevice8->SetTexture(n,d3dtex);
					t++;
				}
				else {
					CGfx::lpD3DDevice8->SetTextureStageState(n,D3DTSS_COLOROP,D3DTOP_DISABLE);
					break;
				}
			}
			if (D3DXVB8 != NULL) {
				CGfx::lpD3DDevice8->SetStreamSource(0,D3DXVB8,sizeof(FVFVertex_t));
				CGfx::lpD3DDevice8->SetVertexShader(FVF_FLAGS);
				CGfx::lpD3DDevice8->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,dwNumVertices-2);
			}
			else {
				D3DXMesh->DrawSubset(subset++);
			}
		}
		CGfx::SetFogMode(bFogMode);
		if (D3DXVB8 != NULL) {
			CGfx::NumVerts+=dwNumVertices;
		}
		else {
			CGfx::NumPolys+=D3DXMesh->GetNumFaces();
			CGfx::NumVerts+=D3DXMesh->GetNumVertices();
		}
		if (bShowVertexInfo) {
			FVFVertex_t *verts;
			D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
			if (verts != NULL) {
				LONG num=D3DXMesh->GetNumVertices();
				for (DWORD n=0 ; n < num ; n++) {
					FLOAT x=verts[n].pos.x;
					FLOAT y=verts[n].pos.y;
					FLOAT z=verts[n].pos.z;
					FLOAT u=verts[n].tu1;
					FLOAT v=verts[n].tv1;
					FLOAT	vx,vy;
					D3DXVECTOR3	vpos(x,y,z),tpos;
					D3DXVec3TransformCoord(&tpos,&vpos,&WorldMatrix);
					if (CGfx::WorldToScreen(tpos,vx,vy,1)) {
						CGfx::PrintText(vx,vy,D3DXCOLOR(1,1,1,1),"%05.02f %05.02f %05.02f",x,y,z);
					}
				}
				D3DXMesh->UnlockVertexBuffer();
			}
		}
	}
}

DWORD
C3DObject::RenderPass()
{
	if (bTransparency || Transparency != 1.0f) {
		return(1);
	}
	return(CGameObject::RenderPass());
}
