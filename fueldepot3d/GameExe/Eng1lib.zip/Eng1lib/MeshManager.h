// MeshManager.h: interface for the CMeshManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESHMANAGER_H__73156DF3_F2D3_4120_8801_C4E7E68FE7D9__INCLUDED_)
#define AFX_MESHMANAGER_H__73156DF3_F2D3_4120_8801_C4E7E68FE7D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "d3dx8.h"

#include <list>
#include <string>

using namespace std;

typedef struct Mesh_tag
{
	CHAR							MeshName[64];
	LPD3DXMESH						D3DXMesh;
	LPD3DXBUFFER					D3DXMaterialBuffer;
	DWORD							NumMaterials;
} Mesh_t;

typedef list<Mesh_t *>				MeshList_t;

typedef struct CylinderMesh_tag
{
	LPD3DXMESH						D3DXMesh;
	UINT							Slices;
	UINT							Stacks;
} CylinderMesh_t;

typedef list<CylinderMesh_t *>		CylinderMeshList_t;

typedef struct SphereMesh_tag
{
	LPD3DXMESH						D3DXMesh;
	UINT							Slices;
	UINT							Stacks;
} SphereMesh_t;

typedef list<SphereMesh_t *>		SphereMeshList_t;

typedef struct Texture_tag
{
	LPDIRECT3DTEXTURE8				D3DTexture;
	DWORD							Flags;
} Texture_t;

typedef list<Texture_t *>			TextureList_t;

typedef struct Material_tag
{
	D3DMATERIAL8					*D3DMaterial;
	TextureList_t					TextureList;
	BOOL							bUnlit;
} Material_t;

typedef list<Material_t *>			MaterialList_t;

class CMeshManager  
{
public:
	CMeshManager();
	virtual ~CMeshManager();

	static VOID						Init();
	static VOID						UnInit();

	static LPD3DXMESH				LoadMesh(string meshname,BOOL bComputeNormals,class C3DObject *obj);
	static LPD3DXMESH				ResizeMesh(LPD3DXMESH D3DXMesh,FLOAT sizex,FLOAT sizey,FLOAT sizez,class C3DObject *obj);
	static LPD3DXMESH				CreateBoxMesh(FLOAT sizex,FLOAT sizey,FLOAT sizez,class C3DObject *obj);
	static LPD3DXMESH				CreateCylinderMesh(FLOAT radiusx,FLOAT radiusz,FLOAT length,UINT slices,UINT stacks,class C3DObject *obj);
	static LPD3DXMESH				CreatePolyMesh(FLOAT size,class C3DObject *obj);
	static LPD3DXMESH				CreateSphereMesh(FLOAT radius,FLOAT slices,FLOAT stacks,class C3DObject *obj);

public:
	static CylinderMeshList_t		CylinderMeshList;
	static MeshList_t				MeshList;
	static SphereMeshList_t			SphereMeshList;

	static LPD3DXMESH				D3DXBoxMesh;
	static LPD3DXMESH				D3DXPolyMesh;
};

#endif // !defined(AFX_MESHMANAGER_H__73156DF3_F2D3_4120_8801_C4E7E68FE7D9__INCLUDED_)
