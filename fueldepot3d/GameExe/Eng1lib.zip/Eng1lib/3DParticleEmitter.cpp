// 3DParticleEmitter.cpp: implementation of the C3DParticleEmitter class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "3DParticleEmitter.h"

#define	MAXSPRITECACHE				256

static
C3DPermanentSprite					*ParticleSpriteCache[MAXSPRITECACHE];

static
DWORD								ParticleSpriteNum=0;

static
BOOL								bInit=FALSE;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DParticleEmitter::C3DParticleEmitter()
{
	SetObjectID('3PAR');
	SetObjectName("C3DPARTICLEEMITTER");

	ParticleList.clear();

	bCanTouch=FALSE;

	Mass=0;
}

C3DParticleEmitter::~C3DParticleEmitter()
{
	string pname=ObjectName+"_PARTICLE";
	for (GameObjectList_t::iterator o=CGameObject::GameObjectList.begin() ; o != CGameObject::GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->IsA(pname)) {
			for (ParticleList_t::iterator p=ParticleList.begin() ; p != ParticleList.end() ; p++) {
				Particle_t *particle=(*p);
				C3DSprite *spr=(C3DSprite *)gobj;
				DWORD flags=-1;
				spr->RemoveTexture(particle->D3DTexture,flags);
			}
			gobj->DeleteMe();
		}
	}
	while (ParticleList.size()) {
		Particle_t *particle=(*ParticleList.begin());
		ParticleList.pop_front();
		SAFE_DELETE(particle);
	}
}

void
C3DParticleEmitter::InitSpriteCache()
{
	for (DWORD n=0 ; n < MAXSPRITECACHE ; n++) {
		ParticleSpriteCache[n]=(C3DPermanentSprite *)SPAWN('3PER');
		ParticleSpriteCache[n]->InitSprite(64);
		ParticleSpriteCache[n]->Mass=0;
		ParticleSpriteCache[n]->bCanTouch=FALSE;
		ParticleSpriteCache[n]->bHidden=TRUE;
		ParticleSpriteCache[n]->bTransparency=TRUE;
		ParticleSpriteCache[n]->bUnlit=TRUE;
	}
	bInit=TRUE;
}

void
C3DParticleEmitter::UnInitSpriteCache()
{
	for (DWORD n=0 ; n < MAXSPRITECACHE ; n++) {
		if (ParticleSpriteCache[n] != NULL) {
			ParticleSpriteCache[n]->bDeleteMe=TRUE;
			ParticleSpriteCache[n]=NULL;
		}
	}
	bInit=FALSE;
}

void
C3DParticleEmitter::ResetSpriteCache()
{
	for (DWORD n=0 ; n < MAXSPRITECACHE ; n++) {
		ParticleSpriteCache[n]->DeleteMe();
	}
}

ParticleIterator
C3DParticleEmitter::AddParticle(string filename,FLOAT lifespan,FLOAT size,FLOAT scatter,FLOAT emitrate,FLOAT scalerate,FLOAT velocity)
{
	Particle_t *particle=new Particle_t;
	particle->D3DTexture=CTexMan::LoadTexture(filename);
	particle->Delay=0;
	particle->EmitRate=1.0f/emitrate;
	particle->LifeSpan=lifespan;
	particle->ScaleRate=scalerate;
	particle->Scatter=scatter;
	particle->Size=size;
	particle->Velocity=velocity;
	ParticleIterator i=ParticleList.insert(ParticleList.end(),particle);

	return(i);
}

ParticleIterator
C3DParticleEmitter::AddParticle(string filename,FLOAT lifespan,FLOAT emitrate,FLOAT velocity)
{
	return(AddParticle(filename,lifespan,32,0,emitrate,0.5f,velocity));
}

ParticleIterator
C3DParticleEmitter::AddParticle(string filename)
{
	return(AddParticle(filename,2,32,50,15,-1,100));
}

void
C3DParticleEmitter::RemoveParticle(ParticleIterator i)
{
	ParticleList.erase(i);
}

void
C3DParticleEmitter::Tick(FLOAT delta)
{
	if (bPause) {
		return;
	}
	for (ParticleIterator p=ParticleList.begin() ; p != ParticleList.end() ; p++) {
		Particle_t *particle=(*p);
		particle->Delay+=delta;
		if (particle->Delay >= particle->EmitRate) {
			particle->Delay-=particle->EmitRate;
			C3DPermanentSprite *sprite=GetSprite();
			if (sprite != NULL) {
				sprite->SetObjectName(ObjectName+"_PARTICLE");
				sprite->AddTexture(NULL,particle->D3DTexture);
				sprite->SetPosition(GetPosition());
				sprite->ScaleX=sprite->ScaleY=sprite->ScaleZ=particle->Size/64.0f;
				FLOAT xscatter=particle->Scatter*(CGfx::Random()-0.5f);
				FLOAT yscatter=particle->Scatter*(CGfx::Random()-0.5f);
				FLOAT vscatter=particle->Velocity+(particle->Scatter*CGfx::Random());
				sprite->SetVelocity(TransformVector(xscatter,yscatter,vscatter));
				sprite->LifeSpan=particle->LifeSpan;
				sprite->Mass=0;
				sprite->ScaleRate=particle->ScaleRate;
				sprite->bEnable=TRUE;
				sprite->bHidden=FALSE;
				sprite->bTransform=TRUE;
			}
		}
	}
}

C3DPermanentSprite *
C3DParticleEmitter::GetSprite()
{
	if (bInit) {
		for (DWORD n=0 ; n < MAXSPRITECACHE ; n++) {
			if (ParticleSpriteCache[ParticleSpriteNum]->bHidden == TRUE) {
				return(ParticleSpriteCache[ParticleSpriteNum]);
			}
			ParticleSpriteNum=(ParticleSpriteNum+1)&(MAXSPRITECACHE-1);
		}
	}
	return(NULL);
}
