// 3DObject.h: interface for the C3DObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DOBJECT_H__5C57AA19_12B9_4B26_9F8A_6F2D28C07D80__INCLUDED_)
#define AFX_3DOBJECT_H__5C57AA19_12B9_4B26_9F8A_6F2D28C07D80__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

class	C3DSphere;

#define	TEXFLAGS_NORMAL				0
#define	TEXFLAGS_ENVIRONMENTMAP		1
#define	TEXFLAGS_REFLECTIONMAP		2
#define	TEXFLAGS_DOT3BUMPMAP		4
#define	TEXFLAGS_ENVBUMPMAP			8
#define	TEXFLAGS_CUBEMAP			16
#define	TEXFLAGS_ADD				32
#define	TEXFLAGS_MODULATE			64
#define	TEXFLAGS_MODULATE2X			128
#define	TEXFLAGS_ALLMATERIALS		256
#define	TEXFLAGS_NOFILTERING		1024

#define	FVF_FLAGS	(D3DFVF_NORMAL|D3DFVF_XYZ|D3DFVF_TEX3|D3DFVF_TEXCOORDSIZE2(0)|D3DFVF_TEXCOORDSIZE2(1)|D3DFVF_TEXCOORDSIZE2(2))

typedef struct FVFVertex_tag
{
	D3DXVECTOR3		pos;
	D3DXVECTOR3		nor;
	FLOAT			tu1,tv1;
	FLOAT			tu2,tv2;
	FLOAT			tu3,tv3;
} FVFVertex_t;
/*
typedef struct Texture_tag
{
	LPDIRECT3DTEXTURE8				D3DTexture;
	DWORD							Flags;
} Texture_t;

typedef list<Texture_t *>			TextureList_t;

typedef struct Material_tag
{
	D3DMATERIAL8					*D3DMaterial;
	TextureList_t					TextureList;
	BOOL							bUnlit;
} Material_t;

typedef list<Material_t *>			MaterialList_t;
*/
class C3DObject : public CGameObject
{
public:
	C3DObject();
	virtual ~C3DObject();

	virtual void					DeleteResources();
	virtual void					CloneNewFVF(BOOL bComputeNormals=TRUE);
	virtual void					SphereMapTexture(FLOAT scaleu=1,FLOAT scalev=1);
	virtual D3DXVECTOR3				GetVertex(DWORD n);
	virtual void					ComputeBoundingBox();
	virtual void					ComputeBoundingSphere();
	virtual void					LoadMesh(string filename,BOOL bComputeNormals=TRUE);

	virtual Material_t				*AddDefaultMaterial();
	virtual Material_t				*AddMaterial(D3DMATERIAL8 *d3dmat);
	virtual Material_t				*AddTexture(Material_t *mat,LPDIRECT3DTEXTURE8 tex,DWORD flags=TEXFLAGS_NORMAL);
	virtual Material_t				*AddTexture(Material_t *mat,string filename,DWORD flags=TEXFLAGS_NORMAL);
	virtual Material_t				*AddTexture(string filename,DWORD flags=TEXFLAGS_NORMAL);
	virtual Material_t				*AddTexture(Material_t *mat,INT resid,DWORD flags=TEXFLAGS_NORMAL);
	virtual Material_t				*AddTexture(INT resid,DWORD flags=TEXFLAGS_NORMAL);
	virtual Material_t				*AddEnvMapTexture(Material_t *mat=NULL,DWORD flags=TEXFLAGS_NORMAL);

	virtual Texture_t				*GetTexture(Material_t *mat,short texnum);

	virtual void					RemoveTexture(LPDIRECT3DTEXTURE8 D3DTexture,DWORD &flags);
	virtual void					RemoveTexture(string texname,DWORD &flags);

	virtual BOOL					IntersectTest(CGameObject *gobj);

	virtual void					Tick(FLOAT delta);
	virtual void					ScanMeshes();
	virtual void					Render();
	virtual DWORD					RenderPass();

public:
	BOOL							bDoubleSided;
	BOOL							bEnvironmentMap;
	BOOL							bFadeOut;
	BOOL							bInvertPolys;
	BOOL							bOptimizeMesh;
	BOOL							bOrtho;
	BOOL							bReflectionMap;
	BOOL							bShowBoundingSphere;
	BOOL							bShowCollisionSphere;
	BOOL							bShowVertexInfo;
	BOOL							bTransparency;
	BOOL							bUnlit;
	BOOL							bWireFrame;

	C3DSphere						*BoundingSphereObject;
	C3DSphere						*CollisionSphereObject;

	DWORD							dwNumVertices;

	FLOAT							ScaleRate;
	FLOAT							TextureScaleU;
	FLOAT							TextureScaleV;
	FLOAT							Transparency;

	D3DXCOLOR						AmbientLighting;
	D3DXCOLOR						SpecularLighting;

	LPDIRECT3DVERTEXBUFFER8			D3DXVB8;
	LPD3DXMESH						D3DXMesh;
	MaterialList_t					MaterialList;
};

#endif // !defined(AFX_3DOBJECT_H__5C57AA19_12B9_4B26_9F8A_6F2D28C07D80__INCLUDED_)
