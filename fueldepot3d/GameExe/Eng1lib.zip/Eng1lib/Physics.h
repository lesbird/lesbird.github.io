// Physics.h: interface for the CPhysics class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHYSICS_H__4E52E0B0_E8D9_4822_A2D1_B5E07511EB12__INCLUDED_)
#define AFX_PHYSICS_H__4E52E0B0_E8D9_4822_A2D1_B5E07511EB12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class	CGameObject;

class CPhysics  
{
public:
	CPhysics();
	virtual ~CPhysics();

	virtual void					InitPhysics(D3DXVECTOR3 grav);

	virtual void					DoPhysics(CGameObject *gobj,FLOAT delta);
	virtual void					DoAcceleration(CGameObject *gobj,FLOAT delta);
	virtual void					DoGravity(CGameObject *gobj,FLOAT delta);
	virtual void					DoVelocity(CGameObject *gobj,FLOAT delta);
	virtual void					DoFriction(CGameObject *gobj,FLOAT delta);
	virtual void					DoKineticFriction(CGameObject *gobj,FLOAT delta);
	virtual void					DoStaticFriction(CGameObject *gobj,FLOAT delta);
	virtual void					DoMoveObject(CGameObject *gobj,FLOAT delta);

	virtual void					DoCollideAllObjects(FLOAT delta);
	virtual void					DoMoveAllObjects(FLOAT delta);

	virtual void					AddContact(CGameObject *gobj1,CGameObject *gobj2,D3DXVECTOR3 n,D3DXVECTOR3 p,FLOAT pen);
	virtual void					ResolveContacts(FLOAT delta);

public:
	D3DXVECTOR3						Gravity;
};

extern
CPhysics							*Physics;
/*
extern
CollisionObjectList_t				CollisionObjectList[COLLISION_GRID_SIZE][COLLISION_GRID_SIZE];
*/
#endif // !defined(AFX_PHYSICS_H__4E52E0B0_E8D9_4822_A2D1_B5E07511EB12__INCLUDED_)
