// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MeshManager.h"
#include "ObjectFactory.h"
#include "TexMan.h"

#include "2DSprite.h"
#include "3DCube.h"
#include "3DCylinder.h"
#include "3DLight.h"
#include "3DParticleEmitter.h"
#include "3DPermanentSprite.h"
#include "3DPolygon.h"
#include "3DProjectile.h"
#include "3DSphere.h"
#include "3DSprite.h"

#include "GameType.h"

#include "CRigidBody.hpp"

#define	SAFE_DELETE(p) { if (p != NULL) { delete p; p=NULL; } }
#define	SAFE_RELEASE(p) { if (p != NULL) { ULONG rc=p->Release(); p=NULL; if (rc != 0) Log("SAFE_RELEASE() %s: %ld (%ld remaining)",__FILE__,__LINE__,rc); } }

enum {
	KEY_ESC=1,
	KEY_1,KEY_2,KEY_3,KEY_4,KEY_5,KEY_6,KEY_7,KEY_8,KEY_9,KEY_0,
	KEY_MINUS,KEY_PLUS,KEY_BKSP,KEY_TAB,
	KEY_Q,KEY_W,KEY_E,KEY_R,KEY_T,KEY_Y,KEY_U,KEY_I,KEY_O,KEY_P,
	KEY_LBRACKET,KEY_RBRACKET,KEY_ENTER,KEY_CTRL,
	KEY_A,KEY_S,KEY_D,KEY_F,KEY_G,KEY_H,KEY_J,KEY_K,KEY_L,
	KEY_COLON,KEY_QUOTE,KEY_TILDE,KEY_LSHIFT,KEY_BSLASH,
	KEY_Z,KEY_X,KEY_C,KEY_V,KEY_B,KEY_N,KEY_M,
	KEY_COMMA,KEY_PERIOD,KEY_FSLASH,KEY_RSHIFT,KEY_PRTSC,KEY_ALT,KEY_SPACE,KEY_CAPS,
	KEY_F1,KEY_F2,KEY_F3,KEY_F4,KEY_F5,KEY_F6,KEY_F7,KEY_F8,KEY_F9,KEY_F10,
	KEY_NUM,KEY_SCROLL,KEY_HOME,KEY_UP,KEY_PGUP,KEY_GREYMINUS,KEY_LEFT,KEY_CENTER,KEY_RIGHT,
	KEY_GREYPLUS,KEY_END,KEY_DOWN,KEY_PGDN,KEY_INS,KEY_DEL,
	KEY_F11=87,KEY_F12,
};

extern
BOOL								bKey[256];

extern
BOOL								bKeyPressed;

extern
BOOL								GetKey(short key);

extern
BOOL								PeekKey(short key);

extern
void								InitKeys();

extern
HWND								hWnd;

extern
void								Log(char *fmt,...);

extern
void								Enter(char *fmt,...);

extern
void								Leave();

extern
DWORD								LogLevel;

extern
void								LogExit(char *file,DWORD line);

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
