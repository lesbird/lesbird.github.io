// 3DPermanentSprite.h: interface for the C3DPermanentSprite class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DPERMANENTSPRITE_H__A05AB8B9_4944_4009_A573_07AAFCACB555__INCLUDED_)
#define AFX_3DPERMANENTSPRITE_H__A05AB8B9_4944_4009_A573_07AAFCACB555__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DSprite.h"

class C3DPermanentSprite : public C3DSprite  
{
public:
	C3DPermanentSprite();
	virtual ~C3DPermanentSprite();

	virtual void					DeleteMe();
};

#endif // !defined(AFX_3DPERMANENTSPRITE_H__A05AB8B9_4944_4009_A573_07AAFCACB555__INCLUDED_)
