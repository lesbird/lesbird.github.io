// GameType.cpp: implementation of the CGameType class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "GameType.h"
#include "Input.h"
#include "Physics.h"

FLOAT								CGameType::GameTime=0;

CGameType							*CGameType::GameType=NULL;

BOOL								bPause=FALSE;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGameType::CGameType()
{
	Enter("CGameType()");

	SetObjectID('GAMT');
	SetObjectName("CGAMETYPE");

	bCanTouch=FALSE;
	bInView=FALSE;

	Mass=0;

	GameState=0;
	GameSubState=0;

	GameType=this;

	GameTime=0;

	CMeshManager::Init();

	Leave();
}

CGameType::~CGameType()
{
	Enter("~CGameType()");

	GameType=NULL;

	Leave();
}

void
CGameType::Init()
{
	Enter("Init()");

	CGfx::bMoveTo=FALSE;
	CGfx::ViewFollowObject=NULL;

	CGfx::PrintText(-1,-1,D3DXCOLOR(0.2f,0.5f,1,1),"...L O A D I N G...");
	CGfx::Render();

	CGameObject::Init();
	CGfx::SetFogMode(FALSE);

	bClearDisplay=TRUE;

	Leave();
}

void
CGameType::InitGame()
{
	Enter("InitGame()");

	GameState='INIT';
	GameSubState='INIT';

	if (Physics != NULL) {
		Physics->InitPhysics(D3DXVECTOR3(0,0,0));
	}

	TransformGameObjects(GameObjectList.begin());

	CGfx::ResetDelta();

	InitKeys();

	Leave();
}

void
CGameType::RestartGame()
{
	Enter("RestartGame()");

	GameState='INIT';
	GameSubState='INIT';

	Leave();
}

void
CGameType::SetGameState(DWORD state,DWORD substate)
{
	GameState=state;
	GameSubState=substate;
}

void
CGameType::SetGameSubState(DWORD substate)
{
	GameSubState=substate;
}

void
CGameType::Transform()
{
}

void
CGameType::Tick(FLOAT delta)
{
	GameTime+=delta;
	if (GetKey(KEY_F2)) {
		bControllerEnable=(bControllerEnable ? FALSE : TRUE);
	}
	if (PeekKey(KEY_LSHIFT) && GetKey(KEY_B)) {
		for (GameObjectList_t::iterator o=CGameObject::GameObjectList.begin() ; o != CGameObject::GameObjectList.end() ; o++) {
			CGameObject *gobj=(*o);
			if (gobj->IsA("C3DOBJECT")) {
				C3DObject *gobj3=(C3DObject *)gobj;
				if (!gobj3->bShowBoundingSphere && !gobj3->bShowCollisionSphere) {
					gobj3->bShowBoundingSphere=TRUE;
					gobj3->bShowCollisionSphere=FALSE;
				}
				else if (gobj3->bShowBoundingSphere && !gobj3->bShowCollisionSphere) {
					gobj3->bShowCollisionSphere=TRUE;
					gobj3->bShowBoundingSphere=FALSE;
				}
				else {
					gobj3->bShowBoundingSphere=FALSE;
					gobj3->bShowCollisionSphere=FALSE;
				}
			}
		}
	}
}

void
CGameType::PreObjectCollision(CGameObject *gobj1,CGameObject *gobj2)
{
}

void
CGameType::PostObjectCollision(CGameObject *gobj1,CGameObject *gobj2)
{
}
