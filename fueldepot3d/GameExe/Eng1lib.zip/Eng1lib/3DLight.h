// 3DLight.h: interface for the C3DLight class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DLIGHT_H__F74339BF_A303_4DE8_9C2B_EA4F5833488C__INCLUDED_)
#define AFX_3DLIGHT_H__F74339BF_A303_4DE8_9C2B_EA4F5833488C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

class	C3DSphere;

class C3DLight : public CGameObject  
{
public:
	C3DLight();
	virtual ~C3DLight();

	virtual void					Transform();

	virtual void					Render();

public:
	BOOL							bShowPosition;
	C3DSphere						*PosSphere;

	D3DLIGHT8						D3DLight;

	DWORD							LightIndex;

	static DWORD					GlobalLightIndex;
};

#endif // !defined(AFX_3DLIGHT_H__F74339BF_A303_4DE8_9C2B_EA4F5833488C__INCLUDED_)
