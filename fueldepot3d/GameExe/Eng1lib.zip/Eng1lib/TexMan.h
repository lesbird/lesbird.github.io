// TexMan.h: interface for the CTexMan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXMAN_H__3331E2C0_18CC_11D5_9332_0010B505D77B__INCLUDED_)
#define AFX_TEXMAN_H__3331E2C0_18CC_11D5_9332_0010B505D77B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "d3dx8.h"

#include <list>
#include <string>

using namespace std;

typedef struct TexManList_tag
{
	LPDIRECT3DTEXTURE8				D3DTexture;
	CHAR							FileName[64];
	INT								ResourceID;
} TexManList_t;

typedef list<TexManList_t *>		TextureManagerList_t;

class CTexMan  
{
public:
	CTexMan();
	virtual ~CTexMan();

	static void						UnInit();

	static LPDIRECT3DTEXTURE8		LoadTexture(string filename,DWORD filter=D3DX_DEFAULT,BOOL bBump=FALSE);
	static LPDIRECT3DTEXTURE8		LoadTexture(INT resid,DWORD filter=D3DX_DEFAULT,BOOL bBump=FALSE);

public:
	static TextureManagerList_t		TextureManagerList;
};

extern
DWORD								TexCacheLoad;

#endif // !defined(AFX_TEXMAN_H__3331E2C0_18CC_11D5_9332_0010B505D77B__INCLUDED_)
