// GameObject.h: interface for the CGameObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEOBJECT_H__F4F60926_A752_48E0_9D34_E9DA961E8DBE__INCLUDED_)
#define AFX_GAMEOBJECT_H__F4F60926_A752_48E0_9D34_E9DA961E8DBE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <list>
#include <string>

using namespace std;

typedef list<class CGameObject *>	GameObjectList_t;
typedef list<class CGameObject *>	SecondPassObjectList_t;
typedef list<class CGameObject *>	SortedObjectList_t;

typedef enum {
	COLLTYPE_NONE,
	COLLTYPE_SPHERE,
	COLLTYPE_BOX,
	COLLTYPE_PLANE
} CollType_t;

class CGameObject  
{
public:
	CGameObject();
	virtual ~CGameObject();

	virtual void					ParentDeleted();
	virtual void					SetObjectID(DWORD id);
	virtual void					SetObjectName(string name);
	virtual BOOL					IsA(string name);

	virtual void					Init();
	virtual void					UnInit();

	virtual void					ActivateApp();
	virtual void					DeActivateApp();

	virtual void					InitRigidBody();
	virtual void					UnInitRigidBody();
	virtual void					BuildCubeRigidBody(FLOAT x,FLOAT y,FLOAT z,FLOAT mass,BOOL bStatic);
	virtual void					BuildSphereRigidBody(FLOAT radius,FLOAT mass,BOOL bStatic);
	virtual void					BuildCylinderRigidBody(FLOAT radius,FLOAT height,FLOAT mass,BOOL bStatic);
	virtual void					BuildPlaneRigidBody(FLOAT width,FLOAT height,FLOAT mass,BOOL bIsStatic);
	virtual void					RigidBodyTransform();

	virtual void					Link(class CGameObject *gobj);
	virtual void					UnLink();
	virtual void					SetMass(FLOAT m);
	virtual void					SetPosition(FLOAT x,FLOAT y,FLOAT z);
	virtual void					SetPosition(const D3DXVECTOR3 p);
	virtual void					AddPosition(FLOAT x,FLOAT y,FLOAT z);
	virtual void					AddPosition(const D3DXVECTOR3 p);
	virtual D3DXVECTOR3				GetPosition();
	virtual void					SetRotation(FLOAT x,FLOAT y,FLOAT z);
	virtual void					SetRotation(const D3DXVECTOR3 r);
	virtual void					AddRotation(FLOAT x,FLOAT y,FLOAT z);
	virtual void					AddRotation(const D3DXVECTOR3 r);
	virtual D3DXVECTOR3				GetRotation();
	static D3DXVECTOR3				GetRotation(D3DXQUATERNION qrot);
	virtual void					SetRotationRate(FLOAT x,FLOAT y,FLOAT z);
	virtual void					SetRotationRate(const D3DXVECTOR3 r);
	virtual void					SetVelocity(FLOAT x,FLOAT y,FLOAT z);
	virtual void					SetVelocity(const D3DXVECTOR3 v);
	virtual FLOAT					GetScale();
	virtual D3DXVECTOR3				TransformPoint(FLOAT x,FLOAT y,FLOAT z);
	virtual D3DXVECTOR3				TransformPoint(const D3DXVECTOR3 p);
	virtual D3DXVECTOR3				TransformVector(FLOAT x,FLOAT y,FLOAT z);
	virtual D3DXVECTOR3				TransformVector(const D3DXVECTOR3 v);
	virtual void					Transform();
	virtual BOOL					IsInView(const D3DXVECTOR3 dx);
	virtual void					PreRender();
	virtual void					Render();
	virtual void					PostRender();
	virtual DWORD					RenderPass();
	virtual void					DeleteMe();

	virtual BOOL					IntersectTest(CGameObject *gobj);
	virtual void					IntersectPassed(CGameObject *gobj);
	virtual void					IntersectFailed(CGameObject *gobj);

	virtual void					Touch(CGameObject *gobj);
	virtual void					UnTouch(CGameObject *gobj);
	virtual void					Touching(CGameObject *gobj);
	virtual BOOL					IsTouching(CGameObject *gobj);
	virtual void					FilterObject(CGameObject *gobj);
	virtual void					FilterObject(DWORD objid);
	virtual void					UnFilterObject(CGameObject *gobj);
	virtual BOOL					IsFiltered(CGameObject *gobj);
	virtual BOOL					CanTouch(CGameObject *gobj);

	virtual void					Notify(CGameObject *gobj);
	virtual void					NotifyDelete(CGameObject *gobj);

	virtual void					Tick(FLOAT delta);
	virtual void					DoLifeSpan(FLOAT delta);
	virtual void					DoRotationRate(FLOAT delta);
	virtual void					DoPhysics(FLOAT delta);

	virtual void					RecordDemo();
	virtual void					PlaybackDemo();

	static void						TransformChildObjects(class CGameObject *gobj,GameObjectList_t::iterator c);
	static void						TransformGameObjects(GameObjectList_t::iterator o);
	static void						CollideAllObjects();
	static void						PreRenderAllObjects();
	static void						RenderAllObjects();
	static void						PostRenderAllObjects();
	static void						RenderSecondPassObject(class CGameObject *gobj);
	static void						TickAllObjects(FLOAT delta);
	static void						SortSecondPassObjects();
	static void						GarbageCleanUp();
	static void						RecordDemoAllObjects();
	static void						PlaybackDemoAllObjects();
	static void						DeleteAllObjects();
	static void						DeleteAllObjects(string objname);
	static void						ActivateAllObjects();
	static void						DeActivateAllObjects();
	static void						ResetStatData();

	virtual void					Enter(char *fmt,...);

public:
	BOOL							bActive;
	BOOL							bCanDelete;
	BOOL							bCanTouch;
	BOOL							bDeleteMe;
	BOOL							bEnable;
	BOOL							bFarClip;
	BOOL							bHidden;
	BOOL							bInView;
	BOOL							bNoFog;
	BOOL							bOnGround;
	BOOL							bStatic;
	BOOL							bTransform;
	BOOL							bViewClip;

	DWORD							CollisionGridX;
	DWORD							CollisionGridY;
	DWORD							CollisionGridIndex;

	DWORD							ObjectID;
	string							ObjectName;
	DWORD							ObjectNum;

	DWORD							FilterObjectID;

	D3DXMATRIX						WorldMatrix;

	D3DXVECTOR3						BoundingSpherePoint;
	D3DXVECTOR3						LastPosition;
	D3DXVECTOR3						Position;
	D3DXVECTOR3						RotationRateVec;
	D3DXQUATERNION					Rotation;
	D3DXQUATERNION					RotationRate;
	
	D3DXVECTOR3						Acceleration;
	D3DXVECTOR3						Gravity;
	D3DXVECTOR3						Impulse;
	D3DXVECTOR3						Velocity;

	D3DXVECTOR3						BoundingBoxMin;
	D3DXVECTOR3						BoundingBoxMax;

	CollType_t						CollisionType;

	FLOAT							BoundingSphereRadius;
	FLOAT							CollisionRadius;
	FLOAT							LifeSpan;
	FLOAT							Radius;
//	FLOAT							Scale;
	FLOAT							ScaleX,ScaleY,ScaleZ;
	FLOAT							Timer;
	FLOAT							ViewDist;

	FLOAT							Mass;
	FLOAT							MassFraction;
	FLOAT							Thrust;

	class CGameObject				*Instigator;
	class CGameObject				*ParentObject;

	GameObjectList_t				ChildObjectList;
	GameObjectList_t				NotifyList;
	GameObjectList_t				TouchFilterList;
	GameObjectList_t				TouchedObjectList;

	class CRigidBody				*RigidBody;

	static BOOL						bSortObjects;

	static DWORD					ActiveObjects;
	static DWORD					DeleteObjectCount;
	static DWORD					GameObjectCount;
	static DWORD					GarbageObjectCount;
	static DWORD					RenderObjectCount;
	static DWORD					TickObjectCount;
	static DWORD					TransformObjectCount;
	static DWORD					SecondPassObjectCount;
	static DWORD					SortMethod;

	static GameObjectList_t			GameObjectList;
	static GameObjectList_t			SecondPassObjectList;
	static GameObjectList_t			SortedObjectList;
};

#endif // !defined(AFX_GAMEOBJECT_H__F4F60926_A752_48E0_9D34_E9DA961E8DBE__INCLUDED_)
