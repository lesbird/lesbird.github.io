// Physics.cpp: implementation of the CPhysics class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Physics.h"
#include "GameObject.h"

#include "CollisionHandler.hpp"

#define	GRAVITY_FORCE				0

CPhysics							*Physics=NULL;

#define	MAX_CONTACTS				100

CContact							Contact[MAX_CONTACTS];

DWORD								NumContacts=0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPhysics::CPhysics()
{
	Enter("CPhysics()");

	NumContacts=0;

	Gravity=D3DXVECTOR3(0,0,0);
	Physics=this;

	Leave();
}

CPhysics::~CPhysics()
{
	Enter("~CPhysics()");

	Physics=NULL;

	Leave();
}

void
CPhysics::InitPhysics(D3DXVECTOR3 grav)
{
	Gravity=grav;
}

void
CPhysics::DoPhysics(CGameObject *gobj,FLOAT delta)
{
	if (gobj->RigidBody == NULL) {
		DoGravity(gobj,delta);
		DoAcceleration(gobj,delta);
		DoVelocity(gobj,delta);
		DoFriction(gobj,delta);
	}
}

void
CPhysics::DoAcceleration(CGameObject *gobj,FLOAT delta)
{
	gobj->Acceleration=gobj->TransformVector(0,0,gobj->MassFraction*gobj->Thrust);
}

void
CPhysics::DoGravity(CGameObject *gobj,FLOAT delta)
{
	D3DXVECTOR3	g;
	D3DXVec3Scale(&g,&Gravity,delta);
	D3DXVec3Add(&gobj->Velocity,&gobj->Velocity,&g);
}

void
CPhysics::DoVelocity(CGameObject *gobj,FLOAT delta)
{
	D3DXVECTOR3	a;
	D3DXVec3Scale(&a,&gobj->Acceleration,delta);
	D3DXVec3Add(&gobj->Velocity,&gobj->Velocity,&a);
	D3DXVec3Add(&gobj->Velocity,&gobj->Velocity,&gobj->Impulse);
	gobj->Impulse=D3DXVECTOR3(0,0,0);
}

void
CPhysics::DoFriction(CGameObject *gobj,FLOAT delta)
{
	if (gobj->bOnGround) {
		D3DXVECTOR3	v;
		D3DXVec3Subtract(&v,&gobj->Position,&gobj->LastPosition);
		FLOAT mag=D3DXVec3Length(&v);
		if (mag != 0) {
			DoKineticFriction(gobj,delta);
		}
		else {
			DoStaticFriction(gobj,delta);
		}
	}
}

void
CPhysics::DoKineticFriction(CGameObject *gobj,FLOAT delta)
{
}

void
CPhysics::DoStaticFriction(CGameObject *gobj,FLOAT delta)
{
}

void
CPhysics::DoMoveObject(CGameObject *gobj,FLOAT delta)
{
	if (gobj->RigidBody == NULL) {
		D3DXVECTOR3	v;
		D3DXVec3Scale(&v,&gobj->Velocity,delta);
		gobj->LastPosition=gobj->GetPosition();
		gobj->AddPosition(v);
		FLOAT mag=D3DXVec3Length(&v);
		if (mag < FLT_EPSILON) {
			gobj->SetVelocity(0,0,0);
			gobj->bActive=FALSE;
		}
	}
}

void
CPhysics::DoCollideAllObjects(FLOAT delta)
{
	GameObjectList_t::iterator oend=CGameObject::GameObjectList.end();
	for (GameObjectList_t::iterator o1=CGameObject::GameObjectList.begin() ; o1 != oend ; o1++) {
		CGameObject *gobj1=(*o1);
		if (gobj1->bDeleteMe) {
			continue;
		}
		if (gobj1->bCanTouch) {
			for (GameObjectList_t::iterator o2=o1 ; o2 != oend ; o2++) {
				CGameObject *gobj2=(*o2);
				if (gobj2->bDeleteMe) {
					continue;
				}
				if (gobj1 == gobj2) {
					continue;
				}
				if (gobj2->bCanTouch) {
					if (gobj1->CanTouch(gobj2)) {
						if (gobj1->IntersectTest(gobj2)) {
							gobj1->IntersectPassed(gobj2);
						}
						else {
							gobj1->IntersectFailed(gobj2);
						}
					}
				}
			}
		}
	}
	ResolveContacts(delta);
}

void
CPhysics::DoMoveAllObjects(FLOAT delta)
{
	for (GameObjectList_t::iterator o=CGameObject::GameObjectList.begin() ; o != CGameObject::GameObjectList.end() ; o++) {
		CGameObject *gobj=(*o);
		if (gobj->bDeleteMe) {
			continue;
		}
		DoMoveObject(gobj,delta);
	}
}

void
CPhysics::AddContact(CGameObject *gobj1,CGameObject *gobj2,D3DXVECTOR3 n,D3DXVECTOR3 p,FLOAT pen)
{
	if (NumContacts < MAX_CONTACTS) {
		CContact *c=&Contact[NumContacts++];
		c->body[0]=gobj1->bStatic ? NULL : gobj1->RigidBody;
		c->body[1]=gobj2->bStatic ? NULL : gobj2->RigidBody;
		c->normal[0]=n.x;
		c->normal[1]=n.y;
		c->normal[2]=n.z;
		c->point[0]=p.x;
		c->point[1]=p.y;
		c->point[2]=p.z;
		c->penetration=pen;
		c->restitution=0.5f;
		c->friction=0.8f;
	}
}

void
CPhysics::ResolveContacts(FLOAT delta)
{
	if (NumContacts > 0) {
		CollisionHandler(Contact,NumContacts,2,delta*3,delta,0.1f,0);
		NumContacts=0;
	}
}
