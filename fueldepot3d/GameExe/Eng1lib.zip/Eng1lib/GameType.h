// GameType.h: interface for the CGameType class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMETYPE_H__3022477F_3E64_4634_B4E7_02755B34A985__INCLUDED_)
#define AFX_GAMETYPE_H__3022477F_3E64_4634_B4E7_02755B34A985__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

class CGameType : public CGameObject  
{
public:
	CGameType();
	virtual ~CGameType();

	virtual void					Init();
	virtual void					InitGame();
	virtual void					RestartGame();
	virtual void					SetGameState(DWORD state,DWORD substate='INIT');
	virtual void					SetGameSubState(DWORD substate);

	virtual void					Transform();
	virtual void					Tick(FLOAT delta);

	virtual void					PreObjectCollision(CGameObject *gobj1,CGameObject *gobj2);
	virtual void					PostObjectCollision(CGameObject *gobj1,CGameObject *gobj2);

public:
	DWORD							GameState;
	DWORD							GameSubState;

	static FLOAT					GameTime;

	static class CGameType			*GameType;
};

extern
BOOL								bPause;

#endif // !defined(AFX_GAMETYPE_H__3022477F_3E64_4634_B4E7_02755B34A985__INCLUDED_)
