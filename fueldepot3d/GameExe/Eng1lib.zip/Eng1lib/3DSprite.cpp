// 3DSprite.cpp: implementation of the C3DSprite class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "3DSprite.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DSprite::C3DSprite()
{
	SetObjectName("C3DSPRITE");
	SetObjectID('3SPR');

	bDoubleSided=TRUE;
	bFadeOut=TRUE;
}

C3DSprite::~C3DSprite()
{

}

void
C3DSprite::InitSprite(FLOAT size)
{
	InitPolygon(size);
}

void
C3DSprite::Tick(FLOAT delta)
{
	C3DPolygon::Tick(delta);
}

void
C3DSprite::Transform()
{
	D3DXVECTOR3	dx;
	D3DXVECTOR3	pos;
	if (ParentObject == NULL) {
		if (RigidBody != NULL) {
			RigidBodyTransform();
		}
		D3DXVECTOR3	ScaleVector(ScaleX,ScaleY,ScaleZ);
		D3DXMatrixTransformation(&WorldMatrix,NULL,NULL,&ScaleVector,NULL,&Rotation,&Position);
		pos=Position;
	}
	else {
		D3DXMatrixScaling(&WorldMatrix,ScaleX,ScaleY,ScaleZ);
		D3DXMATRIX	m;
		D3DXMatrixRotationQuaternion(&m,&Rotation);
		D3DXMatrixMultiply(&WorldMatrix,&WorldMatrix,&m);
		D3DXVec3TransformCoord(&pos,&Position,&ParentObject->WorldMatrix);
	}
	D3DXMATRIX	m;
	D3DXMatrixInverse(&m,NULL,&CGfx::ViewMatrix);
	D3DXMatrixMultiply(&WorldMatrix,&WorldMatrix,&m);
	WorldMatrix._41=pos.x;
	WorldMatrix._42=pos.y;
	WorldMatrix._43=pos.z;
	D3DXVec3Subtract(&dx,&pos,&CGfx::ViewPosition);
	bInView=IsInView(dx);
}
