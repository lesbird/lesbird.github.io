// 3DPolygon.h: interface for the C3DPolygon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DPOLYGON_H__95EFEDE0_1A51_11D5_9332_0010B505D77B__INCLUDED_)
#define AFX_3DPOLYGON_H__95EFEDE0_1A51_11D5_9332_0010B505D77B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DObject.h"

class C3DPolygon : public C3DObject  
{
public:
	C3DPolygon();
	virtual ~C3DPolygon();

	virtual void					InitPolygon(FLOAT size);
	virtual void					InitPolygon(FLOAT size,FLOAT scaleu,FLOAT scalev);
	virtual void					InitPolygon(FLOAT sizew,FLOAT sizeh,FLOAT scaleu,FLOAT scalev);
	virtual void					InitPolygon(FLOAT sizew,FLOAT sizeh);
	virtual void					CloneNewFVF(BOOL bComputeNormals=TRUE);
	virtual void					ResizePolygon(FLOAT sizew,FLOAT sizeh);

public:
	FLOAT							Height;
	FLOAT							Width;
};

#endif // !defined(AFX_3DPOLYGON_H__95EFEDE0_1A51_11D5_9332_0010B505D77B__INCLUDED_)
