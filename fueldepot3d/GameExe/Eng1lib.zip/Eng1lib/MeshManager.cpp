// MeshManager.cpp: implementation of the CMeshManager class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "MeshManager.h"

CylinderMeshList_t					CMeshManager::CylinderMeshList;
MeshList_t							CMeshManager::MeshList;
SphereMeshList_t					CMeshManager::SphereMeshList;

LPD3DXMESH							CMeshManager::D3DXBoxMesh=NULL;
LPD3DXMESH							CMeshManager::D3DXPolyMesh=NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMeshManager::CMeshManager()
{

}

CMeshManager::~CMeshManager()
{

}

VOID
CMeshManager::Init()
{
	UnInit();
}

VOID
CMeshManager::UnInit()
{
	Enter("CMeshManager::UnInit()");

	for (CylinderMeshList_t::iterator cylm=CylinderMeshList.begin() ; cylm != CylinderMeshList.end() ; ) {
		CylinderMesh_t *m=(*cylm);
		SAFE_RELEASE(m->D3DXMesh);
		CylinderMeshList.pop_front();
		cylm=CylinderMeshList.begin();
		SAFE_DELETE(m);
	}

	for (MeshList_t::iterator m=MeshList.begin() ; m != MeshList.end() ; ) {
		Mesh_t *mesh=(*m);
		SAFE_RELEASE(mesh->D3DXMesh);
		SAFE_RELEASE(mesh->D3DXMaterialBuffer);
		MeshList.pop_front();
		m=MeshList.begin();
		SAFE_DELETE(mesh);
	}

	for (SphereMeshList_t::iterator sphm=SphereMeshList.begin() ; sphm != SphereMeshList.end() ; ) {
		SphereMesh_t *m=(*sphm);
		SAFE_RELEASE(m->D3DXMesh);
		SphereMeshList.pop_front();
		sphm=SphereMeshList.begin();
		SAFE_DELETE(m);
	}

	Leave();
}

LPD3DXMESH
CMeshManager::LoadMesh(string filename,BOOL bComputeNormals,C3DObject *obj)
{
	Enter("LoadMesh(%s)",filename.c_str());

	if (obj == NULL) {
		Log("obj == NULL");
		Leave();
		return(NULL);
	}
	for (MeshList_t::iterator m=MeshList.begin() ; m != MeshList.end() ; m++) {
		Mesh_t *mesh=(*m);
		if (strcmp(mesh->MeshName,filename.c_str()) == 0) {
			mesh->D3DXMesh->AddRef();
			obj->D3DXMesh=mesh->D3DXMesh;
			obj->CloneNewFVF(bComputeNormals);
			if (mesh->D3DXMaterialBuffer != NULL) {
				D3DXMATERIAL *matlist=(D3DXMATERIAL *)mesh->D3DXMaterialBuffer->GetBufferPointer();
				for (short n=0 ; n < mesh->NumMaterials ; n++) {
					Material_t *mat=obj->AddMaterial(&matlist[n].MatD3D);
					if (matlist[n].pTextureFilename != NULL) {
						obj->AddTexture(mat,matlist[n].pTextureFilename);
					}
				}
			}
			obj->ComputeBoundingSphere();
			obj->ComputeBoundingBox();
			Leave();
			return(obj->D3DXMesh);
		}
	}

	DWORD			NumMaterials;
	LPD3DXBUFFER	D3DXMaterialBuffer=NULL;
	LPD3DXBUFFER	D3DXAdjacencyBuffer=NULL;
	LPD3DXMESH		D3DXMesh=NULL;

	string xfile="X\\"+filename;
	HRESULT hr=D3DXLoadMeshFromX((char *)xfile.c_str(),D3DXMESH_MANAGED,CGfx::lpD3DDevice8,&D3DXAdjacencyBuffer,&D3DXMaterialBuffer,&NumMaterials,&D3DXMesh);
	if (hr == D3D_OK) {
	    hr=D3DXMesh->OptimizeInplace(D3DXMESHOPT_COMPACT|D3DXMESHOPT_ATTRSORT|D3DXMESHOPT_VERTEXCACHE,(DWORD *)D3DXAdjacencyBuffer->GetBufferPointer(),NULL,NULL,NULL);
		if (hr == D3D_OK) {
			D3DXMATERIAL *matlist=(D3DXMATERIAL *)D3DXMaterialBuffer->GetBufferPointer();
			for (short n=0 ; n < NumMaterials ; n++) {
				Material_t *mat=obj->AddMaterial(&matlist[n].MatD3D);
				if (matlist[n].pTextureFilename != NULL) {
					obj->AddTexture(mat,matlist[n].pTextureFilename);
				}
			}
			SAFE_RELEASE(D3DXAdjacencyBuffer);
		}
		D3DXMesh->AddRef();
		obj->D3DXMesh=D3DXMesh;
		obj->CloneNewFVF(bComputeNormals);

		Mesh_t *mesh=new Mesh_t;
		strcpy(mesh->MeshName,filename.c_str());
		mesh->D3DXMesh=D3DXMesh;
		mesh->D3DXMaterialBuffer=D3DXMaterialBuffer;
		mesh->NumMaterials=NumMaterials;
		MeshList.push_back(mesh);

		obj->ComputeBoundingSphere();
		obj->ComputeBoundingBox();

		Leave();

		return(obj->D3DXMesh);
	}
	
	Leave();

	return(NULL);
}
/*
LPD3DXMESH
CMeshManager::CreateMesh(MeshType_t meshtype,FLOAT sizex,FLOAT sizey,FLOAT sizez,C3DObject *obj)
{
	if (obj == NULL) {
		return(NULL);
	}
	for (MeshList_t::iterator m=MeshList.begin() ; m != MeshList.end() ; m++) {
		Mesh_t *mesh=(*m);
		if (mesh->MeshType == meshtype) {
			mesh->D3DXMesh->AddRef();
			obj->D3DXMesh=mesh->D3DXMesh;
			obj->CloneNewFVF();
			return(obj->D3DXMesh);
		}
	}

	LPD3DXMESH D3DXMesh=NULL;
	switch (meshtype) {
	case MESHTYPE_BOX:
		if (D3DXBoxMesh == NULL) {
			D3DXCreateBox(CGfx::lpD3DDevice8,sizex,sizey,sizez,&D3DXBoxMesh,NULL);
		}
		D3DXMesh=D3DXBoxMesh;
		break;
	case MESHTYPE_CYLINDER:
		if (D3DXCylinderMesh == NULL) {
			D3DXCreateCylinder(CGfx::lpD3DDevice8,sizex,sizez,sizey,16,16,&D3DXMesh,NULL);
		}
		D3DXMesh=D3DXCylinderMesh;
		break;
	case MESHTYPE_POLY:
		if (D3DXPolyMesh == NULL) {
			D3DXCreatePolygon(CGfx::lpD3DDevice8,sizex,4,&D3DXPolyMesh,NULL);
		}
		D3DXMesh=D3DXPolyMesh;
		break;
	case MESHTYPE_SPHERE:
		if (D3DXSphereMesh == NULL) {
			D3DXCreateSphere(CGfx::lpD3DDevice8,sizex,64,64,&D3DXSphereMesh,NULL);
		}
		D3DXMesh=D3DXSphereMesh;
		break;
	}
	if (D3DXMesh != NULL) {
		D3DXMesh->AddRef();
		obj->D3DXMesh=D3DXMesh;
		obj->CloneNewFVF();

		Mesh_t *mesh=new Mesh_t;
		mesh->MeshType=meshtype;
		strcpy(mesh->MeshName,"");
		mesh->D3DXMesh=D3DXMesh;
		MeshList.push_back(mesh);
	}
	return(obj->D3DXMesh);
}

LPD3DXMESH
CMeshManager::CreateMesh(MeshType_t meshtype,FLOAT size,C3DObject *gobj)
{
	CreateMesh(meshtype,size,0,0,C3DObject *obj);
}
*/

LPD3DXMESH
CMeshManager::ResizeMesh(LPD3DXMESH D3DXMesh,FLOAT sizex,FLOAT sizey,FLOAT sizez,C3DObject *obj)
{
	D3DXMesh->AddRef();
	obj->D3DXMesh=D3DXMesh;
	obj->CloneNewFVF(FALSE);
	FVFVertex_t *verts;
	obj->D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
	if (verts != NULL) {
		for (LONG n=0 ; n < obj->D3DXMesh->GetNumVertices() ; n++) {
			verts[n].pos.x*=sizex;
			verts[n].pos.y*=sizey;
			verts[n].pos.z*=sizez;
		}
		obj->D3DXMesh->UnlockVertexBuffer();
	}
	D3DXComputeNormals(obj->D3DXMesh,NULL);

	obj->ComputeBoundingSphere();
	obj->ComputeBoundingBox();
	
	return(obj->D3DXMesh);
}

LPD3DXMESH
CMeshManager::CreateBoxMesh(FLOAT sizex,FLOAT sizey,FLOAT sizez,C3DObject *obj)
{
	if (D3DXBoxMesh == NULL) {
		D3DXCreateBox(CGfx::lpD3DDevice8,1,1,1,&D3DXBoxMesh,NULL);
	}
	return(ResizeMesh(D3DXBoxMesh,sizex,sizey,sizez,obj));
}

LPD3DXMESH
CMeshManager::CreateCylinderMesh(FLOAT radiusx,FLOAT radiusz,FLOAT length,UINT slices,UINT stacks,C3DObject *obj)
{
	for (CylinderMeshList_t::iterator c=CylinderMeshList.begin() ; c != CylinderMeshList.end() ; c++) {
		CylinderMesh_t *m=(*c);
		if (m->Slices == slices && m->Stacks == stacks) {
			return(ResizeMesh(m->D3DXMesh,radiusx,length,radiusz,obj));
		}
	}
	LPD3DXMESH D3DXCylinderMesh=NULL;
	D3DXCreateCylinder(CGfx::lpD3DDevice8,1,1,1,slices,stacks,&D3DXCylinderMesh,NULL);

	CylinderMesh_t *m=new CylinderMesh_t;
	m->D3DXMesh=D3DXCylinderMesh;
	m->Slices=slices;
	m->Stacks=stacks;
	CylinderMeshList.push_back(m);

	return(ResizeMesh(D3DXCylinderMesh,radiusx,length,radiusz,obj));
}

LPD3DXMESH
CMeshManager::CreatePolyMesh(FLOAT size,C3DObject *obj)
{
	if (D3DXPolyMesh == NULL) {
		D3DXCreatePolygon(CGfx::lpD3DDevice8,1,4,&D3DXPolyMesh,NULL);
	}
	D3DXPolyMesh->AddRef();
	obj->D3DXMesh=D3DXPolyMesh;
	obj->CloneNewFVF(FALSE);

	obj->ComputeBoundingSphere();
	obj->ComputeBoundingBox();

	return(obj->D3DXMesh);
}

LPD3DXMESH
CMeshManager::CreateSphereMesh(FLOAT radius,FLOAT slices,FLOAT stacks,C3DObject *obj)
{
	for (SphereMeshList_t::iterator c=SphereMeshList.begin() ; c != SphereMeshList.end() ; c++) {
		SphereMesh_t *m=(*c);
		if (m->Slices == slices && m->Stacks == stacks) {
			ResizeMesh(m->D3DXMesh,radius,radius,radius,obj);
			obj->SphereMapTexture();
			return(obj->D3DXMesh);
		}
	}
	LPD3DXMESH D3DXSphereMesh=NULL;
	D3DXCreateSphere(CGfx::lpD3DDevice8,1,slices,stacks,&D3DXSphereMesh,NULL);

	SphereMesh_t *m=new SphereMesh_t;
	m->D3DXMesh=D3DXSphereMesh;
	m->Slices=slices;
	m->Stacks=stacks;
	SphereMeshList.push_back(m);

	ResizeMesh(D3DXSphereMesh,radius,radius,radius,obj);
	obj->SphereMapTexture();
	return(obj->D3DXMesh);
}
