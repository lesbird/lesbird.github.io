// 3DCylinder.cpp: implementation of the C3DCylinder class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "3DCylinder.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DCylinder::C3DCylinder()
{

}

C3DCylinder::~C3DCylinder()
{

}

void
C3DCylinder::InitCylinder(FLOAT radiusx,FLOAT radiusz,FLOAT length,UINT slices,UINT stacks)
{
	SetObjectID('3CYL');
	SetObjectName("C3DCYLINDER");
	CMeshManager::CreateCylinderMesh(radiusx,radiusz,length,slices,stacks,this);
}

void
C3DCylinder::CloneNewFVF(BOOL bComputeNormals)
{
	if (D3DXMesh != NULL) {
		C3DObject::CloneNewFVF(bComputeNormals);
/*
		FVFVertex_t *verts;
		D3DXMesh->LockVertexBuffer(0,(BYTE **)&verts);
		if (verts != NULL) {
			LONG num=D3DXMesh->GetNumVertices();
			for (short n=0 ; n < num ; n++) {
				switch (n) {
				case 0:
					verts[n].tu1=1;
					verts[n].tv1=1;
					break;
				case 1:
				case 5:
				case 11:
				case 13:
				case 17:
				case 20:
					verts[n].tu1=0;
					verts[n].tv1=1;
					break;
				case 2:
				case 6:
				case 8:
				case 14:
				case 18:
				case 21:
					verts[n].tu1=0;
					verts[n].tv1=0;
					break;
				case 3:
				case 7:
				case 9:
				case 15:
				case 19:
				case 22:
					verts[n].tu1=1;
					verts[n].tv1=0;
					break;
				default:
					verts[n].tu1=0;
					verts[n].tv1=0;
					break;
				}
				verts[n].tu2=verts[n].tu1;
				verts[n].tv2=verts[n].tv1;
				verts[n].tu3=verts[n].tu1;
				verts[n].tv3=verts[n].tv1;
			}
		}
		D3DXMesh->UnlockVertexBuffer();
*/
	}
}
