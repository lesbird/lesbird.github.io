// 3DCube.h: interface for the C3DCube class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DCUBE_H__81DEFDC0_D488_4310_8B2B_648CDA3C55EA__INCLUDED_)
#define AFX_3DCUBE_H__81DEFDC0_D488_4310_8B2B_648CDA3C55EA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "3DObject.h"

class C3DCube : public C3DObject
{
public:
	C3DCube();
	virtual ~C3DCube();

	virtual void					InitCube(FLOAT size);
	virtual void					InitCube(FLOAT w,FLOAT h,FLOAT d,FLOAT scaleu,FLOAT scalev);
	virtual void					CloneNewFVF(BOOL bComputeNormals=TRUE);
};

#endif // !defined(AFX_3DCUBE_H__81DEFDC0_D488_4310_8B2B_648CDA3C55EA__INCLUDED_)
