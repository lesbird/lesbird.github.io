// DefaultGame.h: interface for the CDefaultGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEFAULTGAME_H__02762825_BA79_4416_B91D_0CDBB306CBDE__INCLUDED_)
#define AFX_DEFAULTGAME_H__02762825_BA79_4416_B91D_0CDBB306CBDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"

class CDefaultGame : public CGameObject
{
public:
	CDefaultGame();
	virtual ~CDefaultGame();

	virtual void					Init();
	virtual void					Tick(FLOAT delta);
	virtual void					HandleKeys(DWORD gamestate,FLOAT delta);
	virtual void					Transform();
};

extern
CHAR								*AppName;

#endif // !defined(AFX_DEFAULTGAME_H__02762825_BA79_4416_B91D_0CDBB306CBDE__INCLUDED_)
