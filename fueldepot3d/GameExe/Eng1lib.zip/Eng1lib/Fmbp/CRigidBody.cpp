// FREE SOURCE CODE
// Eugene Laptev, Oxford Dynamics www.oxforddynamics.co.uk
// Copyright (c) 2000, 2001. All Rights Reserved
// This file is subject to license
#ifdef _DEBUG
 #include <stdio.h>
#endif//of #ifdef _DEBUG

#include <stdlib.h>
#include <string.h>//for memset
#include <math.h>
#include "CRigidBody.hpp"

using namespace Vitamina;

CRigidBody::CRigidBody()
{
 real zero_state[13]={0,0,0,0,0,0,0,0,0,0,0,0,0};
 SetStateVector(zero_state);
 m_Q[0]=((real)1.0);
 m_Q[1]=((real)0.0);
 m_Q[2]=((real)0.0);
 m_Q[3]=((real)0.0);
 linear_damping=((real)100.0);
 angular_damping=((real)100.0);
 permanent_force_local_exists=0;
 permanent_torque_local_exists=0;
 ZeroPermanentForce();
 ZeroInstantForce();
 ZeroImpulsiveForce();
 ZeroPermanentTorque();
 ZeroInstantTorque();
 ZeroImpulsiveTorque();
}

int CRigidBody::Build
(
 const real gravity_world[3],//Expressed in World!
 const real TOI_body[3],//m_TOI of the body in body r.f..
 real mass_body//Mass of the chassis.
)
{
 {//Warnings and errors
  if(TOI_body[0]<0||TOI_body[1]<0||TOI_body[2]<0)
  {
   ErrorReport("TOI_body cannot be negative.");
   ASSERT("TOI_body cannot be negative."&&0);
   return 0;
  }
  if(TOI_body[0]+TOI_body[1]<TOI_body[2]|| TOI_body[1]+TOI_body[2]<TOI_body[0]||TOI_body[0]+TOI_body[2]<TOI_body[1])
  {
   ErrorReport("TOI_body does not follow triangle rule.");
   ASSERT("TOI_body does not follow triangle rule."&&0);
   return 0;
  }
 }

 gravity[0]=gravity_world[0];
 gravity[1]=gravity_world[1];
 gravity[2]=gravity_world[2];

 m_TOI[0]=TOI_body[0];
 m_TOI[1]=TOI_body[1];
 m_TOI[2]=TOI_body[2];

 m_mass=mass_body;
 m_state_is_corrupt=1;
 return 1;
}

real CRigidBody::GetMass()const
{
 return m_mass;
}

void CRigidBody::GetTOILocal(real TOI[3])const
{
 TOI[0]=m_TOI[0];
 TOI[1]=m_TOI[1];
 TOI[2]=m_TOI[2];
}

void CRigidBody::GetInverseTOIWorld(real t[3][3])const
{
 ASSERT(!m_state_is_corrupt);
 //memcpy(t,m_TOI_world_inverse,9*sizeof(real));
 t[0][0]=m_TOI_world_inverse[0][0];
 t[0][1]=m_TOI_world_inverse[0][1];
 t[0][2]=m_TOI_world_inverse[0][2];
 t[1][0]=m_TOI_world_inverse[1][0];
 t[1][1]=m_TOI_world_inverse[1][1];
 t[1][2]=m_TOI_world_inverse[1][2];
 t[2][0]=m_TOI_world_inverse[2][0];
 t[2][1]=m_TOI_world_inverse[2][1];
 t[2][2]=m_TOI_world_inverse[2][2];
}

const real* CRigidBody::GetInverseTOIWorld()const
{
 ASSERT(!m_state_is_corrupt);
 return (real*)m_TOI_world_inverse;
}

void CRigidBody::GetTransform(real m[16])const
{//
 //Definition of TM (orinetation):  x_body = TM * x_world
 //The same matrix is used for graphics in OpenGL
 ASSERT(!m_state_is_corrupt&&"You have changed some parts of state vector that may prevent proper returned value.");

 m[0]=m_TM[0][0];
 m[1]=m_TM[0][1];
 m[2]=m_TM[0][2];
 m[3]=0;
 m[4]=m_TM[1][0];
 m[5]=m_TM[1][1];
 m[6]=m_TM[1][2];
 m[7]=0;
 m[8]=m_TM[2][0];
 m[9]=m_TM[2][1];
 m[10]=m_TM[2][2];
 m[11]=0;
 m[12]=m_position[0];
 m[13]=m_position[1];
 m[14]=m_position[2];
 m[15]=1;
}

void CRigidBody::GetOrientation(real m[3][3])const
{
 ASSERT(!m_state_is_corrupt&&"You have changed some parts of state vector that may prevent proper returned value.");
 //memcpy(m,m_TM,9*sizeof(real));
 m[0][0]=m_TM[0][0];
 m[0][1]=m_TM[0][1];
 m[0][2]=m_TM[0][2];
 m[1][0]=m_TM[1][0];
 m[1][1]=m_TM[1][1];
 m[1][2]=m_TM[1][2];
 m[2][0]=m_TM[2][0];
 m[2][1]=m_TM[2][1];
 m[2][2]=m_TM[2][2];
}

const real* CRigidBody::GetOrientation()const
{
 ASSERT(!m_state_is_corrupt&&"You have changed some parts of state vector that may prevent proper returned value.");
 return (real*)m_TM;
}

void CRigidBody::GetQuaternion(real Q[4])const
{
 Q[0]=m_Q[0];
 Q[1]=m_Q[1];
 Q[2]=m_Q[2];
 Q[3]=m_Q[3];
}

const real* CRigidBody::GetQuaternion()const
{
 return m_Q;
}

void CRigidBody::SetQuaternion(const real Q[4])
{
 m_Q[0]=Q[0];
 m_Q[1]=Q[1];
 m_Q[2]=Q[2];
 m_Q[3]=Q[3];
 NormalizeQuaternion(m_Q);
 m_state_is_corrupt=1;
}

void CRigidBody::SetQuaternion(real q0,real qx,real qy,real qz)
{
 m_Q[0]=q0;
 m_Q[1]=qx;
 m_Q[2]=qy;
 m_Q[3]=qz;
 NormalizeQuaternion(m_Q);
 m_state_is_corrupt=1;
}

void CRigidBody::SetOrientation(const real m[3][3]) //Converts to quaternion and sets
{
 real q[4];
 MatrixToQuaternion(q,m);
 SetQuaternion(q);
}

void CRigidBody::Rotate(real angle,int axis)
{//Rotates the body around World axis (012) counterclockwise.
 ASSERT(axis>=0&&axis<=2);
 //TM:= TM &* R
 real r[3][3];
 int i,j,k;
 if(axis==0)
 {
  r[0][0]=((real)1.0);
  r[0][1]=((real)0.0);
  r[0][2]=((real)0.0);
  r[1][0]=((real)0.0);
  r[2][0]=((real)0.0);
  r[1][1]=r[2][2]=(real)cos(angle);
  r[1][2]=(real)sin(angle);
  r[2][1]=-r[1][2];
 }
 else if(axis==1)
 {
  r[1][1]=((real)1.0);
  r[1][0]=((real)0.0);
  r[1][2]=((real)0.0);
  r[0][1]=((real)0.0);
  r[2][1]=((real)0.0);
  r[0][0]=r[2][2]=(real)cos(angle);
  r[2][0]=(real)sin(angle);
  r[0][2]=-r[2][0];
 }
 else if(axis==2)
 {
  r[2][2]=((real)1.0);
  r[2][0]=((real)0.0);
  r[2][1]=((real)0.0);
  r[0][2]=((real)0.0);
  r[1][2]=((real)0.0);
  r[0][0]=r[1][1]=(real)cos(angle);
  r[0][1]=(real)sin(angle);
  r[1][0]=-r[0][1];
 }

 real tm[3][3];
 real tm_new[3][3]={{0,0,0},{0,0,0},{0,0,0}};
 GetOrientation(tm);
 for(i=0;i<3;i++)
 for(j=0;j<3;j++)
 for(k=0;k<3;k++)
  tm_new[i][j]+=tm[i][k]*r[k][j];
 SetOrientation(tm_new);
 SetState();
}

void CRigidBody::RotateLocal(real angle,int axis)
{//Rotates the body around World axis (012) counterclockwise.
 ASSERT(axis>=0&&axis<=2);
 //TM:= TM &* R
 real r[3][3];
 int i,j,k;
 if(axis==0)
 {
  r[0][0]=((real)1.0);
  r[0][1]=((real)0.0);
  r[0][2]=((real)0.0);
  r[1][0]=((real)0.0);
  r[2][0]=((real)0.0);
  r[1][1]=r[2][2]=(real)cos(angle);
  r[1][2]=(real)sin(angle);
  r[2][1]=-r[1][2];
 }
 else if(axis==1)
 {
  r[1][1]=((real)1.0);
  r[1][0]=((real)0.0);
  r[1][2]=((real)0.0);
  r[0][1]=((real)0.0);
  r[2][1]=((real)0.0);
  r[0][0]=r[2][2]=(real)cos(angle);
  r[2][0]=(real)sin(angle);
  r[0][2]=-r[2][0];
 }
 else if(axis==2)
 {
  r[2][2]=((real)1.0);
  r[2][0]=((real)0.0);
  r[2][1]=((real)0.0);
  r[0][2]=((real)0.0);
  r[1][2]=((real)0.0);
  r[0][0]=r[1][1]=(real)cos(angle);
  r[0][1]=(real)sin(angle);
  r[1][0]=-r[0][1];
 }

 real tm[3][3];
 real tm_new[3][3]={{0,0,0},{0,0,0},{0,0,0}};
 GetOrientation(tm);
 for(i=0;i<3;i++)
 for(j=0;j<3;j++)
 for(k=0;k<3;k++)
  tm_new[i][j]+=r[i][k]*tm[k][j];
 SetOrientation(tm_new);
 SetState();
}

void CRigidBody::GetPosition(real position[3])const
{//
 //ASSERT(!m_state_is_corrupt&&"You have changed some parts of state vector that may prevent proper returned value.");
 position[0]=m_position[0];
 position[1]=m_position[1];
 position[2]=m_position[2];
}

//const real* CRigidBody::GetPosition()const
//{
// //ASSERT(!m_state_is_corrupt&&"You have changed some parts of state vector that may prevent proper returned value.");
// return m_position;
//}

void CRigidBody::SetPosition(const real position[3])
{
 m_position[0]=position[0];
 m_position[1]=position[1];
 m_position[2]=position[2];
 m_state_is_corrupt=1;
}

void CRigidBody::SetPosition(real x, real y, real z)
{//
 m_position[0]=x;
 m_position[1]=y;
 m_position[2]=z;
 m_state_is_corrupt=1;
}

void CRigidBody::GetVelocity(real velocity[3])const
{//
 velocity[0]=m_velocity[0];
 velocity[1]=m_velocity[1];
 velocity[2]=m_velocity[2];
}

const real* CRigidBody::GetVelocity()const
{
 return m_velocity;
}

void CRigidBody::SetVelocity(const real velocity[3])
{
 m_velocity[0]=velocity[0];
 m_velocity[1]=velocity[1];
 m_velocity[2]=velocity[2];
 m_state_is_corrupt=1;
}

void CRigidBody::SetVelocity(real x,real y,real z)
{
 m_velocity[0]=x;
 m_velocity[1]=y;
 m_velocity[2]=z;
 m_state_is_corrupt=1;
}

void CRigidBody::GetAngularVelocity(real angular_velocity[3])const
{//
 angular_velocity[0]=m_angular_velocity[0];
 angular_velocity[1]=m_angular_velocity[1];
 angular_velocity[2]=m_angular_velocity[2];
}

const real* CRigidBody::GetAngularVelocity()const
{
 return m_angular_velocity;
}

void CRigidBody::SetAngularVelocity(const real angular_velocity[3])
{
 m_angular_velocity[0]=angular_velocity[0];
 m_angular_velocity[1]=angular_velocity[1];
 m_angular_velocity[2]=angular_velocity[2];
 m_state_is_corrupt=1;
}

void CRigidBody::SetAngularVelocity(real x,real y,real z)
{
 m_angular_velocity[0]=x;
 m_angular_velocity[1]=y;
 m_angular_velocity[2]=z;
 m_state_is_corrupt=1;
}

void CRigidBody::ZeroInstantForce()
{//
 m_instant_force[0]=m_permanent_force[0];
 m_instant_force[1]=m_permanent_force[1];
 m_instant_force[2]=m_permanent_force[2];
 if(permanent_force_local_exists)
 {
  ASSERT(!m_state_is_corrupt);
  fcmToWorldAdd(m_instant_force,m_permanent_force_local,m_TM);
 }
}

void CRigidBody::ZeroPermanentForce()
{//
 m_permanent_force[0]=0;
 m_permanent_force[1]=0;
 m_permanent_force[2]=0;
}

void CRigidBody::ZeroPermanentForceLocal()
{
 m_permanent_force_local[0]=0;
 m_permanent_force_local[1]=0;
 m_permanent_force_local[2]=0;
 permanent_force_local_exists=0;
}

void CRigidBody::ZeroImpulsiveForce()
{//
 m_impulsive_force[0]=0;
 m_impulsive_force[1]=0;
 m_impulsive_force[2]=0;
}

void CRigidBody::AddInstantForce(const real force[3])
{//
 m_instant_force[0]+=force[0];
 m_instant_force[1]+=force[1];
 m_instant_force[2]+=force[2];
}

void CRigidBody::AddInstantForceLocal(const real force[3])
{
 ASSERT(!m_state_is_corrupt);
 ToWorldAdd(m_instant_force,force,m_TM);
}

void CRigidBody::AddPermanentForce(const real force[3])
{//
 m_permanent_force[0]+=force[0];
 m_permanent_force[1]+=force[1];
 m_permanent_force[2]+=force[2];
}

void CRigidBody::AddPermanentForceLocal(const real force[3])
{
 m_permanent_force_local[0]+=force[0];
 m_permanent_force_local[1]+=force[1];
 m_permanent_force_local[2]+=force[2];
 permanent_force_local_exists=1;
}

void CRigidBody::AddImpulsiveForceLocal(const real impulsive_force[3])
{
 ASSERT(!m_state_is_corrupt);
 ToWorldAdd(m_impulsive_force,impulsive_force,m_TM);
}

void CRigidBody::AddInstantForceAtPoint(const real force[3],const real point[3])
{//
 real r[4]align;
 r[0]=point[0]-m_position[0];
 r[1]=point[1]-m_position[1];
 r[2]=point[2]-m_position[2];

 real rxf[4]align;
 CrossProduct(rxf,r,force);

 m_instant_force[0]+=force[0];
 m_instant_force[1]+=force[1];
 m_instant_force[2]+=force[2];

 fcmAddTo(m_instant_torque,rxf);
}

void CRigidBody::AddInstantForceAtPointLocal(const real force[3],const real point[3])
{
 ASSERT(!m_state_is_corrupt);
 real rxf[4]align;
 CrossProduct(rxf,point,force);

 ToWorldAdd(m_instant_force,force,m_TM);
 fcmToWorldAdd(m_instant_torque,rxf,m_TM);
}

void CRigidBody::AddPermanentForceAtPoint(const real force[3],const real point[3])
{
 real r[4]align;
 r[0]=point[0]-m_position[0];
 r[1]=point[1]-m_position[1];
 r[2]=point[2]-m_position[2];

 real rxf[4]align;
 CrossProduct(rxf,r,force);

 m_permanent_force[0]+=force[0];
 m_permanent_force[1]+=force[1];
 m_permanent_force[2]+=force[2];

 fcmAddTo(m_permanent_torque,rxf);
}

void CRigidBody::AddPermanentForceAtPointLocal(const real force[3],const real point[3])
{
 m_permanent_force_local[0]+=force[0];
 m_permanent_force_local[1]+=force[1];
 m_permanent_force_local[2]+=force[2];
 permanent_force_local_exists=1;
 real rxf[4]align;
 CrossProduct(rxf,point,force);
 fcmAddTo(m_permanent_torque_local,rxf);
 permanent_torque_local_exists=1;
}

void CRigidBody::AddImpulsiveForceAtPoint(const real impulsive_force[3],const real point[3])
{
 real r[4]align;
 r[0]=point[0]-m_position[0];
 r[1]=point[1]-m_position[1];
 r[2]=point[2]-m_position[2];

 real rxf[4]align;
 CrossProduct(rxf,r,impulsive_force);

 m_impulsive_force[0]+=impulsive_force[0];
 m_impulsive_force[1]+=impulsive_force[1];
 m_impulsive_force[2]+=impulsive_force[2];

 fcmAddTo(m_impulsive_torque,rxf);
}

void CRigidBody::AddImpulsiveForceAtPointLocal(const real impulsive_force[3],const real point[3])
{
 ASSERT(!m_state_is_corrupt);
 real rxf[4]align;
 CrossProduct(rxf,point,impulsive_force);
 ToWorldAdd(m_impulsive_force,impulsive_force,m_TM);
 fcmToWorldAdd(m_impulsive_torque,rxf,m_TM);
}

void CRigidBody::ZeroInstantTorque()
{
 m_instant_torque[0]=m_permanent_torque[0];
 m_instant_torque[1]=m_permanent_torque[1];
 m_instant_torque[2]=m_permanent_torque[2];
 if(permanent_torque_local_exists)
 {
  ASSERT(!m_state_is_corrupt);
  fcmToWorldAdd(m_instant_torque,m_permanent_torque_local,m_TM);
 }
}

void CRigidBody::ZeroPermanentTorque()
{
 m_permanent_torque[0]=0;
 m_permanent_torque[1]=0;
 m_permanent_torque[2]=0;
}

void CRigidBody::ZeroPermanentTorqueLocal()
{
 m_permanent_torque_local[0]=0;
 m_permanent_torque_local[1]=0;
 m_permanent_torque_local[2]=0;
 permanent_torque_local_exists=0;
}

void CRigidBody::ZeroImpulsiveTorque()
{
 m_impulsive_torque[0]=0;
 m_impulsive_torque[1]=0;
 m_impulsive_torque[2]=0;
}

void CRigidBody::AddInstantTorque(const real torque[3])
{
 m_instant_torque[0]+=torque[0];
 m_instant_torque[1]+=torque[1];
 m_instant_torque[2]+=torque[2];
}

void CRigidBody::AddInstantTorqueLocal(const real torque[3])
{
 ASSERT(!m_state_is_corrupt);
 ToWorldAdd(m_instant_torque,torque,m_TM);
}

void CRigidBody::AddPermanentTorque(const real torque[3])
{
 m_permanent_torque[0]+=torque[0];
 m_permanent_torque[1]+=torque[1];
 m_permanent_torque[2]+=torque[2];
}

void CRigidBody::AddPermanentTorqueLocal(const real torque[3])
{
 m_permanent_torque_local[0]+=torque[0];
 m_permanent_torque_local[1]+=torque[1];
 m_permanent_torque_local[2]+=torque[2];
 permanent_torque_local_exists=1;
}

void CRigidBody::AddImpulsiveTorque(const real impulsive_torque[3])
{
 m_impulsive_torque[0]+=impulsive_torque[0];
 m_impulsive_torque[1]+=impulsive_torque[1];
 m_impulsive_torque[2]+=impulsive_torque[2];
}

void CRigidBody::AddImpulsiveTorqueLocal(const real impulsive_torque[3])
{
 ASSERT(!m_state_is_corrupt);
 ToWorldAdd(m_impulsive_torque,impulsive_torque,m_TM);
}

void CRigidBody::ComputeDerivedQuantities()
{
 //Compute transformation matrix. Korn p. 448 transposed
 QuaternionToMatrix(m_TM,m_Q);

 //Rotate tensor of inertia to World: TOI_world = TM^t * TOI * TM.
 m_TOI_world[0][0]=m_TM[0][0]*m_TM[0][0]*m_TOI[0]+m_TM[1][0]*m_TM[1][0]*m_TOI[1]+m_TM[2][0]*m_TM[2][0]*m_TOI[2];
 m_TOI_world[1][1]=m_TM[0][1]*m_TM[0][1]*m_TOI[0]+m_TM[1][1]*m_TM[1][1]*m_TOI[1]+m_TM[2][1]*m_TM[2][1]*m_TOI[2];
 m_TOI_world[2][2]=m_TM[0][2]*m_TM[0][2]*m_TOI[0]+m_TM[1][2]*m_TM[1][2]*m_TOI[1]+m_TM[2][2]*m_TM[2][2]*m_TOI[2];
 m_TOI_world[1][0]=m_TOI_world[0][1]=-(m_TM[0][0]*m_TM[0][1]*(m_TOI[2]-m_TOI[0])+m_TM[1][0]*m_TM[1][1]*(m_TOI[2]-m_TOI[1]));
 m_TOI_world[2][1]=m_TOI_world[1][2]=-(m_TM[0][1]*m_TM[0][2]*(m_TOI[2]-m_TOI[0])+m_TM[1][1]*m_TM[1][2]*(m_TOI[2]-m_TOI[1]));
 m_TOI_world[2][0]=m_TOI_world[0][2]=-(m_TM[0][0]*m_TM[0][2]*(m_TOI[2]-m_TOI[0])+m_TM[1][0]*m_TM[1][2]*(m_TOI[2]-m_TOI[1]));
 invert3x3_sym(m_TOI_world_inverse,m_TOI_world);

#ifdef _DEBUG
 {//check TOI_world = TM^t * TOI * TM.
  real v[3][3]={{1,0,0},{0,1,0},{0,0,1}};
  for(int i=0;i<3;i++)
  {
   real vb[3];
   real vw[3];
   ToBody(vb,v[i],m_TM);
   vb[0]*=m_TOI[0];
   vb[1]*=m_TOI[1];
   vb[2]*=m_TOI[2];
   ToWorld(vw,vb,m_TM);
   ASSERT(IS_EQ(vw[0],m_TOI_world[0][i],m_TOI[0]*((real)1e-3),((real)1e-3)));
   ASSERT(IS_EQ(vw[1],m_TOI_world[1][i],m_TOI[1]*((real)1e-3),((real)1e-3)));
   ASSERT(IS_EQ(vw[2],m_TOI_world[2][i],m_TOI[2]*((real)1e-3),((real)1e-3)));
  }
 }
 {//check m_TOI_world_inverse
  real v[3][3]={{0,0,0},{0,0,0},{0,0,0}};
  for(int i=0;i<3;i++)
  for(int j=0;j<3;j++)
  for(int k=0;k<3;k++)
   v[i][j]+=m_TOI_world[i][k]*m_TOI_world_inverse[k][j];
  ASSERT(IS_EQ(v[0][0],1,((real)1e-6)));
  ASSERT(IS_EQ(v[1][1],1,((real)1e-6)));
  ASSERT(IS_EQ(v[2][2],1,((real)1e-6)));
  ASSERT(IS_EQ(v[0][1],0,((real)1e-6)));
  ASSERT(IS_EQ(v[0][2],0,((real)1e-6)));
  ASSERT(IS_EQ(v[1][2],0,((real)1e-6)));
  ASSERT(IS_EQ(v[1][0],0,((real)1e-6)));
  ASSERT(IS_EQ(v[2][0],0,((real)1e-6)));
  ASSERT(IS_EQ(v[2][1],0,((real)1e-6)));
 }
#endif//of #ifdef _DEBUG
}

void CRigidBody::GetStateVector(real state[13])const
{
 state[0]=m_Q[0];
 state[1]=m_Q[1];
 state[2]=m_Q[2];
 state[3]=m_Q[3];

 state[4]=m_position[0];
 state[5]=m_position[1];
 state[6]=m_position[2];

 state[7]=m_angular_velocity[0];
 state[8]=m_angular_velocity[1];
 state[9]=m_angular_velocity[2];

 state[10]=m_velocity[0];
 state[11]=m_velocity[1];
 state[12]=m_velocity[2];
}

void CRigidBody::SetStateVector(const real state[13])
{
 m_Q[0]=state[0];
 m_Q[1]=state[1];
 m_Q[2]=state[2];
 m_Q[3]=state[3];

 NormalizeQuaternion(m_Q);

 m_position[0]=state[4];
 m_position[1]=state[5];
 m_position[2]=state[6];

 m_angular_velocity[0]=state[7];
 m_angular_velocity[1]=state[8];
 m_angular_velocity[2]=state[9];

 m_velocity[0]=state[10];
 m_velocity[1]=state[11];
 m_velocity[2]=state[12];

 m_state_is_corrupt=1;
}

void CRigidBody::GetAcceleration(real acceleration[3])const
{
 acceleration[0]=m_acceleration[0];
 acceleration[1]=m_acceleration[1];
 acceleration[2]=m_acceleration[2];
}

const real* CRigidBody::GetAcceleration()const
{
 return m_acceleration;
}

void CRigidBody::GetAngularAcceleration(real angular_acceleration[3])const
{
 angular_acceleration[0]=m_angular_acceleration[0];
 angular_acceleration[1]=m_angular_acceleration[1];
 angular_acceleration[2]=m_angular_acceleration[2];
}

const real* CRigidBody::GetAngularAcceleration()const
{
 return m_angular_acceleration;
}

void CRigidBody::SetState()
{
 ASSERT(IS_EQ(m_Q[0]*m_Q[0]+m_Q[1]*m_Q[1]+m_Q[2]*m_Q[2]+m_Q[3]*m_Q[3],1,((real)1e-6)));
#ifdef FC_SINGLE
 //NormalizeQuaternion(m_Q);
#endif//of #ifdef FC_SINGLE
 ComputeDerivedQuantities();
 m_state_is_corrupt=0;
}

void CRigidBody::GetOmegaDot(real omega_dot[3])
{
 //wdot=I^(-1)(-wxIw + torque)
 real T_x=m_TOI_world[0][1]*m_angular_velocity[0]+m_TOI_world[1][1]*m_angular_velocity[1]+m_TOI_world[1][2]*m_angular_velocity[2];
 real T_y=m_TOI_world[0][2]*m_angular_velocity[0]+m_TOI_world[1][2]*m_angular_velocity[1]+m_TOI_world[2][2]*m_angular_velocity[2];
 real T_Z=m_TOI_world[0][0]*m_angular_velocity[0]+m_TOI_world[0][1]*m_angular_velocity[1]+m_TOI_world[0][2]*m_angular_velocity[2];
 real a_R0=-m_angular_velocity[1]*T_y+m_angular_velocity[2]*T_x+m_instant_torque[0];
 real a_R1=-m_angular_velocity[2]*T_Z+m_angular_velocity[0]*T_y+m_instant_torque[1];
 real a_R2=-m_angular_velocity[0]*T_x+m_angular_velocity[1]*T_Z+m_instant_torque[2];
 omega_dot[0]=m_TOI_world_inverse[0][0]*a_R0+m_TOI_world_inverse[0][1]*a_R1+m_TOI_world_inverse[0][2]*a_R2;
 omega_dot[1]=m_TOI_world_inverse[0][1]*a_R0+m_TOI_world_inverse[1][1]*a_R1+m_TOI_world_inverse[1][2]*a_R2;
 omega_dot[2]=m_TOI_world_inverse[0][2]*a_R0+m_TOI_world_inverse[1][2]*a_R1+m_TOI_world_inverse[2][2]*a_R2;
}

void CRigidBody::CalculateAccelerations(real acceleration[3],real angular_acceleration[3],real timestep)
{//passed values must be aligned
 //Find angular acceleration: wdot=I^(-1)(-wxIw + torque)
 GetOmegaDot(angular_acceleration);
 
 if(angular_damping>((real)0.0))
 {//angular damping is inprecise but stable
  //real inertia=((real)0.333)*(m_TOI[0]+m_TOI[1]+m_TOI[2]);
  //ASSERT(inertia>((real)0.0));
  real ang_fac=((real)1.0)-(real)exp(-timestep/angular_damping);
  fcmAddScaledTo(angular_acceleration,m_angular_velocity,-ang_fac/timestep);
 }

 //Apply damping in a nonstiff way.
 if(linear_damping>((real)0.0))
 {
  real lin_fac=(((real)1.0)-(real)exp(-timestep/linear_damping));
  fcmSpecial(acceleration,-lin_fac/timestep,m_velocity,m_instant_force,1/m_mass,gravity,linear_damping);
 }
 else//of if(linear_damping>((real)0.0))
 {
  fcmCombo(acceleration,gravity,m_instant_force,1/m_mass);
 }
}

inline
void CRigidBody::ApplyVelocities(real timestep)
{
 fcmAddScaledTo(m_position,m_velocity,timestep);
 apply_omega(m_Q,m_angular_velocity,timestep);
}

inline
void CRigidBody::ApplyAccelerations(real timestep)
{
 fcmAddScaledTo(m_angular_velocity,m_angular_acceleration,timestep);
 fcmAddScaledTo(m_velocity,m_acceleration,timestep);
}

void CRigidBody::ApplyImpulses()
{
 //Idw=t => dw=I^(-1)*t

 //Transform torque to body r.f..
 real impulsive_torque_body[4]align;
 fcmToBody(impulsive_torque_body,m_impulsive_torque,m_TM);
 impulsive_torque_body[0]/=m_TOI[0];
 impulsive_torque_body[1]/=m_TOI[1];
 impulsive_torque_body[2]/=m_TOI[2];
 real delta_omega[4]align;
 //Transform delta_omega_body back to World.
 fcmToWorld(delta_omega,impulsive_torque_body,m_TM);
 fcmAddTo(m_angular_velocity,delta_omega);
 fcmAddScaledTo(m_velocity,m_impulsive_force,1/m_mass);
}

void CRigidBody::EulerEvolve(real time_step,int dont_do_impulses/*=0*/)
{
 ASSERT(time_step>=((real)0.0));
 if(m_state_is_corrupt) SetState();
 if(dont_do_impulses==0)
 {
  ApplyImpulses();
  ZeroImpulsiveForce();
  ZeroImpulsiveTorque();
 }

 if(time_step!=((real)0.0))
 {
  CalculateAccelerations(m_acceleration,m_angular_acceleration,time_step);
  ApplyAccelerations(time_step);
  ApplyVelocities(time_step);

  ZeroInstantForce();
  ZeroInstantTorque();
 }
 SetState();
}

void CRigidBody::RungeKuttaEvolve(real time_step,int dont_do_impulses/*=0*/)
{
 ASSERT(time_step>=((real)0.0));
 if(m_state_is_corrupt) SetState();

 if(!dont_do_impulses)
 {
  ApplyImpulses();
  ZeroImpulsiveForce();
  ZeroImpulsiveTorque();
 }

 if(time_step!=((real)0.0))
 {
  real k1[8]align,k2[8]align,k3[8]align,k4[8]align;

  real q[4]align={m_Q[0],m_Q[1],m_Q[2],m_Q[3]};
  real p[4]align={m_position[0],m_position[1],m_position[2]};
  real w[4]align={m_angular_velocity[0],m_angular_velocity[1],m_angular_velocity[2]};
  real v[4]align={m_velocity[0],m_velocity[1],m_velocity[2]};
  real ww[4]align;

  CalculateAccelerations(k1,k1+4,time_step);
  fcmSelfScale(k1,time_step);
  fcmSelfScale(k1+4,time_step);

  fcmCopy4(m_Q,q);
  apply_omega(m_Q,w,time_step/((real)2.0));
  fcmCombo(m_position,p,v,time_step/((real)2.0));
  fcmCombo(m_angular_velocity,w,k1+4,((real)0.5));
  fcmCombo(m_velocity,v,k1,((real)0.5));
  SetState();
  CalculateAccelerations(k2,k2+4,time_step);
  fcmSelfScale(k2,time_step);
  fcmSelfScale(k2+4,time_step);

  fcmCombo(ww,w,k1+4,((real)0.5));
  fcmCopy4(m_Q,q);
  apply_omega(m_Q,ww,time_step/((real)2.0));
  m_position[0]=p[0]+(v[0]+k1[0]/((real)2.0))*time_step/((real)2.0);
  m_position[1]=p[1]+(v[1]+k1[1]/((real)2.0))*time_step/((real)2.0);
  m_position[2]=p[2]+(v[2]+k1[2]/((real)2.0))*time_step/((real)2.0);
  fcmCombo(m_angular_velocity,w,k2+4,((real)0.5));
  fcmCombo(m_velocity,v,k2,((real)0.5));
  SetState();
  CalculateAccelerations(k3,k3+4,time_step);
  fcmSelfScale(k3,time_step);
  fcmSelfScale(k3+4,time_step);

  fcmCopy4(m_Q,q);
  fcmCombo(ww,w,k2+4,((real)0.5));
  apply_omega(m_Q,ww,time_step);
  m_position[0]=p[0]+(v[0]+k2[0]/((real)2.0))*time_step;
  m_position[1]=p[1]+(v[1]+k2[1]/((real)2.0))*time_step;
  m_position[2]=p[2]+(v[2]+k2[2]/((real)2.0))*time_step;
  fcmAdd(m_angular_velocity,w,k3+4);
  fcmAdd(m_velocity,v,k3);
  SetState();
  CalculateAccelerations(k4,k4+4,time_step);
  fcmSelfScale(k4,time_step);
  fcmSelfScale(k4+4,time_step);

  fcmCopy4(m_Q,q);
  ww[0]=w[0]+(k1[4]+k2[4]+k3[4])/((real)6.0);
  ww[1]=w[1]+(k1[5]+k2[5]+k3[5])/((real)6.0);
  ww[2]=w[2]+(k1[6]+k2[6]+k3[6])/((real)6.0);
  apply_omega(m_Q,ww,time_step);
  m_position[0]=p[0]+(v[0]+(k1[0]+k2[0]+k3[0])/((real)6.0))*time_step;
  m_position[1]=p[1]+(v[1]+(k1[1]+k2[1]+k3[1])/((real)6.0))*time_step;
  m_position[2]=p[2]+(v[2]+(k1[2]+k2[2]+k3[2])/((real)6.0))*time_step;
  m_angular_velocity[0]=w[0]+(k1[4]+((real)2.0)*k2[4]+((real)2.0)*k3[4]+k4[4])/((real)6.0);
  m_angular_velocity[1]=w[1]+(k1[5]+((real)2.0)*k2[5]+((real)2.0)*k3[5]+k4[5])/((real)6.0);
  m_angular_velocity[2]=w[2]+(k1[6]+((real)2.0)*k2[6]+((real)2.0)*k3[6]+k4[6])/((real)6.0);
  m_velocity[0]=v[0]+(k1[0]+((real)2.0)*k2[0]+((real)2.0)*k3[0]+k4[0])/((real)6.0);
  m_velocity[1]=v[1]+(k1[1]+((real)2.0)*k2[1]+((real)2.0)*k3[1]+k4[1])/((real)6.0);
  m_velocity[2]=v[2]+(k1[2]+((real)2.0)*k2[2]+((real)2.0)*k3[2]+k4[2])/((real)6.0);

  //calculate accelerations
  m_acceleration[0]=(k1[0]+((real)2.0)*k2[0]+((real)2.0)*k3[0]+k4[0])/((real)6.0)/time_step;
  m_acceleration[1]=(k1[1]+((real)2.0)*k2[1]+((real)2.0)*k3[1]+k4[1])/((real)6.0)/time_step;
  m_acceleration[2]=(k1[2]+((real)2.0)*k2[2]+((real)2.0)*k3[2]+k4[2])/((real)6.0)/time_step;
  m_angular_acceleration[0]=(k1[4]+((real)2.0)*k2[4]+((real)2.0)*k3[4]+k4[4])/((real)6.0);
  m_angular_acceleration[1]=(k1[5]+((real)2.0)*k2[5]+((real)2.0)*k3[5]+k4[5])/((real)6.0);
  m_angular_acceleration[2]=(k1[6]+((real)2.0)*k2[6]+((real)2.0)*k3[6]+k4[6])/((real)6.0);

  SetState();

  ZeroInstantForce();
  ZeroInstantTorque();
 }
 else
  SetState();
}
