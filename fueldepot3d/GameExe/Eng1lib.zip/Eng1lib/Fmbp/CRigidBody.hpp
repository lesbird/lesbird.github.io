// FREE SOURCE CODE
// Eugene Laptev, Oxford Dynamics www.oxforddynamics.co.uk
// Copyright (c) 2000, 2001. All Rights Reserved
// This file is subject to license
#ifndef __CRIGIDBODY_HPP
#define __CRIGIDBODY_HPP

#include "Vitamina.hpp"

class FC_DLL_EXPORT CRigidBody
{
public:
 void* user_data;

 real gravity[4];//:3
 //If you significantly modify the magnitude of gravity
 //in run-time your car (derived from this class) may become unstable.

 real linear_damping;//Both are measured in units of time.
 real angular_damping;

 CRigidBody();
 int Build
 (
  const real gravity_world[3],//Expressed in World.
  const real m_TOI[3],//m_TOI of the body in BRF.
  real m_mass//Mass.
 );

 virtual void EulerEvolve(real time_step,int dont_do_impulses=0);
 void RungeKuttaEvolve(real time_step,int dont_do_impulses=0);

 real GetMass()const;
 void GetTOILocal(real TOI[3])const;
 void GetInverseTOIWorld(real t[3][3])const;
 const real* GetInverseTOIWorld()const;

 virtual void ErrorReport(char* explanation)
 {//Call user callback if any.
  //if(error_report_callback) (error_report_callback)(explanation);
  //printf("Error: %s\n",st);
 }

 virtual void WarningReport(char* explanation)
 {//Call user callback if any.
  //if(warning_report_callback) (warning_report_callback)(explanation);
  //printf("Warning: %s\n",st);
 }

 virtual void GetStateVector(real state[13])const;
 virtual void SetStateVector(const real state[13]);

 virtual void GetTransform(real m[16])const;

 void GetOrientation(real m[3][3])const; //Copies from members: m_TM
 const real* GetOrientation()const; //Returns pointer to member: m_TM

 void SetOrientation(const real m[3][3]); //Converts to quaternion and sets

 void Rotate(real angle,int axis);
 //Rotates the body around World axis (0,1,2) counterclockwise. Updates state.
 void RotateLocal(real angle,int axis);
 //Rotates the body around Local axis (0,1,2) counterclockwise. Updates state.

 void GetQuaternion(real Q[4])const; //Copies from members: m_Q
 const real* GetQuaternion()const; //Returns pointer to member: m_Q
 void SetQuaternion(const real Q[4]); //Copies to members: m_Q
 void SetQuaternion(real q0,real qx,real qy,real qz); //Copies to members: m_Q

 virtual void GetPosition(real position[3])const; //Copies from members: m_position

 void SetPosition(const real position[3]); //Copies to members: m_position
 void SetPosition(real x,real y,real z); //Copies to members: m_position

 void GetVelocity(real velocity[3])const; //Copies from members: m_velocity
 const real* GetVelocity()const; //Returns pointer to member: m_velocity
 void SetVelocity(const real velocity[3]); //Copies to members: m_velocity
 void SetVelocity(real x,real y,real z); //Copies to members: m_velocity

 void GetAngularVelocity(real angular_velocity[3])const; //Copies from members: m_angular_velocity
 const real* GetAngularVelocity()const; //Returns pointer to member: m_angular_velocity
 void SetAngularVelocity(const real angular_velocity[3]); //Copies to members: m_angular_velocity
 void SetAngularVelocity(real x,real y,real z); //Copies to members: m_angular_velocity

 void GetAcceleration(real acceleration[3])const; //Copies from members: m_acceleration
 const real* GetAcceleration()const; //Returns pointer to member: m_acceleration
 void GetAngularAcceleration(real angular_acceleration[3])const; //Copies from members: m_angular_acceleration
 const real* GetAngularAcceleration()const; //Returns pointer to member: m_angular_acceleration

 //Forces: "Instant" lasts only for one timestep, "Permanent" lasts until changed.
 //force/torque and point must be expressed in World (w/o ..Local) or local reference frame (with ..Local)
 void ZeroInstantForce();
 void ZeroPermanentForce();
 void ZeroImpulsiveForce();
 void ZeroPermanentForceLocal();

 void AddInstantForce(const real force[3]);
 void AddPermanentForce(const real force[3]);
 void AddImpulsiveForce(const real impulsive_force[3]);
 void AddInstantForceLocal(const real force[3]);
 void AddPermanentForceLocal(const real force[3]);
 void AddImpulsiveForceLocal(const real impulsive_force[3]);

 void AddInstantForceAtPoint(const real force[3],const real point[3]);
 void AddPermanentForceAtPoint(const real force[3],const real point[3]);
 void AddImpulsiveForceAtPoint(const real impulsive_force[3],const real point[3]);
 void AddInstantForceAtPointLocal(const real force[3],const real point[3]);
 void AddPermanentForceAtPointLocal(const real force[3],const real point[3]);
 void AddImpulsiveForceAtPointLocal(const real impulsive_force[3],const real point[3]);

 void ZeroInstantTorque();
 void ZeroPermanentTorque();
 void ZeroImpulsiveTorque();
 void ZeroPermanentTorqueLocal();

 void AddInstantTorque(const real torque[3]);
 void AddPermanentTorque(const real torque[3]);
 void AddImpulsiveTorque(const real impulsive_torque[3]);
 void AddInstantTorqueLocal(const real torque[3]);
 void AddPermanentTorqueLocal(const real torque[3]);
 void AddImpulsiveTorqueLocal(const real impulsive_torque[3]);

protected:

 real m_position[4];//:3 Position of the CRF in World.
 real m_Q[4];//Orientation quaternion.
 real m_velocity[4];//:3
 real m_angular_velocity[4];//:3
 real m_acceleration[4];//:3
 real m_angular_acceleration[4];//:3

 real m_mass;//Mass.
 real m_TOI[4];//:3 Diagonal elements of tensor of inertia.
 real m_TOI_world[3][4];//:3x3
 real m_TOI_world_inverse[3][4];//:3x3

 real m_TM[3][4];//:3x3

 real m_instant_force[4];//:3
 real m_instant_torque[4];//:3
 real m_permanent_force[4];//:3
 real m_permanent_torque[4];//:3
 real m_permanent_force_local[4];//:3
 real m_permanent_torque_local[4];//:3
 real m_impulsive_force[4];//:3
 real m_impulsive_torque[4];//:3

 int permanent_force_local_exists;
 int permanent_torque_local_exists;

 int m_state_is_corrupt;

 void SetState();
 //Derives all internal parameters from state vector.

 void ComputeDerivedQuantities();
 void GetOmegaDot(real omega_dot[3]);
 void CalculateAccelerations(real acceleration[3],real angular_acceleration[3],real timestep);
 void ApplyAccelerations(real timestep);
 void ApplyVelocities(real timestep);
 void ApplyImpulses();
};
#endif//of #ifndef __CRIGIDBODY_HPP
