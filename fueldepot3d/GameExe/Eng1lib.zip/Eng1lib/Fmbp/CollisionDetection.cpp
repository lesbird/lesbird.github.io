// FREE SOURCE CODE
// Eugene Laptev, Oxford Dynamics www.oxforddynamics.co.uk
// Copyright (c) 2000, 2001. All Rights Reserved
// This file is subject to license
#include<stdlib.h>
#include<float.h>
#include<string.h>//for memcpy
#include<malloc.h>
#include<stdio.h>

#ifdef _DEBUG
 #include <stdio.h>
 //#define CD_DEBUG
#endif//of #ifdef _DEBUG

#include "CollisionDetection.hpp"
#include "CollisionHandler.hpp"

using namespace Vitamina;

CDiskPlaneCollision::CDiskPlaneCollision(const CDisk &disk,const CPlane &plane)
{
 const real (&pn)[3]=plane.normal;
 const real (&c)[3]=disk.center;
 const real (&dn)[3]=disk.normal;
 
 real (&rv)[3]=radiusVector;
 real (&pd)[3]=pointOnDisk;
 real (&pp)[3]=pointOnPlane;
 
 const real k=DotProduct(pn,dn);
 if(k > 1-((real)1e-3) || k < -1+((real)1e-3))
 {
  parallel=true;
  //memset(rv,0,3*sizeof(real));
  rv[0]=((real)0.0);
  rv[1]=((real)0.0);
  rv[2]=((real)0.0);
 }
 else
 {
  parallel=false;
  // let rv=pn-k*dm [=> rv.dn=0];
  // v points from the point on the disk deepest
  // into the plane towards the center of the disk
  rv[0]=pn[0] - k*dn[0];
  rv[1]=pn[1] - k*dn[1];
  rv[2]=pn[2] - k*dn[2];
  const real l=-disk.radius/Magnitude(rv);
  rv[0] *= l;
  rv[1] *= l;
  rv[2] *= l;
 }
 pd[0]=c[0]+rv[0];
 pd[1]=c[1]+rv[1];
 pd[2]=c[2]+rv[2];
 penetration=plane.offset - DotProduct(pd,pn);
 pp[0]=pd[0]+penetration * pn[0];
 pp[1]=pd[1]+penetration * pn[1];
 pp[2]=pd[2]+penetration * pn[2];
}

FC_DLL_EXPORT
bool DiskPlaneCollision(real *penetration,real pointOnDisk[3],const CDisk& disk,const CPlane& plane)
{
 const real (&pn)[3]=plane.normal;
 const real (&c)[3]=disk.center;
 const real (&dn)[3]=disk.normal;

 real rv[3]; // radiusVector
 real * const pd=pointOnDisk;

 const real k=DotProduct(pn,dn);
 if(k > 1-1E-7 || k < -1+1E-7)
  return false; // parallel

 // let rv=pn-k*dm [=> rv.dn=0];
 // v points from the point on the disk deepest
 // into the plane towards the center of the disk
 rv[0]=pn[0] - k*dn[0];
 rv[1]=pn[1] - k*dn[1];
 rv[2]=pn[2] - k*dn[2];
 const real l=-disk.radius/Magnitude(rv);
 rv[0] *= l;
 rv[1] *= l;
 rv[2] *= l;
 pd[0]=c[0]+rv[0];
 pd[1]=c[1]+rv[1];
 pd[2]=c[2]+rv[2];
 *penetration=plane.offset - DotProduct(pd,pn);

 return true;
}

FC_DLL_EXPORT
bool LinePlaneCollision(real *distanceAlongLine,real pointOnPlane[3],const CLine& line,const CPlane& plane)
{
 const real (&n)[3]=plane.normal;
 const real (&d)[3]=line.direction;
 
 const real dn=DotProduct(d,n);
 if(-1E-7 < dn && dn < 1E-7)
  return false; // parallel
 
 const real c=plane.offset;
 const real (&p)[3]=line.point;
 real * const q=pointOnPlane;
 real &k=*distanceAlongLine;
 
 const real pn=DotProduct(p,n);
 k=(c-pn)/dn;
 
 q[0]=p[0]+k*d[0];
 q[1]=p[1]+k*d[1];
 q[2]=p[2]+k*d[2];
 
 return true;
}

// Returns true if disk and plane are not parallel
// SpherePlaneCollision() Returns the penetration distance
// and computes pointOnPlane deepest/nearest the sphere.
// Penetration distance can be negative.
FC_DLL_EXPORT
real SpherePlaneCollision(real pointOnPlane[3],const CSphere& sphere,const CPlane& plane)
{
 const real (&n)[3]=plane.normal;
 const real (&c)[3]=sphere.center;
 
 const real dist=DotProduct(n,c)-plane.offset;
 real penetration=-(dist-sphere.radius);
 
 pointOnPlane[0]=c[0] - dist * n[0];
 pointOnPlane[1]=c[1] - dist * n[1];
 pointOnPlane[2]=c[2] - dist * n[2];
 
 return penetration;
}

// SphereLineCollision() returns the penetration distance
// and computes pointOnLine deepest/nearest the sphere.
// Also computes distanceAlongLine from line.point to
// pointOnLine and the normal perpendicular to the sphere.
// Penetration distance can be negative which indicates no collision.
FC_DLL_EXPORT
real SphereLineCollision(real *distanceAlongLine,real pointOnLine[3],real normal[3],const CSphere& sphere,const CLine& line)
{
 const real (&d)[3]=line.direction;
 const real (&p)[3]=line.point;
 const real (&c)[3]=sphere.center;
 real* const n=normal;
 real* const x=pointOnLine;
 real &k=*distanceAlongLine;
 
 const real pc[]=
 { // vec from p to c
  c[0]-p[0],
  c[1]-p[1],
  c[2]-p[2]
 };
 k=DotProduct(pc,d);
 x[0]=p[0]+k*d[0];
 x[1]=p[1]+k*d[1];
 x[2]=p[2]+k*d[2];
 
 n[0]=c[0]-x[0];
 n[1]=c[1]-x[1];
 n[2]=c[2]-x[2];
 const real l=(real)sqrt(DotProduct(n,n));
 if(l==0)
  return sphere.radius; // normal is undetermined (zero)
 const real s=1/l;
 n[0] *= s;
 n[1] *= s;
 n[2] *= s;
 return sphere.radius-l;
}

// SpherePointCollision() returns the penetration distance
// and computes the normal perpendicular to the sphere.
// Penetration distance can be negative which indicates no collision.
FC_DLL_EXPORT
real SpherePointCollision(real normal[3],const CSphere& sphere,const real point[3])
{
 const real* const p=point;
 const real (&c)[3]=sphere.center;
 real* const n=normal;
 n[0]=c[0]-p[0];
 n[1]=c[1]-p[1];
 n[2]=c[2]-p[2];
 const real l=(real)sqrt(DotProduct(n,n));
 if(l==0)
  return sphere.radius; // normal is undetermined (zero)
 const real s=1/l;
 n[0] *= s;
 n[1] *= s;
 n[2] *= s;
 return sphere.radius-l;
}

// SphereSphereCollision() returns the penetration distance
// and computes the point of contact and normal perpendicular
// to the spheres. Penetration distance can be negative
// which indicates no collision.
FC_DLL_EXPORT
real SphereSphereCollision(real point[3],real normal[3],const CSphere& s1,const CSphere& s2)
{
 const real (&c1)[3]=s1.center;
 const real (&c2)[3]=s2.center;
 real* const n=normal;
 real* const p=point;
 n[0]=c1[0]-c2[0];
 n[1]=c1[1]-c2[1];
 n[2]=c1[2]-c2[2];
 const real a=s2.radius/(s1.radius+s2.radius);
 p[0]=c2[0]+n[0]*a;
 p[1]=c2[1]+n[1]*a;
 p[2]=c2[2]+n[2]*a;
 const real l=Magnitude(n);
 if(l==0)
  return s1.radius+s2.radius; // normal is undetermined (zero)
 const real s=((real)1.0)/l;
 n[0] *= s;
 n[1] *= s;
 n[2] *= s;
 return s1.radius+s2.radius-l;
}

// SphereDiskCollision() computes the penetration distance,
// the pointOnDisk deepest/nearest the sphere.
// The return value is 0 for no collision
// 1 for collision with plane of disk
// 2 for collision with perimiter of disk
FC_DLL_EXPORT
int SphereDiskCollision(real* penetration,real pointOnDisk[3],real normal[3],const CSphere &sphere,const CDisk &disk)
{
 const real (&n)[3]=disk.normal;
 const real (&c)[3]=disk.center;
 const CPlane plane={{n[0],n[1],n[2]},DotProduct(n,c)};
 
 real *p=pointOnDisk;
 *penetration=SpherePlaneCollision(pointOnDisk,sphere,plane);
 
 if(*penetration < 0 || *penetration > 2*sphere.radius)
  return 0; // no collision
 
 const real r[3]=
 {
  p[0]-c[0],
  p[1]-c[1],
  p[2]-c[2]
 };
 
 const real l=Magnitude(r);
 
 if(l<disk.radius)
 {
  // take care because the disk is not one sided
  if(*penetration < sphere.radius)
  ////if(*penetration < disk.radius)
  {
   //memcpy(normal,n,3*sizeof(real));
   normal[0]=n[0];
   normal[1]=n[1];
   normal[2]=n[2];
  }
  else
  {
   normal[0]=-n[0];
   normal[1]=-n[1];
   normal[2]=-n[2];
   *penetration=2*sphere.radius - *penetration;
   ////*penetration=2*.radius - *penetration;
   // collision with other side of disk
  }
  return 1; // collision with plane of disk
 }
 
 const real s=disk.radius/l;
 p[0]=c[0]+r[0] * s;
 p[1]=c[1]+r[1] * s;
 p[2]=c[2]+r[2] * s;
 
 normal[0]=sphere.center[0] - p[0];
 normal[1]=sphere.center[1] - p[1];
 normal[2]=sphere.center[2] - p[2];
 
 const real k=Magnitude(normal);
 
 *penetration=sphere.radius-k;
 
 if(*penetration <= 0)
  return 0; // no collision
 
 const real t=1/k;
 normal[0] *= t;
 normal[1] *= t;
 normal[2] *= t;
 
 return 2; // collision with perimiter of disk
}

void CBox::ComputeVertices(real vertex[8][3]) const
{
 real eaxis[3][3]=
 {
  {extent[0]*axis[0][0],extent[0]*axis[0][1],extent[0]*axis[0][2]},
  {extent[1]*axis[1][0],extent[1]*axis[1][1],extent[1]*axis[1][2]},
  {extent[2]*axis[2][0],extent[2]*axis[2][1],extent[2]*axis[2][2]}
 };

 vertex[0][0]=center[0]-eaxis[0][0]-eaxis[1][0]-eaxis[2][0];
 vertex[0][1]=center[1]-eaxis[0][1]-eaxis[1][1]-eaxis[2][1];
 vertex[0][2]=center[2]-eaxis[0][2]-eaxis[1][2]-eaxis[2][2];

 vertex[1][0]=center[0]+eaxis[0][0]-eaxis[1][0]-eaxis[2][0];
 vertex[1][1]=center[1]+eaxis[0][1]-eaxis[1][1]-eaxis[2][1];
 vertex[1][2]=center[2]+eaxis[0][2]-eaxis[1][2]-eaxis[2][2];
 
 vertex[2][0]=center[0]+eaxis[0][0]+eaxis[1][0]-eaxis[2][0];
 vertex[2][1]=center[1]+eaxis[0][1]+eaxis[1][1]-eaxis[2][1];
 vertex[2][2]=center[2]+eaxis[0][2]+eaxis[1][2]-eaxis[2][2];
 
 vertex[3][0]=center[0]-eaxis[0][0]+eaxis[1][0]-eaxis[2][0];
 vertex[3][1]=center[1]-eaxis[0][1]+eaxis[1][1]-eaxis[2][1];
 vertex[3][2]=center[2]-eaxis[0][2]+eaxis[1][2]-eaxis[2][2];

 vertex[4][0]=center[0]-eaxis[0][0]-eaxis[1][0]+eaxis[2][0];
 vertex[4][1]=center[1]-eaxis[0][1]-eaxis[1][1]+eaxis[2][1];
 vertex[4][2]=center[2]-eaxis[0][2]-eaxis[1][2]+eaxis[2][2];
 
 vertex[5][0]=center[0]+eaxis[0][0]-eaxis[1][0]+eaxis[2][0];
 vertex[5][1]=center[1]+eaxis[0][1]-eaxis[1][1]+eaxis[2][1];
 vertex[5][2]=center[2]+eaxis[0][2]-eaxis[1][2]+eaxis[2][2];
 
 vertex[6][0]=center[0]+eaxis[0][0]+eaxis[1][0]+eaxis[2][0];
 vertex[6][1]=center[1]+eaxis[0][1]+eaxis[1][1]+eaxis[2][1];
 vertex[6][2]=center[2]+eaxis[0][2]+eaxis[1][2]+eaxis[2][2];
 
 vertex[7][0]=center[0]-eaxis[0][0]+eaxis[1][0]+eaxis[2][0];
 vertex[7][1]=center[1]-eaxis[0][1]+eaxis[1][1]+eaxis[2][1];
 vertex[7][2]=center[2]-eaxis[0][2]+eaxis[1][2]+eaxis[2][2];
}

FC_DLL_EXPORT
int BoxBoxIntersectionTest(const CBox& box0,const CBox& box1)
{
 // compute difference of box centers,D=C1-C0
 real D[3]=
 {
  box1.center[0]-box0.center[0],
  box1.center[1]-box0.center[1],
  box1.center[2]-box0.center[2]
 };
 
 real C[3][3];    //matrix C=A^T B,c_{ij}=Dot(A_i,B_j)
 real absC[3][3]; //|c_{ij}|
 real AD[3];      //Dot(A_i,D)
 real R0,R1,R;    //interval radii and distance between centers
 real R01;        //=R0+R1
 
 //A0
 C[0][0]=DotProduct(box0.axis[0],box1.axis[0]);
 C[0][1]=DotProduct(box0.axis[0],box1.axis[1]);
 C[0][2]=DotProduct(box0.axis[0],box1.axis[2]);
 AD[0]=DotProduct(box0.axis[0],D);
 absC[0][0]=(real)fabs(C[0][0]);
 absC[0][1]=(real)fabs(C[0][1]);
 absC[0][2]=(real)fabs(C[0][2]);
 R=(real)fabs(AD[0]);
 R1=box1.extent[0]*absC[0][0]+box1.extent[1]*absC[0][1]+box1.extent[2]*absC[0][2];
 R01=box0.extent[0]+R1;
 if(R>R01)return 0;
 
 //A1
 C[1][0]=DotProduct(box0.axis[1],box1.axis[0]);
 C[1][1]=DotProduct(box0.axis[1],box1.axis[1]);
 C[1][2]=DotProduct(box0.axis[1],box1.axis[2]);
 AD[1]=DotProduct(box0.axis[1],D);
 absC[1][0]=(real)fabs(C[1][0]);
 absC[1][1]=(real)fabs(C[1][1]);
 absC[1][2]=(real)fabs(C[1][2]);
 R=(real)fabs(AD[1]);
 R1=box1.extent[0]*absC[1][0]+box1.extent[1]*absC[1][1]+box1.extent[2]*absC[1][2];
 R01=box0.extent[1]+R1;
 if(R>R01)return 0;
 
 //A2
 C[2][0]=DotProduct(box0.axis[2],box1.axis[0]);
 C[2][1]=DotProduct(box0.axis[2],box1.axis[1]);
 C[2][2]=DotProduct(box0.axis[2],box1.axis[2]);
 AD[2]=DotProduct(box0.axis[2],D);
 absC[2][0]=(real)fabs(C[2][0]);
 absC[2][1]=(real)fabs(C[2][1]);
 absC[2][2]=(real)fabs(C[2][2]);
 R=(real)fabs(AD[2]);
 R1=box1.extent[0]*absC[2][0]+box1.extent[1]*absC[2][1]+box1.extent[2]*absC[2][2];
 R01=box0.extent[2]+R1;
 if(R>R01)return 0;

 //B0
 R=(real)fabs(DotProduct(box1.axis[0],D));
 R0=box0.extent[0]*absC[0][0]+box0.extent[1]*absC[1][0]+box0.extent[2]*absC[2][0];
 R01=R0+box1.extent[0];
 if(R>R01)return 0;
 
 //B1
 R=(real)fabs(DotProduct(box1.axis[1],D));
 R0=box0.extent[0]*absC[0][1]+box0.extent[1]*absC[1][1]+box0.extent[2]*absC[2][1];
 R01=R0+box1.extent[1];
 if(R>R01)return 0;
 
 //B2
 R=(real)fabs(DotProduct(box1.axis[2],D));
 R0=box0.extent[0]*absC[0][2]+box0.extent[1]*absC[1][2]+box0.extent[2]*absC[2][2];
 R01=R0+box1.extent[2];
 if(R>R01)return 0;
 
 //A0xB0
 R=(real)fabs(AD[2]*C[1][0]-AD[1]*C[2][0]);
 R0=box0.extent[1]*absC[2][0]+box0.extent[2]*absC[1][0];
 R1=box1.extent[1]*absC[0][2]+box1.extent[2]*absC[0][1];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A0xB1
 R=(real)fabs(AD[2]*C[1][1]-AD[1]*C[2][1]);
 R0=box0.extent[1]*absC[2][1]+box0.extent[2]*absC[1][1];
 R1=box1.extent[0]*absC[0][2]+box1.extent[2]*absC[0][0];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A0xB2
 R=(real)fabs(AD[2]*C[1][2]-AD[1]*C[2][2]);
 R0=box0.extent[1]*absC[2][2]+box0.extent[2]*absC[1][2];
 R1=box1.extent[0]*absC[0][1]+box1.extent[1]*absC[0][0];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A1xB0
 R=(real)fabs(AD[0]*C[2][0]-AD[2]*C[0][0]);
 R0=box0.extent[0]*absC[2][0]+box0.extent[2]*absC[0][0];
 R1=box1.extent[1]*absC[1][2]+box1.extent[2]*absC[1][1];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A1xB1
 R=(real)fabs(AD[0]*C[2][1]-AD[2]*C[0][1]);
 R0=box0.extent[0]*absC[2][1]+box0.extent[2]*absC[0][1];
 R1=box1.extent[0]*absC[1][2]+box1.extent[2]*absC[1][0];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A1xB2
 R=(real)fabs(AD[0]*C[2][2]-AD[2]*C[0][2]);
 R0=box0.extent[0]*absC[2][2]+box0.extent[2]*absC[0][2];
 R1=box1.extent[0]*absC[1][1]+box1.extent[1]*absC[1][0];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A2xB0
 R=(real)fabs(AD[1]*C[0][0]-AD[0]*C[1][0]);
 R0=box0.extent[0]*absC[1][0]+box0.extent[1]*absC[0][0];
 R1=box1.extent[1]*absC[2][2]+box1.extent[2]*absC[2][1];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A2xB1
 R=(real)fabs(AD[1]*C[0][1]-AD[0]*C[1][1]);
 R0=box0.extent[0]*absC[1][1]+box0.extent[1]*absC[0][1];
 R1=box1.extent[0]*absC[2][2]+box1.extent[2]*absC[2][0];
 R01=R0+R1;
 if(R>R01)return 0;
 
 //A2xB2
 R=(real)fabs(AD[1]*C[0][2]-AD[0]*C[1][2]);
 R0=box0.extent[0]*absC[1][2]+box0.extent[1]*absC[0][2];
 R1=box1.extent[0]*absC[2][1]+box1.extent[1]*absC[2][0];
 R01=R0+R1;
 if(R>R01)return 0;
 
 return 1;
}

FC_DLL_EXPORT
int PointBoxCollisionDetection(real normal[3],real &penetration,real point[3],const CBox& box)
{
 real rel_point[3]={point[0]-box.center[0],point[1]-box.center[1],point[2]-box.center[2]};
 real rel_point_body[3];
 ToBody(rel_point_body,rel_point,box.axis);
 if(rel_point_body[0]>=box.extent[0]||rel_point_body[0]<=-box.extent[0])return 0;
 if(rel_point_body[1]>=box.extent[1]||rel_point_body[1]<=-box.extent[1])return 0;
 if(rel_point_body[2]>=box.extent[2]||rel_point_body[2]<=-box.extent[2])return 0;
 real mindist,tmp;
 int index=1;
 mindist=Min(box.extent[0]-rel_point_body[0],box.extent[0]+rel_point_body[0]);
 tmp=Min(box.extent[1]-rel_point_body[1],box.extent[1]+rel_point_body[1]);
 if(mindist>tmp)
 {
  mindist=tmp;
  index=2;
 }
 tmp=Min(box.extent[2]-rel_point_body[2],box.extent[2]+rel_point_body[2]);
 if(mindist>tmp)
 {
  mindist=tmp;
  index=3;
 }
 ASSERT(mindist>0);
 if(rel_point_body[index-1]>((real)0.0))
 {
  normal[0]=box.axis[index-1][0];
  normal[1]=box.axis[index-1][1];
  normal[2]=box.axis[index-1][2];
  ASSERT(IS_EQ(Magnitude(normal),((real)1.0),((real)1e-8)));
  penetration=mindist;
  return index;
 }
 else
 {
  normal[0]=-box.axis[index-1][0];
  normal[1]=-box.axis[index-1][1];
  normal[2]=-box.axis[index-1][2];
  ASSERT(IS_EQ(Magnitude(normal),((real)1.0),((real)1e-8)));
  penetration=mindist;
  return -index;
 }
}

FC_DLL_EXPORT
int PointBoxIntersectionTest(const real point[3],const CBox& box)
{
 real rel_point[3]={point[0]-box.center[0],point[1]-box.center[1],point[2]-box.center[2]};
 real rel_point_body[3];
 ToBody(rel_point_body,rel_point,box.axis);
 if(rel_point_body[0]>=box.extent[0]||rel_point_body[0]<=-box.extent[0])return 0;
 if(rel_point_body[1]>=box.extent[1]||rel_point_body[1]<=-box.extent[1])return 0;
 if(rel_point_body[2]>=box.extent[2]||rel_point_body[2]<=-box.extent[2])return 0;
 return 1;
}

void SegmentSegmentCollision(real &t0,real &t1,const real r0[3],const real dir0[3],const real r1[3],const real dir1[3])
{
 real p[3];
 Subtract(p,r1,r0);
 real pa=DotProduct(p,dir0);
 real pb=DotProduct(p,dir1);
 real aa=DotProduct(dir0,dir0);
 real ab=DotProduct(dir0,dir1);
 real bb=DotProduct(dir1,dir1);
 real det=ab*ab-aa*bb;
 if(det<((real)-1e-6))
 {
  t0=(ab*pb-bb*pa)/det;
  t1=(aa*pb-ab*pa)/det;
#ifdef _DEBUG
 real delp[3]=
 {
  r1[0]+dir1[0]*t1-r0[0]-dir0[0]*t0,
  r1[1]+dir1[1]*t1-r0[1]-dir0[1]*t0,
  r1[2]+dir1[2]*t1-r0[2]-dir0[2]*t0
 };
 real dp0=DotProduct(dir0,delp);
 real dp1=DotProduct(dir1,delp);
 ASSERT(IS_EQ(dp0,0,((real)1e-6)));
 ASSERT(IS_EQ(dp1,0,((real)1e-6)));
#endif//of #ifdef _DEBUG
 }
 else
 {
  t0=((real)0.5);
  t1=((real)0.5);
 }
}

static inline
void SegmentSegmentCollision1(real &t0,real &t1,const real r0[3],const real dir0[3],const real r1[3],const real dir1[3])
{//unit length of dir0 and dir1
 ASSERT(IS_EQ(Magnitude(dir0),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(Magnitude(dir1),((real)1.0),((real)1e-6)));
 real p[3];
 Subtract(p,r1,r0);
 real pa=DotProduct(p,dir0);
 real pb=DotProduct(p,dir1);
 real ab=DotProduct(dir0,dir1);
 real det=ab*ab-((real)1.0);
 if(det<((real)-1e-6))
 {
  t0=(ab*pb-pa)/det;
  t1=(pb-ab*pa)/det;
#ifdef _DEBUG
 real delp[3]=
 {
  r1[0]+dir1[0]*t1-r0[0]-dir0[0]*t0,
  r1[1]+dir1[1]*t1-r0[1]-dir0[1]*t0,
  r1[2]+dir1[2]*t1-r0[2]-dir0[2]*t0
 };
 real dp0=DotProduct(dir0,delp);
 real dp1=DotProduct(dir1,delp);
 ASSERT(IS_EQ(dp0,0,((real)1e-6)));
 ASSERT(IS_EQ(dp1,0,((real)1e-6)));
#endif//of #ifdef _DEBUG
 }
 else
 {//parellel
  t0=((real)0.0);
  t1=((real)0.0);
 }
}

#ifdef CD_DEBUG
extern int frozen;
extern real ts_save;
extern real timestep;
extern int do_collisions;
extern int do_blinking;
extern int ii,jj,aa;
int freeze=0;
#endif//of #ifdef CD_DEBUG

//Returns 0 if boxes do not intersect,otherwise fills contact information
FC_DLL_EXPORT
int BoxBoxCollisionDetection(real res_normal[3],real res_point[3],real &res_penetration,const CBox& box0,const CBox& box1)
{

#ifdef CD_DEBUG
 static FILE *fl=fopen("tatb.txt","at");
#endif//of #ifdef CD_DEBUG

 // compute difference of box centers,D=C1-C0
 real D[3]=
 {
  box1.center[0]-box0.center[0],
  box1.center[1]-box0.center[1],
  box1.center[2]-box0.center[2]
 };
 //quick distance check
 //if(Magnitude(D)>=Magnitude(box0.extent)+Magnitude(box1.extent)) return 0;
#ifdef _DEBUG
 ASSERT(box0.extent[0]>0);
 ASSERT(box0.extent[1]>0);
 ASSERT(box0.extent[2]>0);
 ASSERT(box1.extent[0]>0);
 ASSERT(box1.extent[1]>0);
 ASSERT(box1.extent[2]>0);

 //right-handedness check
 real cp[3];
 CrossProduct(cp,box0.axis[0],box0.axis[1]);
 ASSERT(IS_EQ(cp[0],box0.axis[2][0],((real)1e-6)));
 ASSERT(IS_EQ(cp[1],box0.axis[2][1],((real)1e-6)));
 ASSERT(IS_EQ(cp[2],box0.axis[2][2],((real)1e-6)));

 CrossProduct(cp,box1.axis[0],box1.axis[1]);
 ASSERT(IS_EQ(cp[0],box1.axis[2][0],((real)1e-6)));
 ASSERT(IS_EQ(cp[1],box1.axis[2][1],((real)1e-6)));
 ASSERT(IS_EQ(cp[2],box1.axis[2][2],((real)1e-6)));

 //orthonormality check
 ASSERT(IS_EQ(Magnitude(box0.axis[0]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(Magnitude(box0.axis[1]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(Magnitude(box0.axis[2]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(DotProduct(box0.axis[0],box0.axis[1]),((real)0.0),((real)1e-6)));
 ASSERT(IS_EQ(DotProduct(box0.axis[1],box0.axis[2]),((real)0.0),((real)1e-6)));
 ASSERT(IS_EQ(DotProduct(box0.axis[2],box0.axis[0]),((real)0.0),((real)1e-6)));

 ASSERT(IS_EQ(Magnitude(box1.axis[0]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(Magnitude(box1.axis[1]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(Magnitude(box1.axis[2]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(DotProduct(box1.axis[0],box1.axis[1]),((real)0.0),((real)1e-6)));
 ASSERT(IS_EQ(DotProduct(box1.axis[1],box1.axis[2]),((real)0.0),((real)1e-6)));
 ASSERT(IS_EQ(DotProduct(box1.axis[2],box1.axis[0]),((real)0.0),((real)1e-6)));
#endif//of #ifdef _DEBUG

 real C[3][3];    //matrix C=A^T B,c_{ij}=Dot(A_i,B_j)
 real absC[3][3]; //|c_{ij}|
 real AD[3];      //Dot(A_i,D)
 real BD[3];      //Dot(B_i,D)
 real R0,R1,R;    //interval radii and distance between centers
 real R01;        //=R0+R1
 real penetration;
 int intersection_index=-1;

 real rA[3],rB[3];
 real tA,tB;

 real deltap[3];
 int signA[2],signB[2];

 res_penetration=FLT_MAX;
 //A0
 C[0][0]=DotProduct(box0.axis[0],box1.axis[0]);
 C[0][1]=DotProduct(box0.axis[0],box1.axis[1]);
 C[0][2]=DotProduct(box0.axis[0],box1.axis[2]);
 AD[0]=DotProduct(box0.axis[0],D);
 absC[0][0]=(real)fabs(C[0][0]);
 absC[0][1]=(real)fabs(C[0][1]);
 absC[0][2]=(real)fabs(C[0][2]);
 R=(real)fabs(AD[0]);
 R1=box1.extent[0]*absC[0][0]+box1.extent[1]*absC[0][1]+box1.extent[2]*absC[0][2];
 R01=box0.extent[0]+R1;
 penetration=R01-R;
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=0;
 }
 
 //A1
 C[1][0]=DotProduct(box0.axis[1],box1.axis[0]);
 C[1][1]=DotProduct(box0.axis[1],box1.axis[1]);
 C[1][2]=DotProduct(box0.axis[1],box1.axis[2]);
 AD[1]=DotProduct(box0.axis[1],D);
 absC[1][0]=(real)fabs(C[1][0]);
 absC[1][1]=(real)fabs(C[1][1]);
 absC[1][2]=(real)fabs(C[1][2]);
 R=(real)fabs(AD[1]);
 R1=box1.extent[0]*absC[1][0]+box1.extent[1]*absC[1][1]+box1.extent[2]*absC[1][2];
 R01=box0.extent[1]+R1;
 penetration=R01-R;
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=1;
 }
 
 //A2
 C[2][0]=DotProduct(box0.axis[2],box1.axis[0]);
 C[2][1]=DotProduct(box0.axis[2],box1.axis[1]);
 C[2][2]=DotProduct(box0.axis[2],box1.axis[2]);
 AD[2]=DotProduct(box0.axis[2],D);
 absC[2][0]=(real)fabs(C[2][0]);
 absC[2][1]=(real)fabs(C[2][1]);
 absC[2][2]=(real)fabs(C[2][2]);
 R=(real)fabs(AD[2]);
 R1=box1.extent[0]*absC[2][0]+box1.extent[1]*absC[2][1]+box1.extent[2]*absC[2][2];
 R01=box0.extent[2]+R1;
 penetration=R01-R;
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=2;
 }

 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[0][0]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[0][1]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[0][2]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[1][0]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[1][1]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[1][2]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[2][0]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[2][1]!=((real)1.0));
 ASSERT("The routine may not return a correct result for perfectly parallel boxes,sorry. Make a small perturbation"&&C[2][2]!=((real)1.0));

 //B0
 BD[0]=DotProduct(box1.axis[0],D);
 R=(real)fabs(BD[0]);
 R0=box0.extent[0]*absC[0][0]+box0.extent[1]*absC[1][0]+box0.extent[2]*absC[2][0];
 R01=R0+box1.extent[0];
 penetration=R01-R;
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=3;
 }
 
 //B1
 BD[1]=DotProduct(box1.axis[1],D);
 R=(real)fabs(BD[1]);
 R0=box0.extent[0]*absC[0][1]+box0.extent[1]*absC[1][1]+box0.extent[2]*absC[2][1];
 R01=R0+box1.extent[1];
 penetration=R01-R;
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=4;
 }
 
 //B2
 BD[2]=DotProduct(box1.axis[2],D);
 R=(real)fabs(BD[2]);
 R0=box0.extent[0]*absC[0][2]+box0.extent[1]*absC[1][2]+box0.extent[2]*absC[2][2];
 R01=R0+box1.extent[2];
 penetration=R01-R;
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=5;
 }

 //A0xB0
 R=(real)fabs(AD[2]*C[1][0]-AD[1]*C[2][0]);
 ASSERT(IS_EQ((real)fabs(BD[1]*C[0][2]-BD[2]*C[0][1]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[0][2]*C[0][2]+C[0][1]*C[0][1]),(real)sqrt(C[0][2]*C[0][2]+C[0][1]*C[0][1]),((real)1e-6)));
 R0=box0.extent[1]*absC[2][0]+box0.extent[2]*absC[1][0];
 R1=box1.extent[1]*absC[0][2]+box1.extent[2]*absC[0][1];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[0][2]*C[0][2]+C[0][1]*C[0][1]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=6;
 }

 //A0xB1
 R=(real)fabs(AD[2]*C[1][1]-AD[1]*C[2][1]);
 ASSERT(IS_EQ((real)fabs(BD[0]*C[0][2]-BD[2]*C[0][0]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[2][1]*C[2][1]+C[1][1]*C[1][1]),(real)sqrt(C[0][2]*C[0][2]+C[0][0]*C[0][0]),((real)1e-6)));
 R0=box0.extent[1]*absC[2][1]+box0.extent[2]*absC[1][1];
 R1=box1.extent[0]*absC[0][2]+box1.extent[2]*absC[0][0];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[2][1]*C[2][1]+C[1][1]*C[1][1]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=7;
 }

 //A0xB2
 R=(real)fabs(AD[2]*C[1][2]-AD[1]*C[2][2]);
 ASSERT(IS_EQ((real)fabs(BD[0]*C[0][1]-BD[1]*C[0][0]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[2][2]*C[2][2]+C[1][2]*C[1][2]),(real)sqrt(C[0][1]*C[0][1]+C[0][0]*C[0][0]),((real)1e-6)));
 R0=box0.extent[1]*absC[2][2]+box0.extent[2]*absC[1][2];
 R1=box1.extent[0]*absC[0][1]+box1.extent[1]*absC[0][0];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[2][2]*C[2][2]+C[1][2]*C[1][2]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=8;
 }
 
 //A1xB0
 R=(real)fabs(AD[0]*C[2][0]-AD[2]*C[0][0]);
 ASSERT(IS_EQ((real)fabs(BD[1]*C[1][2]-BD[2]*C[1][1]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[2][0]*C[2][0]+C[0][0]*C[0][0]),(real)sqrt(C[1][2]*C[1][2]+C[1][1]*C[1][1]),((real)1e-6)));
 R0=box0.extent[0]*absC[2][0]+box0.extent[2]*absC[0][0];
 R1=box1.extent[1]*absC[1][2]+box1.extent[2]*absC[1][1];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[2][0]*C[2][0]+C[0][0]*C[0][0]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=9;
 }
 
 //A1xB1
 R=(real)fabs(AD[0]*C[2][1]-AD[2]*C[0][1]);
 ASSERT(IS_EQ((real)fabs(BD[0]*C[1][2]-BD[2]*C[1][0]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[2][1]*C[2][1]+C[0][1]*C[0][1]),(real)sqrt(C[1][2]*C[1][2]+C[1][0]*C[1][0]),((real)1e-6)));
 R0=box0.extent[0]*absC[2][1]+box0.extent[2]*absC[0][1];
 R1=box1.extent[0]*absC[1][2]+box1.extent[2]*absC[1][0];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[2][1]*C[2][1]+C[0][1]*C[0][1]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=10;
 }
 
 //A1xB2
 R=(real)fabs(AD[0]*C[2][2]-AD[2]*C[0][2]);
 ASSERT(IS_EQ((real)fabs(BD[0]*C[1][1]-BD[1]*C[1][0]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[2][2]*C[2][2]+C[0][2]*C[0][2]),(real)sqrt(C[1][1]*C[1][1]+C[1][0]*C[1][0]),((real)1e-6)));
 R0=box0.extent[0]*absC[2][2]+box0.extent[2]*absC[0][2];
 R1=box1.extent[0]*absC[1][1]+box1.extent[1]*absC[1][0];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[2][2]*C[2][2]+C[0][2]*C[0][2]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=11;
 }
 
 //A2xB0
 R=(real)fabs(AD[1]*C[0][0]-AD[0]*C[1][0]);
 ASSERT(IS_EQ((real)fabs(BD[1]*C[2][2]-BD[2]*C[2][1]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[1][0]*C[1][0]+C[0][0]*C[0][0]),(real)sqrt(C[2][2]*C[2][2]+C[2][1]*C[2][1]),((real)1e-6)));
 R0=box0.extent[0]*absC[1][0]+box0.extent[1]*absC[0][0];
 R1=box1.extent[1]*absC[2][2]+box1.extent[2]*absC[2][1];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[1][0]*C[1][0]+C[0][0]*C[0][0]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=12;
 }
 
 //A2xB1
 R=(real)fabs(AD[1]*C[0][1]-AD[0]*C[1][1]);
 ASSERT(IS_EQ((real)fabs(BD[0]*C[2][2]-BD[2]*C[2][0]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[1][1]*C[1][1]+C[0][1]*C[0][1]),(real)sqrt(C[2][2]*C[2][2]+C[2][0]*C[2][0]),((real)1e-6)));
 R0=box0.extent[0]*absC[1][1]+box0.extent[1]*absC[0][1];
 R1=box1.extent[0]*absC[2][2]+box1.extent[2]*absC[2][0];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[1][1]*C[1][1]+C[0][1]*C[0][1]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=13;
 }
 
 //A2xB2
 R=(real)fabs(AD[1]*C[0][2]-AD[0]*C[1][2]);
 ASSERT(IS_EQ((real)fabs(BD[0]*C[2][1]-BD[1]*C[2][0]),R,((real)1e-6)));
 ASSERT(IS_EQ((real)sqrt(C[1][2]*C[1][2]+C[0][2]*C[0][2]),(real)sqrt(C[2][1]*C[2][1]+C[2][0]*C[2][0]),((real)1e-6)));
 R0=box0.extent[0]*absC[1][2]+box0.extent[1]*absC[0][2];
 R1=box1.extent[0]*absC[2][1]+box1.extent[1]*absC[2][0];
 R01=R0+R1;
 penetration=(R01-R)/(real)sqrt(C[1][2]*C[1][2]+C[0][2]*C[0][2]);
 if(penetration<0)
 {
  ASSERT(BoxBoxIntersectionTest(box0,box1)==0);
  return 0;
 }
 else if(penetration<res_penetration)
 {
  res_penetration=penetration;
  intersection_index=14;
 }
 ASSERT(intersection_index!=-1);

 if(intersection_index<3)
 {//Normal from box0,vertex from box1
  ASSERT(AD[intersection_index]!=0);
  int sign[3]=
  {
   C[intersection_index][0]>((real)0.0)?1:-1,
   C[intersection_index][1]>((real)0.0)?1:-1,
   C[intersection_index][2]>((real)0.0)?1:-1
  };
  if(AD[intersection_index]>0)
  {
   res_normal[0]=-box0.axis[intersection_index][0];
   res_normal[1]=-box0.axis[intersection_index][1];
   res_normal[2]=-box0.axis[intersection_index][2];
   res_point[0]=box1.center[0]-sign[0]*box1.axis[0][0]*box1.extent[0]-sign[1]*box1.axis[1][0]*box1.extent[1]-sign[2]*box1.axis[2][0]*box1.extent[2];
   res_point[1]=box1.center[1]-sign[0]*box1.axis[0][1]*box1.extent[0]-sign[1]*box1.axis[1][1]*box1.extent[1]-sign[2]*box1.axis[2][1]*box1.extent[2];
   res_point[2]=box1.center[2]-sign[0]*box1.axis[0][2]*box1.extent[0]-sign[1]*box1.axis[1][2]*box1.extent[1]-sign[2]*box1.axis[2][2]*box1.extent[2];
  }
  else
  {
   res_normal[0]=box0.axis[intersection_index][0];
   res_normal[1]=box0.axis[intersection_index][1];
   res_normal[2]=box0.axis[intersection_index][2];
   res_point[0]=box1.center[0]+sign[0]*box1.axis[0][0]*box1.extent[0]+sign[1]*box1.axis[1][0]*box1.extent[1]+sign[2]*box1.axis[2][0]*box1.extent[2];
   res_point[1]=box1.center[1]+sign[0]*box1.axis[0][1]*box1.extent[0]+sign[1]*box1.axis[1][1]*box1.extent[1]+sign[2]*box1.axis[2][1]*box1.extent[2];
   res_point[2]=box1.center[2]+sign[0]*box1.axis[0][2]*box1.extent[0]+sign[1]*box1.axis[1][2]*box1.extent[1]+sign[2]*box1.axis[2][2]*box1.extent[2];
  }
 }
 else if(intersection_index<6)
 {//Normal from box1,vertex from box0
  ASSERT(DotProduct(box1.axis[0],D)!=((real)0.0));
  int sign[3]=
  {
   C[0][intersection_index-3]>((real)0.0)?1:-1,
   C[1][intersection_index-3]>((real)0.0)?1:-1,
   C[2][intersection_index-3]>((real)0.0)?1:-1
  };
  if(DotProduct(box1.axis[intersection_index-3],D)>0)
  {
   res_normal[0]=-box1.axis[intersection_index-3][0];
   res_normal[1]=-box1.axis[intersection_index-3][1];
   res_normal[2]=-box1.axis[intersection_index-3][2];
   res_point[0]=box0.center[0]+sign[0]*box0.axis[0][0]*box0.extent[0]+sign[1]*box0.axis[1][0]*box0.extent[1]+sign[2]*box0.axis[2][0]*box0.extent[2];
   res_point[1]=box0.center[1]+sign[0]*box0.axis[0][1]*box0.extent[0]+sign[1]*box0.axis[1][1]*box0.extent[1]+sign[2]*box0.axis[2][1]*box0.extent[2];
   res_point[2]=box0.center[2]+sign[0]*box0.axis[0][2]*box0.extent[0]+sign[1]*box0.axis[1][2]*box0.extent[1]+sign[2]*box0.axis[2][2]*box0.extent[2];
  }
  else
  {
   res_normal[0]=box1.axis[intersection_index-3][0];
   res_normal[1]=box1.axis[intersection_index-3][1];
   res_normal[2]=box1.axis[intersection_index-3][2];
   res_point[0]=box0.center[0]-sign[0]*box0.axis[0][0]*box0.extent[0]-sign[1]*box0.axis[1][0]*box0.extent[1]-sign[2]*box0.axis[2][0]*box0.extent[2];
   res_point[1]=box0.center[1]-sign[0]*box0.axis[0][1]*box0.extent[0]-sign[1]*box0.axis[1][1]*box0.extent[1]-sign[2]*box0.axis[2][1]*box0.extent[2];
   res_point[2]=box0.center[2]-sign[0]*box0.axis[0][2]*box0.extent[0]-sign[1]*box0.axis[1][2]*box0.extent[1]-sign[2]*box0.axis[2][2]*box0.extent[2];
  }
 }
 else
 switch(intersection_index)
 {
  case 6://A0xB0
  {
   signA[0]=-C[2][0]>0?1:-1;
   signA[1]=C[1][0] >0?1:-1;
   signB[0]=-C[0][2]>0?1:-1;
   signB[1]=C[0][1] >0?1:-1;
   {//A0
    real d=        -C[2][0]*AD[1]+C[1][0]*AD[2];
    real AAD[3]={0,-C[2][0]*d,   C[1][0]*d};
    real dp=
     box0.extent[1]*signA[0]*AAD[1]+
     box0.extent[2]*signA[1]*AAD[2];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]+
      box0.axis[1][0]*box0.extent[1]*signA[0]+
      box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]+
      box0.axis[1][1]*box0.extent[1]*signA[0]+
      box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]+
      box0.axis[1][2]*box0.extent[1]*signA[0]+
      box0.axis[2][2]*box0.extent[2]*signA[1];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]+
      -box0.axis[1][0]*box0.extent[1]*signA[0]+
      -box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]+
      -box0.axis[1][1]*box0.extent[1]*signA[0]+
      -box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]+
      -box0.axis[1][2]*box0.extent[1]*signA[0]+
      -box0.axis[2][2]*box0.extent[2]*signA[1];
    }
   }//A0
   {//B0
    real d=        -C[0][2]*BD[1]+C[0][1]*BD[2];
    real BBD[3]={0,-C[0][2]*d,   C[0][1]*d};
    real dp=
     box1.extent[1]*signB[0]*BBD[1]+
     box1.extent[2]*signB[1]*BBD[2];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]+
      -box1.axis[1][0]*box1.extent[1]*signB[0]+
      -box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]+
      -box1.axis[1][1]*box1.extent[1]*signB[0]+
      -box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]+
      -box1.axis[1][2]*box1.extent[1]*signB[0]+
      -box1.axis[2][2]*box1.extent[2]*signB[1];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]+
      box1.axis[1][0]*box1.extent[1]*signB[0]+
      box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]+
      box1.axis[1][1]*box1.extent[1]*signB[0]+
      box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]+
      box1.axis[1][2]*box1.extent[1]*signB[0]+
      box1.axis[2][2]*box1.extent[2]*signB[1];
    }
   }//B
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[0],rB,box1.axis[0]);
   ASSERT("case6"&&tA>=((real)-0.01)&&tA<=box0.extent[0]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[0]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[0][0]*tA;
   res_point[1]=rA[1]+box0.axis[0][1]*tA;
   res_point[2]=rA[2]+box0.axis[0][2]*tA;
   deltap[0]=rB[0]+box1.axis[0][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[0][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[0][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case6"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     0,
     -C[2][0],
     C[1][0] 
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 7://A0xB1
  {
   signA[0]=-C[2][1]>0?1:-1;
   signA[1]=C[1][1] >0?1:-1;
   signB[0]=C[0][2] >0?1:-1;
   signB[1]=-C[0][0]>0?1:-1;
   {//A0
    real d=        -C[2][1]*AD[1]+C[1][1]*AD[2];
    real AAD[3]={0,-C[2][1]*d,   C[1][1]*d};
    real dp=
     box0.extent[1]*signA[0]*AAD[1]+
     box0.extent[2]*signA[1]*AAD[2];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]+
      box0.axis[1][0]*box0.extent[1]*signA[0]+
      box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]+
      box0.axis[1][1]*box0.extent[1]*signA[0]+
      box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]+
      box0.axis[1][2]*box0.extent[1]*signA[0]+
      box0.axis[2][2]*box0.extent[2]*signA[1];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]+
      -box0.axis[1][0]*box0.extent[1]*signA[0]+
      -box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]+
      -box0.axis[1][1]*box0.extent[1]*signA[0]+
      -box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]+
      -box0.axis[1][2]*box0.extent[1]*signA[0]+
      -box0.axis[2][2]*box0.extent[2]*signA[1];
    }
   }//A0
   {//B1
    real d=      C[0][2]*BD[0]-C[0][0]*BD[2];
    real BBD[3]={C[0][2]*d,0,-C[0][0]*d};
    real dp=
     box1.extent[0]*signB[0]*BBD[0]+
     box1.extent[2]*signB[1]*BBD[2];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]+
      -box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]+
      -box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]+
      -box1.axis[2][2]*box1.extent[2]*signB[1];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]+
      box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]+
      box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]+
      box1.axis[2][2]*box1.extent[2]*signB[1];
    }
   }//B
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[0],rB,box1.axis[1]);
   ASSERT("case7"&&tA>=((real)-0.01)&&tA<=box0.extent[0]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[1]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[0][0]*tA;
   res_point[1]=rA[1]+box0.axis[0][1]*tA;
   res_point[2]=rA[2]+box0.axis[0][2]*tA;
   deltap[0]=rB[0]+box1.axis[1][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[1][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[1][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case7"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     0,
     -C[2][1],
     C[1][1] 
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 8://A0xB2
  {
   signA[0]=-C[2][2]>0?1:-1;
   signA[1]=C[1][2] >0?1:-1;
   signB[0]=-C[0][1]>0?1:-1;
   signB[1]=C[0][0] >0?1:-1;
   {//A0
    real d=        -C[2][2]*AD[1]+C[1][2]*AD[2];
    real AAD[3]={0,-C[2][2]*d,   C[1][2]*d};
    real dp=
     box0.extent[1]*signA[0]*AAD[1]+
     box0.extent[2]*signA[1]*AAD[2];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]+
      box0.axis[1][0]*box0.extent[1]*signA[0]+
      box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]+
      box0.axis[1][1]*box0.extent[1]*signA[0]+
      box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]+
      box0.axis[1][2]*box0.extent[1]*signA[0]+
      box0.axis[2][2]*box0.extent[2]*signA[1];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]+
      -box0.axis[1][0]*box0.extent[1]*signA[0]+
      -box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]+
      -box0.axis[1][1]*box0.extent[1]*signA[0]+
      -box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]+
      -box0.axis[1][2]*box0.extent[1]*signA[0]+
      -box0.axis[2][2]*box0.extent[2]*signA[1];
    }
   }//A0
   {//B2
    real d=      -C[0][1]*BD[0]+C[0][0]*BD[1];
    real BBD[3]={-C[0][1]*d,   C[0][0]*d,0};
    real dp=
     box1.extent[0]*signB[0]*BBD[0]+
     box1.extent[1]*signB[1]*BBD[1];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]*signB[1]+
      -box1.axis[2][0]*box1.extent[2];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]*signB[1]+
      -box1.axis[2][1]*box1.extent[2];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]*signB[1]+
      -box1.axis[2][2]*box1.extent[2];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      box1.axis[0][0]*box1.extent[0]*signB[0]+
      box1.axis[1][0]*box1.extent[1]*signB[1]+
      -box1.axis[2][0]*box1.extent[2];
     rB[1]=
      box1.center[1]+
      box1.axis[0][1]*box1.extent[0]*signB[0]+
      box1.axis[1][1]*box1.extent[1]*signB[1]+
      -box1.axis[2][1]*box1.extent[2];
     rB[2]=
      box1.center[2]+
      box1.axis[0][2]*box1.extent[0]*signB[0]+
      box1.axis[1][2]*box1.extent[1]*signB[1]+
      -box1.axis[2][2]*box1.extent[2];
    }
   }//B2
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[0],rB,box1.axis[2]);
   ASSERT("case8"&&tA>=((real)-0.01)&&tA<=box0.extent[0]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[2]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[0][0]*tA;
   res_point[1]=rA[1]+box0.axis[0][1]*tA;
   res_point[2]=rA[2]+box0.axis[0][2]*tA;
   deltap[0]=rB[0]+box1.axis[2][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[2][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[2][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case8"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     0,
     -C[2][2],
     C[1][2] 
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 9://A1xB0
  {
   signA[0]=C[2][0] >0?1:-1;
   signA[1]=-C[0][0]>0?1:-1;
   signB[0]=-C[1][2]>0?1:-1;
   signB[1]=C[1][1] >0?1:-1;
   {//A1
    real d=      C[2][0]*AD[0]-C[0][0]*AD[2];
    real AAD[3]={C[2][0]*d,0,-C[0][0]*d};
    real dp=
     box0.extent[0]*signA[0]*AAD[0]+
     box0.extent[2]*signA[1]*AAD[2];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]+
      box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]+
      box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]+
      box0.axis[2][2]*box0.extent[2]*signA[1];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]+
      -box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]+
      -box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]+
      -box0.axis[2][2]*box0.extent[2]*signA[1];
    }
   }//A1
   {//B0
    real d=        -C[1][2]*BD[1]+C[1][1]*BD[2];
    real BBD[3]={0,-C[1][2]*d,   C[1][1]*d};
    real dp=
     box1.extent[1]*signB[0]*BBD[1]+
     box1.extent[2]*signB[1]*BBD[2];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]+
      -box1.axis[1][0]*box1.extent[1]*signB[0]+
      -box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]+
      -box1.axis[1][1]*box1.extent[1]*signB[0]+
      -box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]+
      -box1.axis[1][2]*box1.extent[1]*signB[0]+
      -box1.axis[2][2]*box1.extent[2]*signB[1];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]+
      box1.axis[1][0]*box1.extent[1]*signB[0]+
      box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]+
      box1.axis[1][1]*box1.extent[1]*signB[0]+
      box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]+
      box1.axis[1][2]*box1.extent[1]*signB[0]+
      box1.axis[2][2]*box1.extent[2]*signB[1];
    }
   }//B0
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[1],rB,box1.axis[0]);
   ASSERT("case9"&&tA>=((real)-0.01)&&tA<=box0.extent[1]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[0]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[1][0]*tA;
   res_point[1]=rA[1]+box0.axis[1][1]*tA;
   res_point[2]=rA[2]+box0.axis[1][2]*tA;
   deltap[0]=rB[0]+box1.axis[0][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[0][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[0][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case9"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     C[2][0],
     0,
     -C[0][0]
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 10://A1xB1
  {
   signA[0]=C[2][1] >0?1:-1;
   signA[1]=-C[0][1]>0?1:-1;
   signB[0]=C[1][2] >0?1:-1;
   signB[1]=-C[1][0]>0?1:-1;
   {//A1
    real d=      C[2][1]*AD[0]-C[0][1]*AD[2];
    real AAD[3]={C[2][1]*d,0,-C[0][1]*d};
    real dp=
     box0.extent[0]*signA[0]*AAD[0]+
     box0.extent[2]*signA[1]*AAD[2];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]+
      box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]+
      box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]+
      box0.axis[2][2]*box0.extent[2]*signA[1];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]+
      -box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]+
      -box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]+
      -box0.axis[2][2]*box0.extent[2]*signA[1];
    }
   }//A1
   {//B1
    real d=      C[1][2]*BD[0]-C[1][0]*BD[2];
    real BBD[3]={C[1][2]*d,0,-C[1][0]*d};
    real dp=
     box1.extent[0]*signB[0]*BBD[0]+
     box1.extent[2]*signB[1]*BBD[2];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]+
      -box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]+
      -box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]+
      -box1.axis[2][2]*box1.extent[2]*signB[1];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]+
      box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]+
      box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]+
      box1.axis[2][2]*box1.extent[2]*signB[1];
    }
   }//B1
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[1],rB,box1.axis[1]);
   ASSERT("case10"&&tA>=((real)-0.01)&&tA<=box0.extent[1]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[1]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[1][0]*tA;
   res_point[1]=rA[1]+box0.axis[1][1]*tA;
   res_point[2]=rA[2]+box0.axis[1][2]*tA;
   deltap[0]=rB[0]+box1.axis[1][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[1][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[1][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case10"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     C[2][1],
     0,
     -C[0][1]
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 11://A1xB2
  {
   signA[0]=C[2][2] >0?1:-1;
   signA[1]=-C[0][2]>0?1:-1;
   signB[0]=-C[1][1]>0?1:-1;
   signB[1]=C[1][0] >0?1:-1;
   {//A1
    real d=      C[2][2]*AD[0]-C[0][2]*AD[2];
    real AAD[3]={C[2][2]*d,0,-C[0][2]*d};
    real dp=
     box0.extent[0]*signA[0]*AAD[0]+
     box0.extent[2]*signA[1]*AAD[2];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]+
      box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]+
      box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]+
      box0.axis[2][2]*box0.extent[2]*signA[1];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]+
      -box0.axis[2][0]*box0.extent[2]*signA[1];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]+
      -box0.axis[2][1]*box0.extent[2]*signA[1];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]+
      -box0.axis[2][2]*box0.extent[2]*signA[1];
    }
   }//A1
   {//B2
    real d=      -C[1][1]*BD[0]+C[1][0]*BD[1];
    real BBD[3]={-C[1][1]*d,   C[1][0]*d,0};
    real dp=
     box1.extent[0]*signB[0]*BBD[0]+
     box1.extent[1]*signB[1]*BBD[1];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]*signB[1]+
      -box1.axis[2][0]*box1.extent[2];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]*signB[1]+
      -box1.axis[2][1]*box1.extent[2];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]*signB[1]+
      -box1.axis[2][2]*box1.extent[2];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      box1.axis[0][0]*box1.extent[0]*signB[0]+
      box1.axis[1][0]*box1.extent[1]*signB[1]+
      -box1.axis[2][0]*box1.extent[2];
     rB[1]=
      box1.center[1]+
      box1.axis[0][1]*box1.extent[0]*signB[0]+
      box1.axis[1][1]*box1.extent[1]*signB[1]+
      -box1.axis[2][1]*box1.extent[2];
     rB[2]=
      box1.center[2]+
      box1.axis[0][2]*box1.extent[0]*signB[0]+
      box1.axis[1][2]*box1.extent[1]*signB[1]+
      -box1.axis[2][2]*box1.extent[2];
    }
   }//B2
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[1],rB,box1.axis[2]);
   ASSERT("case11"&&tA>=((real)-0.01)&&tA<=box0.extent[1]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[2]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[1][0]*tA;
   res_point[1]=rA[1]+box0.axis[1][1]*tA;
   res_point[2]=rA[2]+box0.axis[1][2]*tA;
   deltap[0]=rB[0]+box1.axis[2][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[2][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[2][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case11"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     C[2][2],
     0,
     -C[0][2]
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    drawline(box0.center,box0.axis[1]);
    drawline(box1.center,box1.axis[2]);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 12://A2xB0
  {
   signA[0]=-C[1][0]>0?1:-1;
   signA[1]=C[0][0] >0?1:-1;
   signB[0]=-C[2][2]>0?1:-1;
   signB[1]=C[2][1] >0?1:-1;
   {//A2
    real d=      -C[1][0]*AD[0]+C[0][0]*AD[1];
    real AAD[3]={-C[1][0]*d,   C[0][0]*d,0};
    real dp=
     box0.extent[0]*signA[0]*AAD[0]+
     box0.extent[1]*signA[1]*AAD[1];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      box0.axis[0][0]*box0.extent[0]*signA[0]+
      box0.axis[1][0]*box0.extent[1]*signA[1]+
      -box0.axis[2][0]*box0.extent[2];
     rA[1]=
      box0.center[1]+
      box0.axis[0][1]*box0.extent[0]*signA[0]+
      box0.axis[1][1]*box0.extent[1]*signA[1]+
      -box0.axis[2][1]*box0.extent[2];
     rA[2]=
      box0.center[2]+
      box0.axis[0][2]*box0.extent[0]*signA[0]+
      box0.axis[1][2]*box0.extent[1]*signA[1]+
      -box0.axis[2][2]*box0.extent[2];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]*signA[1]+
      -box0.axis[2][0]*box0.extent[2];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]*signA[1]+
      -box0.axis[2][1]*box0.extent[2];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]*signA[1]+
      -box0.axis[2][2]*box0.extent[2];
    }
   }//A2   
   {//B0
    real d=        -C[2][2]*BD[1]+C[2][1]*BD[2];
    real BBD[3]={0,-C[2][2]*d,   C[2][1]*d};
    real dp=
     box1.extent[1]*signB[0]*BBD[1]+
     box1.extent[2]*signB[1]*BBD[2];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]+
      -box1.axis[1][0]*box1.extent[1]*signB[0]+
      -box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]+
      -box1.axis[1][1]*box1.extent[1]*signB[0]+
      -box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]+
      -box1.axis[1][2]*box1.extent[1]*signB[0]+
      -box1.axis[2][2]*box1.extent[2]*signB[1];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]+
      box1.axis[1][0]*box1.extent[1]*signB[0]+
      box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]+
      box1.axis[1][1]*box1.extent[1]*signB[0]+
      box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]+
      box1.axis[1][2]*box1.extent[1]*signB[0]+
      box1.axis[2][2]*box1.extent[2]*signB[1];
    }
   }//B0
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[2],rB,box1.axis[0]);
   ASSERT("case12"&&tA>=((real)-0.01)&&tA<=box0.extent[2]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[0]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[2][0]*tA;
   res_point[1]=rA[1]+box0.axis[2][1]*tA;
   res_point[2]=rA[2]+box0.axis[2][2]*tA;
   deltap[0]=rB[0]+box1.axis[0][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[0][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[0][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case12"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     -C[1][0],
     C[0][0],
     0
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 13://A2xB1
  {
   signA[0]=-C[1][1]>0?1:-1;
   signA[1]=C[0][1] >0?1:-1;
   signB[0]=C[2][2] >0?1:-1;
   signB[1]=-C[2][0]>0?1:-1;
   {//A2
    real d=      -C[1][1]*AD[0]+C[0][1]*AD[1];
    real AAD[3]={-C[1][1]*d,   C[0][1]*d,0};
    real dp=
     box0.extent[0]*signA[0]*AAD[0]+
     box0.extent[1]*signA[1]*AAD[1];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      box0.axis[0][0]*box0.extent[0]*signA[0]+
      box0.axis[1][0]*box0.extent[1]*signA[1]+
      -box0.axis[2][0]*box0.extent[2];
     rA[1]=
      box0.center[1]+
      box0.axis[0][1]*box0.extent[0]*signA[0]+
      box0.axis[1][1]*box0.extent[1]*signA[1]+
      -box0.axis[2][1]*box0.extent[2];
     rA[2]=
      box0.center[2]+
      box0.axis[0][2]*box0.extent[0]*signA[0]+
      box0.axis[1][2]*box0.extent[1]*signA[1]+
      -box0.axis[2][2]*box0.extent[2];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]*signA[1]+
      -box0.axis[2][0]*box0.extent[2];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]*signA[1]+
      -box0.axis[2][1]*box0.extent[2];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]*signA[1]+
      -box0.axis[2][2]*box0.extent[2];
    }
   }//A2
   {//B1
    real d=      C[2][2]*BD[0]-C[2][0]*BD[2];
    real BBD[3]={C[2][2]*d,0,-C[2][0]*d};
    real dp=
     box1.extent[0]*signB[0]*BBD[0]+
     box1.extent[2]*signB[1]*BBD[2];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]+
      -box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]+
      -box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]+
      -box1.axis[2][2]*box1.extent[2]*signB[1];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]+
      box1.axis[2][0]*box1.extent[2]*signB[1];
     rB[1]=
      box1.center[1]+
      box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]+
      box1.axis[2][1]*box1.extent[2]*signB[1];
     rB[2]=
      box1.center[2]+
      box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]+
      box1.axis[2][2]*box1.extent[2]*signB[1];
    }
   }//B1
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[2],rB,box1.axis[1]);
   ASSERT("case13"&&tA>=((real)-0.01)&&tA<=box0.extent[2]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[1]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[2][0]*tA;
   res_point[1]=rA[1]+box0.axis[2][1]*tA;
   res_point[2]=rA[2]+box0.axis[2][2]*tA;
   deltap[0]=rB[0]+box1.axis[1][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[1][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[1][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case13"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     -C[1][1],
     C[0][1],
     0
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
  case 14://A2xB2
  {
   signA[0]=-C[1][2]>0?1:-1;
   signA[1]=C[0][2] >0?1:-1;
   signB[0]=-C[2][1]>0?1:-1;
   signB[1]=C[2][0] >0?1:-1;
   {//A2
    real d=      -C[1][2]*AD[0]+C[0][2]*AD[1];
    real AAD[3]={-C[1][2]*d,   C[0][2]*d,0};
    real dp=
     box0.extent[0]*signA[0]*AAD[0]+
     box0.extent[1]*signA[1]*AAD[1];
    if(dp>((real)0.0))
    {
     rA[0]=
      box0.center[0]+
      box0.axis[0][0]*box0.extent[0]*signA[0]+
      box0.axis[1][0]*box0.extent[1]*signA[1]+
      -box0.axis[2][0]*box0.extent[2];
     rA[1]=
      box0.center[1]+
      box0.axis[0][1]*box0.extent[0]*signA[0]+
      box0.axis[1][1]*box0.extent[1]*signA[1]+
      -box0.axis[2][1]*box0.extent[2];
     rA[2]=
      box0.center[2]+
      box0.axis[0][2]*box0.extent[0]*signA[0]+
      box0.axis[1][2]*box0.extent[1]*signA[1]+
      -box0.axis[2][2]*box0.extent[2];
    }
    else
    {
     rA[0]=
      box0.center[0]+
      -box0.axis[0][0]*box0.extent[0]*signA[0]+
      -box0.axis[1][0]*box0.extent[1]*signA[1]+
      -box0.axis[2][0]*box0.extent[2];
     rA[1]=
      box0.center[1]+
      -box0.axis[0][1]*box0.extent[0]*signA[0]+
      -box0.axis[1][1]*box0.extent[1]*signA[1]+
      -box0.axis[2][1]*box0.extent[2];
     rA[2]=
      box0.center[2]+
      -box0.axis[0][2]*box0.extent[0]*signA[0]+
      -box0.axis[1][2]*box0.extent[1]*signA[1]+
      -box0.axis[2][2]*box0.extent[2];
    }
   }//A2
   {//B2
    real d=      -C[2][1]*BD[0]+C[2][0]*BD[1];
    real BBD[3]={-C[2][1]*d,   C[2][0]*d,0};
    real dp=
     box1.extent[0]*signB[0]*BBD[0]+
     box1.extent[1]*signB[1]*BBD[1];
    if(dp>((real)0.0))
    {
     rB[0]=
      box1.center[0]+
      -box1.axis[0][0]*box1.extent[0]*signB[0]+
      -box1.axis[1][0]*box1.extent[1]*signB[1]+
      -box1.axis[2][0]*box1.extent[2];
     rB[1]=
      box1.center[1]+
      -box1.axis[0][1]*box1.extent[0]*signB[0]+
      -box1.axis[1][1]*box1.extent[1]*signB[1]+
      -box1.axis[2][1]*box1.extent[2];
     rB[2]=
      box1.center[2]+
      -box1.axis[0][2]*box1.extent[0]*signB[0]+
      -box1.axis[1][2]*box1.extent[1]*signB[1]+
      -box1.axis[2][2]*box1.extent[2];
    }
    else
    {
     rB[0]=
      box1.center[0]+
      box1.axis[0][0]*box1.extent[0]*signB[0]+
      box1.axis[1][0]*box1.extent[1]*signB[1]+
      -box1.axis[2][0]*box1.extent[2];
     rB[1]=
      box1.center[1]+
      box1.axis[0][1]*box1.extent[0]*signB[0]+
      box1.axis[1][1]*box1.extent[1]*signB[1]+
      -box1.axis[2][1]*box1.extent[2];
     rB[2]=
      box1.center[2]+
      box1.axis[0][2]*box1.extent[0]*signB[0]+
      box1.axis[1][2]*box1.extent[1]*signB[1]+
      -box1.axis[2][2]*box1.extent[2];
    }
   }//B
   SegmentSegmentCollision1(tA,tB,rA,box0.axis[2],rB,box1.axis[2]);
   ASSERT("case14"&&tA>=((real)-0.01)&&tA<=box0.extent[2]*((real)2.0)+((real)1.01)&&tB>=((real)-0.01)&&tB<=box1.extent[2]*((real)2.0)+((real)1.01));
   res_point[0]=rA[0]+box0.axis[2][0]*tA;
   res_point[1]=rA[1]+box0.axis[2][1]*tA;
   res_point[2]=rA[2]+box0.axis[2][2]*tA;
   deltap[0]=rB[0]+box1.axis[2][0]*tB-res_point[0];
   deltap[1]=rB[1]+box1.axis[2][1]*tB-res_point[1];
   deltap[2]=rB[2]+box1.axis[2][2]*tB-res_point[2];
#ifdef CD_DEBUG
   real mag=Magnitude(deltap);
   ASSERT("case14"&&IS_EQ(mag,res_penetration,((real)1e-6)));
   if(!IS_EQ(mag,res_penetration,((real)1e-6)) ||
      !(tA>=((real)-0.01)&&tA<=((real)1.01)&&tB>=((real)-0.01)&&tB<=((real)1.01)))
   {
    if(frozen==0)freeze=1;
    real nor[3];
    real norA[3]=
    {
     -C[1][2],
     C[0][2],
     0
    };
    ToWorld(nor,norA,box0.axis);
    real mid_point[3];
    mid_point[0]=rA[0]+dirA[0]*((real)0.5);
    mid_point[1]=rA[1]+dirA[1]*((real)0.5);
    mid_point[2]=rA[2]+dirA[2]*((real)0.5);
    drawline(mid_point,nor);

    drawline(box0.center,box0.axis[2]);
    drawline(box1.center,box1.axis[2]);
    drawline(mid_point,nor);
    fprintf(fl,"case %d tA: %g tB: %g dirA[%9.6g,%9.6g,%9.6g] dirB[%9.6g,%9.6g,%9.6g]\n",intersection_index,tA,tB,dirA[0],dirA[1],dirA[2],dirB[0],dirB[1],dirB[2]);
   }
#endif//of #ifdef CD_DEBUG
   Normalize(res_normal,deltap);
   break;
  }
 }
#ifdef CD_DEBUG
 if(freeze)
 {
  ts_save=timestep;
  timestep=((real)0.0);
  frozen=1;
  do_collisions=0;
  freeze=0;
  char st[30];
  sprintf(st,"%d",intersection_index);
  glutSetWindowTitle(st);
 }
 if(intersection_index>5)
 {
  drawline(rA,dirA);
  drawline(rB,dirB,5);
  real p1[3]=
  {
   res_point[0]+res_normal[0]*res_penetration,
   res_point[1]+res_normal[1]*res_penetration,
   res_point[2]+res_normal[2]*res_penetration
  };
  drawline1(res_point,p1);
 }
#endif//of #ifdef CD_DEBUG
 ASSERT(BoxBoxIntersectionTest(box0,box1));
 return 1;
}

class CTriangle
{
public: 
 real point[3][3];//points should be ordered CC as seen from top of normal
 //derived
 real normal[3];
 real offset;
 real incl_start[5];
 real incl_end[5];
 int NO_incl;
 real biggest_penetration;
};

static
void ComputeInclinedEdgeNormals(real inclined_edge_normal[3][3],const real (*point)[3],const real updir[3])
{
 real dp[3];
 Subtract(dp,point[1],point[0]);
 CrossProduct(inclined_edge_normal[0],dp,updir);
 Normalize(inclined_edge_normal[0],inclined_edge_normal[0]);

 Subtract(dp,point[2],point[1]);
 CrossProduct(inclined_edge_normal[1],dp,updir);
 Normalize(inclined_edge_normal[1],inclined_edge_normal[1]);

 Subtract(dp,point[0],point[2]);
 CrossProduct(inclined_edge_normal[2],dp,updir);
 Normalize(inclined_edge_normal[2],inclined_edge_normal[2]);
}

static
void ComputePhiStartEnd(real *phi_start,real *phi_end,real radius,real normal[3],real offset)
{//Computes exclusion zone
 real det=(normal[1]*normal[1]+normal[0]*normal[0])*radius*radius-offset*offset;
 if(det<=0)
 {//either disk lies above the plane or below entirely
  if(offset>0)
  {//entirely below - exclusion zone is empty
   *phi_start=((real)0.0);
   *phi_end=((real)0.0);
  }
  else
  {//entirely above - all disk is excluded
   *phi_start=((real)1.0);
   *phi_end=((real)1.0);
  }
  return;
 }
 real sqrt_det=(real)sqrt(det);
 real nd2=(real)sqrt_det*(real)fabs(normal[0]);
 real nd2_sign=normal[1]*(normal[0]<0 ? -1 : 1)*sqrt_det;
 real n2o=offset*normal[1];
 real n1o=offset*normal[0];
 *phi_start=(real)atan2(n2o+nd2,n1o-nd2_sign);
 *phi_end=(real)atan2(n2o-nd2,n1o+nd2_sign);
 real deriv[2]={-(real)sin(*phi_start),(real)cos(*phi_start)};
 if(deriv[0]*normal[0]+deriv[1]*normal[1]<0)
 {//swap phi_start and phi_end
  real tmp=*phi_start;
  *phi_start=*phi_end;
  *phi_end=tmp;
 }
}

static inline
int is_inside(real phi,real phi_start,real phi_end)
{
 ASSERT(phi_start>=-PI&&phi_start<=PI);
 ASSERT(phi_end>=-PI&&phi_end<=PI);
 ASSERT(phi>=-PI&&phi<=PI);
 if(phi_start<phi_end)
  return (phi>phi_start) && (phi<phi_end);
 else
  return (phi>phi_start) || (phi<phi_end);
}

static inline
real distance_CC(real start,real end)
{//distance counterclockwise
 ASSERT(start>=-PI&&start<=PI);
 ASSERT(end>=-PI&&end<=PI);
 if(end>start)
  return end-start;
 else
  return end+2*PI-start;
}

#ifdef _DEBUG
static int number_of_recordings=50;
static int save=0;
static int count=0;
static real delta_x=9;
static real delta_y=-3;
static real normal_scale=((real)2.0);
static FILE* fl=0;
static int count_x=0;
static int count_y=0;
static real myfabs(real arg)
{
 if(arg<((real)0.0000000001)) return ((real)0.0000000001);
 else return arg;
}
#endif//of #ifdef _DEBUG

FC_DLL_EXPORT
int TerrainWheelCollisionDetection
(
 real normal[3],real point[3],real *penetration,//output
 real ***triangle,
 const real **triangle_normal,
 int NO_triangles,
 const CDisk& disk,
 real disk_width,
 const real direction_up[3]
)
{//The function can be greatly improved in terms of speed - now it is beta
 int i,j,k,side;
 real total_weight=((real)0.0);
 real total_covered_angle=((real)0.0);
 Zero(normal);
 Zero(point);
 *penetration=((real)0.0);


#ifdef _DEBUG
 {
  int i;

  if(save&&count<number_of_recordings)
  {
   count_y=count;
   count_x=0;
   if(fl==0)
   {
    remove("t:\\AcadCommands.txt");
    fl=fopen("t:\\AcadCommands.txt","wt");
   }
   fprintf(fl,
    "text\n"
    "%.15g,%.15g\n"
    "0.7\n"//height
    "0\n"//rotation
    "NO_triangles=%d,disk.radius=%g\n\n",
    disk.center[0]+(count_x+((real)0.5))*delta_x,disk.center[1]+(count_y)*delta_y,
    NO_triangles,disk.radius);
   real dw=disk_width>((real)0.0)?disk_width:disk.radius*((real)0.001);
   fprintf(fl,
    "cylinder\n"
    "%.15g,%.15g,%.15g\n"//one end
    "%.15g\n"//radius
    "c\n"//radius
    "%.15g,%.15g,%.15g\n",//another end
    disk.center[0]+(count_x-1)*delta_x-disk.normal[0]*dw/((real)2.0),disk.center[1]+count_y*delta_y-disk.normal[1]*dw/((real)2.0),disk.center[2]-disk.normal[2]*dw/((real)2.0),
    disk.radius,
    disk.center[0]+(count_x-1)*delta_x+disk.normal[0]*dw/((real)2.0),disk.center[1]+count_y*delta_y+disk.normal[1]*dw/((real)2.0),disk.center[2]+disk.normal[2]*dw/((real)2.0));

   for(i=0;i<NO_triangles;i++)
   {
    //draw triangle
    fprintf(fl,
     "line\n"
     "%.15g,%.15g,%.15g\n"
     "%.15g,%.15g,%.15g\n"
     "%.15g,%.15g,%.15g\n"
     "c\n",
     triangle[i][0][0]+(count_x-1)*delta_x,triangle[i][0][1]+count_y*delta_y,triangle[i][0][2],
     triangle[i][1][0]+(count_x-1)*delta_x,triangle[i][1][1]+count_y*delta_y,triangle[i][1][2],
     triangle[i][2][0]+(count_x-1)*delta_x,triangle[i][2][1]+count_y*delta_y,triangle[i][2][2]);
    //draw normal
    if(triangle_normal)
    {
     real tc[3]=
     {
      (triangle[i][0][0]+triangle[i][1][0]+triangle[i][2][0])/((real)3.0)+(count_x-1)*delta_x,
      (triangle[i][0][1]+triangle[i][1][1]+triangle[i][2][1])/((real)3.0)+count_y*delta_y,
      (triangle[i][0][2]+triangle[i][1][2]+triangle[i][2][2])/((real)3.0)
     };
     real tce[3];
     Combo(tce,tc,triangle_normal[i],normal_scale);;

     fprintf(fl,
     "line\n"
     "%.15g,%.15g,%.15g\n"
     "%.15g,%.15g,%.15g\n"
     "\n",
     tc[0],tc[1],tc[2],
     tce[0],tce[1],tce[2]);
    }
   }
   count++;
  }
  else if(fl)
  {
   fprintf(fl,"zoom\ne\n");
   fclose(fl);
   fl=0;
   count=0;
   save=0;
  }
 }
#endif//of #ifdef _DEBUG


 CTriangle *tr = (CTriangle *)_alloca(2*NO_triangles*sizeof(CTriangle));
 real *tr_weight=(real*)_alloca(2*NO_triangles*sizeof(real));
 real *tr_covered_angle=(real*)_alloca(2*NO_triangles*sizeof(real));

 for(i=0;i<NO_triangles;i++)
 {
  if(triangle_normal)
  {
   //check right-handedness
   real cp[3];
   real edge0[3],edge1[3];
   Subtract(edge0,triangle[i][1],triangle[i][0]);
   Subtract(edge1,triangle[i][2],triangle[i][1]);
   CrossProduct(cp,edge0,edge1);
   if(DotProduct(cp,triangle_normal[i])>0)
   {
    Copy(tr[i].point[0],triangle[i][0]);
    Copy(tr[i].point[1],triangle[i][1]);
    Copy(tr[i].point[2],triangle[i][2]);
    Copy(tr[NO_triangles+i].point[0],triangle[i][0]);
    Copy(tr[NO_triangles+i].point[1],triangle[i][1]);
    Copy(tr[NO_triangles+i].point[2],triangle[i][2]);
   }
   else
   {//swap order
    Copy(tr[i].point[0],triangle[i][1]);
    Copy(tr[i].point[1],triangle[i][0]);
    Copy(tr[i].point[2],triangle[i][2]);
    Copy(tr[NO_triangles+i].point[0],triangle[i][1]);
    Copy(tr[NO_triangles+i].point[1],triangle[i][0]);
    Copy(tr[NO_triangles+i].point[2],triangle[i][2]);
   }
   Copy(tr[i].normal,triangle_normal[i]);
   ASSERT("Normal must be normalized"&&IS_EQ(Magnitude(tr[i].normal),((real)1.0),((real)1e-6)));
  }
  else
  {//Compute the normal
   Copy(tr[i].point[0],triangle[i][0]);
   Copy(tr[i].point[1],triangle[i][1]);
   Copy(tr[i].point[2],triangle[i][2]);
   Copy(tr[NO_triangles+i].point[0],triangle[i][0]);
   Copy(tr[NO_triangles+i].point[1],triangle[i][1]);
   Copy(tr[NO_triangles+i].point[2],triangle[i][2]);
   real edge0[3],edge1[3];
   Subtract(edge0,triangle[i][1],triangle[i][0]);
   Subtract(edge1,triangle[i][2],triangle[i][1]);
   CrossProduct(tr[i].normal,edge0,edge1);
   ASSERT("Degenerate triangle"&&Magnitude(tr[i].normal)>((real)1e-6));
   Normalize(tr[i].normal,tr[i].normal);
  }
 }

 real transform[3][3];//={{1,0,0},{0,1,0},{0,0,1}};
 Copy(transform[2],disk.normal);
 ASSERT(IS_EQ(Magnitude(transform[2]),((real)1.0),((real)1e-6)));
 MakeOrthonormalBasis(transform[0],transform[1],transform[2]);
 ASSERT(IS_EQ(Magnitude(transform[0]),((real)1.0),((real)1e-6)));
 ASSERT(IS_EQ(Magnitude(transform[1]),((real)1.0),((real)1e-6)));

 real *dir_up=(real*)_alloca(3*sizeof(real));
 if(direction_up==0)
 {
  Zero(dir_up);
  real total_normal_weight=((real)0.0);
  for(i=0;i<NO_triangles;i++)
  {
   real cp[3];
   //real edge0[3],edge1[3];
   //Subtract(edge0,triangle[i][1],triangle[i][0]);
   //Subtract(edge1,triangle[i][2],triangle[i][1]);
   //CrossProduct(cp,edge0,edge1);
   Add(cp,triangle[i][0],triangle[i][1]);
   AddTo(cp,triangle[i][2]);
   SelfScale(cp,1/((real)3.0));

   //real normal_weight=Magnitude(cp);
   real normal_weight=DotProduct(cp,cp);
   AddScaledTo(dir_up,tr[i].normal,normal_weight);
   total_normal_weight+=normal_weight;
  }
  //SelfScale(dir_up,1/total_normal_weight);
  real tmp[3];
  ToBody(tmp,dir_up,transform);Copy(dir_up,tmp);
  Normalize(dir_up,dir_up);
  direction_up=dir_up;
 }
 else
 {
  ToBody(dir_up,direction_up,transform);
  direction_up=dir_up;
  ASSERT(IS_EQ(Magnitude(direction_up),((real)1.0),((real)1e-6)));
 }
 
 for(side=0;side<1+(disk_width>((real)0.0)?1:0);side++)
 for(i=0;i<NO_triangles;i++)
 {
  real excl_start[5];
  real excl_end[5];
  real weight[5];
  tr[side*NO_triangles+i].NO_incl=0;
  tr[side*NO_triangles+i].biggest_penetration=((real)0.0);

  //weight[i]=0.0;
  tr_covered_angle[side*NO_triangles+i]=((real)0.0);

  //convert triangles to the disk reference frame
  if(side==0)
  {
   SubtractFrom(tr[i].point[0],disk.center);
   SubtractFrom(tr[i].point[1],disk.center);
   SubtractFrom(tr[i].point[2],disk.center);
   real tmp[3];
   ASSERT(IS_EQ(Magnitude(tr[i].normal),((real)1.0),((real)1e-6)));
   ToBody(tmp,tr[i].normal, transform); Copy(tr[i].normal, tmp);
   ASSERT(IS_EQ(Magnitude(tr[i].normal),((real)1.0),((real)1e-6)));
   ToBody(tmp,tr[i].point[0],transform); Copy(tr[i].point[0],tmp);
   ToBody(tmp,tr[i].point[1],transform); Copy(tr[i].point[1],tmp);
   ToBody(tmp,tr[i].point[2],transform); Copy(tr[i].point[2],tmp);
  }
 
  if(disk_width>((real)0.0))
  {
   if(side==0)
   {
    tr[i].point[0][2]-=disk_width/((real)2.0);
    tr[i].point[1][2]-=disk_width/((real)2.0);
    tr[i].point[2][2]-=disk_width/((real)2.0);
   }
   else
   {
    tr[i].point[0][2]+=disk_width;
    tr[i].point[1][2]+=disk_width;
    tr[i].point[2][2]+=disk_width;
   }
  }

  tr[side*NO_triangles+i].offset=DotProduct(tr[i].normal,tr[i].point[0]);

  //find excl_start excl_end
  ComputePhiStartEnd(excl_start+3,excl_end+3,disk.radius,tr[i].normal,tr[side*NO_triangles+i].offset);
  real inclined_edge_normals[3][3];
  ComputeInclinedEdgeNormals(inclined_edge_normals,tr[i].point,direction_up);

  real offset=DotProduct(inclined_edge_normals[0],tr[i].point[0]);
  ComputePhiStartEnd(excl_start+0,excl_end+0,disk.radius,inclined_edge_normals[0],offset);
  offset=DotProduct(inclined_edge_normals[1],tr[i].point[1]);
  ComputePhiStartEnd(excl_start+1,excl_end+1,disk.radius,inclined_edge_normals[1],offset);
  offset=DotProduct(inclined_edge_normals[2],tr[i].point[0]);
  ComputePhiStartEnd(excl_start+2,excl_end+2,disk.radius,inclined_edge_normals[2],offset);

  //exclude upper part of disk WRT normal
  excl_start[4]=(real)atan2(-tr[i].normal[0],tr[i].normal[1]);
  excl_end[4]=(real)atan2(tr[i].normal[0],-tr[i].normal[1]);//improve
  real deriv[2]={-(real)sin(excl_start[4]),(real)cos(excl_start[4])};
  if(deriv[0]*tr[i].normal[0]+deriv[1]*tr[i].normal[1]<0)
  {
   //swap excl_start,excl_end
   real tmp=excl_start[4];
   excl_start[4]=excl_end[4];
   excl_end[4]=tmp;
  }

  for(k=0;k<5;k++)
  {
   if(excl_start[k]==((real)1.0)&&excl_end[k]==((real)1.0))
   {//all disk is excluded
    goto next_triangle;
   }
  }
  //now combine all excl_start's and excl_end's
  {//coalesce exclusion zones
   int merged=0;//,iter=0;
   do
   {
    merged=0;
    for(k=0;k<5;k++)
    {
     if(excl_start[k]==0&&excl_end[k]==0)
      continue;//exclusion zone is empty
     for(j=0;j<5;j++)
     {
      if(excl_start[j]==0&&excl_end[j]==0)
       continue;//exclusion zone is empty
      if(is_inside(excl_start[k],excl_start[j],excl_end[j]))
      {//merge these two zones
       {//check for the two zones to completely cover the circle
        if(is_inside(excl_start[j],excl_start[k],excl_end[k]))
        if(is_inside(excl_end[j],excl_start[k],excl_end[k]))
         goto next_triangle;
       }
       excl_start[k]=excl_start[j];
       if(is_inside(excl_end[k],excl_start[j],excl_end[j]))
        excl_end[k]=excl_end[j];
       //mark zone j empty
       excl_start[j]=0;
       excl_end[j]=0;
       merged=1;
      }
      else
      if(is_inside(excl_end[k],excl_start[j],excl_end[j]))
      {//merge these two zones
       excl_end[k]=excl_end[j];
       ASSERT(!is_inside(excl_start[k],excl_start[j],excl_end[j]));
        //excl_start[k]=excl_start[j];
       //mark zone j empty
       excl_start[j]=0;
       excl_end[j]=0;
       merged=1;
      }
     }
    }
    //iter++;
   }while(merged==1);
  }//coalesce exclusion zones

  goto skip;
  next_triangle:;
  continue;
  skip:;

#ifdef _DEBUG
  for(k=0;k<5;k++)
  if(excl_start[k]==1&&excl_end[k]==1)
  {//all disk is excluded
   ASSERT(0);
   //continue;//next triangle
  }
#endif//of #ifdef _DEBUG

  //find first start
  int found=0;
  for(k=0;k<5;k++)//loop trough exclusion zones
  {
   if(excl_start[k]==0&&excl_end[k]==0)
    continue;
   {
    tr[side*NO_triangles+i].incl_start[tr[side*NO_triangles+i].NO_incl]=excl_end[k];
    found=1;
   }
   break;
  }
  if(found==1)
  {
   for(k=0;k<5;k++)//can be 'while'
   {
    {
     int mindistindex=-1;
     real mindist=2*PI;
  
     for(j=0;j<5;j++)//loop trough exclusion zones
     {
      if(excl_start[j]==0&&excl_end[j]==0)
       continue;//exclusion zone is empty
      real dist=distance_CC(tr[side*NO_triangles+i].incl_start[tr[side*NO_triangles+i].NO_incl],excl_start[j]);
      if(dist<mindist)
      {
       mindist=dist;
       mindistindex=j;
      }
     }
     ASSERT(mindistindex!=-1);
     tr[side*NO_triangles+i].incl_end[tr[side*NO_triangles+i].NO_incl]=excl_start[mindistindex];
    }
    tr[side*NO_triangles+i].NO_incl++;

    //find start of the next inclusion zone
    int mindistindex=-1;
    real mindist=2*PI;
 
    for(j=0;j<5;j++)//loop trough exclusion zones
    {
     if(excl_start[j]==0&&excl_end[j]==0)
      continue;//exclusion zone is empty
     real dist=distance_CC(tr[side*NO_triangles+i].incl_end[tr[side*NO_triangles+i].NO_incl-1],excl_end[j]);
     if(dist<mindist)
     {
      mindist=dist;
      mindistindex=j;
     }
    }
    ASSERT(mindistindex!=-1);
    {
     if(excl_end[mindistindex]!=tr[side*NO_triangles+i].incl_start[0])
      tr[side*NO_triangles+i].incl_start[tr[side*NO_triangles+i].NO_incl]=excl_end[mindistindex];
     else
      break;
    }
   }
  }
#ifdef _DEBUG
  //now the number of inclusion zones should be equal to the number of exclusion zones.
  {
   int NO_excl=0;
   for(j=0;j<5;j++)
   {
    if(excl_start[j]==0&&excl_end[j]==0)
     continue;
    NO_excl++;
   }
   ASSERT(NO_excl==tr[side*NO_triangles+i].NO_incl);
  }
#endif//of #ifdef _DEBUG

  //now for every inclusion zone find average_point and weight

  tr_weight[side*NO_triangles+i]=((real)0.0);
  for(j=0;j<tr[side*NO_triangles+i].NO_incl;j++)
  {
   
   real biggest_penetration=0,penetration;
   biggest_penetration=-(disk.radius*(real)cos(tr[side*NO_triangles+i].incl_start[j])*tr[i].normal[0]
   +disk.radius*(real)sin(tr[side*NO_triangles+i].incl_start[j])*tr[i].normal[1]-tr[side*NO_triangles+i].offset);
   //insure that penetration is positive
   ASSERT(biggest_penetration>((real)-1e-6));
   
   penetration=-(disk.radius*(real)cos(tr[side*NO_triangles+i].incl_end[j])*tr[i].normal[0]
   +disk.radius*(real)sin(tr[side*NO_triangles+i].incl_end[j])*tr[i].normal[1]-tr[side*NO_triangles+i].offset);
   if(penetration>biggest_penetration)
    biggest_penetration=penetration;
   ASSERT(penetration>((real)-1e-6));

   real phi=(real)atan2(tr[i].normal[1],tr[i].normal[0]);
   if(is_inside(phi,tr[side*NO_triangles+i].incl_start[j],tr[side*NO_triangles+i].incl_end[j]))
   {
    penetration=-(disk.radius*(real)cos(phi)*tr[i].normal[0]
    +disk.radius*(real)sin(phi)*tr[i].normal[1]-tr[side*NO_triangles+i].offset);
    ASSERT(penetration>((real)-1e-6));
    if(penetration>biggest_penetration)
     biggest_penetration=penetration;
   }
   real phi2=phi>0?phi-PI:phi+PI;
   if(is_inside(phi2,tr[side*NO_triangles+i].incl_start[j],tr[side*NO_triangles+i].incl_end[j]))
   {
    penetration=-(disk.radius*(real)cos(phi2)*tr[i].normal[0]
    +disk.radius*(real)sin(phi2)*tr[i].normal[1]-tr[side*NO_triangles+i].offset);
    ASSERT(penetration>((real)-1e-6));
    if(penetration>biggest_penetration)
     biggest_penetration=penetration;
   }
   if(biggest_penetration>tr[side*NO_triangles+i].biggest_penetration)
    tr[side*NO_triangles+i].biggest_penetration=biggest_penetration;

   //make end always bigger than start
   if(tr[side*NO_triangles+i].incl_start[j]>tr[side*NO_triangles+i].incl_end[j])
    tr[side*NO_triangles+i].incl_end[j]+=2*PI;

   tr_covered_angle[side*NO_triangles+i]+=tr[side*NO_triangles+i].incl_end[j]-tr[side*NO_triangles+i].incl_start[j];

   //weight is integral(penetration,Dphi);
   //was +(...
   weight[j]=-((-tr[side*NO_triangles+i].incl_end[j]+tr[side*NO_triangles+i].incl_start[j])*tr[side*NO_triangles+i].offset
    +(((real)cos(tr[side*NO_triangles+i].incl_start[j])-(real)cos(tr[side*NO_triangles+i].incl_end[j]))*tr[i].normal[1]
    +((real)sin(tr[side*NO_triangles+i].incl_end[j])-(real)sin(tr[side*NO_triangles+i].incl_start[j]))*tr[i].normal[0])*disk.radius);

   real cosstart=(real)cos(tr[side*NO_triangles+i].incl_start[j]);
   real cosend=(real)cos(tr[side*NO_triangles+i].incl_end[j]);
   real diff_sq=-cosstart*cosstart+cosend*cosend;
   real denom=1/weight[j]*disk.radius/((real)2.0);//was -1/...
   real a=((real)2.0)*tr[side*NO_triangles+i].offset;
   real cov_ang=-tr[side*NO_triangles+i].incl_end[j]+tr[side*NO_triangles+i].incl_start[j];
   real sinstart=(real)sin(tr[side*NO_triangles+i].incl_start[j]);
   real sinend=(real)sin(tr[side*NO_triangles+i].incl_end[j]);
   real diffendstart=cosend*sinend-cosstart*sinstart;
   real ap[3];
   ap[0]=((sinend-sinstart)*a+(diff_sq*tr[i].normal[1]+(-diffendstart+cov_ang)*tr[i].normal[0])*disk.radius)*denom;
   ap[1]=((-cosend+cosstart)*a+(diff_sq*tr[i].normal[0]+(diffendstart+cov_ang)*tr[i].normal[1])*disk.radius)*denom;
   ap[2]=((real)0.0);
   AddScaledTo(point,ap,weight[j]);
   //AddScaledTo(point,ap,tr[side*NO_triangles+i].incl_end[j]-tr[side*NO_triangles+i].incl_start[j]);
   tr_weight[side*NO_triangles+i]+=weight[j];
  }
  if(tr_covered_angle[side*NO_triangles+i]==((real)0.0))
  {
   ASSERT(tr_weight[side*NO_triangles+i]==((real)0.0));
   continue;
  }

  //AddScaledTo(normal,tr[i].normal,tr_weight[i]);
  AddScaledTo(normal,tr[i].normal,tr_covered_angle[side*NO_triangles+i]);

  total_weight+=tr_weight[side*NO_triangles+i];
  //real pen=tr[side*NO_triangles+i].biggest_penetration;//*DotProduct(tr[i].normal,normal);
  total_covered_angle+=tr_covered_angle[side*NO_triangles+i];
 }
 
 if(total_covered_angle==((real)0.0))
  return 0;
 ASSERT(total_covered_angle>((real)0.0));
 
 SelfScale(point,1/total_weight);
 //move point to disk
 real angle=(real)atan2(point[1],point[0]);
 point[0]=(real)cos(angle)*disk.radius;
 point[1]=(real)sin(angle)*disk.radius;
 //Adjust normal to cross the axle line.
 real dpn=(normal[0]*point[0]+normal[1]*point[1])/(disk.radius*disk.radius);
 normal[0]=point[0]*dpn;
 normal[1]=point[1]*dpn;
 Normalize(normal,normal);

 //now find penetration
 int side_index,iindex;
#ifdef _DEBUG
 side_index=-1;
 iindex=-1;
#endif//of #ifdef _DEBUG
 real max_penetration=((real)0.0);
 for(side=0;side<1+(disk_width>((real)0.0)?1:0);side++)
 for(i=0;i<NO_triangles;i++)
 {
  real pen=tr[side*NO_triangles+i].biggest_penetration*DotProduct(tr[i].normal,normal);
  if(pen>max_penetration)
  {
   max_penetration=pen;
   side_index=side;
   iindex=i;
  }
  //*penetration+=pen*tr_covered_angle[side*NO_triangles+i];
  //*penetration+=pen*tr_weight[side*NO_triangles+i];
 }
 //*penetration/=total_covered_angle;//*DotProduct(tr[iindex].normal,normal);
 //*penetration/=total_weight*DotProduct(tr[iindex].normal,normal);
 //*penetration=tr[side_index*NO_triangles+iindex].biggest_penetration/DotProduct(tr[iindex].normal,normal);
 //*penetration=max_penetration/DotProduct(tr[iindex].normal,normal);
 *penetration=max_penetration;

#ifdef _DEBUG
 {
  ASSERT(side_index!=-1);
  ASSERT(iindex!=-1);
#ifdef FC_SINGLE
  ASSERT(DotProduct(tr[iindex].normal,normal)<=((real)1.001));
  ASSERT(DotProduct(tr[iindex].normal,normal)>((real)-1e-3));
#else//of #ifdef FC_SINGLE
  ASSERT(DotProduct(tr[iindex].normal,normal)<=((real)1.000001));
  ASSERT(DotProduct(tr[iindex].normal,normal)>((real)-1e-6));
#endif//of #ifdef FC_SINGLE
  real mag=Magnitude(tr[iindex].normal);
  real mag1=Magnitude(normal);
  real mag2=Magnitude(normal);
 }
#endif//of #ifdef _DEBUG

 //convert back to world
 real tmp[3];
 ToWorld(tmp,normal,transform);Copy(normal,tmp);

 ToWorld(tmp,point,transform);
 Add(point,tmp,disk.center);
 ASSERT(IS_EQ(Magnitude(normal),((real)1.0),((real)1e-6)));
#ifdef _DEBUG
 {
  real r[3];
  real rxa[3];
  Subtract(r,point,disk.center);
  CrossProduct(rxa,r,disk.normal);
  Normalize(rxa,rxa);
  real dp=DotProduct(rxa,normal);              
  ASSERT("normal is not crossing the axle line" && IS_EQ(dp,0,((real)0.01)));
  static int again=0;
  if(again)
  {
   TerrainWheelCollisionDetection
   (
    normal,point,penetration,
    triangle,
    triangle_normal,
    NO_triangles,
    disk,
    disk_width,
    direction_up
   );
  }
 }
#endif//of #ifdef _DEBUG
 return 1;
}

FC_DLL_EXPORT
int BoxSphereCollisionDetection(real normal[3],real point[3],real& penetration,const CBox& box,const CSphere& sphere)
{
 real c[3];//sphere center in box RF
 real tmp[3];
 Subtract(tmp,sphere.center,box.center);
 ToBody(c,tmp,box.axis);
 if(c[0]>box.extent[0])
 {
  if(c[1]>box.extent[1])
  {
   if(c[2]>box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     box.extent[0]-c[0],
     box.extent[1]-c[1],
     box.extent[2]-c[2]
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]+box.axis[1][0]*box.extent[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]+box.axis[1][1]*box.extent[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]+box.axis[1][2]*box.extent[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     box.extent[0]-c[0],
     box.extent[1]-c[1],
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]<=-box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]+box.axis[1][0]*box.extent[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]+box.axis[1][1]*box.extent[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]+box.axis[1][2]*box.extent[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-edge
    real d[3]=
    {
     box.extent[0]-c[0],
     box.extent[1]-c[1],
     0
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]+box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]+box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]+box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
  else if(c[1]<-box.extent[1])
  {
   if(c[2]>box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     box.extent[0]-c[0],
     -box.extent[1]-c[1],
     box.extent[2]-c[2]
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]<=-box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]-box.axis[1][0]*box.extent[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]-box.axis[1][1]*box.extent[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]-box.axis[1][2]*box.extent[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     box.extent[0]-c[0],
     -box.extent[1]-c[1],
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]<=-box.extent[1]);
    ASSERT(c[2]<=-box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]-box.axis[1][0]*box.extent[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]-box.axis[1][1]*box.extent[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]-box.axis[1][2]*box.extent[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-edge
    real d[3]=
    {
     box.extent[0]-c[0],
     -box.extent[1]-c[1],
     0
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]<=-box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]-box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]-box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]-box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
  else
  {
   if(c[2]>box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     box.extent[0]-c[0],
     0,
     box.extent[2]-c[2]
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[2]*d[2]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     box.extent[0]-c[0],
     0,
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]<=-box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[2]*d[2]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-face
    real d[3]=
    {
     box.extent[0]-c[0],
     0,
     0
    };
    ASSERT(c[0]>box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=-d[0];//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
 }
 else if(c[0]<-box.extent[0])
 {
  if(c[1]>box.extent[1])
  {
   if(c[2]>box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     -box.extent[0]-c[0],
     box.extent[1]-c[1],
     box.extent[2]-c[2]
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]+box.axis[1][0]*box.extent[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]+box.axis[1][1]*box.extent[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]+box.axis[1][2]*box.extent[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     -box.extent[0]-c[0],
     box.extent[1]-c[1],
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]<=-box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]+box.axis[1][0]*box.extent[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]+box.axis[1][1]*box.extent[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]+box.axis[1][2]*box.extent[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-edge
    real d[3]=
    {
     -box.extent[0]-c[0],
     box.extent[1]-c[1],
     0
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]+box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]+box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]+box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
  else if(c[1]<=-box.extent[1])
  {
   if(c[2]>box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     -box.extent[0]-c[0],
     -box.extent[1]-c[1],
     box.extent[2]-c[2]
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]<=-box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]-box.axis[1][0]*box.extent[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]-box.axis[1][1]*box.extent[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]-box.axis[1][2]*box.extent[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-vertex
    real d[3]=
    {
     -box.extent[0]-c[0],
     -box.extent[1]-c[1],
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]<=-box.extent[1]);
    ASSERT(c[2]<=-box.extent[2]);
    real dist=Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]-box.axis[1][0]*box.extent[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]-box.axis[1][1]*box.extent[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]-box.axis[1][2]*box.extent[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-edge
    real d[3]=
    {
     -box.extent[0]-c[0],
     -box.extent[1]-c[1],
     0
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]<=-box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]-box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]-box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]-box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
  else
  {
   if(c[2]>box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     -box.extent[0]-c[0],
     0,
     box.extent[2]-c[2]
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[2]*d[2]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     -box.extent[0]-c[0],
     0,
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]<=-box.extent[2]);
    real dist=(real)sqrt(d[0]*d[0]+d[2]*d[2]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-face
    real d[3]=
    {
     -box.extent[0]-c[0],
     0,
     0
    };
    ASSERT(c[0]<=-box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=d[0];//Magnitude(d);
    ASSERT(dist>=0);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]-box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]-box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]-box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
 }
 else
 {
  if(c[1]>box.extent[1])
  {
   if(c[2]>box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     0,
     box.extent[1]-c[1],
     box.extent[2]-c[2]
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=(real)sqrt(d[2]*d[2]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]+box.axis[1][0]*box.extent[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+box.axis[1][1]*box.extent[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+box.axis[1][2]*box.extent[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     0,
     box.extent[1]-c[1],
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]<-box.extent[2]);
    real dist=(real)sqrt(d[2]*d[2]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]+box.axis[1][0]*box.extent[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+box.axis[1][1]*box.extent[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+box.axis[1][2]*box.extent[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-face
    real d[3]=
    {
     0,
     box.extent[1]-c[1],
     0
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]>box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=-d[1];//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]+box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
  else if(c[1]<-box.extent[1])
  {
   if(c[2]>box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     0,
     -box.extent[1]-c[1],
     box.extent[2]-c[2]
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]<-box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=(real)sqrt(d[2]*d[2]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]-box.axis[1][0]*box.extent[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]-box.axis[1][1]*box.extent[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]-box.axis[1][2]*box.extent[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-edge
    real d[3]=
    {
     0,
     -box.extent[1]-c[1],
     -box.extent[2]-c[2]
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]<-box.extent[1]);
    ASSERT(c[2]<-box.extent[2]);
    real dist=(real)sqrt(d[2]*d[2]+d[1]*d[1]);//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]-box.axis[1][0]*box.extent[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]-box.axis[1][1]*box.extent[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]-box.axis[1][2]*box.extent[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere-face
    real d[3]=
    {
     0,
     -box.extent[1]-c[1],
     0
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]<-box.extent[1]);
    ASSERT(c[2]>=-box.extent[2]&&c[2]<=box.extent[2]);
    real dist=d[1];//Magnitude(d);
    ASSERT(dist>=0);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]-box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]-box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]-box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
  }
  else
  {
   if(c[2]>box.extent[2])
   {//sphere-face
    real d[3]=
    {
     0,
     0,
     box.extent[2]-c[2],
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]>box.extent[2]);
    real dist=-d[2];//Magnitude(d);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]+box.axis[1][0]*c[1]+box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+box.axis[1][1]*c[1]+box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+box.axis[1][2]*c[1]+box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else if(c[2]<-box.extent[2])
   {//sphere-face
    real d[3]=
    {
     0,
     0,
     -box.extent[2]-c[2],
    };
    ASSERT(c[0]>=-box.extent[0]&&c[0]<=box.extent[0]);
    ASSERT(c[1]>=-box.extent[1]&&c[1]<=box.extent[1]);
    ASSERT(c[2]<-box.extent[2]);
    real dist=d[2];//Magnitude(d);
    ASSERT(dist>=0);
    if(dist>sphere.radius)
     return 0;
    else
    {
     penetration=sphere.radius-dist;
     Normalize(tmp,d);
     ToWorld(normal,tmp,box.axis);
     point[0]=box.center[0]+box.axis[0][0]*c[0]+box.axis[1][0]*c[1]-box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+box.axis[1][1]*c[1]-box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+box.axis[1][2]*c[1]-box.axis[2][2]*box.extent[2];
     ASSERT(penetration >=((real)0.0)); return 1;
    }
   }
   else
   {//sphere is inside: face
    real d[3]=
    {
     box.extent[0]-(real)fabs(c[0])+sphere.radius,
     box.extent[1]-(real)fabs(c[1])+sphere.radius,
     box.extent[2]-(real)fabs(c[2])+sphere.radius,
    };
    if(d[0]<d[1]&&d[0]<d[2])
    {
     normal[0]=box.axis[0][0]*(c[0]>((real)0.0)?-1:1);
     normal[1]=box.axis[0][1]*(c[0]>((real)0.0)?-1:1);
     normal[2]=box.axis[0][2]*(c[0]>((real)0.0)?-1:1);
     penetration=d[0];
     point[0]=box.center[0]+(c[0]>((real)0.0)?1:-1)*box.axis[0][0]*box.extent[0]+box.axis[1][0]*c[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+(c[0]>((real)0.0)?1:-1)*box.axis[0][1]*box.extent[0]+box.axis[1][1]*c[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+(c[0]>((real)0.0)?1:-1)*box.axis[0][2]*box.extent[0]+box.axis[1][2]*c[1]+box.axis[2][2]*c[2];
    }
    else
    if(d[1]<d[0]&&d[1]<d[2])
    {
     normal[0]=box.axis[1][0]*(c[1]>((real)0.0)?-1:1);
     normal[1]=box.axis[1][1]*(c[1]>((real)0.0)?-1:1);
     normal[2]=box.axis[1][2]*(c[1]>((real)0.0)?-1:1);
     penetration=d[1];
     point[0]=box.center[0]+box.axis[0][0]*c[0]+(c[1]>((real)0.0)?1:-1)*box.axis[1][0]*box.extent[1]+box.axis[2][0]*c[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+(c[1]>((real)0.0)?1:-1)*box.axis[1][1]*box.extent[1]+box.axis[2][1]*c[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+(c[1]>((real)0.0)?1:-1)*box.axis[1][2]*box.extent[1]+box.axis[2][2]*c[2];
    }
    else
    {
     normal[0]=box.axis[2][0]*(c[2]>((real)0.0)?-1:1);
     normal[1]=box.axis[2][1]*(c[2]>((real)0.0)?-1:1);
     normal[2]=box.axis[2][2]*(c[2]>((real)0.0)?-1:1);
     penetration=d[2];
     point[0]=box.center[0]+box.axis[0][0]*c[0]+box.axis[1][0]*c[1]+(c[2]>((real)0.0)?1:-1)*box.axis[2][0]*box.extent[2];
     point[1]=box.center[1]+box.axis[0][1]*c[0]+box.axis[1][1]*c[1]+(c[2]>((real)0.0)?1:-1)*box.axis[2][1]*box.extent[2];
     point[2]=box.center[2]+box.axis[0][2]*c[0]+box.axis[1][2]*c[1]+(c[2]>((real)0.0)?1:-1)*box.axis[2][2]*box.extent[2];
    }
    ASSERT(penetration >=((real)0.0)); return 1;
   }
  }
 }
}

/********************************************************/
/* AABB-triangle overlap test code                      */
/* by Tomas M�ller                                      */
/* Function: int triBoxOverlap(real boxcenter[3],     */
/*          real boxhalfsize[3],real vertex[3][3]);     */
/* History:                                             */
/*   2001-03-05: released the code in its first version */
/*                                                      */
/* Acknowledgement: Many thanks to Pierre Terdiman for  */
/* suggestions and discussions on how to optimize code. */
/********************************************************/

#define FINDMINMAX(x0,x1,x2,min,max)\
 min=max=x0;\
 if(x1<min) min=x1;\
 if(x1>max) max=x1;\
 if(x2<min) min=x2;\
 if(x2>max) max=x2;

int PlaneAABoxIntersectionTest(const real normal[3],real d,const real maxbox[3])
{
 int q;
 real vmin[3],vmax[3];
 for(q=0;q<=2;q++)
 {
  if(normal[q]>0.0f)
  {
   vmin[q]=-maxbox[q];
   vmax[q]=maxbox[q];
  }
  else
  {
   vmin[q]=maxbox[q];
   vmax[q]=-maxbox[q];
  }
 }
 if(DotProduct(normal,vmin)+d>0.0f) return 0;
 if(DotProduct(normal,vmax)+d>0.0f) return 1;
 return 0;
}

/*======================== X-tests ========================*/
#define AXISTEST_X01(a,b,fa,fb)\
 p0=a*v0[1]-b*v0[2];\
 p2=a*v2[1]-b*v2[2];\
 if(p0<p2) {min=p0; max=p2;} else {min=p2; max=p0;}\
 rad=fa*boxhalfsize[1]+fb*boxhalfsize[2];\
 if(min>rad || max<-rad) return 0;

#define AXISTEST_X2(a,b,fa,fb)\
 p0=a*v0[1]-b*v0[2];\
 p1=a*v1[1]-b*v1[2];\
 if(p0<p1) {min=p0; max=p1;} else {min=p1; max=p0;}\
 rad=fa*boxhalfsize[1]+fb*boxhalfsize[2];\
 if(min>rad || max<-rad) return 0;

/*======================== Y-tests ========================*/
#define AXISTEST_Y02(a,b,fa,fb)\
 p0=-a*v0[0]+b*v0[2];\
 p2=-a*v2[0]+b*v2[2];\
 if(p0<p2) {min=p0; max=p2;} else {min=p2; max=p0;}\
 rad=fa*boxhalfsize[0]+fb*boxhalfsize[2];\
 if(min>rad || max<-rad) return 0;

#define AXISTEST_Y1(a,b,fa,fb)\
 p0=-a*v0[0]+b*v0[2];\
 p1=-a*v1[0]+b*v1[2];\
 if(p0<p1) {min=p0; max=p1;} else {min=p1; max=p0;}\
 rad=fa*boxhalfsize[0]+fb*boxhalfsize[2];\
 if(min>rad || max<-rad) return 0;

/*======================== Z-tests ========================*/

#define AXISTEST_Z12(a,b,fa,fb)\
 p1=a*v1[0]-b*v1[1];\
 p2=a*v2[0]-b*v2[1];\
 if(p2<p1) {min=p2; max=p1;} else {min=p1; max=p2;}\
 rad=fa*boxhalfsize[0]+fb*boxhalfsize[1];\
 if(min>rad || max<-rad) return 0;

#define AXISTEST_Z0(a,b,fa,fb)\
 p0=a*v0[0]-b*v0[1];\
 p1=a*v1[0]-b*v1[1];\
 if(p0<p1) {min=p0; max=p1;} else {min=p1; max=p0;}\
 rad=fa*boxhalfsize[0]+fb*boxhalfsize[1];\
 if(min>rad || max<-rad) return 0;

FC_DLL_EXPORT
int TriangleAABoxIntersectionTest(const real boxcenter[3],const real boxhalfsize[3],const real vertex0[3],const real vertex1[3],const real vertex2[3])
{
 /*    use separating axis theorem to test overlap between triangle and box */
 /*    need to test for overlap in these directions: */
 /*    1) the {x,y,z}-directions (actually,since we use the AABB of the triangle */
 /*       we do not even need to test these) */
 /*    2) normal of the triangle */
 /*    3) crossproduct(edge from tri,{x,y,z}-directin) */
 /*       this gives 3x3=9 more tests */
 real v0[3],v1[3],v2[3];
 real min,max,d,p0,p1,p2,rad,fex,fey,fez;  
 real normal[3],e0[3],e1[3],e2[3];
 
 /* 1) first test overlap in the {x,y,z}-directions */
 /*    find min,max of the triangle each direction,and test for overlap in */
 /*    that direction -- this is equivalent to testing a minimal AABB around */
 /*    the triangle against the AABB */
#if 1
 /* This is the fastest branch on Sun */
 /* move everything so that the boxcenter is in (0,0,0) */
 Subtract(v0,vertex0,boxcenter);
 Subtract(v1,vertex1,boxcenter);
 Subtract(v2,vertex2,boxcenter);
 
 /* test in X-direction */
 FINDMINMAX(v0[0],v1[0],v2[0],min,max);
 if(min>boxhalfsize[0] || max<-boxhalfsize[0]) return 0;
 
 /* test in Y-direction */
 FINDMINMAX(v0[1],v1[1],v2[1],min,max);
 if(min>boxhalfsize[1] || max<-boxhalfsize[1]) return 0;
 
 /* test in Z-direction */
 FINDMINMAX(v0[2],v1[2],v2[2],min,max);
 if(min>boxhalfsize[2] || max<-boxhalfsize[2]) return 0;
#else
 /*    another implementation */
 /*    test in X */
 v0[0]=vertex[0][0]-boxcenter[0];
 v1[0]=vertex[1][0]-boxcenter[0];
 v2[0]=vertex[2][0]-boxcenter[0];
 FINDMINMAX(v0[0],v1[0],v2[0],min,max);
 if(min>boxhalfsize[0] || max<-boxhalfsize[0]) return 0;
 
 /*    test in Y */
 v0[1]=vertex[0][1]-boxcenter[1];
 v1[1]=vertex[1][1]-boxcenter[1];
 v2[1]=vertex[2][1]-boxcenter[1];
 FINDMINMAX(v0[1],v1[1],v2[1],min,max);
 if(min>boxhalfsize[1] || max<-boxhalfsize[1]) return 0;
 
 /*    test in Z */
 v0[2]=vertex[0][2]-boxcenter[2];
 v1[2]=vertex[1][2]-boxcenter[2];
 v2[2]=vertex[2][2]-boxcenter[2];
 FINDMINMAX(v0[2],v1[2],v2[2],min,max);
 if(min>boxhalfsize[2] || max<-boxhalfsize[2]) return 0;
#endif
 
 /*    2) */
 /*    test if the box intersects the plane of the triangle */
 /*    compute plane equation of triangle: normal*x+d=0 */
 Subtract(e0,v1,v0);      /* tri edge 0 */
 Subtract(e1,v2,v1);      /* tri edge 1 */
 CrossProduct(normal,e0,e1);
 d=-DotProduct(normal,v0);  /* plane eq: normal.x+d=0 */
 
 if(!PlaneAABoxIntersectionTest(normal,d,boxhalfsize)) return 0;
 
 /*    compute the last triangle edge */
 Subtract(e2,v0,v2);
 
 /*    3) */
 fex=(real)fabs(e0[0]);
 fey=(real)fabs(e0[1]);
 fez=(real)fabs(e0[2]);
 AXISTEST_X01(e0[2],e0[1],fez,fey);
 AXISTEST_Y02(e0[2],e0[0],fez,fex);
 AXISTEST_Z12(e0[1],e0[0],fey,fex);
 
 fex=(real)fabs(e1[0]);
 fey=(real)fabs(e1[1]);
 fez=(real)fabs(e1[2]);
 AXISTEST_X01(e1[2],e1[1],fez,fey);
 AXISTEST_Y02(e1[2],e1[0],fez,fex);
 AXISTEST_Z0(e1[1],e1[0],fey,fex);
 
 fex=(real)fabs(e2[0]);
 fey=(real)fabs(e2[1]);
 fez=(real)fabs(e2[2]);
 AXISTEST_X2(e2[2],e2[1],fez,fey);
 AXISTEST_Y1(e2[2],e2[0],fez,fex);
 AXISTEST_Z12(e2[1],e2[0],fey,fex);
 
 return 1;
}

#define FABS(x) (real((real)fabs(x)))        /* implement as is fastest on your machine */

/* if USE_EPSILON_TEST is true then we do a check:
if |dv|<EPSILON then dv=0.0;
else no check is done (which is less robust)
*/
#define USE_EPSILON_TEST TRUE
#define EPSILON ((real)0.000001)



/* sort so that a<=b */
#define SORT(a,b)\
{\
 if(a>b)\
 {\
  real c;\
  c=a;\
  a=b;\
  b=c;\
 }\
}

/* this edge to edge test is based on Franlin Antonio's gem:
"Faster Line Segment Intersection",in Graphics Gems III,
pp. 199-202 */
#define EDGE_EDGE_TEST(V0,U0,U1)\
{\
 Bx=U0[i0]-U1[i0];\
 By=U0[i1]-U1[i1];\
 Cx=V0[i0]-U0[i0];\
 Cy=V0[i1]-U0[i1];\
 f=Ay*Bx-Ax*By;\
 d=By*Cx-Bx*Cy;\
 if((f>0&&d>=0&&d<=f)||(f<0&&d<=0&&d>=f))\
 {\
  e=Ax*Cy-Ay*Cx;\
  if(f>0)\
  {\
   if(e>=0 && e<=f) return 1;\
  }\
  else \
  {\
   if(e<=0 && e>=f) return 1;\
  }\
 }\
}

#define EDGE_AGAINST_TRI_EDGES(V0,V1,U0,U1,U2)\
{\
 real Ax,Ay,Bx,By,Cx,Cy,e,d,f;\
 Ax=V1[i0]-V0[i0];\
 Ay=V1[i1]-V0[i1];\
 /* test edge U0,U1 against V0,V1 */\
 EDGE_EDGE_TEST(V0,U0,U1);\
 /* test edge U1,U2 against V0,V1 */\
 EDGE_EDGE_TEST(V0,U1,U2);\
 /* test edge U2,U1 against V0,V1 */\
 EDGE_EDGE_TEST(V0,U2,U0);\
}

#define POINT_IN_TRI(V0,U0,U1,U2)\
{\
 real a,b,c,d0,d1,d2;\
 /* is T1 completly inside T2? */\
 /* check if V0 is inside tri(U0,U1,U2) */\
 a=U1[i1]-U0[i1];\
 b=-(U1[i0]-U0[i0]);\
 c=-a*U0[i0]-b*U0[i1];\
 d0=a*V0[i0]+b*V0[i1]+c;\
\
 a=U2[i1]-U1[i1];\
 b=-(U2[i0]-U1[i0]);\
 c=-a*U1[i0]-b*U1[i1];\
 d1=a*V0[i0]+b*V0[i1]+c;\
\
 a=U0[i1]-U2[i1];\
 b=-(U0[i0]-U2[i0]);\
 c=-a*U2[i0]-b*U2[i1];\
 d2=a*V0[i0]+b*V0[i1]+c;\
 if(d0*d1>((real)0.0))\
 {\
  if(d0*d2>((real)0.0)) return 1;\
 }\
}

int coplanar_tri_tri(const real N[3],const real V0[3],const real V1[3],const real V2[3],
                     const real U0[3],const real U1[3],const real U2[3])
{
 real A[3];
 short i0,i1;
 /* first project onto an axis-aligned plane,that maximizes the area */
 /* of the triangles,compute indices: i0,i1. */
 A[0]=FABS(N[0]);
 A[1]=FABS(N[1]);
 A[2]=FABS(N[2]);
 if(A[0]>A[1])
 {
  if(A[0]>A[2])
  {
   i0=1;      /* A[0] is greatest */
   i1=2;
  }
  else
  {
   i0=0;      /* A[2] is greatest */
   i1=1;
  }
 }
 else   /* A[0]<=A[1] */
 {
  if(A[2]>A[1])
  {
   i0=0;      /* A[2] is greatest */
   i1=1;
  }
  else
  {
   i0=0;      /* A[1] is greatest */
   i1=2;
  }
 }
 
 /* test all edges of triangle 1 against the edges of triangle 2 */
 EDGE_AGAINST_TRI_EDGES(V0,V1,U0,U1,U2);
 EDGE_AGAINST_TRI_EDGES(V1,V2,U0,U1,U2);
 EDGE_AGAINST_TRI_EDGES(V2,V0,U0,U1,U2);
 
 /* finally,test if tri1 is totally contained in tri2 or vice versa */
 POINT_IN_TRI(V0,U0,U1,U2);
 POINT_IN_TRI(U0,V0,V1,V2);
 
 return 0;
}



#define NEWCOMPUTE_INTERVALS(VV0,VV1,VV2,D0,D1,D2,D0D1,D0D2,A,B,C,X0,X1)\
{\
 if(D0D1>0.0f)\
 {\
  /* here we know that D0D2<=0.0 */\
  /* that is D0,D1 are on the same side,D2 on the other or on the plane */\
  A=VV2; B=(VV0-VV2)*D2; C=(VV1-VV2)*D2; X0=D2-D0; X1=D2-D1;\
 }\
 else if(D0D2>0.0f)\
 {\
  /* here we know that d0d1<=0.0 */\
  A=VV1; B=(VV0-VV1)*D1; C=(VV2-VV1)*D1; X0=D1-D0; X1=D1-D2;\
 }\
 else if(D1*D2>0.0f || D0!=0.0f)\
 {\
  /* here we know that d0d1<=0.0 or that D0!=0.0 */\
  A=VV0; B=(VV1-VV0)*D0; C=(VV2-VV0)*D0; X0=D0-D1; X1=D0-D2;\
 }\
 else if(D1!=0.0f)\
 {\
  A=VV1; B=(VV0-VV1)*D1; C=(VV2-VV1)*D1; X0=D1-D0; X1=D1-D2;\
 }\
 else if(D2!=0.0f)\
 {\
  A=VV2; B=(VV0-VV2)*D2; C=(VV1-VV2)*D2; X0=D2-D0; X1=D2-D1;\
 }\
 else \
 {\
  /* triangles are coplanar */\
  return coplanar_tri_tri(N1,V0,V1,V2,U0,U1,U2);\
 }\
}

FC_DLL_EXPORT
int TriangleTriangleIntersectionTest(const real V0[3],const real V1[3],const real V2[3],
                                     const real U0[3],const real U1[3],const real U2[3])
{
 real E1[3],E2[3];
 real N1[3],N2[3],d1,d2;
 real du0,du1,du2,dv0,dv1,dv2;
 real D[3];
 real isect1[2],isect2[2];
 real du0du1,du0du2,dv0dv1,dv0dv2;
 short index;
 real vp0,vp1,vp2;
 real up0,up1,up2;
 real bb,cc,max;
 
 /* compute plane equation of triangle(V0,V1,V2) */
 Subtract(E1,V1,V0);
 Subtract(E2,V2,V0);
 CrossProduct(N1,E1,E2);
 d1=-DotProduct(N1,V0);
 /* plane equation 1: N1.X+d1=0 */
 
 /* put U0,U1,U2 into plane equation 1 to compute signed distances to the plane*/
 du0=DotProduct(N1,U0)+d1;
 du1=DotProduct(N1,U1)+d1;
 du2=DotProduct(N1,U2)+d1;
 
 /* coplanarity robustness check */
#if USE_EPSILON_TEST==TRUE
 if(FABS(du0)<EPSILON) du0=((real)0.0);
 if(FABS(du1)<EPSILON) du1=((real)0.0);
 if(FABS(du2)<EPSILON) du2=((real)0.0);
#endif
 du0du1=du0*du1;
 du0du2=du0*du2;
 
 if(du0du1>0.0f && du0du2>0.0f) /* same sign on all of them + not equal 0 ? */
  return 0;                    /* no intersection occurs */
 
 /* compute plane of triangle (U0,U1,U2) */
 Subtract(E1,U1,U0);
 Subtract(E2,U2,U0);
 CrossProduct(N2,E1,E2);
 d2=-DotProduct(N2,U0);
 /* plane equation 2: N2.X+d2=0 */
 
 /* put V0,V1,V2 into plane equation 2 */
 dv0=DotProduct(N2,V0)+d2;
 dv1=DotProduct(N2,V1)+d2;
 dv2=DotProduct(N2,V2)+d2;
 
#if USE_EPSILON_TEST==TRUE
 if(FABS(dv0)<EPSILON) dv0=((real)0.0);
 if(FABS(dv1)<EPSILON) dv1=((real)0.0);
 if(FABS(dv2)<EPSILON) dv2=((real)0.0);
#endif
 
 dv0dv1=dv0*dv1;
 dv0dv2=dv0*dv2;
 
 if(dv0dv1>0.0f && dv0dv2>0.0f) /* same sign on all of them + not equal 0 ? */
  return 0;                    /* no intersection occurs */
 
 /* compute direction of intersection line */
 CrossProduct(D,N1,N2);
 
 /* compute and index to the largest component of D */
 max=(real)FABS(D[0]);
 index=0;
 bb=(real)FABS(D[1]);
 cc=(real)FABS(D[2]);
 if(bb>max) max=bb,index=1;
 if(cc>max) max=cc,index=2;
 
 /* this is the simplified projection onto L*/
 vp0=V0[index];
 vp1=V1[index];
 vp2=V2[index];
 
 up0=U0[index];
 up1=U1[index];
 up2=U2[index];
 
 /* compute interval for triangle 1 */
 real a,b,c,x0,x1;
 NEWCOMPUTE_INTERVALS(vp0,vp1,vp2,dv0,dv1,dv2,dv0dv1,dv0dv2,a,b,c,x0,x1);
 
 /* compute interval for triangle 2 */
 real d,e,f,y0,y1;
 NEWCOMPUTE_INTERVALS(up0,up1,up2,du0,du1,du2,du0du1,du0du2,d,e,f,y0,y1);
 
 real xx,yy,xxyy,tmp;
 xx=x0*x1;
 yy=y0*y1;
 xxyy=xx*yy;
 
 tmp=a*xxyy;
 isect1[0]=tmp+b*x1*yy;
 isect1[1]=tmp+c*x0*yy;
 
 tmp=d*xxyy;
 isect2[0]=tmp+e*xx*y1;
 isect2[1]=tmp+f*xx*y0;
 
 SORT(isect1[0],isect1[1]);
 SORT(isect2[0],isect2[1]);
 
 if(isect1[1]<isect2[0] || isect2[1]<isect1[0]) return 0;
 return 1;
}

FC_DLL_EXPORT
int TriangleRayIntersection(real *t,real *u,real *v,const real origin[3],const real direction[3],
                               const real vertex0[3],const real vertex1[3],const real vertex2[3])
{
 real edge1[3],edge2[3],tvec[3],pvec[3],qvec[3];
 real det,inv_det;
 
 /* find vectors for two edges sharing vertex0 */
 Subtract(edge1,vertex1,vertex0);
 Subtract(edge2,vertex2,vertex0);
 
 /* begin calculating determinant - also used to calculate U parameter */
 CrossProduct(pvec,direction,edge2);
 
 /* if determinant is near zero,ray lies in plane of triangle */
 det=DotProduct(edge1,pvec);
 
#ifdef TEST_CULL  /* define TEST_CULL if back-face culling is desired */
 if(det<EPSILON)
  return 0;
 
 /* calculate distance from vertex0 to ray origin */
 Subtract(tvec,origin,vertex0);
 
 /* calculate U parameter and test bounds */
 *u=DotProduct(tvec,pvec);
 if(*u<((real)0.0)||*u>det)
  return 0;
 
 /* prepare to test V parameter */
 CrossProduct(qvec,tvec,edge1);
 
 /* calculate V parameter and test bounds */
 *v=DotProduct(direction,qvec);
 if(*v<((real)0.0)||*u + *v>det)
  return 0;
 
 /* calculate t,scale parameters,ray intersects triangle */
 *t=DotProduct(edge2,qvec);
 inv_det=((real)1.0) / det;
 *t*=inv_det;
 *u*=inv_det;
 *v*=inv_det;
#else                    /* the non-culling branch */
 if(det>-EPSILON && det<EPSILON)
  return 0;
 inv_det=((real)1.0) / det;
 
 /* calculate distance from vertex0 to ray origin */
 Subtract(tvec,origin,vertex0);
 
 /* calculate U parameter and test bounds */
 *u=DotProduct(tvec,pvec) * inv_det;
 if(*u<((real)0.0)||*u>((real)1.0))
  return 0;
 
 /* prepare to test V parameter */
 CrossProduct(qvec,tvec,edge1);
 
 /* calculate V parameter and test bounds */
 *v=DotProduct(direction,qvec) * inv_det;
 if(*v<((real)0.0)||*u + *v>((real)1.0))
  return 0;
 
 /* calculate t,ray intersects triangle */
 *t=DotProduct(edge2,qvec) * inv_det;
#endif
 return 1;
}

int CMesh::ReadFromASEFile(char *filename)
{
 FILE *fl;
 int return_value=1;
 int numvertices,numfaces;
 
 number_of_faces=number_of_vertices=0;
 delete[]vertex;
 delete[]face;
 delete[]normal;
 vertex=0;
 face=0;
 normal=0;
 
 fl=fopen(filename,"rt");
 if(fl==0)
 {
  ASSERT("Cannot open file for reading."&&0);
  return 0;
 }
 char *line=new char[8192];
 do{if(!fgets(line,8191,fl))goto error;}
 while(sscanf(line," *MESH_NUMVERTEX %d",&numvertices)!=1);
 do{if(!fgets(line,8191,fl))goto error;}
 while(sscanf(line," *MESH_NUMFACES %d",&numfaces)!=1);
 ASSERT(numfaces>0);
 ASSERT(numvertices>0);
 
 vertex=new CPoint[numvertices];
 face=new CFace[numfaces];
 
 //read vertex
 do{if(!fgets(line,8191,fl))goto error;}
 while(strstr(line,"*MESH_VERTEX_LIST")==0);
 
 int vnum;
 alwaysdouble x,y,z;
 if(!fgets(line,8191,fl))goto error;
 while(sscanf(line," *MESH_VERTEX %d %lf %lf %lf",&vnum,&x,&y,&z)==4)
 {
  vertex[vnum][0]=(real)x;
  vertex[vnum][1]=(real)y;
  vertex[vnum][2]=(real)z;
  number_of_vertices++;
  if(number_of_vertices>numvertices)goto error;
  if(!fgets(line,8191,fl))goto error;
 }
 if(number_of_vertices<numvertices)goto error;
 
 //read faces
 do{if(!fgets(line,8191,fl))goto error;}
 while(strstr(line,"*MESH_FACE_LIST")==0);
 
 int fnum,i,j,k;
 if(!fgets(line,8191,fl))goto error;
 while(sscanf(line," *MESH_FACE %d: A: %d B: %d C: %d",&fnum,&i,&j,&k)==4)
 {
  face[fnum].v[0]=i;
  face[fnum].v[1]=j;
  face[fnum].v[2]=k;
  face[fnum].normal=0;
  face[fnum].base=vertex;
  number_of_faces++;
  if(number_of_faces>numfaces)goto error;
  if(!fgets(line,8191,fl))goto error;
 }
 if(number_of_faces<numfaces)goto error;
 
 //read normals
 do{if(!fgets(line,8191,fl))goto no_normals;}
 while(strstr(line,"*MESH_NORMALS")==0);
 
 normal=new CPoint[numfaces];
 
 {
  int nof=0;
  if(!fgets(line,8191,fl))goto error;
  while(sscanf(line," *MESH_FACENORMAL %d %lf %lf %lf",&fnum,&x,&y,&z)==4)
  {
   ASSERT(fnum>=0&&fnum<numfaces);
   normal[fnum][0]=(real)x;
   normal[fnum][1]=(real)y;
   normal[fnum][2]=(real)z;
   face[fnum].normal=normal+fnum;
   nof++;
   if(nof>numfaces)goto error;
   if(!fgets(line,8191,fl))goto error;
   while(strstr(line,"*MESH_VERTEXNORMAL")!=0)
    if(!fgets(line,8191,fl))goto error;
  }
  if(nof<numfaces)goto error;
 }
 
no_normals:;
 goto skip;
error:;
 delete[]vertex;
 delete[]face;
 delete[]normal;
 vertex=0;
 face=0;
 normal=0;
 ASSERT("The ASE file cannot be understood"&&0);
 return_value=0;
skip:;
 delete[]line;
 fclose(fl);
 return return_value;
}

int CMesh::ReadFromASEFileWierd(char *filename)
{
 FILE *fl;
 int return_value=1;
 int numvertices,numfaces;
 
 number_of_faces=number_of_vertices=0;
 delete[]vertex;
 delete[]face;
 delete[]normal;
 vertex=0;
 face=0;
 normal=0;
 
 fl=fopen(filename,"rt");
 if(fl==0)
 {
  ASSERT("Cannot open file for reading"&&0);
  return 0;
 }
 char *line=new char[8192];
 do{if(!fgets(line,8191,fl))goto error;}
 while(sscanf(line," *MESH_NUMVERTEX %d",&numvertices)!=1);
 do{if(!fgets(line,8191,fl))goto error;}
 while(sscanf(line," *MESH_NUMFACES %d",&numfaces)!=1);
 ASSERT(numfaces>0);
 ASSERT(numvertices>0);
 
 vertex=new CPoint[numvertices];
 face=new CFace[numfaces];
 
 //read vertex
 do{if(!fgets(line,8191,fl))goto error;}
 while(strstr(line,"*MESH_VERTEX_LIST")==0);
 
 int vnum;
 alwaysdouble x,y,z;
 if(!fgets(line,8191,fl))goto error;
 while(sscanf(line," *MESH_VERTEX %d %lf %lf %lf",&vnum,&x,&y,&z)==4)
 {
  vertex[vnum][0]=(real)x;
  vertex[vnum][1]=(real)-z;
  vertex[vnum][2]=(real)-y;
  number_of_vertices++;
  if(number_of_vertices>numvertices)goto error;
  if(!fgets(line,8191,fl))goto error;
 }
 if(number_of_vertices<numvertices)goto error;
 
 //read faces
 do{if(!fgets(line,8191,fl))goto error;}
 while(strstr(line,"*MESH_FACE_LIST")==0);
 
 int fnum,i,j,k;
 if(!fgets(line,8191,fl))goto error;
 while(sscanf(line," *MESH_FACE %d: A: %d B: %d C: %d",&fnum,&i,&j,&k)==4)
 {
  face[fnum].v[0]=i;
  face[fnum].v[1]=j;
  face[fnum].v[2]=k;
  face[fnum].normal=0;
  face[fnum].base=vertex;
  number_of_faces++;
  if(number_of_faces>numfaces)goto error;
  if(!fgets(line,8191,fl))goto error;
 }
 if(number_of_faces<numfaces)goto error;
 
 //read normals
 do{if(!fgets(line,8191,fl))goto no_normals;}
 while(strstr(line,"*MESH_NORMALS")==0);
 
 normal=new CPoint[numfaces];
 
 {
  int nof=0;
  if(!fgets(line,8191,fl))goto error;
  while(sscanf(line," *MESH_FACENORMAL %d %lf %lf %lf",&fnum,&x,&y,&z)==4)
  {
   ASSERT(fnum>=0&&fnum<numfaces);
   normal[fnum][0]=(real)x;
   normal[fnum][1]=(real)-z;
   normal[fnum][2]=(real)-y;
   face[fnum].normal=normal+fnum;
   nof++;
   if(nof>numfaces)goto error;
   if(!fgets(line,8191,fl))goto error;
   while(strstr(line,"*MESH_VERTEXNORMAL")!=0)
    if(!fgets(line,8191,fl))goto error;
  }
  if(nof<numfaces)goto error;
 }
 
no_normals:;
 goto skip;
error:;
 delete[]vertex;
 delete[]face;
 delete[]normal;
 vertex=0;
 face=0;
 normal=0;
 ASSERT("The file cannot be understood"&&0);
 return_value=0;
skip:;
 delete[]line;
 fclose(fl);
 return return_value;
}

void CBSPTree::CheckForFaceIndecesResize()
{
 if(face_indices_filled>=face_indices_allocated-2)
 {
  int *face_indices_new=new int[face_indices_allocated*2];
  memcpy(face_indices_new,faces,face_indices_allocated*sizeof(int));//
  delete[]faces;
  faces=face_indices_new;
  face_indices_allocated*=2;
 }
}

void CBSPTree::CheckForNodesResize()
{
 if(node_indices_filled>=node_indices_allocated-2)
 {
  CBSPNode *node_new=new CBSPNode[node_indices_allocated*2];
  memcpy(node_new,nodes,node_indices_allocated*sizeof(CBSPNode));//
  delete[]nodes;
  nodes=node_new;
  node_indices_allocated*=2;
 }
}

int CBSPTree::Create(const CMesh &mesh,real cell_sizep,real body_radiusp)
{
 const int initial_number_of_nodes=100;
 const int initial_number_of_face_indices=100;

 cell_size=cell_sizep;
 body_radius=body_radiusp;
 ASSERT(cell_size>=0);
 ASSERT(body_radius>=0);
 ASSERT(created==0);
 if(mesh.number_of_faces==0)
  return 0;
 //allocate arrays for nodes and indices
 nodes=new CBSPNode[initial_number_of_nodes];
 node_indices_allocated=initial_number_of_nodes;
 faces=new int[initial_number_of_face_indices];
 face_indices_allocated=initial_number_of_face_indices;

 //find mesh bounding box: min,max
 max[0]=min[0]=mesh.vertex[0][0];
 max[1]=min[1]=mesh.vertex[0][1];
 max[2]=min[2]=mesh.vertex[0][2];
 int i;
 for(i=1;i<mesh.number_of_vertices;i++)
 {
  if(mesh.vertex[i][0]<min[0]) min[0]=mesh.vertex[i][0];
  if(mesh.vertex[i][1]<min[1]) min[1]=mesh.vertex[i][1];
  if(mesh.vertex[i][2]<min[2]) min[2]=mesh.vertex[i][2];
  if(mesh.vertex[i][0]>max[0]) max[0]=mesh.vertex[i][0];
  if(mesh.vertex[i][1]>max[1]) max[1]=mesh.vertex[i][1];
  if(mesh.vertex[i][2]>max[2]) max[2]=mesh.vertex[i][2];
 }
 min[0]-=body_radius;
 min[1]-=body_radius;
 min[2]-=body_radius;
 max[0]+=body_radius;
 max[1]+=body_radius;
 max[2]+=body_radius;
 real size[3];
 Subtract(size,max,min);
 //find max dimention to make the mesh BBOx square
 real maxdim=size[0]>size[1]?size[0]:size[1];
 if(size[2]>maxdim) maxdim=size[2];
 max[0]=min[0]+maxdim;
 max[1]=min[1]+maxdim;
 max[2]=min[2]+maxdim;
 //create root node
 node_indices_filled=0;
 Copy(nodes[node_indices_filled].min,min);
 Copy(nodes[node_indices_filled].max,max);
 nodes[node_indices_filled].parent=-1;
 //run depth-first search
 Recurse(mesh,node_indices_filled);
 created=1;
 return 1;
}

void CBSPTree::Recurse(const CMesh &mesh, int current_node_index)
{
 int i;
 node_indices_filled++;
 //make the nodes ending if:
 //1)it is smaller than cell_size
 //2)it contains 1 or no faces
 real size[3];
 Subtract(size,nodes[current_node_index].max,nodes[current_node_index].min);
 ASSERT(size[0]>((real)0.0));
 ASSERT(size[1]>((real)0.0));
 ASSERT(size[2]>((real)0.0));
 ASSERT(IS_EQ(size[0],size[1],((real)1e-6)));
 ASSERT(IS_EQ(size[2],size[1],((real)1e-6)));
 ASSERT(IS_EQ(size[2],size[0],((real)1e-6)));
 real max_size=size[0]>size[1]?size[0]:size[1];
 if(size[2]>max_size) max_size=size[2];
 SelfScale(size,((real)0.5));//extent
 size[0]+=body_radius;
 size[1]+=body_radius;
 size[2]+=body_radius;
 real center[3];
 Add(center,nodes[current_node_index].min,nodes[current_node_index].max);
 SelfScale(center,((real)0.5));//center
 nodes[current_node_index].ending=0;
 if(max_size<cell_size)
 {
  nodes[current_node_index].ending=1;
  nodes[current_node_index].child[1]=0;
  nodes[current_node_index].child[0]=face_indices_filled;
  //find face indices that intersect the (min-body_radius,max+body_radius) box
  for(i=0;i<mesh.number_of_faces;i++)
  {
   if(TriangleAABoxIntersectionTest(center,size,mesh.vertex[mesh.face[i].v[0]],mesh.vertex[mesh.face[i].v[1]],mesh.vertex[mesh.face[i].v[2]]))
   {
    //put into index base
    nodes[current_node_index].child[1]++;
    faces[face_indices_filled]=i;
    face_indices_filled++;
    CheckForFaceIndecesResize();
   }
  }
 }
 else
 {
  //check if there is any intersecting triangle
  int found=0;
  int index=0;
  for(i=0;i<mesh.number_of_faces;i++)
  if(TriangleAABoxIntersectionTest(center,size,mesh.vertex[mesh.face[i].v[0]],mesh.vertex[mesh.face[i].v[1]],mesh.vertex[mesh.face[i].v[2]]))
  {
   found++;
   index=i;
   if(found>1)break;
  }
  if(found<=1)//node is ending too
  {
   nodes[current_node_index].ending=1;
   nodes[current_node_index].child[0]=face_indices_filled;
   nodes[current_node_index].child[1]=found;
   faces[face_indices_filled]=index;
   face_indices_filled++;
   CheckForFaceIndecesResize();
  }
 }

 if(nodes[current_node_index].ending==0)
 {//otherwise recurse
  real in[3],ax[3];
  int j;
  for(j=0;j<8;j++)
  {
   if(j&1)
   {
    in[0]=center[0];
    ax[0]=nodes[current_node_index].max[0];
   }
   else
   {
    in[0]=nodes[current_node_index].min[0];
    ax[0]=center[0];
   }
   if(j&2)
   {
    in[1]=center[1];
    ax[1]=nodes[current_node_index].max[1];
   }
   else
   {
    in[1]=nodes[current_node_index].min[1];
    ax[1]=center[1];
   }
   if(j&4)
   {
    in[2]=center[2];
    ax[2]=nodes[current_node_index].max[2];
   }
   else
   {
    in[2]=nodes[current_node_index].min[2];
    ax[2]=center[2];
   }
   Copy(nodes[node_indices_filled].min,in);
   Copy(nodes[node_indices_filled].max,ax);
   nodes[current_node_index].child[j]=node_indices_filled;
   nodes[node_indices_filled].parent=current_node_index;
   CheckForNodesResize();
   Recurse(mesh,node_indices_filled);
  }
 }
}

int CBSPTree::GetPartOfMesh(int &first_face_index_position,int &number_of_faces,const real position[3],int starting_node)const
{
 ASSERT(created);
 if
 (
  nodes[starting_node].ending&&
  position[0]>=nodes[starting_node].min[0]&&
  position[1]>=nodes[starting_node].min[1]&&
  position[2]>=nodes[starting_node].min[2]&&
  position[0]<=nodes[starting_node].max[0]&&
  position[1]<=nodes[starting_node].max[1]&&
  position[2]<=nodes[starting_node].max[2]
 )
 {
  first_face_index_position=nodes[starting_node].child[0];
  number_of_faces=nodes[starting_node].child[1];
  ASSERT(position[0]>=nodes[starting_node].min[0] && position[0]<=nodes[starting_node].max[0]);
  ASSERT(position[1]>=nodes[starting_node].min[1] && position[1]<=nodes[starting_node].max[1]);
  ASSERT(position[2]>=nodes[starting_node].min[2] && position[2]<=nodes[starting_node].max[2]);
  return starting_node;
 }

 while//go up towards the root
 (
  (starting_node!=-1)
  &&
  (
   position[0]<nodes[starting_node].min[0]||
   position[1]<nodes[starting_node].min[1]||
   position[2]<nodes[starting_node].min[2]||
   position[0]>nodes[starting_node].max[0]||
   position[1]>nodes[starting_node].max[1]||
   position[2]>nodes[starting_node].max[2]
  )
 )
 starting_node=nodes[starting_node].parent;

 if(starting_node==-1)
 {
  number_of_faces=0;
  return 0;
 }
 else
 {//go down
  while(nodes[starting_node].ending==0)
  {
   real center[3];
   Add(center,nodes[starting_node].min,nodes[starting_node].max);
   SelfScale(center,((real)0.5));
   int j=0;
   if(position[0]>center[0]) j|=1;
   if(position[1]>center[1]) j|=2;
   if(position[2]>center[2]) j|=4;
   ASSERT(position[0]>=nodes[starting_node].min[0] && position[0]<=nodes[starting_node].max[0]);
   ASSERT(position[1]>=nodes[starting_node].min[1] && position[1]<=nodes[starting_node].max[1]);
   ASSERT(position[2]>=nodes[starting_node].min[2] && position[2]<=nodes[starting_node].max[2]);
   starting_node=nodes[starting_node].child[j];
   ASSERT(position[0]>=nodes[starting_node].min[0] && position[0]<=nodes[starting_node].max[0]);
   ASSERT(position[1]>=nodes[starting_node].min[1] && position[1]<=nodes[starting_node].max[1]);
   ASSERT(position[2]>=nodes[starting_node].min[2] && position[2]<=nodes[starting_node].max[2]);
  }
  first_face_index_position=nodes[starting_node].child[0];
  number_of_faces=nodes[starting_node].child[1];
  return starting_node;
 }
}

int CBSPTree::Save(const char *filename)const
{
 ASSERT(created);
 FILE *fl;
 
 fl=fopen(filename,"wb");
 if(fl==0)
 {
  ASSERT("Cannot open files for writing."&&0);
  return 0;
 }
 fwrite(this,1,sizeof(CBSPTree),fl);
 fwrite(nodes,1,node_indices_filled*sizeof(CBSPNode),fl);
 fwrite(faces,1,face_indices_filled*sizeof(int),fl);
 fclose(fl);
 return 1;
}

int CBSPTree::Load(const char *filename)
{
 FILE *fl;
 
 fl=fopen(filename,"rb");
 if(fl==0)
 {
  ASSERT("Cannot open files for reading."&&0);
  return 0;
 }
 Destroy();
 fread(this,1,sizeof(*this),fl);
 /*
 static CBSPTree tr;
 fread(&tr,1,sizeof(*this),fl);

 created=tr.created;
 Copy(min,tr.min);
 Copy(max,tr.max);
 cell_size=tr.cell_size;
 body_radius=tr.body_radius;
 face_indices_filled=tr.face_indices_filled;
 node_indices_filled=tr.node_indices_filled;
 */
 nodes=new CBSPNode[node_indices_filled];
 faces=new int[face_indices_filled];
 node_indices_allocated=node_indices_filled;
 face_indices_allocated=face_indices_filled;

 fread(nodes,1,node_indices_filled*sizeof(CBSPNode),fl);
 fread(faces,1,face_indices_filled*sizeof(int),fl);
 fclose(fl);
 return 1;
}

int CBSPTree::AcadDraw(const char *filename)const
{
 FILE *fl;
 
 fl=fopen(filename,"wt");
 if(fl==0)
 {
  ASSERT("Cannot open file for writing."&&0);
  return 0;
 }
 int i;
 for(i=0;i<node_indices_filled;i++)
  if(nodes[i].ending)
  {
   /*
   fprintf(fl,
    "box\n"
    "%g,%g,%g\n"
    "%g,%g,%g\n",
    nodes[i].min[0],nodes[i].min[1],nodes[i].min[2],
    nodes[i].max[0],nodes[i].max[1],nodes[i].max[2]
    );
    */
   fprintf(fl,
    "point\n"
    "%g,%g,%g\n",
    ((real)0.5)*(nodes[i].min[0]+nodes[i].max[0]),((real)0.5)*(nodes[i].min[1]+nodes[i].max[1]),((real)0.5)*(nodes[i].min[2]+nodes[i].max[2])
    );
  }
 fprintf(fl,"zoom\ne\n");
  
 fclose(fl);
 return 1;
}

void CQuadTree::CheckForFaceIndecesResize()
{
 if(face_indices_filled>=face_indices_allocated-2)
 {
  int *face_indices_new=new int[face_indices_allocated*2];
  memcpy(face_indices_new,faces,face_indices_allocated*sizeof(int));//
  delete[]faces;
  faces=face_indices_new;
  face_indices_allocated*=2;
 }
}

void CQuadTree::CheckForNodesResize()
{
 if(node_indices_filled>=node_indices_allocated-2)
 {
  CQuadNode *node_new=new CQuadNode[node_indices_allocated*2];
  memcpy(node_new,nodes,node_indices_allocated*sizeof(CQuadNode));//
  delete[]nodes;
  nodes=node_new;
  node_indices_allocated*=2;
 }
}

int CQuadTree::Create(const CMesh &mesh,real cell_sizep,real body_radiusp,int ignored_dimentionp)
{
 const int initial_number_of_nodes=100;
 const int initial_number_of_face_indices=100;

 ASSERT(cell_size>=0);
 ASSERT(body_radius>=0);
 ASSERT(created==0);
 ASSERT(ignored_dimentionp==0||ignored_dimentionp==1||ignored_dimentionp==2);

 id=ignored_dimentionp;
 if(id==0){d0=1;d1=2;}
 else if(id==1){d0=0;d1=2;}
 else if(id==2){d0=0;d1=1;}

 cell_size=cell_sizep;
 body_radius=body_radiusp;
 if(mesh.number_of_faces==0)
  return 0;
 //allocate arrays for nodes and indices
 nodes=new CQuadNode[initial_number_of_nodes];
 node_indices_allocated=initial_number_of_nodes;
 faces=new int[initial_number_of_face_indices];
 face_indices_allocated=initial_number_of_face_indices;

 //find mesh bounding box: min,max
 max[0]=min[0]=mesh.vertex[0][0];
 max[1]=min[1]=mesh.vertex[0][1];
 max[2]=min[2]=mesh.vertex[0][2];
 int i;
 for(i=1;i<mesh.number_of_vertices;i++)
 {
  if(mesh.vertex[i][0]<min[0]) min[0]=mesh.vertex[i][0];
  if(mesh.vertex[i][1]<min[1]) min[1]=mesh.vertex[i][1];
  if(mesh.vertex[i][2]<min[2]) min[2]=mesh.vertex[i][2];
  if(mesh.vertex[i][0]>max[0]) max[0]=mesh.vertex[i][0];
  if(mesh.vertex[i][1]>max[1]) max[1]=mesh.vertex[i][1];
  if(mesh.vertex[i][2]>max[2]) max[2]=mesh.vertex[i][2];
 }
 min[0]-=body_radius;
 min[1]-=body_radius;
 min[2]-=body_radius;
 max[0]+=body_radius;
 max[1]+=body_radius;
 max[2]+=body_radius;
 real size[3];
 Subtract(size,max,min);
 //find max dimention to make the mesh BBOx square
 real maxdim=size[0]>size[1]?size[0]:size[1];
 if(size[2]>maxdim) maxdim=size[2];
 max[0]=min[0]+maxdim;
 max[1]=min[1]+maxdim;
 max[2]=min[2]+maxdim;
 //create root node
 node_indices_filled=0;
 //Copy(nodes[node_indices_filled].min,min);
 nodes[node_indices_filled].min[0]=min[d0];
 nodes[node_indices_filled].min[1]=min[d1];
 //Copy(nodes[node_indices_filled].max,max);
 nodes[node_indices_filled].max[0]=max[d0];
 nodes[node_indices_filled].max[1]=max[d1];

 nodes[node_indices_filled].parent=-1;
 //run depth-first search
 Recurse(mesh,node_indices_filled);
 created=1;
 return 1;
}

void CQuadTree::Recurse(const CMesh &mesh, int current_node_index)
{
 int i;
 node_indices_filled++;
 //make the nodes ending if:
 //1)it is smaller than cell_size
 //2)it contains 1 or no faces
 real size[3];
 //Subtract(size,nodes[current_node_index].max,nodes[current_node_index].min);
 size[d0]=(nodes[current_node_index].max[0]-nodes[current_node_index].min[0]);
 size[d1]=(nodes[current_node_index].max[1]-nodes[current_node_index].min[1]);
 size[id]=(max[id]-min[id]);
 
 ASSERT(size[d0]>((real)0.0));
 ASSERT(size[d1]>((real)0.0));
 ASSERT(IS_EQ(size[d0],size[d1],((real)1e-6)));
 real max_size=size[d0]>size[d1]?size[d0]:size[d1];
 SelfScale(size,((real)0.5));//extent
 size[0]+=body_radius;
 size[1]+=body_radius;
 size[2]+=body_radius;
 real center[3];
 //Add(center,nodes[current_node_index].min,nodes[current_node_index].max);
 center[d0]=((real)0.5)*(nodes[current_node_index].min[0]+nodes[current_node_index].max[0]);
 center[d1]=((real)0.5)*(nodes[current_node_index].min[1]+nodes[current_node_index].max[1]);
 center[id]=((real)0.5)*(min[id]+max[id]);
 nodes[current_node_index].ending=0;
 if(max_size<cell_size)
 {
  nodes[current_node_index].ending=1;
  nodes[current_node_index].child[1]=0;
  nodes[current_node_index].child[0]=face_indices_filled;
  //find face indices that intersect the (min-body_radius,max+body_radius) box
  for(i=0;i<mesh.number_of_faces;i++)
  {
   if(TriangleAABoxIntersectionTest(center,size,mesh.vertex[mesh.face[i].v[0]],mesh.vertex[mesh.face[i].v[1]],mesh.vertex[mesh.face[i].v[2]]))
   {
    //put into index base
    nodes[current_node_index].child[1]++;
    faces[face_indices_filled]=i;
    face_indices_filled++;
    CheckForFaceIndecesResize();
   }
  }
 }
 else
 {
  //check if there is any intersecting triangle
  int found=0;
  int index=0;
  for(i=0;i<mesh.number_of_faces;i++)
  if(TriangleAABoxIntersectionTest(center,size,mesh.vertex[mesh.face[i].v[0]],mesh.vertex[mesh.face[i].v[1]],mesh.vertex[mesh.face[i].v[2]]))
  {
   found++;
   index=i;
   if(found>1)break;
  }
  if(found<=1)//node is ending too
  {
   nodes[current_node_index].ending=1;
   nodes[current_node_index].child[0]=face_indices_filled;
   nodes[current_node_index].child[1]=found;
   faces[face_indices_filled]=index;
   face_indices_filled++;
   CheckForFaceIndecesResize();
  }
 }

 if(nodes[current_node_index].ending==0)
 {//otherwise recurse
  real in[2],ax[2];
  int j;
  for(j=0;j<4;j++)
  {
   if(j&1)
   {
    in[0]=center[d0];
    ax[0]=nodes[current_node_index].max[0];
   }
   else
   {
    in[0]=nodes[current_node_index].min[0];
    ax[0]=center[d0];
   }
   if(j&2)
   {
    in[1]=center[d1];
    ax[1]=nodes[current_node_index].max[1];
   }
   else
   {
    in[1]=nodes[current_node_index].min[1];
    ax[1]=center[d1];
   }
   //Copy(nodes[node_indices_filled].min,in);
   nodes[node_indices_filled].min[0]=in[0];
   nodes[node_indices_filled].min[1]=in[1];
   //Copy(nodes[node_indices_filled].max,ax);
   nodes[node_indices_filled].max[0]=ax[0];
   nodes[node_indices_filled].max[1]=ax[1];
   nodes[current_node_index].child[j]=node_indices_filled;
   nodes[node_indices_filled].parent=current_node_index;
   CheckForNodesResize();
   Recurse(mesh,node_indices_filled);
  }
 }
}

int CQuadTree::GetPartOfMesh(int &first_face_index_position,int &number_of_faces,const real position[3],int starting_node)const
{
 ASSERT(created);
 if
 (
  nodes[starting_node].ending&&
  position[d0]>=nodes[starting_node].min[0]&&
  position[d1]>=nodes[starting_node].min[1]&&
  position[d0]<=nodes[starting_node].max[0]&&
  position[d1]<=nodes[starting_node].max[1]
 )
 {
  first_face_index_position=nodes[starting_node].child[0];
  number_of_faces=nodes[starting_node].child[1];
  ASSERT(position[d0]>=nodes[starting_node].min[0] && position[d0]<=nodes[starting_node].max[0]);
  ASSERT(position[d1]>=nodes[starting_node].min[1] && position[d1]<=nodes[starting_node].max[1]);
  return starting_node;
 }

 while//go up towards the root
 (
  (starting_node!=-1)
  &&
  (
   position[d0]<nodes[starting_node].min[0]||
   position[d1]<nodes[starting_node].min[1]||
   position[d0]>nodes[starting_node].max[0]||
   position[d1]>nodes[starting_node].max[1]
  )
 )
 starting_node=nodes[starting_node].parent;

 if(starting_node==-1)
 {
  number_of_faces=0;
  return 0;
 }
 else
 {//go down
  while(nodes[starting_node].ending==0)
  {
   real center[2];
   //Add(center,nodes[starting_node].min,nodes[starting_node].max);
   center[0]=((real)0.5)*(nodes[starting_node].min[0]+nodes[starting_node].max[0]);
   center[1]=((real)0.5)*(nodes[starting_node].min[1]+nodes[starting_node].max[1]);
   //SelfScale(center,0.5);
   int j=0;
   if(position[d0]>center[0]) j|=1;
   if(position[d1]>center[1]) j|=2;
   ASSERT(position[d0]>=nodes[starting_node].min[0] && position[d0]<=nodes[starting_node].max[0]);
   ASSERT(position[d1]>=nodes[starting_node].min[1] && position[d1]<=nodes[starting_node].max[1]);
   starting_node=nodes[starting_node].child[j];
   ASSERT(position[d0]>=nodes[starting_node].min[0] && position[d0]<=nodes[starting_node].max[0]);
   ASSERT(position[d1]>=nodes[starting_node].min[1] && position[d1]<=nodes[starting_node].max[1]);
  }
  first_face_index_position=nodes[starting_node].child[0];
  number_of_faces=nodes[starting_node].child[1];
  return starting_node;
 }
}

int CQuadTree::Save(const char *filename)const
{
 ASSERT(created);
 FILE *fl;
 
 fl=fopen(filename,"wb");
 if(fl==0)
 {
  ASSERT("Cannot open files for writing."&&0);
  return 0;
 }
 fwrite(this,1,sizeof(CQuadTree),fl);
 fwrite(nodes,1,node_indices_filled*sizeof(CQuadNode),fl);
 fwrite(faces,1,face_indices_filled*sizeof(int),fl);
 fclose(fl);
 return 1;
}

int CQuadTree::Load(const char *filename)
{
 FILE *fl;
 
 fl=fopen(filename,"rb");
 if(fl==0)
 {
  ASSERT("Cannot open files for reading."&&0);
  return 0;
 }
 Destroy();
 fread(this,1,sizeof(*this),fl);
 /*
 static CQuadTree tr;
 fread(&tr,1,sizeof(*this),fl);

 created=tr.created;
 Copy(min,tr.min);
 Copy(max,tr.max);
 cell_size=tr.cell_size;
 body_radius=tr.body_radius;
 face_indices_filled=tr.face_indices_filled;
 node_indices_filled=tr.node_indices_filled;
 */
 nodes=new CQuadNode[node_indices_filled];
 faces=new int[face_indices_filled];
 node_indices_allocated=node_indices_filled;
 face_indices_allocated=face_indices_filled;

 fread(nodes,1,node_indices_filled*sizeof(CQuadNode),fl);
 fread(faces,1,face_indices_filled*sizeof(int),fl);
 fclose(fl);
 return 1;
}

int CQuadTree::AcadDraw(const char *filename)const
{
 FILE *fl;
 
 fl=fopen(filename,"wt");
 if(fl==0)
 {
  ASSERT("Cannot open file for writing."&&0);
  return 0;
 }
 int i;
 for(i=0;i<node_indices_filled;i++)
  if(nodes[i].ending)
  {
   /*
   fprintf(fl,
    "box\n"
    "%g,%g,%g\n"
    "%g,%g,%g\n",
    nodes[i].min[0],nodes[i].min[1],nodes[i].min[2],
    nodes[i].max[0],nodes[i].max[1],nodes[i].max[2]
    );
    */
   fprintf(fl,
    "point\n"
    "%g,%g\n",
    ((real)0.5)*(nodes[i].min[0]+nodes[i].max[0]),((real)0.5)*(nodes[i].min[1]+nodes[i].max[1])
    );
  }
 fprintf(fl,"zoom\ne\n");
  
 fclose(fl);
 return 1;
}
