// FREE SOURCE CODE
// Eugene Laptev, Oxford Dynamics www.oxforddynamics.co.uk
// Copyright (c) 2000, 2001. All Rights Reserved
// This file is subject to license
#include <stdio.h>
#include "Vitamina.hpp"
#include "CollisionHandler.hpp"

using namespace Vitamina;

#ifdef _DEBUG
static int number_of_recordings=2;
static int save=0;
static int count=0;
static real delta_x=9;
static real delta_y=-9;
static real normal_velocity_scale=((real)2.5);
static real tangential_velocity_scale=((real)7.0);
static real impulse_scale=25;
static FILE* fl=0;
static int count_x=0;
static int count_y=0;
static real impulse[3];
static real myfabs(real arg)
{
 if(arg<((real)0.0000000001)) return ((real)0.0000000001);
 else return arg;
}
#endif//of #ifdef _DEBUG

void CContact::Initialize(real ts, int relaxation_type,real relaxation_time)
{
 int b;
 if(friction!=((real)0.0))
 {
  MakeOrthonormalBasis(tangent[0],tangent[1],normal);
#ifdef _DEBUG
  if(normal[0]==((real)0.0)&&normal[1]==((real)1.0)&&normal[2]==((real)0.0))
  {
   tangent[0][0]=((real)1.0);
   tangent[0][1]=((real)0.0);
   tangent[0][2]=((real)0.0);
   tangent[1][0]=((real)0.0);
   tangent[1][1]=((real)0.0);
   tangent[1][2]=((real)1.0);
  }
#endif//of #ifdef _DEBUG
  Zero(v);
  for(b=0;b<2;b++)
  if(body[b])
  {
   body[b]->GetInverseTOIWorld(TOI_i[b]);
   body[b]->GetPosition(relp[b]);
   Subtract(relp[b],point,relp[b]);
   real vel[3];
   CrossProduct(vel,body[b]->GetAngularVelocity(),relp[b]);
   AddTo(vel,body[b]->GetVelocity());
   
   real gr_vel[3];//to prevent sliding on slopes
   if(ts>((real)0.0))
    Scale(gr_vel,body[b]->gravity,ts*((real)0.5));
   else
    Zero(gr_vel);
   //AddScaledTo(vel,body[b]->gravity,ts);//use timestep taken from the contact
    
   if(b==0)
   {
    v[0]+=DotProduct(vel,normal);
    v[1]+=DotProduct(vel,tangent[0])+DotProduct(gr_vel,tangent[0]);
    v[2]+=DotProduct(vel,tangent[1])+DotProduct(gr_vel,tangent[1]);
   }
   else
   {
    v[0]-=DotProduct(vel,normal);
    v[1]-=DotProduct(vel,tangent[0])+DotProduct(gr_vel,tangent[0]);
    v[2]-=DotProduct(vel,tangent[1])+DotProduct(gr_vel,tangent[1]);
   }
#ifdef RESTITUTION_TROUGH
   rhs[0]=-v[0]*restitution;
   rhs[1]=((real)0.0);
   rhs[2]=((real)0.0);
#endif//of #ifdef RESTITUTION_TROUGH
  }
 }
 else
 {//frictionless
  v[0]=((real)0.0);
  for(b=0;b<2;b++)
  if(body[b])
  {
   body[b]->GetInverseTOIWorld(TOI_i[b]);
   body[b]->GetPosition(relp[b]);
   Subtract(relp[b],point,relp[b]);
   real vel[3];
   CrossProduct(vel,body[b]->GetAngularVelocity(),relp[b]);
   AddTo(vel,body[b]->GetVelocity());

   //if(ts>((real)0.0))
   // AddScaledTo(vel,body[b]->gravity,ts);
   //else if(ts<((real)0.0))
   // AddScaledTo(vel,body[b]->gravity,time_step);//use timestep taken from the contact

   if(b==0)
    v[0]+=DotProduct(vel,normal);
   else
    v[0]-=DotProduct(vel,normal);
  }
#ifdef RESTITUTION_TROUGH
   rhs[0]=-v[0]*restitution;
#endif//of #ifdef RESTITUTION_TROUGH
 }
 if(relaxation_type==2)
 {
  v[0]-=penetration/relaxation_time;
//#ifdef RESTITUTION_TROUGH
//  rhs[0]+=penetration/relaxation_time;
//#endif//of #ifdef RESTITUTION_TROUGH
 }
}

void CContact::ComputeA()
{
 real mi;

 if(friction!=((real)0.0))
 {
  if(body[0]!=0&&body[1]==0||body[1]!=0&&body[0]==0)
  {//one body is world
   int b=0;
   if(body[1]) b=1;

   CrossProduct(rxNt[b][0],relp[b],normal);
   CrossProduct(rxNt[b][1],relp[b],tangent[0]);
   CrossProduct(rxNt[b][2],relp[b],tangent[1]);
   //Multiply TOI_i[b] * rxN
   int j,k;
   for(j=0;j<3;j++)
   for(k=0;k<3;k++)
    TOI_i_rxNt[b][k][j]=DotProduct(TOI_i[b][j],rxNt[b][k]);
   //Multiply rxN^T * TOI_i_rxNt
   for(j=0;j<3;j++)
   for(k=j+1;k<3;k++)
    A[k][j]=A[j][k]=DotProduct(rxNt[b][j],TOI_i_rxNt[b][k]);
   A[0][0]=DotProduct(rxNt[b][0],TOI_i_rxNt[b][0]);
   A[1][1]=DotProduct(rxNt[b][1],TOI_i_rxNt[b][1]);
   A[2][2]=DotProduct(rxNt[b][2],TOI_i_rxNt[b][2]);
   massi_angular[b]=A[0][0];
   mi=((real)1.0)/body[b]->GetMass();
   A[0][0]+=mi;
   A[1][1]+=mi;
   A[2][2]+=mi;
   ASSERT(A[0][0]>((real)0.0));
   ASSERT(A[1][1]>((real)0.0));
   ASSERT(A[2][2]>((real)0.0));
  }
  else
  {//both bodies are non-zero
   Zero(A[0]);
   Zero(A[1]);
   Zero(A[2]);
   //compute local mass inverted
   real local_massi[3][3];
   real rt=relp[0][0]*TOI_i[0][1][2];
   real diff_rt0=relp[0][1]*TOI_i[0][0][1]-relp[0][0]*TOI_i[0][1][1];
   real diff_rt1=relp[0][0]*TOI_i[0][2][2]-relp[0][2]*TOI_i[0][0][2];
   real diff_rt2=relp[0][1]*TOI_i[0][0][2]-rt;
   real diff_rt3=relp[0][1]*TOI_i[0][0][0]-relp[0][0]*TOI_i[0][0][1];
   local_massi[0][0]=relp[0][1]*relp[0][1]*TOI_i[0][2][2]+(relp[0][2]*TOI_i[0][1][1]-((real)2.0)*relp[0][1]*TOI_i[0][1][2])*relp[0][2];
   local_massi[1][1]=relp[0][2]*(relp[0][2]*TOI_i[0][0][0]-relp[0][0]*TOI_i[0][0][2])+diff_rt1*relp[0][0];
   local_massi[2][2]=diff_rt3*relp[0][1]-diff_rt0*relp[0][0];
   local_massi[0][1]=local_massi[1][0]=relp[0][2]*(rt-relp[0][2]*TOI_i[0][0][1])-diff_rt1*relp[0][1];
   local_massi[0][2]=local_massi[2][0]=diff_rt0*relp[0][2]-diff_rt2*relp[0][1];
   local_massi[1][2]=local_massi[2][1]=diff_rt2*relp[0][0]-diff_rt3*relp[0][2];
   
   real acc[3];
   Multiply(acc,local_massi,normal);
   massi_angular[0]=DotProduct(acc,normal);

   rt=relp[1][0]*TOI_i[1][1][2];
   diff_rt0=relp[1][1]*TOI_i[1][0][1]-relp[1][0]*TOI_i[1][1][1];
   diff_rt1=relp[1][0]*TOI_i[1][2][2]-relp[1][2]*TOI_i[1][0][2];
   diff_rt2=relp[1][1]*TOI_i[1][0][2]-rt;
   diff_rt3=relp[1][1]*TOI_i[1][0][0]-relp[1][0]*TOI_i[1][0][1];
   local_massi[0][0]+=relp[1][1]*relp[1][1]*TOI_i[1][2][2]+(relp[1][2]*TOI_i[1][1][1]-((real)2.0)*relp[1][1]*TOI_i[1][1][2])*relp[1][2];
   local_massi[1][1]+=relp[1][2]*(relp[1][2]*TOI_i[1][0][0]-relp[1][0]*TOI_i[1][0][2])+diff_rt1*relp[1][0];
   local_massi[2][2]+=relp[1][1]*diff_rt3-diff_rt0*relp[1][0];
   real tmp1[3];
   tmp1[0]=relp[1][2]*(rt-relp[1][2]*TOI_i[1][0][1])-diff_rt1*relp[1][1];
   tmp1[1]=diff_rt0*relp[1][2]-diff_rt2*relp[1][1];
   tmp1[2]=diff_rt2*relp[1][0]-diff_rt3*relp[1][2];
   local_massi[0][1]+=tmp1[0];
   local_massi[0][2]+=tmp1[1];
   local_massi[1][2]+=tmp1[2];
   local_massi[1][0]+=tmp1[0];
   local_massi[2][0]+=tmp1[1];
   local_massi[2][1]+=tmp1[2];
   //Congruence transform with N^T matrix
   real D[3][3];
   int i;
   for(i=0;i<3;i++)
   {
    D[0][i]=DotProduct(local_massi[i],normal);
    D[1][i]=DotProduct(local_massi[i],tangent[0]);
    D[2][i]=DotProduct(local_massi[i],tangent[1]);
   }
   A[0][0]=DotProduct(D[0],normal);
   A[1][1]=DotProduct(D[1],tangent[0]);
   A[2][2]=DotProduct(D[2],tangent[1]);
   A[1][0]=A[0][1]=DotProduct(D[0],tangent[0]);
   A[2][0]=A[0][2]=DotProduct(D[0],tangent[1]);
   A[2][1]=A[1][2]=DotProduct(D[1],tangent[1]);

   massi_angular[1]=A[0][0]-massi_angular[0];

   mi=((real)1.0)/body[0]->GetMass()+((real)1.0)/body[1]->GetMass();

   A[0][0]+=mi;
   A[1][1]+=mi;
   A[2][2]+=mi;
   ASSERT(A[0][0]>((real)0.0));
   ASSERT(A[1][1]>((real)0.0));
   ASSERT(A[2][2]>((real)0.0));
  }
  //cholesky decomposition
  Af[2][0]=A[2][0]/A[0][0];
  Af[2][2]=A[2][2]-A[2][0]*Af[2][0];
  Af[2][1]=A[2][1]-A[1][0]*Af[2][0];
  Af[1][0]=A[1][0]/A[0][0];
  Af[1][1]=A[1][1]-Af[1][0]*A[1][0];
  real tem=Af[2][1]/Af[1][1];
  Af[2][2]-=Af[2][1]*tem;
  Af[2][1]=tem;
 }
 else
 {//frictionless
  int b;
  A[0][0]=((real)0.0);

  for(b=0;b<2;b++)
  if(body[b])
  {
   CrossProduct(rxNt[b][0],relp[b],normal);
   //Multiply TOI_i[b] * rxN
   int j;
   real tmp[3];
   for(j=0;j<3;j++)
    tmp[j]=DotProduct(TOI_i[b][j],rxNt[b][0]);
   //Multiply rxN^T * tmp
   A[0][0]+=DotProduct(rxNt[b][0],tmp);
   massi_angular[b]=A[0][0];
   mi=((real)1.0)/body[b]->GetMass();
   A[0][0]+=mi;
  }
 }
}

void CContact::ComputeNormalMassi()
{
 int b;

 for(b=0;b<2;b++)
 if(body[b])
 {
  real rxN[3];
  CrossProduct(rxN,relp[b],normal);
  real tmp[3];
  Multiply(tmp,TOI_i[b],rxN);
  massi_angular[b]=DotProduct(rxN,tmp);
 }
}

void CContact::ResolveImpact(real delta_velocity[2][3],real delta_omega[2][3],real normal_dv)
{//Resolves impact
 if(!A_computed)
 {
  ComputeA();
  A_computed=1;
  normal_mass_computed=1;
 }
 if(friction==((real)0.0))
 {
  real f=normal_dv/A[0][0];
#ifdef _DEBUG
  Zero(impulse);
  impulse[0]=f;
#endif//of #ifdef _DEBUG
  //apply normal f
  if(body[0])
  {
   Scale(delta_velocity[0],normal,f/body[0]->GetMass());
   real torque_body[3];
   //CrossProduct(torque_body,relp[0],normal);
   Scale(torque_body,rxNt[0][0],f);
   Multiply(delta_omega[0],TOI_i[0],torque_body);
   real velocity[3];
   body[0]->GetVelocity(velocity);
   AddTo(velocity,delta_velocity[0]);
   body[0]->SetVelocity(velocity);
   body[0]->GetAngularVelocity(velocity);
   AddTo(velocity,delta_omega[0]);
   body[0]->SetAngularVelocity(velocity);
  }
  if(body[1])
  {
   Scale(delta_velocity[1],normal,-f/body[1]->GetMass());
   real torque_body[3];
   //CrossProduct(torque_body,relp[1],normal);
   Scale(torque_body,rxNt[1][0],-f);
   //SelfScale(torque_body,-f);
   Multiply(delta_omega[1],TOI_i[1],torque_body);
   real velocity[3];
   body[1]->GetVelocity(velocity);
   AddTo(velocity,delta_velocity[1]);
   body[1]->SetVelocity(velocity);
   body[1]->GetAngularVelocity(velocity);
   AddTo(velocity,delta_omega[1]);
   body[1]->SetAngularVelocity(velocity);
  }
 }
 else
 {
  //find clamped friction impulse
  real f[3]={normal_dv,-v[1],-v[2]};
  //cholesky back substitution
  f[1]-=Af[1][0]*f[0];
  f[2]-=Af[2][0]*f[0]+Af[2][1]*f[1];
  f[0]=f[0]/A[0][0];
  f[1]=f[1]/Af[1][1];
  f[2]=f[2]/Af[2][2];
  f[1]-=Af[2][1]*f[2];
  f[0]-=Af[2][0]*f[2]+Af[1][0]*f[1];
#ifdef _DEBUG
  {
   //check
   real b[3]={normal_dv,-v[1],-v[2]};
   real res[3];
   Multiply(res,A,f);
   SubtractFrom(res,b);
#ifdef FC_SINGLE
   ASSERT(res[0]<1e-3&&res[0]>-1e-3);
   ASSERT(res[1]<1e-3&&res[1]>-1e-3);
   ASSERT(res[2]<1e-3&&res[2]>-1e-3);
#else//of #ifdef FC_SINGLE
   ASSERT(res[0]<1e-6&&res[0]>-1e-6);
   ASSERT(res[1]<1e-6&&res[1]>-1e-6);
   ASSERT(res[2]<1e-6&&res[2]>-1e-6);
#endif//of #ifdef FC_SINGLE
  }
#endif//of #ifdef _DEBUG

  real td=(real)sqrt(f[1]*f[1]+f[2]*f[2]);
  //We don't check opposing condition since it can be shown that if
  //clamped friction solution is inside the cone we can drive to the
  //same configuration without friction to introduce energy.
  if(td>friction*f[0])
  {
   f[0]=normal_dv/(A[0][0]+A[0][1]*friction*f[1]/td+A[0][2]*friction*f[2]/td);
   if(f[0]<((real)0.0))
   {
    ASSERT("Doing frictionless"&&0);
    f[0]=-v[0]*(1+restitution)/A[0][0];
    f[1]=((real)0.0);
    f[2]=((real)0.0);
   }
   else
   {
    //ASSERT(f[1]*v[1]+f[2]*v[2]<=((real)0.0)&&"Not serious. Opposing violation")
    //If the violation exists it occures only with small tangential velocity
    f[1]*=friction*f[0]/td;
    f[2]*=friction*f[0]/td;
   }
  }

#ifdef _DEBUG
  Copy(impulse,f);
#endif//of #ifdef _DEBUG

  //apply calculated contact force
  real force[3];
  TripleScaledSum(force,normal,f[0],tangent[0],f[1],tangent[1],f[2]);

  if(body[0]==0||body[1]==0)
  {
   int b=0;
   if(body[1]) b=1;
   MultiplyTranspose(delta_omega[b],TOI_i_rxNt[b],f);
   Scale(delta_velocity[b],force,((real)1.0)/body[b]->GetMass());
   real velocity[3];
   body[b]->GetVelocity(velocity);
   AddTo(velocity,delta_velocity[b]);
   body[b]->SetVelocity(velocity);
   body[b]->GetAngularVelocity(velocity);
   AddTo(velocity,delta_omega[b]);
   body[b]->SetAngularVelocity(velocity);
  }
  else
  {
   Scale(delta_velocity[0],force,((real)1.0)/body[0]->GetMass());
   real torque_body[3];
   CrossProduct(torque_body,relp[0],force);
   Multiply(delta_omega[0],TOI_i[0],torque_body);
   real velocity[3];
   body[0]->GetVelocity(velocity);
   AddTo(velocity,delta_velocity[0]);
   body[0]->SetVelocity(velocity);
   body[0]->GetAngularVelocity(velocity);
   AddTo(velocity,delta_omega[0]);
   body[0]->SetAngularVelocity(velocity);

   Scale(delta_velocity[1],force,((real)-1.0)/body[1]->GetMass());
   CrossProduct(torque_body,force,relp[1]);//negative sign
   Multiply(delta_omega[1],TOI_i[1],torque_body);
   body[1]->GetVelocity(velocity);
   AddTo(velocity,delta_velocity[1]);
   body[1]->SetVelocity(velocity);
   body[1]->GetAngularVelocity(velocity);
   AddTo(velocity,delta_omega[1]);
   body[1]->SetAngularVelocity(velocity);
  }
 }
}

void CContact::ResolvePenetration(real delta_velocity[2][3],real delta_omega[2][3],real h[2],real penetration,int relaxation_type)
{
 ASSERT(penetration>((real)0.0));
 real pa[2],pl[2];
 int b;

 if(relaxation_type==0)
 {
  if(!normal_mass_computed)
  {
   ComputeNormalMassi();
   normal_mass_computed=1;
  }
  real mit=((real)0.0);
  if(body[0])
   mit+=massi_angular[0]+((real)1.0)/body[0]->GetMass();
  if(body[1])
  {
   mit+=massi_angular[1]+((real)1.0)/body[1]->GetMass();
   pa[1]=-penetration*massi_angular[1]/mit;
   pl[1]=-penetration/(mit*body[1]->GetMass());
  }
  if(body[0])
  {
   pa[0]=penetration*massi_angular[0]/mit;
   pl[0]=penetration/(mit*body[0]->GetMass());
  }
  for(b=0;b<2;b++)
  if(body[b])
  {
   //calculate h: dq will be represented as {domega,h}
   real t[3];
   CrossProduct(t,normal,relp[b]);
   Multiply(delta_omega[b],TOI_i[b],t);
   CrossProduct(t,delta_omega[b],relp[b]);
   h[b]=pa[b]/DotProduct(t,normal);
   ASSERT(h[b]!=((real)0.0));

   Scale(delta_velocity[b],normal,pl[b]/h[b]);

   //change the body's position
   real pos[3];
   body[b]->GetPosition(pos);
   AddScaledTo(pos,normal,pl[b]);
   body[b]->SetPosition(pos);
   //change the body's quaternion
   real Q[4];
   body[b]->GetQuaternion(Q);
   apply_omega(Q,delta_omega[b],h[b]);
   body[b]->SetQuaternion(Q);
  }
 }
 else
 {
  real mit=((real)0.0);
  if(body[0])
   mit+=((real)1.0)/body[0]->GetMass();
  if(body[1])
  {
   mit+=((real)1.0)/body[1]->GetMass();
   pa[1]=((real)0.0);
   pl[1]=-penetration/(mit*body[1]->GetMass());
  }
  if(body[0])
  {
   pa[0]=((real)0.0);
   pl[0]=penetration/(mit*body[0]->GetMass());
  }
  for(b=0;b<2;b++)
  if(body[b])
  {
   Zero(delta_omega[b]);
   h[b]=((real)1.0);
   Scale(delta_velocity[b],normal,pl[b]);
   //change the body's position
   real pos[3];
   body[b]->GetPosition(pos);
   AddScaledTo(pos,normal,pl[b]);
   body[b]->SetPosition(pos);
  }
 }
#ifdef _DEBUG
 if(body[0]==0)
  pa[0]=pl[0]=((real)0.0);
 if(body[1]==0)
  pa[1]=pl[1]=((real)0.0);
 ASSERT(IS_EQ(pa[0]+pl[0]-pa[1]-pl[1],penetration,((real)1e-6)));
#endif//of #ifdef _DEBUG
}

FC_DLL_EXPORT
void CollisionHandler(CContact *c, int NO_contacts, int relaxation_type, real relaxation_time, real time_step, real velocity_tolerance, real penetration_tolerance)
{
 //relaxation_type=0:projection
 //relaxation_type=1:linear projection
 //relaxation_type=2:relaxation with relaxation_time
 int i,iter,index;
 real delta_velocity[2][3],delta_omega[2][3],h[2];
 real max_penetration,max_vel;
 real cp[3];

 ASSERT(relaxation_type==0||relaxation_type==1||relaxation_type==2);
 ASSERT(time_step>=((real)0.0));
 ASSERT(velocity_tolerance>=((real)0.0));
 ASSERT(penetration_tolerance>=((real)0.0));
 ASSERT(NO_contacts>=0);
 for(i=0;i<NO_contacts;i++)
 {
  //check stuff
  //ASSERT(c[i].penetration>=((real)0.0));
  ASSERT(c[i].body[0]||c[i].body[1]);
  ASSERT(c[i].friction>=((real)0.0));
  ASSERT("Normal must be normalized"&&IS_EQ(Magnitude(c[i].normal),((real)1.0),((real)1e-6)));
  c[i].Initialize(time_step,relaxation_type,relaxation_time);
  c[i].A_computed=0;
  c[i].normal_mass_computed=0;
 } 
 iter=0;

#ifdef _DEBUG
 {
  int i;

  if(save&&count<number_of_recordings)
  {
   count_y=count;
   count_x=0;
   if(fl==0)
   {
    remove("t:\\AcadCommands.txt");
    fl=fopen("t:\\AcadCommands.txt","wt");
    fprintf(fl,
     "text\n"
     "%.15g,%.15g\n"
     "0.7\n"//height
     "0\n"//rotation
     "friction=%g restitution=%g velocity_tolerance=%g timestep=%g\n"
     "gravity_0=%g gravity_1=%g gravity_2=%g\n"
     "timestep*gravity_0=%g timestep*gravity_1=%g timestep*gravity_2=%g\n"
     "normal_velocity_scale=%g tangential_velocity_scale=%g impulse_scale=%g\n\n",
     c[0].point[0]+(count_x-((real)0.5))*delta_x,c[0].point[2]+(count_y-((real)1.5))*delta_y,
     c[0].friction,c[0].restitution,velocity_tolerance,time_step,
     DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].normal),
     DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].tangent[0]),
     DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].tangent[1]),
     time_step*DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].normal),
     time_step*DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].tangent[0]),
     time_step*DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].tangent[1]),
     normal_velocity_scale,tangential_velocity_scale,impulse_scale);
   }
   fprintf(fl,
    "line\n"
    "%.15g,%.15g\n"
    "%.15g,%.15g\n\n",
    c[0].point[0]+(count_x-1)*delta_x, c[0].point[2]+count_y*delta_y,
    c[0].point[0]+(count_x-1)*delta_x+time_step*DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].tangent[0])*tangential_velocity_scale,
    c[0].point[2]+count_y*delta_y+time_step*DotProduct((c[0].body[0]?c[0].body[0]:c[0].body[1])->gravity,c[0].tangent[1])*tangential_velocity_scale);
   //draw lines
   fprintf(fl,"line\n");
   for(i=0;i<NO_contacts;i++)
   {
    if(i>0 &&(
      (c[i].body[0]==c[i-1].body[0]&&c[i-1].body[0])||
      (c[i].body[0]==c[i-1].body[1]&&c[i-1].body[1])||
      (c[i].body[1]==c[i-1].body[0]&&c[i-1].body[0])||
      (c[i].body[1]==c[i-1].body[1]&&c[i-1].body[1])))
    fprintf(fl,"%.15g,%.15g\n",c[i].point[0]+(count_x-1)*delta_x,c[i].point[2]+count_y*delta_y);
    else
    {
     fprintf(fl,"c\n");
     fprintf(fl,"line\n");
     fprintf(fl,"%.15g,%.15g\n",c[i].point[0]+(count_x-1)*delta_x,c[i].point[2]+count_y*delta_y);
    }
   }
   fprintf(fl,"c\n");
   //draw text
   for(i=0;i<NO_contacts;i++)
    fprintf(fl,
     "text\n"
     "%.15g,%.15g\n"
     "0.75\n"//height
     "0\n"//rotation
     "%d\n\n",
     c[i].point[0]+(count_x-1)*delta_x,c[i].point[2]+count_y*delta_y,i);
   //draw velocities
   for(i=0;i<NO_contacts;i++)
   {
    fprintf(fl,
     "pline\n"
     "%.15g,%.15g\n"
      "w\n"
      "0.2\n"
      "0.2\n"
     "%.15g,%.15g\n"
     "\n",
     c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
     c[i].point[0]+count_x*delta_x+c[i].v[1]*tangential_velocity_scale,c[i].point[2]+count_y*delta_y+c[i].v[2]*tangential_velocity_scale);
    fprintf(fl,
     "text\n"
     "j\n"
     "bl\n"
     "%.15g,%.15g\n"
     "0.40\n"//height
     "0\n"//rotation
     " %.5g\n\n",
     c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
     c[i].v[0]);
    /*
    fprintf(fl,
     "polygon\n"
     "6\n"//sides
     "%.15g,%.15g\n"//center
     "c\n"//circumscribed
     "%.15g\n",//radius
     c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
     myfabs(-c[i].v[0]*normal_velocity_scale));
    */
    fprintf(fl,
     "pline\n"
     "%.15g,%.15g\n"
      "w\n"
      "0.2\n"
      "0.2\n"
     "%.15g,%.15g\n"
     "\n",
     c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
     c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y+c[i].v[0]*normal_velocity_scale);
   }
   count++;
  }
  else if(fl)
  {
   fprintf(fl,"zoom\ne\n");
   fclose(fl);
   fl=0;
   count=0;
   save=0;
  }
 }
#endif//of #ifdef _DEBUG

 while(iter<NO_contacts*4)
 {
  //find contact with maximum magnitude of negative velocity
  max_vel=-velocity_tolerance;
  index=-1;

#ifdef RESTITUTION_TROUGH
  for(i=0;i<NO_contacts;i++)
  {
   real dv=-c[i].rhs[0]+c[i].v[0];
   if(dv<max_vel)
   {
    max_vel=dv;
    index=i;
   }
  }
  if(index==-1)break;
  ASSERT(max_vel<((real)0.0));
  c[index].ResolveImpact(delta_velocity,delta_omega,-max_vel+velocity_tolerance);
#else//of #ifdef RESTITUTION_TROUGH
  for(i=0;i<NO_contacts;i++)
  {
   real dv=c[i].v[0]*(((real)1.0)+c[i].restitution);
   if(dv<max_vel)
   {
    max_vel=dv;
    index=i;
   }
  }
  if(index==-1)break;
  ASSERT(max_vel<((real)0.0));
  c[index].ResolveImpact(delta_velocity,delta_omega,-max_vel+velocity_tolerance);
#endif//of #ifdef RESTITUTION_TROUGH

#ifdef _DEBUG
  {
   //count_x++;
   if(save&&fl)
   {
    /*//draw lines
    fprintf(fl,"line\n");
    for(i=0;i<NO_contacts;i++)
     fprintf(fl,"%.15g,%.15g\n",c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y);
    fprintf(fl,"c\n");
    */
    //draw points
    for(i=0;i<NO_contacts;i++)
     fprintf(fl,"point\n%.15g,%.15g\n",c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y);
    
    //draw impulse
    fprintf(fl,
     "line\n"
     "%.15g,%.15g\n"
     "%.15g,%.15g\n"
     "\n",
     c[index].point[0]+count_x*delta_x,c[index].point[2]+count_y*delta_y,
     c[index].point[0]+count_x*delta_x+impulse[1]*impulse_scale/c[index].friction,
     c[index].point[2]+count_y*delta_y+impulse[2]*impulse_scale/c[index].friction);
    fprintf(fl,
     "circle\n"
     "%.15g,%.15g\n"
     "%.15g\n",
     c[index].point[0]+count_x*delta_x,c[index].point[2]+count_y*delta_y,
     fabs(impulse[0]*impulse_scale));
   }
  }
#endif//of #ifdef _DEBUG

  //update contact velocities
  for(i=0;i<NO_contacts;i++)
  {
   if(c[i].body[0])
   {
    if(c[i].body[0]==c[index].body[0])
    {
     CrossProduct(cp,delta_omega[0],c[i].relp[0]);
     AddTo(cp,delta_velocity[0]);
     c[i].v[0]+=DotProduct(c[i].normal,cp);
     if(c[i].friction!=((real)0.0))
     {
      c[i].v[1]+=DotProduct(c[i].tangent[0],cp);
      c[i].v[2]+=DotProduct(c[i].tangent[1],cp);
     }
    }
    else if(c[i].body[0]==c[index].body[1])
    {
     CrossProduct(cp,delta_omega[1],c[i].relp[0]);
     AddTo(cp,delta_velocity[1]);
     c[i].v[0]+=DotProduct(c[i].normal,cp);
     if(c[i].friction!=((real)0.0))
     {
      c[i].v[1]+=DotProduct(c[i].tangent[0],cp);
      c[i].v[2]+=DotProduct(c[i].tangent[1],cp);
     }
    }
   }
   if(c[i].body[1])
   {
    if(c[i].body[1]==c[index].body[0])
    {
     CrossProduct(cp,delta_omega[0],c[i].relp[1]);
     AddTo(cp,delta_velocity[0]);
     c[i].v[0]-=DotProduct(c[i].normal,cp);
     if(c[i].friction!=((real)0.0))
     {
      CrossProduct(cp,delta_omega[0],c[i].relp[1]);
      c[i].v[1]-=DotProduct(c[i].tangent[0],cp);
      c[i].v[2]-=DotProduct(c[i].tangent[1],cp);
     }
    }
    else if(c[i].body[1]==c[index].body[1])
    {
     CrossProduct(cp,delta_omega[1],c[i].relp[1]);
     AddTo(cp,delta_velocity[1]);
     c[i].v[0]-=DotProduct(c[i].normal,cp);
     if(c[i].friction!=((real)0.0))
     {
      c[i].v[1]-=DotProduct(c[i].tangent[0],cp);
      c[i].v[2]-=DotProduct(c[i].tangent[1],cp);
     }
    }
   }
  }
#ifdef _DEBUG
  {
   if(save&&fl)
   {
    count_x++;
    //draw velocities
    for(i=0;i<NO_contacts;i++)
    {
     fprintf(fl,
      "pline\n"
      "%.15g,%.15g\n"
      "w\n"
      "0.2\n"
      "0.2\n"
      "%.15g,%.15g\n"
      "\n",
      c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
      c[i].point[0]+count_x*delta_x+c[i].v[1]*tangential_velocity_scale,c[i].point[2]+count_y*delta_y+c[i].v[2]*tangential_velocity_scale);
     /*
     fprintf(fl,
      "polygon\n"
      "6\n"//sides
      "%.15g,%.15g\n"//center
      "c\n"//circumscribed
      "%.15g\n",//radius
      c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
      myfabs(-c[i].v[0]*normal_velocity_scale));
     */
     fprintf(fl,
      "pline\n"
      "%.15g,%.15g\n"
      "w\n"
      "0.2\n"
      "0.2\n"
      "%.15g,%.15g\n"
      "\n",
      c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
      c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y+c[i].v[0]*normal_velocity_scale);
     fprintf(fl,
      "text\n"
      "j\n"
      "bl\n"
      "%.15g,%.15g\n"
      "0.40\n"//height
      "0\n"//rotation
      " %.5g\n\n",//
      c[i].point[0]+count_x*delta_x,c[i].point[2]+count_y*delta_y,
      c[i].v[0]);
    }
   }
   /* //causes state corrupt assert
   ASSERT(c[index].v[0]>-1e-6+velocity_tolerance);
   for(i=0;i<NO_contacts;i++)
   {
    real cc[3];
    Copy(cc,c[i].v);
    c[i].Initialize(time_step,relaxation_type,relaxation_time);
    ASSERT(IS_EQ(cc[0],c[i].v[0],1e-6));
    ASSERT(IS_EQ(cc[1],c[i].v[1],1e-6));
    ASSERT(IS_EQ(cc[2],c[i].v[2],1e-6));
   }
   */
  }
#endif//of #ifdef _DEBUG
  iter++;
 }
 ASSERT("May happen occasionally. COLLISION HANDLER."&&iter<NO_contacts*4&&NO_contacts||NO_contacts==0);

 if(relaxation_type!=2)
 {
  //Now compensate for penetration
  iter=0;
  while(iter<NO_contacts*4)
  {
   //find biggest penetration
   max_penetration=penetration_tolerance;
   index=-1;
   for(i=0;i<NO_contacts;i++)
   if(c[i].penetration>max_penetration)
   {
    max_penetration=c[i].penetration;
    index=i;
   }
   if(index==-1)break;
   ASSERT(max_penetration>((real)0.0));
   c[index].ResolvePenetration(delta_velocity,delta_omega,h,max_penetration-penetration_tolerance*((real)0.5),relaxation_type);
   //update penetrations
   for(i=0;i<NO_contacts;i++)
   {
    if(c[i].body[0])
    {
     if(c[i].body[0]==c[index].body[0])
     {
      CrossProduct(cp,delta_omega[0],c[i].relp[0]);
      AddTo(cp,delta_velocity[0]);
      c[i].penetration-=h[0]*DotProduct(cp,c[i].normal);//0
     }
     else if(c[i].body[0]==c[index].body[1])
     {
      CrossProduct(cp,delta_omega[1],c[i].relp[0]);
      AddTo(cp,delta_velocity[1]);
      c[i].penetration-=h[1]*DotProduct(cp,c[i].normal);//-
     }
    }
    if(c[i].body[1])
    {
     if(c[i].body[1]==c[index].body[0])
     {
      CrossProduct(cp,delta_omega[0],c[i].relp[1]);
      AddTo(cp,delta_velocity[0]);
      c[i].penetration+=h[0]*DotProduct(cp,c[i].normal);//+
     }
     else if(c[i].body[1]==c[index].body[1])
     {
      CrossProduct(cp,delta_omega[1],c[i].relp[1]);
      AddTo(cp,delta_velocity[1]);
      c[i].penetration+=h[1]*DotProduct(cp,c[i].normal);//+
     }
    }
   }
   iter++;
  }
  ASSERT("May happen occasionally. PROJECTOR."&&iter<NO_contacts*4&&NO_contacts||NO_contacts==0);
 }
}
