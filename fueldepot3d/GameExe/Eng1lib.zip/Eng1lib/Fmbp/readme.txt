FREE MULTY-BODY PACKAGE v2.07
-----------------------------
Read license.txt for conditions of use.

The package consists of two parts: single rigid body simulator
and collision handler.

Additionally there is a set of simple collision detection routines
and other miscellaneous functions.

The package is a part of CFastCar project -
incredibly fast, precise and simple library for vehicle simulation in games.

The multy-body package is capable to simulate single rigid bodies
such as boxes or balls and resolve interactions between them and
between world or immovable objects.

Interactions - collisions or contacts (micro-collisions) are
handled with physical properties of restitution and friction.


Contents
--------
CollisionDetection.cpp \
CollisionDetection.hpp - collision detection routines
CollisionHandler.cpp \
CollisionHandler.hpp - collision handler
CRigidBody.cpp \
CRigidBody.hpp - CRigidBody class implementation
VectorOperations.inl, VectorOperationsAligned.inl - inline
 vector functions for hardware optimization
license.txt - license agreement
readme.txt - this file
Vitamina.cpp \
Vitamina.hpp - base definitions and miscellaniouse functions


How to use
----------
Include CRigidBody.hpp, CollisionHandler.hpp and maybe
CollisionDetection.hpp in your source files. Include
corresponding cpp-files and Vitamina.cpp into your project.


Documentation
-------------
Since this multy-body package is a by-product of FastCar
project it does not have separate documentation.
The documentation explaining how to use the multy-body
package is contained among FastCar documentation mainly
on the following web-pages:
www.oxforddynamics.co.uk/function_and_member_reference_CRigidBody.htm
for description of CRigidBody class functionality
www.oxforddynamics.co.uk/collisions_with_other_objects.htm
for description of Collision Handler
www.oxforddynamics.co.uk/outline_of_the_use.htm
for some description of use


Author - Eugene Laptev, Oxford Dynamics
eugene_laptev@oxforddynamics.co.uk,
eugene_laptev@hotmail.com

www.oxforddynamics.co.uk