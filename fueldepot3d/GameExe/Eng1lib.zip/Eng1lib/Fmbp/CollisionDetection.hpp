// FREE SOURCE CODE
// Eugene Laptev, Oxford Dynamics www.oxforddynamics.co.uk
// Copyright (c) 2000, 2001. All Rights Reserved
// This file is subject to license
#ifndef __COLLISIONDETECTION_HPP
#define __COLLISIONDETECTION_HPP

#include "Vitamina.hpp"

using namespace Vitamina;

class CContact;

struct FC_DLL_EXPORT CPlane
{
 real normal[3];
 real offset; // offest = DotProduct(normal, any point on plane)
};

struct FC_DLL_EXPORT CSphere
{
 real center[3];
 real radius;
};

struct FC_DLL_EXPORT CDisk
{
 real normal[3];
 real center[3];
 real radius;
};

struct FC_DLL_EXPORT CLine
{
 real point[3];
 real direction[3];
};

class FC_DLL_EXPORT CBox
{
public:
 real center[3];
 real axis[3][3];//transformation matrix
 real extent[3];//half full size-eqivalent to radius not diameter
 void ComputeVertices (real vertex[8][3])const;
 void GetTransform(real t[16])
 {
  t[0]=axis[0][0];
  t[1]=axis[0][1];
  t[2]=axis[0][2];
  t[3]=0.0;
  t[4]=axis[1][0];
  t[5]=axis[1][1];
  t[6]=axis[1][2];
  t[7]=0.0;
  t[8]=axis[2][0];
  t[9]=axis[2][1];
  t[10]=axis[2][2];
  t[11]=0.0;
  t[12]=center[0];
  t[13]=center[1];
  t[14]=center[2];
  t[15]=1.0;
 }
};

class CBoxLeaf:public CBox
{
public:
 CBoxLeaf *parent;
 real TM_rel[4][4];
 //real TM_abs[4][4];
 CBoxLeaf()
 {
  memset(TM_rel,0,16*sizeof(real));
  memset(axis,0,9*sizeof(real));
  TM_rel[0][0]=1.0;
  TM_rel[0][1]=0.0;
  TM_rel[0][2]=0.0;
  TM_rel[0][3]=0.0;

  TM_rel[1][0]=0.0;
  TM_rel[1][1]=1.0;
  TM_rel[1][2]=0.0;
  TM_rel[1][3]=0.0;

  TM_rel[2][0]=0.0;
  TM_rel[2][1]=0.0;
  TM_rel[2][2]=1.0;
  TM_rel[2][3]=0.0;

  TM_rel[3][3]=1.0;
  parent=0;
 }
 void UpdateAbsoluteTM()
 {
  ASSERT(parent!=0);
  ToWorld(center,TM_rel[3],parent->axis);
  center[0]+=parent->center[0];
  center[1]+=parent->center[1];
  center[2]+=parent->center[2];
  //R_abs=R_rel &* parent->R_abs;
  int i,j,k;
  for(i=0;i<3;i++)
  for(j=0;j<3;j++)
  {
   axis[i][j]=0.0;
   for(k=0;k<3;k++)
    axis[i][j]+=TM_rel[i][k]*parent->axis[k][j];
  }
 }
};

class CBoxTree
{
public:
 CBoxLeaf *box;
 int nob;

 CBoxTree(int num)
 {
  ASSERT(num>0);
  box=new CBoxLeaf[num];
  nob=num;
  box[0].parent=0;
 }
 ~CBoxTree()
 {
  delete[]box;
 }
 void UpdateAbsoluteTMs()
 {
  int i;
  for(i=1;i<nob;i++)
  {
   box[i].UpdateAbsoluteTM();
  }
 }
};

// The constructor of CDiskPlaneCollision
// fills the struct with the results of
// collision between the disk and the plane.
// Penetration distance can be negative
// which indicates no collision.
struct FC_DLL_EXPORT CDiskPlaneCollision
{
 bool parallel;
 real penetration;
 real radiusVector[3];
 // radius vec from center of disk to point on disk
 real pointOnDisk[3];
 real pointOnPlane[3];
 
 CDiskPlaneCollision(const CDisk &disk, const CPlane &plane);
};


//BSP

typedef real CPoint[3];

struct FC_DLL_EXPORT CFace
{
 int v[3];//3 indices
 CPoint *base;//base for indexing
 CPoint *normal;
};

class FC_DLL_EXPORT CMesh
{
public:
 int number_of_faces;
 int number_of_vertices;

 CPoint *vertex;
 CFace *face;
 CPoint *normal;
 CMesh(){vertex=0;face=0;normal=0;number_of_faces=0;number_of_vertices=0;};
 ~CMesh(){delete[]vertex;delete[]face;delete[]normal;};

 int ReadFromASEFile(char *filename);
 //ASE file is a text mesh file (ASCII scene export) created in 3DS Max
 //When exporting tick only "Mesh Definition", "Mesh Normals" and "Geometric".
 //Set number of digits to maximum.
 //The function uses new and delete operators.
 //Returns 1 on success and 0 on failure.
 int ReadFromASEFileWierd(char *filename);
 //Reads y as -z and z as -y
};

struct CBSPNode
{
 int parent;
 CPoint min,max;
 int ending;
 int child[8];
 /* PS2 does not support unnamed unions so
 child[0] will be first_face_index
 child[1] will be number_of_faces
 */
};

class FC_DLL_EXPORT CBSPTree
{
public:
 int *faces;//indexed by integer. contains indices of faces inside mesh.face
 CPoint min,max;
 int node_indices_allocated;
 int face_indices_allocated;
 int node_indices_filled;
 int face_indices_filled;
 real cell_size;
 real body_radius;
 int created;

 CBSPTree()
 {
  Zero(min); Zero(max);
  nodes=0; faces=0;
  node_indices_allocated=0; face_indices_allocated=0;
  node_indices_filled=0; face_indices_filled=0;
  cell_size=0; body_radius=0;
  created=0;
 };
 ~CBSPTree(){Destroy();};

 int Create(const CMesh &mesh,real cell_size,real body_radius);
 int GetPartOfMesh(int &first_face_index_position,int &number_of_faces,const real position[3],int starting_node=0)const;
 void Destroy()
 {
  delete[]nodes;
  delete[]faces;
  nodes=0;
  faces=0;
  created=0;
 };
 int Save(const char *filename)const;
 int Load(const char *filename);
 int AcadDraw(const char *filename)const;

private:
 CBSPNode *nodes;//indexed by integer inside CBSPNode

 void CheckForFaceIndecesResize();
 void CheckForNodesResize();
 void Recurse(const CMesh &mesh,int current_node_index);
 //min,max,parent must be filled
 //checks if the node can be ending
 //if yes fills faces, if no recurses further.
};

struct CQuadNode
{
 int parent;
 real min[2];
 real max[2];
 int ending;
 int child[4];
 /* PS2 does not support unnamed unions so
 child[0] will be first_face_index
 child[1] will be number_of_faces
 */
};

class FC_DLL_EXPORT CQuadTree
{
public:
 int *faces;//indexed by integer. contains indices of faces inside mesh.face
 CPoint min,max;//3D
 int node_indices_allocated;
 int face_indices_allocated;
 int node_indices_filled;
 int face_indices_filled;
 real cell_size;
 real body_radius;
 int d0,d1;//working dimentions:0..2
 int id;//ignored dimention:0..2
 int created;

 CQuadTree()
 {
  Zero(min); Zero(max);
  nodes=0; faces=0;
  node_indices_allocated=0; face_indices_allocated=0;
  node_indices_filled=0; face_indices_filled=0;
  cell_size=0; body_radius=0;
  d0=-1;d1=-1;id=-1;
  created=0;
 };
 ~CQuadTree(){Destroy();};

 int Create(const CMesh &mesh,real cell_size,real body_radius,int ignored_dimention);
 int GetPartOfMesh(int &first_face_index_position,int &number_of_faces,const real position[3],int starting_node=0)const;
 void Destroy()
 {
  delete[]nodes;
  delete[]faces;
  nodes=0;
  faces=0;
  created=0;
 };
 int Save(const char *filename)const;
 int Load(const char *filename);
 int AcadDraw(const char *filename)const;

private:
 CQuadNode *nodes;//indexed by integer inside CQuadNode

 void CheckForFaceIndecesResize();
 void CheckForNodesResize();
 void Recurse(const CMesh &mesh,int current_node_index);
 //min,max,parent must be filled
 //checks if the node can be ending
 //if yes fills faces, if no recurses further.
};


///////////////////////////////////////////////////////////
///////////////////////FUNCTIONS///////////////////////////
///////////////////////////////////////////////////////////

class CFastCar;

FC_DLL_EXPORT
int TerrainWheelCollisionDetection
(
 real normal[3], real point[3], real *penetration,//output
 real ***triangle,
 const real **triangle_normal,
 int NO_triangles,
 const CDisk& disk,
 real disk_width,
 const real direction_up[3]
);
//Wheel-terrain CD function.
//access to a triangle's coordinates is done by
//triangle[triangle number][vertex number][coordinate number]
//triangle_normal is array of pointers to 3d-points, which are triangle normals
//triangle_normal can be NULL in which case normals will be calculated basing
//on CCwise rule
//NO-triangles - number of triangles
//disk is the disk of the wheel
//width is the wheel width. it can be zero which will produce almost
//twice as fewer operations and recommended for thin wheels.
//direction_up is the average direction from disabled part of space to
//empty part of space. If it is NULL this direction will be calculated
//as weighed average of triangle normals, weights being square distances
//from triangle centers to disk center.

FC_DLL_EXPORT
bool DiskPlaneCollision(real *penetration, real pointOnDisk[3], const CDisk&, const CPlane&);
// Returns true if disk and plane are not parallel
// Penetration can be negative indicating no collision.

FC_DLL_EXPORT
bool LinePlaneCollision(real *distanceAlongLine, real pointOnPlane[3], const CLine&, const CPlane&);
// Returns true if line and plane are not parallel

FC_DLL_EXPORT
real SpherePlaneCollision(real pointOnPlane[3], const CSphere&, const CPlane&);
// Returns the penetration distance
// and computes pointOnPlane deepest/nearest the sphere.
// Penetration distance can be negative which indicates
// no collision.

FC_DLL_EXPORT
real SphereLineCollision(real *distanceAlongLine, real pointOnLine[3], real normal[3], const CSphere& sphere, const CLine& line);
// Returns the penetration distance and computes
// pointOnLine deepest/nearest the sphere.
// Also computes distanceAlongLine from line.point to
// pointOnLine and the normal perpendicular to the sphere.
// Penetration distance can be negative which indicates
// no collision.

FC_DLL_EXPORT
real SpherePointCollision(real normal[3], const CSphere&, const real point[3]);
// Returns the penetration distance and computes the 
// normal perpendicular to the sphere.
// Penetration distance can be negative which indicates
// no collision.

FC_DLL_EXPORT
real SphereSphereCollision(real point[3], real normal[3], const CSphere&, const CSphere&);
// Returns the penetration distance and computes the 
// contact point and normal perpendicular to the spheres.
// Penetration distance can be negative which indicates
// no collision.

FC_DLL_EXPORT
int SphereDiskCollision(real* penetration, real pointOnDisk[3], real normal[3], const CSphere &sphere, const CDisk &disk);
// SphereDiskCollision() computes the penetration distance, normal and pointOnDisk
// the pointOnDisk deepest/nearest the sphere.
// The return value is 0 for no collision
// 1 for collision with plane of disk
// 2 for collision with perimiter of disk

FC_DLL_EXPORT
int PointBoxIntersectionTest(const real point[3],const CBox& box);
//1 if intersect 0 if not

FC_DLL_EXPORT
int PointBoxCollisionDetection(real normal[3],real &penetration,real point[3], const CBox& box);
//Returns 1 if boxes intersect, 0 if dont.
//If Intersect normal, penetration and point are filled

FC_DLL_EXPORT
int BoxBoxIntersectionTest(const CBox& box0,const CBox& box1);
//Returns 1 if boxes intersect, 0 if dont

FC_DLL_EXPORT
int BoxBoxCollisionDetection(real normal[3],real point[3],real &penetration,const CBox& box0,const CBox& box1);
//Returns 1 if the boxes intersect, 0 if dont.
//If the boxes intersect the normal point and penetration are filled.
//The point is picked in such a way that point+normal*penetration gives another
//extreme point of CD region.
//Normal is directed from box1 to box0

FC_DLL_EXPORT
int BoxSphereCollisionDetection(real normal[3],real point[3],real& penetration,const CBox& box,const CSphere& sphere);
//Returns 1 if there is interpenetration or 0 if there is not.
//Fills normal, point, penetration if there is penetration
//normal is directed outside sphere. point lies on box surface.

FC_DLL_EXPORT
int TriangleAABoxIntersectionTest(const real box_center[3],const real box_halfsize[3],const real vertex0[3],const real vertex1[3],const real vertex2[3]);
//Returns 1 if there is an intersection and 0 if there is not.

FC_DLL_EXPORT
int TriangleTriangleIntersectionTest(const real V0[3],const real V1[3],const real V2[3],
                                     const real U0[3],const real U1[3],const real U2[3]);
//Returns 1 if there is an intersection and 0 if there is not.

FC_DLL_EXPORT
int TriangleRayIntersection(real *t,real *u,real *v,const real origin[3],const real direction[3],
                           const real vertex0[3],const real vertex1[3],const real vertex2[3]);
//Returns 1 if there is an intersection or 0 if there is not.
//t specifies point of intersection along the ray.
//u,v specify point of intersection in the triangle:
//INTERSECTION=origin+t*direction=vertex0+u*(vertex1-vertex0)+v*(vertex2-vertex0)
//u+v<1, u,v>=0

#endif//of #ifndef __COLLISIONDETECTION_HPP
