// 3DProjectile.cpp: implementation of the C3DProjectile class.
// Copyright (C) 2002 Les Bird (lesbird@lesbird.com)
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Gfx.h"
#include "3DProjectile.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C3DProjectile::C3DProjectile()
{
	SetObjectID('3PRJ');
	SetObjectName("C3DPROJECTILE");

	bTransparency=TRUE;
	bUnlit=TRUE;
}

C3DProjectile::~C3DProjectile()
{

}

BOOL
C3DProjectile::CanTouch(CGameObject *gobj)
{
	if (gobj->ObjectID == ObjectID) {
		return(FALSE);
	}
	return(C3DSprite::CanTouch(gobj));
}

void
C3DProjectile::Touch(CGameObject *gobj)
{
	C3DSprite::Touch(gobj);
	DeleteMe();
}

void
C3DProjectile::Tick(FLOAT delta)
{
	C3DSprite::Tick(delta);
	if (!bPause) {
		ScaleX=ScaleY=ScaleZ=1.0f+((CGfx::Random()*2)-1.0f);
	}
}
