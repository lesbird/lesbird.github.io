// 3DParticleEmitter.h: interface for the C3DParticleEmitter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_3DPARTICLEEMITTER_H__0E78D115_6168_4EDD_9A9C_6D4E09048908__INCLUDED_)
#define AFX_3DPARTICLEEMITTER_H__0E78D115_6168_4EDD_9A9C_6D4E09048908__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GameObject.h"
#include "3DPermanentSprite.h"

typedef struct Particle_tag
{
	LPDIRECT3DTEXTURE8				D3DTexture;
	FLOAT							Delay;
	FLOAT							EmitRate;
	FLOAT							LifeSpan;
	FLOAT							ScaleRate;
	FLOAT							Scatter;
	FLOAT							Size;
	FLOAT							Velocity;
} Particle_t;

typedef list<Particle_t *>			ParticleList_t;
typedef ParticleList_t::iterator	ParticleIterator;

class C3DParticleEmitter : public CGameObject  
{
public:
	C3DParticleEmitter();
	virtual ~C3DParticleEmitter();

	static void						InitSpriteCache();
	static void						UnInitSpriteCache();
	static void						ResetSpriteCache();

	virtual ParticleIterator		AddParticle(string filename,FLOAT lifespan,FLOAT size,FLOAT scatter,FLOAT emitrate,FLOAT scalerate,FLOAT velocity);
	virtual ParticleIterator		AddParticle(string filename,FLOAT lifespan,FLOAT emitrate,FLOAT velocity);
	virtual ParticleIterator		AddParticle(string filename);
	virtual void					RemoveParticle(ParticleIterator i);

	virtual void					Tick(FLOAT delta);

	virtual C3DPermanentSprite		*GetSprite();

public:
	ParticleList_t					ParticleList;
};

#endif // !defined(AFX_3DPARTICLEEMITTER_H__0E78D115_6168_4EDD_9A9C_6D4E09048908__INCLUDED_)
