/***************************************************************************
 *                                                                         *
 *   FACHAT.C                                                              *
 *                                                                         *
 *   Copyright (C) 1989 GALACTICOMM, Inc.    All Rights Reserved.          *
 *                                                                         *
 *   This is the Flash Attack pre- and post-game chat handler.             *
 *                                                                         *
 *                                            - T. Stryker 6/15/89         *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "ctype.h"
#include "dos.h"
#include "dosface.h"
#include "fkcode.h"
#include "portable.h"
#include "fa.h"
 
int horiz;
int begin;
int gotimi;
int played,xview,yview;
int trmscx,trmscy;
char trmscn[4000];
 
#define SIZEXV 78
#define SIZEYV 16
#define LOCXV   2
#define LOCYV   8
 
#define scrnad(x,y) (frzseg()+(x)*2+(y)*160)
 
shocha()
{
     int i;
 
     onscrn=1;
     setwin(0L,0,0,79,24,1);
     if (played) {
          iniscn(SFAVIEW,frzseg());
          seebas(SIZEXV,SIZEYV,LOCXV,LOCYV);
          view();
     }
     else {
          iniscn(horiz ? SFACHATH : SFACHATV,frzseg());
     }
     setatr(0x70);
     for (i=0 ; i < npyrs ; i++) {
          loccwl(i);
          printf(" %s ",names[i]);
          player[i].chawin[CHWSIZ*2-1]=AT4WRT;
          dspchw(i);
     }
     i=player[self].chapos;
     locate((i&1) ? 78 : 37,(i&~1)+1);
}
 
moview(dx,dy)
int dx,dy;
{
     if (disp && played) {
          if (xview+dx >= 0 && xview+dx < ISLWID-SIZEXV
           && yview+dy >= 0 && yview+dy < ISLHGT-SIZEYV) {
               xview+=dx;
               yview+=dy;
               view();
          }
     }
}
 
view()
{
     int savx,savy,i;
 
     seefld(xview,yview);
     savx=curcurx();
     savy=curcury();
     setatr(0x70);
     for (i=0 ; i < 80 ; i+=10) {
          locate(LOCXV-1+i,LOCYV-1);
          printf("%3d",xview+i);
     }
     for (i=0 ; i < 20 ; i+=5) {
          locate(LOCXV-2,LOCYV+i);
          printf("%02d",yview+i);
     }
     locate(savx,savy);
}
 
loccwl(pyrn)
int pyrn;
{
     int j;
 
     j=player[pyrn].chapos;
     locate((j&1) ? 43 : 2,(j&~1));
}
 
lblsk(sknum,lblstg)           /* label soft keys with legends              */
int sknum;
char *lblstg;
{
     if (disp) {
          if (horiz) {
               locate((sknum-1)*8+1,23);
          }
          else {
               locate(((sknum&1) ? 1 : 9),((sknum-1)&~1)+15);
          }
          printf(lblstg);
          rstloc();
     }
}
 
dwchat()
{
     int c;
 
     inirtk();
     begin=0;
     while (!begin) {
          if (kbhit()) {
               ecoutp(getchc());
          }
          switch (c=ecinp()) {
          case -1:
               break;
          case -TICK:
               rseed+=1;
               prcrtk();
               break;
          case -REMOVE:
               pyrn=ecinp()-'0';
               if (onscrn) {
                    loccwl(pyrn);
                    setatr(AT4CHW);
                    printf("\315\315\315\315\315\315\315\315\315\315\315\315");
                    rstloc();
                    player[pyrn].pinpmo=INCHAT;
                    setmem(player[pyrn].chawin,CHWSIZ*2,0);
                    dspchw(pyrn);
               }
               if (--npyrs != pyrn) {
                    movmem(&player[npyrs],&player[pyrn],sizeof(struct player));
                    names[pyrn]=names[npyrs];
                    if (self == npyrs) {
                         self=pyrn;
                    }
               }
               clardy();
               break;
          case -LINEUP:
               linem();
               break;
          case -NODATA:
               lvpool();
               outser(0,'\r');
               termnl("\n*** LOST CONTACT ***\n");
               inirtk();
               shocha();
               break;
          default:
               setpyr(pyrn);
               if (!chkimi(c)) {
                    dwcchr(c);
               }
          }
     }
}
 
outimi(code)
int code;
{
     gotimi=0;
     sptimi(code);
}
 
sptimi(code)
int code;
{
     if (!gotimi) {
          ecoutp(code);
          rtkick(9,sptimi,code);
     }
}
 
chkimi(c)
int c;
{
     if (c == IMINGM) {
          if (pyrn == self) {
               gotimi=1;
          }
          else if (pyrp->pinpmo < MAIN) {
               pyrp->pinpmo=INGAME;
               dspchw(pyrn);
          }
     }
     else if (c == IMINCH) {
          if (pyrn == self) {
               gotimi=1;
          }
          else if (pyrp->pinpmo == INGAME) {
               pyrp->pinpmo=INCHAT;
               dspchw(pyrn);
          }
     }
     else {
          return(0);
     }
     return(1);
}
 
linem()
{
     int i,j;
 
     for (i=0 ; i < npyrs ; i++) {
          for (j=0 ; j < npyrs ; j++) {
               if (player[j].chapos == i) {
                    break;
               }
          }
          if (j == npyrs) {
               break;
          }
     }
     parsln();
     setmem(pyrp=&player[npyrs-1],sizeof(struct player),0);
     pyrp->pinpmo=INCHAT;
     pyrp->chapos=i;
     if (onscrn) {
          loccwl(npyrs-1);
          setatr(0x70);
          printf(" %s ",names[npyrs-1]);
          rstloc();
     }
     clardy();
}
 
dwcchr(c)
int c;
{
     disp=((pyrn == self) && onscrn);
     switch (pyrp->pinpmo) {
     case INGAME:
          break;
     case WT4ESC:
          if (c != 27 && c != F7) {
               break;
          }
          if (pyrn == self) {
               outimi(IMINCH);
          }
     case HLPSCN:
          pyrp->pinpmo=INCHAT;
          if (pyrn == self) {
               shocha();
          }
          if (c == F7) {
               chachr(c);
          }
          break;
     case RDY2GO:
          pyrp->pinpmo=INCHAT;
          setatr(AT4SKS);
          lblsk(7," PLAY! ");
          dspchw(pyrn);
          if (c != F7) {
               chachr(c);
          }
          break;
     case INCHAT:
          chachr(c);
          break;
     default:
          catastro("PLAYER %d INPUT MODE %d",pyrn,pyrp->pinpmo);
     }
}
 
chachr(c)
int c;
{
     switch (c) {
     case F1:
          pyrp->pinpmo=HLPSCN;
          if (disp) {
               iniscn(played ? SFAHELPV : SFAHELPC,frzseg());
               onscrn=0;
               locate(0,0);
          }
          break;
     case F2:
          if (disp) {
               horiz=!horiz;
               shocha();
          }
          break;
     case F7:
          pyrp->pinpmo=RDY2GO;
          setatr(AT4SKS^0x77);
          lblsk(7," PLAY! ");
          dspchw(pyrn);
          begin=ok2bgn();
          break;
     case F9:
          if (disp) {
               lvpool();
               lvpool();
               termnl("\n*** HIT F9 TO RETURN TO FLASH ATTACK V2.2 ***\n");
               inirtk();
               shocha();
          }
          break;
     case F10:
          if (disp) {
               rstscn();
               finfa();
          }
          break;
     case CRSRLF:
          moview(-10,0);
          break;
     case CRSRRT:
          moview(10,0);
          break;
     case CRSRUP:
          moview(0,-5);
          break;
     case CRSRDN:
          moview(0,5);
          break;
     case HOME:
          moview(-10,-5);
          break;
     case END:
          moview(-10,5);
          break;
     case PGUP:
          moview(10,-5);
          break;
     case PGDN:
          moview(10,5);
          break;
     default:
          if ((c&0xFF00) == 0) {
               noise(13);
               if (c == 8 || c == 127) {
                    movmem(pyrp->chawin,
                           pyrp->chawin+2,(CHWSIZ-1)*2);
                    pyrp->chawin[0]=0;
               }
               else {
                    movmem(pyrp->chawin+2,
                           pyrp->chawin,(CHWSIZ-1)*2);
                    pyrp->chawin[CHWSIZ*2-2]=(c == '\r' ? 17 : c);
                    pyrp->chawin[CHWSIZ*2-1]=AT4WRT;
               }
               dspchw(pyrn);
          }
     }
}
 
clardy()
{
     int i;
 
     for (i=0,pyrp=player ; i < npyrs ; i++,pyrp++) {
          if (pyrp->pinpmo == RDY2GO) {
               pyrp->pinpmo=INCHAT;
               setatr(AT4SKS);
               disp=((i == self)&onscrn);
               lblsk(7," PLAY! ");
               dspchw(i);
          }
     }
}
 
ok2bgn()
{
     int i;
 
     for (i=0 ; i < npyrs ; i++) {
          if (player[i].pinpmo != RDY2GO) {
               return(0);
          }
     }
     return(1);
}
 
dspchw(pyrn)
int pyrn;
{
     int j;
     char *src;
     static char rdystg[CHWSIZ*2]={
          32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,
          32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,
          'R',AT4RDY,'E',AT4RDY,'A',AT4RDY,'D',AT4RDY,'Y',AT4RDY,' ',AT4RDY,
          'T',AT4RDY,'O',AT4RDY,' ',AT4RDY,'P',AT4RDY,'L',AT4RDY,'A',AT4RDY,
          'Y',AT4RDY,
          32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,
          32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY,32,AT4RDY
     };
     static char pngstg[CHWSIZ*2]={
          32,AT4PNG,32,AT4PNG,32,AT4PNG,32,AT4PNG,32,AT4PNG,32,AT4PNG,
          'N',AT4PNG,'O',AT4PNG,'W',AT4PNG,' ',AT4PNG,'P',AT4PNG,'L',AT4PNG,
          'A',AT4PNG,'Y',AT4PNG,'I',AT4PNG,'N',AT4PNG,'G',AT4PNG,' ',AT4PNG,
           4 ,AT4PNG,' ',AT4PNG,'P',AT4PNG,'L',AT4PNG,'E',AT4PNG,'A',AT4PNG,
          'S',AT4PNG,'E',AT4PNG,' ',AT4PNG,'W',AT4PNG,'A',AT4PNG,'I',AT4PNG,
          'T',AT4PNG,
          32,AT4PNG,32,AT4PNG,32,AT4PNG,32,AT4PNG,32,AT4PNG,32,AT4PNG
     };
 
     if (onscrn) {
          j=player[pyrn].chapos;
          switch (player[pyrn].pinpmo) {
          case RDY2GO:
               src=rdystg;
               break;
          case INGAME:
               src=pngstg;
               break;
          default:
               src=player[pyrn].chawin;
          }
          movmem(src,scrnad((j&1) ? 42 : 1,(j&~1)+1),CHWSIZ*2);
     }
}
 
lvpool()
{
     outser(0,CAN);
     outser(0,CAN);
     outser(0,CAN);
     for (fstick=0 ; fstick < 12 ; ) {
     }
}
 
termnl(stg)
char *stg;
{
     int i,c;
     static char ansiid[]={"\33[6n"};
     char *ansptr;
 
     if (trmscn[0] != 0) {
          rstscn();
     }
     locate(0,0);
     setatr(0x70);
     printf(" Flash Attack V2.2 \4 Copr. 1989 Galacticomm Inc. \4 F1=HELP \4 F9=CHAT \4 F10=EXIT ");
     rstloc();
     setatr(AT4WRT);
     setwin(0L,0,1,79,24,1);
     printf(stg);
     ansptr=ansiid;
     while (1) {
          while ((c=rdser(0)) != '\0') {
               if (c != -1) {
                    if (c == 7) {
                         noise(1);
                    }
                    else if (c == *ansptr) {
                         printf("%c",c);
                         if (*++ansptr == '\0') {
                              outser(0,'R');
                              ansptr=ansiid;
                         }
                    }
                    else {
                         ansptr=ansiid;
                         printf("%c",c);
                    }
               }
               if (kbhit()) {
                    switch (c=getchc()) {
                    case F1:
                         savscn();
                         iniscn(SFAHELPT,frzseg());
                         locate(0,0);
                         getchc();
                         rstscn();
                         break;
                    case F9:
                         printf("\n... Attempting to enter Flash Chat ...\n");
                         flashm();
                         break;
                    case F10:
                         finfa();
                         break;
                    default:
                         if (c >= 0 && c <= 127) {
                              outser(0,c);
                         }
                    }
               }
          }
          for (i=0 ; i < 5 ; i++) {
               while ((c=rdser(0)) == EOF) {
               }
               if (c != '\0') {
                    break;
               }
          }
          fstick=0;
          clreci();
          while ((c=ecinp()) == -1) {
               if (kbhit()) {
                    break;
               }
          }
          if (c == -LINEUP) {
               break;
          }
          printf("\n*** NO INITIAL LINEUP ***\n");
     }
     parsln();
     for (i=0 ; i < npyrs ; i++) {
          setmem(pyrp=&player[i],sizeof(struct player),0);
          pyrp->pinpmo=INCHAT;
          pyrp->chapos=i;
     }
     self=npyrs-1;
     played=0;
     printf("\n... Entering Flash Chat ...\n");
     savscn();
}
 
savscn()
{
     movmem(frzseg(),trmscn,4000);
     trmscx=curcurx();
     trmscy=curcury();
}
 
rstscn()
{
     movmem(trmscn,frzseg(),4000);
     locate(trmscx,trmscy);
}
 
flashm()
{
     char *sptr;
     int c;
     static char idstg[]={
       "\bFlash Attack V2.2 / Flash Protocol Copyright 1989 Galacticomm, Inc.\r"
     };
 
     for (sptr=idstg ; *sptr != '\0' ; sptr++) {
          outser(0,*sptr);
          for (fstick=0 ; fstick < 3 ; ) {   /* fstick auto-incs at 145.6 Hz */
               if ((c=rdser(0)) == *sptr) {
                    break;
               }
               if (c == '\0') {
                    return;
               }
          }
     }
}
 
pstgam()
{
     for (pyrn=0,pyrp=player ; pyrn < npyrs ; pyrn++,pyrp++) {
          if (pyrp->pinpmo >= MAIN) {
               if (pyrp->pinpmo == PLYHLP) {
                    xpyhlp();
               }
               pyrp->pinpmo=WT4ESC;
          }
     }
     locate(0,24);
     setatr(0x8F);
     printf("\20\20\20");
     setatr(0x0F);
     printf("   Game Over, Hit ESC to Review   ");
     setatr(0x8F);
     printf("\21\21\21");
     locate(0,0);
     prepvw();
}
 
prepvw()
{
     int *islptr,i,j,blink;
     char *namptr;
 
     played=1;
     xview=yview=500;
     for (i=0,islptr=island ; i < ISLHGT ; i++) {
          for (j=0 ; j < ISLWID ; j++,islptr++) {
               switch (*islptr&0xFF) {
               case 247:
                    break;
               case 255:
                    *islptr=241+MINATR;
                    break;
               default:
                    if (j < xview) {
                         xview=j;
                    }
                    if (i < yview) {
                         yview=i;
                    }
               }
          }
     }
     xview/=10;
     xview*=10;
     yview/=5;
     yview*=5;
     for (i=0 ; i < npying ; i++) {
          namptr=base[i].name;
          islptr=isle(base[i].bx,base[i].by)+ISLWID*2-strlen(namptr)/2+1;
          blink=(base[i].cond != 0 ? 0x8000 : 0);
          while (*namptr != '\0') {
               *islptr++=BASATR+blink+*namptr++;
          }
     }
}
 
