/***************************************************************************
 *                                                                         *
 *   FAMACS.C                                                              *
 *                                                                         *
 *   Copyright (C) 1989 GALACTICOMM, Inc.    All Rights Reserved.          *
 *                                                                         *
 *   This is the Flash macro handler facility.                             *
 *                                                                         *
 *                                            - T. Stryker 8/31/89         *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "ctype.h"
#include "dos.h"
#include "dosface.h"
#include "fkcode.h"
#include "portable.h"
#include "fa.h"
 
#define MAXPBS   10
#define NMACS    10
#define MACSIZ 1081
 
int pbacks,
    pbmore,
    record,
    malter;
 
int rcidx[NMACS];
 
int *mcarea;
 
int npbs,
    pbstk[MAXPBS],
    pbidx[MAXPBS];
 
inimac()
{
     FILE *fp;
 
     mcarea=(int *)alcmem(NMACS*MACSIZ*sizeof(int));
     if ((fp=fopen("famacros.bin",FOPRB)) == NULL) {
          setmem(mcarea,NMACS*MACSIZ*sizeof(int),0);
     }
     else if (fread(mcarea,MACSIZ*sizeof(int),NMACS,fp) != NMACS) {
          catastro("ERROR READING FAMACROS.BIN");
     }
     else {
          fclose(fp);
     }
}
 
swaptl()
{
     char *ttlp1,*ttlp2,ttline[40*2];
     int i;
 
     for (i=0 ; i < 4 ; i++) {
          ttlp1=frzseg()+(21+i)*160;
          ttlp2=scntbl+SFAMACS*4000+i*160;
          movmem(ttlp1,ttline,40*2);
          movmem(ttlp2,ttlp1,40*2);
          movmem(ttline,ttlp2,40*2);
     }
}
 
chkmac()
{
     int c;
     static int oldfs2;
 
     if (npbs > 0 && fstick2 != oldfs2 && fstick2 != oldfs2+1) {
          oldfs2=fstick2;
          if ((c=*(mcarea+pbstk[npbs-1]*MACSIZ+pbidx[npbs-1])) == 0) {
               npbs-=1;
               if ((pbmore-=1) < 0) {
                    pbmore=0;
               }
               pbacks&=~(1<<pbstk[npbs]);
               puprpf(pbstk[npbs],0x03,23);
               if (!(record|pbacks)) {
                    swaptl();
               }
          }
          else {
               pbidx[npbs-1]+=1;
               mcoutp(c);
          }
     }
}
 
mcoutp(c)
int c;
{
     int i,mask;
 
     if (c >= ALT+F1 && c <= ALT+F10) {
          i=((c-(ALT+F1))>>8);
          mask=(1<<i);
          if (npbs >= MAXPBS || (pbacks&mask)) {
               noise(1);
          }
          else {
               if (!(record|pbacks)) {
                    swaptl();
               }
               puprpf(i,0x70,23);
               pbacks|=mask;
               pbstk[npbs]=i;
               pbidx[npbs++]=0;
               if (!((record&mask) && !pbmore && rcidx[i] == 0)) {
                    tryrec(c);
                    pbmore+=1;
               }
          }
     }
     else {
          tryrec(c);
          if (c >= CTRL+F1 && c <= CTRL+F10) {
               if (!(record|pbacks)) {
                    swaptl();
                    malter=1;
               }
               c=((c-(CTRL+F1))>>8);
               mask=(1<<c);
               if ((record^=mask)&mask) {
                    rcidx[c]=0;
                    puprpf(c,0x70,22);
               }
               else {
                    if (!pbmore) {
                         rcidx[c]-=1;
                    }
                    *(mcarea+c*MACSIZ+rcidx[c])=0;
                    puprpf(c,0x04,22);
                    if (!(record|pbacks)) {
                         swaptl();
                    }
               }
               pbmore=0;
          }
          else if (c == 3) {            /* ctrl-C */
               endmac();
          }
          else {
               ecoutp(c);
          }
     }
}
 
tryrec(c)
int c;
{
     int i,mask,*iptr;
 
     if (record && !pbmore) {
          for (i=0,mask=1 ; i < NMACS ; i++,mask<<=1) {
               if (mask&record) {
                    if (rcidx[i] >= MACSIZ-1) {
                         noise(1);
                    }
                    else {
                         iptr=mcarea+i*MACSIZ+rcidx[i];
                         *iptr++=c;
                         rcidx[i]+=1;
                    }
               }
          }
     }
}
 
puprpf(c,attr,ypos)
int c,attr,ypos;
{
     setatr(attr);
     locate(8+c*3,ypos);
     printf("F%d",c+1);
     rstloc();
}
 
endmac()
{
     int i,mask;
 
     if (record|pbacks) {
          for (i=0,mask=1; i < 10 ; i++,mask<<=1) {
               if (record&mask) {
                    *(mcarea+i*MACSIZ+rcidx[i]-1)=0;
                    puprpf(i,0x04,22);
               }
               if (pbacks&mask) {
                    puprpf(i,0x03,23);
               }
          }
          swaptl();
          pbacks=pbmore=npbs=record=0;
     }
}
 
finmac()
{
     FILE *fp;
 
     endmac();
     if (malter) {
          if ((fp=fopen("famacros.bin",FOPWB)) == NULL) {
               catastro("CAN'T WRITE FAMACROS.BIN");
          }
          fwrite(mcarea,MACSIZ*sizeof(int),NMACS,fp);
          fclose(fp);
     }
}
 
