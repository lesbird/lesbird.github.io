/***************************************************************************
 *                                                                         *
 *   FA.C                                                                  *
 *                                                                         *
 *   Copyright (C) 1989 GALACTICOMM, Inc.    All Rights Reserved.          *
 *                                                                         *
 *   This is the Flash Attack mainline.                                    *
 *                                                                         *
 *                                            - T. Stryker 3/5/89          *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "ctype.h"
#include "setjmp.h"
#include "dos.h"
#include "dosface.h"
#include "fkcode.h"
#include "portable.h"
#include "fa.h"
 
extern jmp_buf disaster;      /* master error-recovery longjmp save block  */
 
char *names[MAXPYR+1];
int rseed;
struct player player[MAXPYR];
struct base base[MAXBAS];
 
int gamovr,
    npyrs,
    npying,
    nleft,
    onscrn,
    pyrn,
    basn,
    self,
    disp,
    tnkn,
    tnkrow;
 
struct player *pyrp;
struct base *basp;
struct tank *tnkp;
 
int *island;
 
int at4cnd[]={0x07,0x8C,0x0E,0x0A,0x8F};
char *cndstg[]={" GONE "," RED  ","YELLOW","GREEN ","WINNER"};
 
#define NLASG  16
#define NLSPRT  8
#define LXPMFE  8
#define NSESG  20
 
int lasinu;
int skrinu;
int neuinu;
 
long seed;
 
main(argc,argv)                    /* Flash Attack main program loop       */
int argc;
char *argv[];
{
     if (setjmp(ADDR_OFdisaster) != 0) {
          finfa();
     }
     init(argc,argv);
     if (solo) {
          inigam();
          fstick=0;
          while (!gamovr) {
               dwinp();
               if (fstick > 7) {
                    fstick-=8;
                    prcrtk();
               }
               showin();
          }
          finfa();
     }
     else {
          outser(0,'\r');
          termnl("\14");
          shocha();
          while (1) {
               dwchat();
               inigam();
               while (!gamovr) {
                    dwinp();
                    showin();
               }
               endmac();
               pstgam();
               showin();
          }
     }
}
 
dwinp()
{
     int c;
 
     if (kbhit()) {
          mcoutp(getchc());
     }
     chkmac();
     switch (c=ecinp()) {
     case -1:
          break;
     case -TICK:
          rseed+=1;
          prcrtk();
          break;
     case -REMOVE:
          setpyr(ecinp()-'0');
          if (pyrp->pinpmo >= MAIN) {
               setbas(pyrp->pbase);
               if (basp->cond != 0) {
                    basp->cond=0;
                    kilbas(basn);
                    reeval();
               }
               basp->bplayr=-1;
          }
          if (--npyrs != pyrn) {
               movmem(&player[npyrs],pyrp,sizeof(struct player));
               names[pyrn]=names[npyrs];
               if (self == npyrs) {
                    self=pyrn;
               }
               if (pyrp->pinpmo >= MAIN) {
                    base[pyrp->pbase].bplayr=pyrn;
               }
          }
          break;
     case -NODATA:
          gamovr=1;
          setbas(player[self].pbase);
          basp->cond=0;
          kilbas(basn);
          break;
     case -LINEUP:
          outimi(IMINGM);
          linem();
          break;
     default:
          setpyr(pyrn);
          if (!chkimi(c)) {
               if (pyrp->pinpmo < MAIN) {
                    dwcchr(c);
               }
               else {
                    dwgchr(c);
               }
          }
     }
}
 
dwgchr(c)
int c;
{
     int *combuf;
 
     setbas(pyrp->pbase);
     if (c == F10 || c == 27) {
          if (pyrp->pinpmo == PLYHLP) {
               xpyhlp();
          }
          if (disp) {
               wcoord(0,-1);
               setwin(0L,1,1,38,13,0);
               setatr(0x0B);
               printf("\14\n\n\n  You have hit %s, which means that",
                       c == F10 ? "F10" : "ESC");
               printf("\n       you will forfeit the game!");
               printf("\n\n          Are you sure (y/n)? ");
          }
          pyrp->pinpmo=XITING;
     }
     else {
          switch (pyrp->pinpmo) {
          case MAIN:
               mainky(c);
               break;
          case SELTNK:
               switch (c) {
               case 't':
               case 'T':
               case 'g':
               case 'G':
                    pyrp->pinpmo=SLATNK;
                    break;
               case 'a':
               case 'A':
                    clrtnk();
                    addtnk(0);
                    addtnk(1);
                    addtnk(2);
                    addtnk(3);
                    pyrp->pinpmo=MAIN;
                    break;
               case '1':
               case '2':
               case '3':
               case '4':
                    clrtnk();
                    addtnk(c-'1');
               default:
                    pyrp->pinpmo=MAIN;
               }
               break;
          case SLATNK:
               switch (c) {
               case '1':
               case '2':
               case '3':
               case '4':
                    addtnk(c-'1');
               default:
                    pyrp->pinpmo=MAIN;
               }
               break;
          case ENTANG:
          case ENTANG+1:
               if (basp->cond > 0) {
                    entdat(c,&basp->angle,360,2,18);
               }
               break;
          case ENTRNG:
          case ENTRNG+1:
               if (basp->cond > 0) {
                    entdat(c,&basp->range,300,10,18);
               }
               break;
          case COMMU:
               if (c == '\r') {
                    mainky(0);
                    c=17;
               }
               if ((c&0xFF00) == 0) {
                    noise(9);
                    combuf=((int *)pysptr)+20*80+1;
                    if (c == 8 || c == 127) {
                         movmem(combuf,combuf+1,34*2);
                         *(combuf)=(AT4WRT<<8);
                    }
                    else {
                         movmem(combuf+1,combuf,34*2);
                         *(combuf+34)=(c&0xFF)+(AT4WRT<<8);
                    }
               }
               break;
          case PLYHLP:
               xpyhlp();
               pyrp->pinpmo=MAIN;
               break;
          case XITING:
               switch (c) {
               case 'y':
               case 'Y':
                    if (disp) {
                         printf("%c",c);
                         finfa();
                    }
                    break;
               default:
                    if (disp) {
                         setwin(0L,0,0,79,24,1);
                         wcoord(0,basp->bx-18,basp->by-6);
                    }
                    mainky(0);
               }
               break;
          }
     }
}
 
xpyhlp()
{
     if (pyrn == self) {
          setwin(0L,0,0,79,24,1);
          pysptr=frzseg();
          movmem(plyscn,pysptr,4000);
          crtbas(pysptr,80);
     }
}
 
mainky(c)
int c;
{
     pyrp->pinpmo=MAIN;
     if (disp) {
          locate(0,0);
     }
     switch (c) {
     case CRSRUP:
          trymov(0,-1);
          break;
     case CRSRDN:
          trymov(0,1);
          break;
     case CRSRLF:
          trymov(-1,0);
          break;
     case CRSRRT:
          trymov(1,0);
          break;
     case HOME:
          trymov(-1,-1);
          break;
     case END:
          trymov(-1,1);
          break;
     case PGUP:
          trymov(1,-1);
          break;
     case PGDN:
          trymov(1,1);
          break;
     case '8':
          tryfir(0,-1);
          break;
     case '2':
          tryfir(0,1);
          break;
     case '4':
          tryfir(-1,0);
          break;
     case '6':
          tryfir(1,0);
          break;
     case '7':
          tryfir(-1,-1);
          break;
     case '1':
          tryfir(-1,1);
          break;
     case '9':
          tryfir(1,-1);
          break;
     case '3':
          tryfir(1,1);
          break;
     case '5':
          tryfir(0,0);
          break;
     case 'm':
     case 'M':
     case '+':
          trymin();
          break;
     case 'p':
     case 'P':
          trypod();
          break;
     case 't':
     case 'T':
     case 'g':
     case 'G':
          pyrp->pinpmo=SELTNK;
          break;
     case 'l':
     case 'L':
          trylas();
          break;
     case 'n':
     case 'N':
          tryneu();
          break;
     case 's':
     case 'S':
          tryseek();
          break;
     case 'a':
     case 'A':
          if (basp->cond > 0) {
               if (disp) {
                    locate(4,18);
               }
               dspdat(2,18,basp->angle=0);
               pyrp->pinpmo=ENTANG;
          }
          break;
     case 'r':
     case 'R':
          if (basp->cond > 0) {
               if (disp) {
                    locate(12,18);
               }
               dspdat(10,18,basp->range=0);
               pyrp->pinpmo=ENTRNG;
          }
          break;
     case 'c':
     case 'C':
          if (disp) {
               locate(35,20);
          }
          pyrp->pinpmo=COMMU;
          break;
     case 'd':
     case 'D':
          trydfs();
          break;
     case F1:
          if (pyrn == self) {
               pysptr=plyscn;
               movmem(frzseg(),plyscn,4000);
               crtbas(plyscn,80);
               iniscn(basp->cond == 0 ? SFAHELPG : SFAHELPP,frzseg());
               setwin(plyscn,0,0,79,24,1);
          }
          pyrp->pinpmo=PLYHLP;
          break;
     }
}
 
entdat(c,datadr,lim,x,y)
int c;
int *datadr;
int lim,x,y;
{
     if ((pyrp->pinpmo&1) == (ENTANG&1)) {
          switch (c) {
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
               dspdat(x,y,*datadr=(*datadr+c-'0')*10);
               if (*datadr < lim) {
                    break;
               }
          case '.':
               pyrp->pinpmo+=1;
               if (disp) {
                    locate(x+4,y);
               }
               break;
          default:
               mainky(c);
          }
     }
     else {
          switch (c) {
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
               dspdat(x,y,*datadr=*datadr+c-'0');
               mainky(0);
               break;
          case '.':
               break;
          default:
               mainky(c);
          }
     }
}
 
trydfs()
{
     if (basp->cond != 0 && basp->dfshld > 0) {
          basp->dfshld-=1;
          if (disp) {
               setatr(AT4DOT);
               locate(38-basp->dfshld%2,20-basp->dfshld/2);
               printf("\xF9");
               rstloc();
          }
          basp->shldtmr=6;
          turnbas(0x89);
     }
}
 
turnbas(color)
int color;
{
     static int xoffs[]={0,1,-2,-1,2,3,0,1};
     static int yoffs[]={-1,-1,0,0,0,0,1,1};
     int i;
     char *ptr;
 
     for (i=0 ; i < sizeof(xoffs)/sizeof(int) ; i++) {
          ptr=(char *)isle(basp->bx+xoffs[i],basp->by+yoffs[i]);
          if (*ptr == 219) {
               *(ptr+1)=color;
          }
     }
}
 
timesh()
{
     int i;
 
     for (i=0 ; i < npying ; i++) {
          setbas(i);
          if (basp->shldtmr != 0 && --(basp->shldtmr) == 0) {
               turnbas(BASATR>>8);
          }
     }
     rtkick(10,timesh);
}
 
tryseek()
{
     if (!skrinu && basp->cond != 0 && basp->seekers > 0) {
          skrinu=1;
          basp->seekers-=1;
          seeker(basn,0,0,0);
          if (disp) {
               setatr(AT4DOT);
               locate(25-basp->seekers,18);
               printf("\xF9");
               rstloc();
          }
     }
}
 
seeker(bn,x,y,stage)
int bn,x,y,stage;
{
     static char skpath[]={
          0,0,0,0,0,0,
          1,1,1,1,
          2,2,2,2,2,2,2,
          3,3,3,3,
 
          0,0,0,0,0,0,0,0,
          1,1,1,1,
          2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,3,3,
 
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          1,1,1,1,1,1,1,1,1,1,1,1,
          2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
          3,3,3,3,3,3,3,3,3,3,3,3
     };
 
     int c,natonce,sshift;
     static int unders[NSESG];
     static int *befors[NSESG];
     static int hitone;
 
     setbas(bn);
     if (stage == 0) {
          x=basp->bx-2;
          y=basp->by-2;
          hitone=0;
     }
     for (natonce=12,sshift=stage>>3 ; sshift != 0 ; natonce+=4,sshift>>=1) {
     }
     do {
          if (stage >= NSESG) {
               if (unders[0] == -1) {
                    skrinu=0;
                    return;
               }
               *befors[0]=unders[0];
          }
          movmem(unders+1,unders,(NSESG-1)*sizeof(int));
          movmem(befors+1,befors,(NSESG-1)*sizeof(int *));
          if (stage >= sizeof(skpath) || hitone) {
               unders[NSESG-1]=-1;
          }
          else {
               switch (skpath[stage]) {
               case 0:
                    x+=1;
                    break;
               case 1:
                    y+=1;
                    break;
               case 2:
                    x-=1;
                    break;
               case 3:
                    y-=1;
                    break;
               }
               befors[NSESG-1]=isle(x,y);
               c=((unders[NSESG-1]=*isle(x,y))&0xFF);
               switch (c) {
               case '+':
               case 255:
               case ' ':
               case 5:
               case 239:
               case 146:
               case 157:
               case 176:
               case 247:
               case 219:
                    *isle(x,y)=197+SKRATR;
                    if ((stage&31) == 0) {
                         noise(8);
                    }
                    break;
               default:
                    hitone=1;
                    fnztnk(x,y,3,1);
                    unders[NSESG-1]=' '+MTNATR;
                    noise(4);
               }
          }
          stage+=1;
     } while ((natonce-=((skpath[stage]&1) == 0 ? 1 : 3)) > 0);
     rtkick(1,seeker,bn,x,y,stage);
}
 
tryneu()
{
     int neutron();
 
     if (neuinu < 5 && basp->cond != 0 && basp->neutrons > 0) {
          neuinu+=1;
          basp->neutrons-=1;
          noise(5);
          rtkick(75,neutron,basp->bx,basp->by,basp->angle,basp->range,0);
          if (disp) {
               setatr(AT4DOT);
               locate(24-basp->neutrons%11,16-basp->neutrons/11);
               printf("\xF9");
               rstloc();
          }
     }
}
 
neutron(x,y,angle,range,stage)
int x,y,angle,range,stage;
{
     int i,wherex,wherey;
     long lrange;
     static char rubble[]={32,32,32,32,239,176,146,157};
 
     if (stage == 90) {
          neuinu-=1;
          return;
     }
     for (i=0 ; i < 2 ; i++) {
          lrange=(long)range;
          wherex=( sindeg(angle)*lrange+(x+rnd()%11-5)*100000L+99999L)/100000L;
          wherey=(-cosdeg(angle)*lrange+(y+rnd()% 5-2)*100000L+50000L)/100000L;
          if (!(wherex < 0 || wherex >= ISLWID
             || wherey < 0 || wherey >= ISLHGT)) {
               switch (*isle(wherex,wherey)&0xFF) {
               case '+':
               case 255:
               case ' ':
               case 5:
               case 239:
               case 146:
               case 157:
               case 176:
                    exptnk(wherex,wherey,0,0,
                           rubble[rnd()%sizeof(rubble)]+MTNATR);
                    noise(4);
                    break;
               case 247:
                    exptnk(wherex,wherey,0,0,*isle(wherex,wherey));
                    noise(4);
                    break;
               case 219:
                    if ((*isle(wherex,wherey)&0xFF00) == BASATR) {
                         exptnk(wherex,wherey,0,0,176+BASATR);
                         updbas(wherex,wherey,4);
                    }
                    else {
                         noise(1);
                    }
                    break;
               case 249:
               case 254:
               case 15:
               case 240:
               case 178:
                    noise(4);
                    break;
               default:
                    fnztnk(wherex,wherey,3,1);
                    noise(4);
               }
          }
          stage+=1;
     }
     rtkick(1,neutron,x,y,angle,range,stage);
}
 
trylas()
{
     if (!lasinu && basp->cond != 0 && basp->lasers > 0) {
          lasinu=1;
          basp->lasers-=1;
          laser(basp->bx,basp->by,basp->angle,0);
          if (disp) {
               setatr(AT4DOT);
               locate(12-basp->lasers%12,16-basp->lasers/12);
               printf("\xF9");
               rstloc();
          }
     }
}
 
laser(x,y,angle,stage)
int x,y,angle,stage;
{
     int i,c,cprime,wherex,wherey;
     long stag10;
     static int unders[NLASG];
     static int *befors[NLASG];
     static int dups,offedj,nexplo;
 
     if (stage == 0) {
          dups=offedj=nexplo=0;
     }
     for (i=0 ; i < NLSPRT ; i++) {
          if (stage >= NLASG+dups) {
               if (unders[0] == -1) {
                    lasinu=0;
                    return;
               }
               *befors[0]=unders[0];
          }
          movmem(unders+1,unders,(NLASG-1)*sizeof(int));
          movmem(befors+1,befors,(NLASG-1)*sizeof(int *));
          if (!offedj) {
               while (1) {
                    stag10=stage*10L+32L;
                    wherex=( sindeg(angle)*stag10+x*100000L+99999L)/100000L;
                    wherey=(-cosdeg(angle)*stag10+y*100000L+50000L)/100000L;
                    if (isle(wherex,wherey) != befors[NLASG-1]) {
                         break;
                    }
                    stage+=1;
                    dups+=1;
               }
               if (wherex < 0 || wherex >= ISLWID
                || wherey < 0 || wherey >= ISLHGT) {
                    unders[NLASG-1]=-1;
                    offedj=1;
               }
               else {
                    befors[NLASG-1]=isle(wherex,wherey);
                    c=((unders[NLASG-1]=*isle(wherex,wherey))&0xFF);
                    if (c != ' ' && c != 247 && c != '+' && c != 255) {
                         switch (c) {
                         case 5:
                         case 176:
                              exptnk(wherex,wherey,0,0,cprime=' '+MTNATR);
                              noise(4);
                              break;
                         case 239:
                              offedj=1;
                         case 146:
                         case 157:
                              exptnk(wherex,wherey,0,0,cprime=176+BASATR);
                              noise(4);
                              break;
                         case 219:
                              if ((*isle(wherex,wherey)&0xFF00) == BASATR) {
                                   exptnk(wherex,wherey,0,0,cprime=176+BASATR);
                                   updbas(wherex,wherey,4);
                              }
                              else {
                                   cprime=-1;
                                   offedj=1;
                                   noise(1);
                              }
                              break;
                         default:
                              fnztnk(wherex,wherey,3,1);
                              cprime=' '+MTNATR;
                              noise(4);
                         }
                         unders[NLASG-1]=cprime;
                         if (++nexplo > LXPMFE) {
                              i=NLSPRT;
                         }
                    }
                    else {
                         *isle(wherex,wherey)='*'+LASATR;
                         if ((stage&15) == 0) {
                              noise(6);
                         }
                    }
               }
          }
          else {
               unders[NLASG-1]=-1;
          }
          stage+=1;
     }
     nexplo-=1;
     rtkick(1,laser,x,y,angle,stage);
}
 
tryfir(dx,dy)
int dx,dy;
{
     int i,j,mask,lim,c;
     int x,y;
 
     for (i=0,mask=1 ; i < MAXTNK ; i++,mask<<=1) {
          if (pyrp->ptnkfl&mask) {
               settnk(i);
               if (tnkp->cond != 0 && tnkp->cond != -10 && tnkp->phasers > 0) {
                    tnkp->phasers-=1;
                    if (disp) {
                         setatr(AT4DOT);
                         locate(71-tnkp->phasers%14,tnkrow+2-tnkp->phasers/14);
                         printf("\xF9");
                         rstloc();
                    }
                    lim=(dy == 0 ? 7 : 2);
                    for (j=0,x=tnkp->rx,y=tnkp->ry ; j < lim ; j++) {
                         x+=dx;
                         y+=dy;
                         c=(*isle(x,y)&0xFF);
                         if (c != ' ' && c != 247 && c != '+' && c != 255) {
                              break;
                         }
                    }
                    switch (c) {
                    case '+':
                    case 255:
                    case ' ':
                    case 5:
                         exptnk(x,y,0,0,' '+MTNATR);
                         noise(2);
                         break;
                    case 247:
                    case 239:
                    case 146:
                    case 157:
                    case 176:
                         exptnk(x,y,0,0,*isle(x,y));
                         noise(2);
                         break;
                    case 219:
                         if ((*isle(x,y)&0xFF00) == BASATR) {
                              exptnk(x,y,0,0,176+BASATR);
                              updbas(x,y,2);
                         }
                         else {
                              noise(1);
                         }
                         break;
                    case 249:
                    case 254:
                    case 15:
                    case 240:
                    case 178:
                         fnztnk(x,y,1,0);
                         noise(2);
                         break;
                    default:
                         fnztnk(x,y,1,1);
                         noise(2);
                    }
               }
          }
     }
}
 
fnztnk(x,y,zapamt,anyway)
int x,y,zapamt,anyway;
{
     int i,j;
     struct tank *rp;
 
     for (i=0 ; i < npying ; i++) {
          if (base[i].cond != 0) {
               for (j=0 ; j < MAXTNK ; j++) {
                    rp=&base[i].tank[j];
                    if (x == rp->rx && y == rp->ry
                      && rp->cond != 0 && rp->cond != -10) {
                         hittnk(i,j,zapamt);
                         return;
                    }
               }
          }
     }
     if (anyway) {
          exptnk(x,y,0,0,' '+MTNATR);
     }
}
 
updbas(x,y,noisen)
int x,y,noisen;
{
     int i,bx,by;
 
     for (i=0 ; i < npying ; i++) {
          if (base[i].cond != 0) {
               bx=base[i].bx;
               by=base[i].by;
               if (((y == by-1 || y == by+1) && (x == bx || x == bx+1))
                || (y == by
                  && (x == bx-2 || x == bx-1 || x == bx+2 || x == bx+3))) {
                    if (noisen == 0) {
                         base[i].bleft+=1;
                         reeval();
                    }
                    else {
                         base[i].bleft-=1;
                         reeval();
                         noise(12);
                    }
                    return;
               }
          }
     }
     if (noisen != 0) {
          noise(noisen);
     }
}
 
reeval()
{
     int savebn,j,guylft;
     static int maafon[]={8,8,8,7,6,5,4,3,2,1,1};
 
     savebn=basn;
     for (j=0 ; j < npying ; j++) {
          setbas(j);
          if (basp->cond != 0) {
               if (basp->bleft < maafon[nleft]) {
                    basp->cond=0;
                    kilbas(basn);
                    j=-1;
               }
               else {
                    guylft=j;
                    if (basp->bleft == 8) {
                         basp->cond=3;
                    }
                    else if (basp->bleft <= maafon[nleft]+1) {
                         basp->cond=1;
                    }
                    else {
                         basp->cond=2;
                    }
                    dsbcnd(basn);
               }
          }
     }
     switch (nleft) {
     case 0:
          guylft=savebn;
     case 1:
          gamovr=1;
          base[guylft].cond=4;
          kilbas(guylft);
          break;
     }
     setbas(savebn);
}
 
trymin()
{
     int i,mask;
 
     for (i=0,mask=1 ; i < MAXTNK ; i++,mask<<=1) {
          if (pyrp->ptnkfl&mask) {
               settnk(i);
               if (tnkp->cond > 0 && tnkp->mines > 0) {
                    tnkp->mines-=1;
                    tnkp->behind=(disp ? '+' : 255)+MINATR;
                    if (disp) {
                         setatr(AT4DOT);
                         locate(64-tnkp->mines%7,tnkrow+5-tnkp->mines/7);
                         printf("\xF9");
                         rstloc();
                    }
               }
          }
     }
}
 
trypod()
{
     int i,mask;
 
     for (i=0,mask=1 ; i < MAXTNK ; i++,mask<<=1) {
          if (pyrp->ptnkfl&mask) {
               settnk(i);
               if (tnkp->cond > 0 && tnkp->pods > 0) {
                    tnkp->pods-=1;
                    tnkp->behind=219+BASATR;
                    if (disp) {
                         setatr(AT4DOT);
                         locate(71-tnkp->pods%6,tnkrow+5-tnkp->pods/6);
                         printf("\xF9");
                         rstloc();
                    }
               }
          }
     }
}
 
clrtnk()
{
     int i;
 
     pyrp->ptnkfl=0;
     if (disp) {
          setatr(0x70);
          for (i=0 ; i < MAXTNK ; i++) {
               locate(41,i*6);
               printf(" ");
               rstloc();
          }
     }
}
 
addtnk(tn)
int tn;
{
     pyrp->ptnkfl^=(1<<tn);
     if (disp) {
          setatr(0x70);
          locate(41,tn*6);
          printf("%c",(pyrp->ptnkfl&(1<<tn)) ? 16 : 32);
          rstloc();
     }
}
 
trymov(dx,dy)
int dx,dy;
{
     int i,mask;
     int candx,candy;
 
     for (i=0,mask=1 ; i < MAXTNK ; i++,mask<<=1) {
          if (pyrp->ptnkfl&mask) {
               settnk(i);
               candx=tnkp->rx+dx;
               candy=tnkp->ry+dy;
               if (tnkp->cond > 0 && tnkp->fuel > 0) {
                    tnkp->fuel-=1;
                    if (tnkp->cond == 1 && (rnd()&1)) {
                         dsrfue();
                    }
                    else {
                         switch (*isle(candx,candy)&0xFF) {
                         case ' ':
                         case 5:
                              noise(11);
                              if (candy == basp->by
                               && (candx == basp->bx || candx == basp->bx+1)) {
                                   rfresh();
                              }
                              moveto(candx,candy);
                              break;
                         case 176:
                              noise(11);
                              if ((rnd()&0x1110) == 0) {
                                   moveto(candx,candy);
                              }
                              else {
                                   dsrfue();
                              }
                              break;
                         case 247:
                              noise(7);
                              moveto(candx,candy);
                              byetnk();
                              dsrcnd();
                              zaptnk(basn,tnkn,0);
                              break;
                         case '+':
                         case 255:
                              noise(3);
                              moveto(candx,candy);
                              hittnk(basn,tnkn,2);
                              break;
                         case 146:
                         case 157:
                              noise(15);
                              hittnk(basn,tnkn,1);
                              break;
                         default:
                              noise(11);
                              dsrfue();
                         }
                    }
               }
               else if (tnkp->cond == -10
                && candx >= HWATER && candx <= ISLWID-HWATER
                && candy >= VWATER && candy <= ISLHGT-VWATER) {
                    tnkp->rx=candx;
                    tnkp->ry=candy;
                    if (disp) {
                         wcoord(tnkn+1,candx-7,candy-2);
                    }
               }
          }
     }
}
 
zaptnk(bn,tn,count)
int bn,tn,count;
{
     setbas(bn);
     settnk(tn);
     if (count == 6) {
          kiltnk();
     }
     else {
          *isle(tnkp->rx,tnkp->ry)=((count&1) ? 4+RWTATR : tnkp->behind);
          rtkick(1,zaptnk,bn,tn,count+1);
     }
}
 
hittnk(bn,tn,zapamt)
int bn,tn,zapamt;
{
     int savbn,savtn;
 
     savbn=basn;
     savtn=tnkn;
     setbas(bn);
     settnk(tn);
     if (tnkp->cond == 0 || (tnkp->cond < 0 && (tnkp->cond+=zapamt) >= 0)) {
          byetnk();
     }
     else if (tnkp->cond > 0) {
          if (tnkp->behind != 176+BASATR) {
               tnkp->behind=' '+MTNATR;
          }
          if ((tnkp->cond-=zapamt) <= 0) {
               byetnk();
               exptnk(basn,tnkn,1,0,tnkp->behind);
          }
          else {
               tnkp->cond=-tnkp->cond;
               exptnk(basn,tnkn,1,0,4+TNKATR);
          }
     }
     dsrcnd();
     setbas(savbn);
     settnk(savtn);
}
 
byetnk()
{
     int tflag,savpn;
 
     if (basp->bplayr >= 0) {
          savpn=pyrn;
          setpyr(basp->bplayr);
          tnkp->cond=0;
          tflag=(1<<tnkn);
          if ((pyrp->ptnkfl&tflag) != 0 && pyrp->ptnkfl != tflag) {
               addtnk(tnkn);
          }
          setpyr(savpn);
     }
}
 
exptnk(bnx,tny,istnk,count,vwdone)
int bnx,tny,istnk,count,vwdone;
{
     static char exploc[]={249,254,15,240,178};
     static int expatr[]={0x0F00,0x0E00,0x0C00};
 
     if (count != sizeof(exploc)) {
          rtkick(1,exptnk,bnx,tny,istnk,count+1,vwdone);
     }
     if (istnk) {
          setbas(bnx);
          settnk(tny);
          bnx=tnkp->rx;
          tny=tnkp->ry;
     }
     if (count == sizeof(exploc)) {
          *isle(bnx,tny)=vwdone;
          if (istnk) {
               if (tnkp->cond == 0) {
                    kiltnk();
               }
               else if (tnkp->cond != -10) {
                    tnkp->cond=-tnkp->cond;
               }
          }
     }
     else {
          *isle(bnx,tny)=exploc[count]+expatr[count/2];
     }
}
 
kiltnk()
{
     int i,j;
     char *wptr;
 
     *isle(tnkp->rx,tnkp->ry)=tnkp->behind;
     if (basp->cond != 0) {
          if (basp->tanks <= 0) {
               tnkp->cond=0;
               dsrcnd();
               if (disp) {
                    wcoord(tnkn+1,-1);
                    for (i=0 ; i < 5 ; i++) {
                         wptr=pysptr+(tnkrow+i)*160+(160+42*2);
                         for (j=0 ; j < 15 ; j++) {
                              *wptr++=' ';
                              *wptr++=0x40;
                         }
                    }
               }
          }
          else {
               basp->tanks-=1;
               if (disp) {
                    setatr(AT4DOT);
                    locate(35-basp->tanks%9,18-basp->tanks/9);
                    printf("\xF9");
                    rstloc();
               }
               initnk(tnkn);
          }
     }
}
 
kilbas(bn)
int bn;
{
     int savepn,savebn,savern;
     int i,tnkfl,mask;
 
     savepn=pyrn;
     savebn=basn;
     savern=tnkn;
     setbas(bn);
     if (basp->bplayr < 0) {
          catastro("KILBAS ERROR: %d",bn);
     }
     setpyr(basp->bplayr);
     basp->tanks=0;
     dsbcnd(bn);
     if (--nleft >= 1) {
          if (disp) {
               endmac();
               iniscn(SFAZAPPED,pysptr);
               tnkfl=pyrp->ptnkfl;
               pyrp->ptnkfl=0;
               for (i=0,mask=1 ; i < MAXTNK ; i++,mask<<=1) {
                    if (tnkfl&mask) {
                         addtnk(i);
                    }
               }
          }
          if (nleft >= 2) {
               for (i=0 ; i < MAXTNK ; i++) {
                    settnk(i);
                    tnkp->cond=-10;
                    *isle(tnkp->rx,tnkp->ry)=tnkp->behind;
                    if (disp) {
                         wcoord(tnkn+1,tnkp->rx-7,tnkp->ry-2);
                    }
               }
               switch (pyrp->pinpmo) {
               case ENTANG:
               case ENTANG+1:
               case ENTRNG:
               case ENTRNG+1:
                    mainky(0);
               }
          }
     }
     noise(14);
     setpyr(savepn);
     setbas(savebn);
     settnk(savern);
}
 
dspdat(x,y,dat)
int x,y,dat;
{
     if (disp) {
          setatr(AT4WRT);
          locate(x,y);
          printf("%3d.%d",dat/10,dat%10);
          rstloc();
     }
}
 
dsbcnd(bn)
int bn;
{
     int cond;
 
     if (base[bn].bplayr == self) {
          cond=base[bn].cond;
          setatr(at4cnd[cond]);
          locate(26,15);
          printf(cndstg[cond]);
          rstloc();
          noise(cond == 1 ? 10 : 0);
     }
}
 
dsrcnd()
{
     int cond;
 
     if (disp) {
          cond=abs(tnkp->cond);
          setatr(at4cnd[cond]);
          locate(73,tnkrow+1);
          printf(cndstg[cond]);
          rstloc();
     }
}
 
dsrfue()
{
     if (disp) {
          setatr(AT4WRT);
          locate(74,tnkrow+5);
          printf("%4d",tnkp->fuel);
          rstloc();
     }
}
 
moveto(x,y)
int x,y;
{
     /* debug!!! */
#define yak(x) ((x) == 255+MINATR ? '+'+MINATR : (x))
 
     int crc=0,*ip;
 
     crc=calcrc(crc,tnkp->rx);
     crc=calcrc(crc,tnkp->ry);
     ip=isle(tnkp->rx-1,tnkp->ry-1);
     crc=calcrc(crc,yak(*(ip)));
     crc=calcrc(crc,yak(*(ip+1)));
     crc=calcrc(crc,yak(*(ip+2)));
     crc=calcrc(crc,yak(*(ip+ISLWID)));
     crc=calcrc(crc,yak(*(ip+ISLWID+1)));
     crc=calcrc(crc,yak(*(ip+ISLWID+2)));
     crc=calcrc(crc,yak(*(ip+ISLWID*2)));
     crc=calcrc(crc,yak(*(ip+ISLWID*2+1)));
     crc=calcrc(crc,yak(*(ip+ISLWID*2+2)));
     putdbg(crc);
 
     /* end debug */
 
     if ((*isle(tnkp->rx,tnkp->ry)=tnkp->behind) == 219+BASATR) {
          updbas(tnkp->rx,tnkp->ry,0);
     }
     tnkp->behind=*isle(x,y);
     *isle(x,y)=4+TNKATR;
     tnkp->rx=x;
     tnkp->ry=y;
     if (disp) {
          wcoord(tnkn+1,x-7,y-2);
          setatr(AT4WRT);
          locate(73,tnkrow+3);
          printf("%3d",x);
          rstloc();
          locate(77,tnkrow+3);
          printf("%2d",y);
          rstloc();
          dsrfue();
     }
}
 
cosdeg(degtt)
{
     return(sindeg(degtt+900));
}
 
sindeg(degtt)
int degtt;
{
     int deg,minus=0;
     long frc;
     int result;
     static int sintab[91]={
              0,
            175,
            349,
            523,
            698,
            872,
           1045,
           1219,
           1392,
           1564,
           1736,
           1908,
           2079,
           2250,
           2419,
           2588,
           2756,
           2924,
           3090,
           3256,
           3420,
           3584,
           3746,
           3907,
           4067,
           4226,
           4384,
           4540,
           4695,
           4848,
           5000,
           5150,
           5299,
           5446,
           5592,
           5736,
           5878,
           6018,
           6157,
           6293,
           6428,
           6561,
           6691,
           6820,
           6947,
           7071,
           7193,
           7314,
           7431,
           7547,
           7660,
           7771,
           7880,
           7986,
           8090,
           8192,
           8290,
           8387,
           8480,
           8572,
           8660,
           8746,
           8829,
           8910,
           8988,
           9063,
           9135,
           9205,
           9272,
           9336,
           9397,
           9455,
           9511,
           9563,
           9613,
           9659,
           9703,
           9744,
           9781,
           9816,
           9848,
           9877,
           9903,
           9925,
           9945,
           9962,
           9976,
           9986,
           9994,
           9998,
          10000
     };
 
     while (degtt >= 3600) {
          degtt-=3600;
     }
     if (degtt >= 1800) {
          minus=1;
          degtt-=1800;
     }
     if (degtt >= 900) {
          degtt=1800-degtt;
     }
     deg=degtt/10;
     frc=(long)(degtt%10);
     result=(sintab[deg]*(10L-frc)+sintab[deg+1]*frc+5L)/10L;
     return(minus ? -result : result);
}
 
rnd()
{
     seed=seed*33821223L+871L;
     return((int)(seed>>16)&32767);
}
 
finfa()
{
     if (!solo) {
          lvpool();
          lvpool();
          finser(0);
     }
     noise(0);
     finsnd();
     finmac();
     locate(0,24);
     exit();
}
 
char *
catfix1()
{
     return("");
}
 
char *
catfix2()
{
     return("");
}
 
