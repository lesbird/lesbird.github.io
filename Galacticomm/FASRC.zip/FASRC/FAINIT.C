/***************************************************************************
 *                                                                         *
 *   FAINIT.C                                                              *
 *                                                                         *
 *   Copyright (C) 1989 GALACTICOMM, Inc.    All Rights Reserved.          *
 *                                                                         *
 *   This is the Flash Attack playfield initializer, and other startup     *
 *   routines.                                                             *
 *                                                                         *
 *                                            - T. Stryker 5/17/89         *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "ctype.h"
#include "setjmp.h"
#include "dos.h"
#include "dosface.h"
#include "fkcode.h"
#include "portable.h"
#include "fa.h"
 
extern
long seed;
 
char *plyscn,*pysptr;
 
static
int  curr,
     hilim,
     dir,
     minb4c,
     count;
 
#define VBLWID  60
#define VBLHGT  23
#define MINVWS   2
#define MINHWS   5
 
#define MXMTCT 72+14
#define MXMTSZ 14+5
 
#define MXFRCT 148+14
#define MXFRSZ 4+3
 
#define MXLKCT 5
#define MXLKSZ 12+4
 
char rimbuf[5*21*2];
 
init(argc,argv)
int argc;
char *argv[];
{
     static int spckys[]={
          CRSRLF,CRSRRT,CRSRUP,CRSRDN,HOME,END,PGUP,PGDN,'m','p',
          F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,13,8,27,IMINCH,IMINGM,0
     };
 
     inicom(argc,argv);
     inisnd();
     setspc(spckys);
     island=(int *)alcmem(ISLWID*ISLHGT*2);
     plyscn=alcmem(4000);
     fldbas(island,ISLWID);
     crtbas(frzseg(),80);
     inimac();
}
 
inigam()
{
     int i;
 
     iniscn(SFA,pysptr=frzseg());
     locate(0,0);
     seed=rseed;
     inirtk();
     timesh();
     onscrn=0;
     inirim();
     makisl();
     if (npyrs == 1) {
          nleft=npying=2;
     }
     else {
          nleft=npying=npyrs;
     }
     for (i=0 ; i < npying ; i++) {
          setpyr(i);
          pyrp->pinpmo=MAIN;
          pyrp->pbase=i;
          pyrp->ptnkfl=1;
          base[i].bplayr=i;
          inibas(i);
          strcpy(basp->name,(i != 0 && npyrs == 1 ? "(target)" : names[i]));
     }
     gamovr=lasinu=skrinu=neuinu=0;
}
 
inirim()
{
     char *rimptr;
     int i;
 
     for (i=0,rimptr=rimbuf ; i < 5 ; i++,rimptr+=21*2) {
          movmem(frzseg()+(tnkrow+i)*160+(160+58*2),rimptr,21*2);
     }
}
 
makisl()
{
     int *islptr;
     int x,y;
     int i,j,k,stklen;
     int stick1,stick2,stick3,stick4;
     int necorn,swcorn;
     int nmtns,sizmtn,mtnwid[MXMTSZ],mtnx,mtny,mtnchg;
     int nfrss,sizfrs,frswid[MXLKSZ],frsx,frsy,frschg,frsxk;
 
     for (islptr=island,i=0 ; i < ISLWID*ISLHGT ; i++) {
          *islptr++=247+WTRATR;
     }
     for (y=VWATER+VBLHGT ; y < ISLHGT-VWATER-VBLHGT ; y++) {
          islptr=isle(HWATER+VBLWID,y);
          for (x=HWATER+VBLWID ; x < ISLWID-HWATER-VBLWID ; x++) {
               *islptr++=' '+MTNATR;
          }
     }
 
     stick1=rnd()%VBLHGT;
     stick2=rnd()%VBLWID;
     stick3=rnd()%VBLHGT;
     stick4=rnd()%VBLWID;
 
     hilim=VBLHGT;
     minb4c=MINHWS;
     curr=stick1;
     dir=1;
     count=0;
     for (x=HWATER+VBLWID ; x < ISLWID-HWATER-VBLWID+stick2 ; x++) {
          stklen=cookup();
          for (i=0,y=VWATER+VBLHGT-stklen ; i < stklen ; i++,y++) {
               *isle(x,y)=' '+MTNATR;
          }
     }
     necorn=stklen;
     curr=stick3;
     dir=1;
     count=0;
     for (x=ISLWID-HWATER-VBLWID-1 ; x >= HWATER+VBLWID-stick4 ; x--) {
          stklen=cookup();
          for (i=0,y=ISLHGT-VWATER-VBLHGT ; i < stklen ; i++,y++) {
               *isle(x,y)=' '+MTNATR;
          }
     }
     swcorn=stklen;
     hilim=VBLWID;
     minb4c=MINVWS;
     curr=stick2;
     dir=1;
     count=0;
     for (y=VWATER+VBLHGT-necorn ; y < ISLHGT-VWATER-VBLHGT+stick3 ; y++) {
          stklen=cookup();
          if (y < VWATER+VBLHGT && stklen < stick2) {
               stklen=stick2;
               dir=1;
          }
          for (i=0,x=ISLWID-HWATER-VBLWID+stklen-1 ; i < stklen ; i++,x--) {
               if (*isle(x,y) == ' '+MTNATR) {
                    break;
               }
               *isle(x,y)=' '+MTNATR;
          }
     }
     curr=stick4;
     dir=1;
     count=0;
     for (y=ISLHGT-VWATER-VBLHGT-1+swcorn ; y >= VWATER+VBLHGT-stick1 ; y--) {
          stklen=cookup();
          if (y > ISLHGT-VWATER-VBLHGT-1 && stklen < stick4) {
               stklen=stick4;
               dir=1;
          }
          for (i=0,x=HWATER+VBLWID-stklen ; i < stklen ; i++,x++) {
               if (*isle(x,y) == ' '+MTNATR) {
                    break;
               }
               *isle(x,y)=' '+MTNATR;
          }
     }
     nmtns=rnd()%MXMTCT+1;
     for (i=0 ; i < nmtns ; i++) {
          sizmtn=rnd()%MXMTSZ;
          hilim=8;
          minb4c=2;
          curr=2;
          dir=1;
          count=0;
          for (j=0 ; j < sizmtn ; j++) {
               mtnwid[j]=cookup();
          }
          hilim=8;
          minb4c=1;
          curr=rnd()%9;
          dir=((rnd()&1) ? 1 : -1);
          count=0;
          mtnx=rnd()%ISLWID;
          mtny=rnd()%ISLHGT;
          for (j=0 ; j < sizmtn ; j++) {
               if (++mtny >= ISLHGT) {
                    break;
               }
               mtnchg=cookup()-4;
               if (abs(mtnchg) >= mtnwid[j]) {
                    mtnwid[j]=abs(mtnchg)+1;
               }
               mtnx+=mtnchg;
               for (k=0 ; k < mtnwid[j] ; k++) {
                    if (mtnx+k < ISLWID
                     && mtnx+k > 0
                     && *isle(mtnx+k,mtny) == ' '+MTNATR) {
                         *isle(mtnx+k,mtny)=239+MTNATR;
                    }
               }
          }
     }
     nfrss=rnd()%MXFRCT;
     for (i=0 ; i < nfrss ; i++) {
          sizfrs=rnd()%MXFRSZ;
          hilim=35;
          minb4c=2;
          curr=rnd()%30+5;
          dir=1;
          count=0;
          for (j=0 ; j < sizfrs ; j++) {
               frswid[j]=cookup();
          }
          frswid[0]=frswid[1]-(rnd()%8)-2;
          frswid[sizfrs-1]=frswid[sizfrs-2]-(rnd()%8)-2;
          hilim=2;
          minb4c=1;
          curr=1;
          dir=((rnd()&1) ? 1 : -1);
          count=0;
          frsx=rnd()%ISLWID;
          frsy=rnd()%ISLHGT;
          for (j=0 ; j < sizfrs ; j++) {
               if (++frsy >= ISLHGT) {
                    break;
               }
               frschg=cookup()-1;
               frsx+=frschg;
               for (k=0 ; k < frswid[j] ; k++) {
                    frsxk=frsx+k-frswid[j]/2;
                    if (frsxk < ISLWID
                     && frsxk > 0
                     && *isle(frsxk,frsy) == ' '+MTNATR) {
                         *isle(frsxk,frsy)=5+FRSATR;
                    }
               }
          }
     }
     nfrss=rnd()%MXLKCT;
     for (i=0 ; i < nfrss ; i++) {
          sizfrs=rnd()%MXLKSZ;
          frswid[0]=2*sizfrs;
          for (j=1 ; j < sizfrs/2 ; j++) {
               frswid[j]=frswid[j-1]+rnd()%((sizfrs/2-j)*3);
          }
          for ( ; j < sizfrs ; j++) {
               frswid[j]=frswid[j-1]-rnd()%((j-sizfrs/2+1)*3);
          }
          hilim=2;
          minb4c=1;
          curr=1;
          dir=((rnd()&1) ? 1 : -1);
          count=0;
          frsx=rnd()%ISLWID;
          frsy=rnd()%ISLHGT;
          for (j=0 ; j < sizfrs ; j++) {
               if (++frsy >= ISLHGT) {
                    break;
               }
               frschg=cookup()-1;
               frsx+=frschg;
               for (k=0 ; k < frswid[j] ; k++) {
                    frsxk=frsx+k-frswid[j]/2;
                    if (frsxk < ISLWID
                     && frsxk > 0) {
                         *isle(frsxk,frsy)=247+WTRATR;
                    }
               }
          }
     }
}
 
cookup()
{
     int newdir,new,chg;
 
     if (rnd()%minb4c > 0) {
          new=curr;
     }
     else {
          newdir=(rnd()%7 < 4 ? -1 : 1);
          if (newdir != dir) {
               if (count < minb4c) {
                    newdir=0;
               }
               else {
                    dir=newdir;
               }
          }
          for (chg=1 ; chg != 0 && (chg&rnd()) == 0 ; chg+=chg) {
          }
          new=curr+(chg&7)*newdir;
          if (new < 0) {
               new=0;
          }
     }
     if (new > hilim) {
          new=hilim;
     }
     if (new == curr) {
          count+=1;
     }
     else {
          curr=new;
          count=0;
     }
     return(new);
}
 
iniscn(scnnum,where)               /* initialize a screen from screen image */
int scnnum;
char *where;
{
     movmem(scntbl+scnnum*4000,where,4000);
}
 
inibas(bn)
int bn;
{
     int candx,candy;
     int i,j;
     int *ip;
     static char basplt[5][10]={
           32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
           32, 32, 32, 32,219,219, 32, 32, 32, 32,
           32, 32,219,219, 32, 32,219,219, 32, 32,
           32, 32, 32, 32,219,219, 32, 32, 32, 32,
           32, 32, 32, 32, 32, 32, 32, 32, 32, 32
     };
 
     setbas(bn);
     for (i=50 ; i >= 0 ; i--) {
          do {
               candx=rnd()%(LNDWID-8)+HWATER+3;
               candy=rnd()%(LNDHGT-5)+VWATER+2;
          } while (*isle(candx,candy) == 247+WTRATR);
          basp->bx=candx;
          basp->by=candy;
          if (i > 25) {
               for (j=0 ; j < basn ; j++) {
                    if (abs(base[j].bx-candx) < 30
                     && abs(base[j].by-candy) < 10) {
                         break;
                    }
               }
          }
          else {
               for (j=0 ; j < basn ; j++) {
                    if (abs(base[j].bx-candx) < 12
                     && abs(base[j].by-candy) < 5) {
                         break;
                    }
               }
          }
          if (j == basn) {
               break;
          }
     }
     for (i=0 ; i < 5 ; i++) {
          for (j=0,ip=isle(basp->bx-4,basp->by-2+i) ; j < 10 ; j++) {
               *ip++=basplt[i][j]+BASATR;
          }
     }
     if (disp) {
          wcoord(0,basp->bx-18,basp->by-6);
          setatr(AT4WRT);
          locate(33,15);
          printf("%3d",basp->bx);
          locate(37,15);
          printf("%2d",basp->by);
          locate(0,0);
     }
     basp->cond=3;
     basp->lasers=24;
     basp->neutrons=22;
     basp->seekers=9;
     basp->tanks=14;
     basp->angle=900;
     basp->range=100;
     basp->bleft=8;
     basp->shldtmr=0;
     basp->dfshld=8;
     initnk(0);
     initnk(1);
     initnk(2);
     initnk(3);
}
 
initnk(tn)
int tn;
{
     static int roffx[4]={-4,5,-4,5};
     static int roffy[4]={-2,-2,2,2};
 
     settnk(tn);
     rfresh();
     moveto(tnkp->rx=basp->bx+roffx[tnkn],tnkp->ry=basp->by+roffy[tnkn]);
     tnkp->behind=' '+MTNATR;
}
 
rfresh()
{
     char *rimptr;
     int i;
 
     if (disp) {
          for (i=0,rimptr=rimbuf ; i < 5 ; i++,rimptr+=21*2) {
               movmem(rimptr,pysptr+(tnkrow+i)*160+(160+58*2),21*2);
          }
     }
     tnkp->cond=3;
     tnkp->phasers=28;
     tnkp->mines=14;
     tnkp->pods=12;
     tnkp->fuel=500;
}
 
setpyr(pn)
int pn;
{
     pyrn=pn;
     pyrp=&player[pyrn];
}
 
setbas(bn)
int bn;
{
     basn=bn;
     basp=&base[basn];
     disp=(basp->bplayr == self);
}
 
settnk(tn)
int tn;
{
     tnkn=tn;
     tnkp=&(basp->tank[tnkn]);
     tnkrow=6*tnkn;
}
 
