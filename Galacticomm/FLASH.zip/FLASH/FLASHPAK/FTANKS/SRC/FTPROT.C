/***************************************************************************
 *   FTPROT.C       Flash Tanks protection stuff                           *
 *                                                                         *
 *   This code is supplied only as an example of encrypting registration   *
 *   numbers and using them with Flash games.                              *
 *                                                                         *
 *                                                     10/15/91 Les Bird   *
 ***************************************************************************/

#include "stdio.h"

char rg[]={"999999999"};
char rs[10];
char rt[]={"513"};

long rn;

char *comput(stg)             /* decodes the encrypted registration number */
char *stg;                    /* ..which is patched in rg[] (above) by an  */
{                             /* ..external patching program.              */
     int n;
     char c,*ptr;

     for (n=0,ptr=stg ; n < 9 ; n++,ptr++) {
          c=*ptr;
          *ptr=(c^26)+n;
     }
     return(stg);
}

regok()
{
     int n,temp;
     char rgs[10];

     setmem(rgs,10,0);
     sprintf(rgs,"%09ld",rn);
     for (n=0 ; n < strlen(rgs) ; n++) {
          temp+=rgs[n];
     }
     temp^=91;
     setmem(rgs,10,0);
     sprintf(rgs,"%3d",temp);
     return((strncmp(rgs,rt) != 0));
}
