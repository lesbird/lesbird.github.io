/***************************************************************************/
/*   PROTCT.C  - Encoded serial number protection module                   */
/*                                                                         */
/*                                                     12/28/91 - Les Bird */
/***************************************************************************/

#include "stdlib.h"
#include "fscomm.h"

int                           /* aborts Flash pool if invalid serial #     */
chkser(long lupser,long flsser)
{
     if (lupser == 0L) {
          return(1);
     }
     else if (flsser >= 900000000L && flsser-900000000L != lupser) {
          return(1);
     }
     return(0);
}

void
entgam(void)
{
     char namver[21];

     sprintf(namver,"Flash %s %s",GAMNAM,GAMVER);
     printf("\n... Attempting to enter %s ...\n",namver);
     flashm(namver,0L);
}
