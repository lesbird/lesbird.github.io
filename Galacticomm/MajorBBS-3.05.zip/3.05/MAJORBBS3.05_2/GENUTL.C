/***************************************************************************
 *                                                                         *
 *   GENUTL.C                                                              *
 *                                                                         *
 *   Copyright (C) 1987 GALACTICOMM, Inc.      All Rights Reserved.        *
 *                                                                         *
 *   This file contains miscellaneous utility functions.                   *
 *                                                                         *
 *                                            - T. Stryker 6/10/86         *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "setjmp.h"
 
jmp_buf disaster;             /* master error-recovery longjmp save block  */
 
int _fmode=0;                 /* lattice global for non/text xlation       */
 
char *alcmem(size)
int size;
{
     char *getmem(),*retval;
 
     if ((retval=getmem(size)) == NULL) {
          catamsg("FREE MEMORY POOL EXHAUSTED");
          longjmp(&disaster,1);
     }
     return(retval);
}
 
deamem(ptr,size)
char *ptr;
int size;
{
     if (rlsmem(ptr,size) != 0) {
          catastro("FATAL ERROR ATTEMPTING TO RELEASE MEMORY");
     }
}
 
catamsg(string,parm1,parm2)
char *string;
long parm1,parm2;
{
     setwin(0L,0,0,79,24,1);
     printf("\n*** ");
     printf(string,parm1,parm2);
     printf(" ***\7\n");
}
 
catastro(string,parm1,parm2)
char *string;
long parm1,parm2;
{
     catamsg(string,parm1,parm2);
     longjmp(&disaster,2);
}
 
usrcat(arg)
int arg;
{
     longjmp(&disaster,arg);
}
