/***************************************************************************
 *                                                                         *
 *   DATNTIM.C                                                             *
 *                                                                         *
 *   Copyright (C) 1987 GALACTICOMM, Inc.      All Rights Reserved.        *
 *                                                                         *
 *   These routines act like those in a well-known C utility library       *
 *   by the same names, at least for the limited purposes to which         *
 *   they are put by the Major BBS software.                               *
 *                                                                         *
 *                                            - T. Stryker 11/11/86        *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "dos.h"
 
char *date(sptr,mode)
char *sptr;
int mode;
{
     union REGS regs;
     static char moname[][4]={"JAN","FEB","MAR","APR","MAY","JUN",
                              "JUL","AUG","SEP","OCT","NOV","DEC"};
 
     regs.h.ah=0x2A;
     int86(0x21,&regs,&regs);
     switch (mode) {
     case 2:
          sprintf(sptr,"%02d/%02d/%02d",regs.h.dh,regs.h.dl,regs.x.cx%100);
          sptr+=8;
          break;
     case 7:
          sprintf(sptr,"%02d %3s %4d",regs.h.dl,moname[regs.h.dh-1],regs.x.cx);
          sptr+=11;
          break;
     }
     return(sptr);
}
 
char *time(sptr,mode)
char *sptr;
int mode;
{
     union REGS regs;
     int hour,minute;
 
     regs.h.ah=0x2C;
     int86(0x21,&regs,&regs);
     switch (mode) {
     case 2:
          sprintf(sptr,"%02d:%02d:%02d",regs.h.ch,regs.h.cl,regs.h.dh);
          sptr+=8;
          break;
     case 5:
          sprintf(sptr,"%02d:%02d",regs.h.ch,regs.h.cl);
          sptr+=5;
          break;
     }
     return(sptr);
}
