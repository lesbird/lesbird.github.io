/***************************************************************************
 *                                                                         *
 *   TYPAUDIT.C                                                            *
 *                                                                         *
 *   Copyright (C) 1986, 1987 by GALACTICOMM, Inc.  All Rights Reserved.   *
 *                                                                         *
 *   This is the Major BBS audit trail output utility.                     *
 *                                                                         *
 *                                            - T. Stryker 03/31/87        *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "setjmp.h"
#include "btvstf.h"
#include "majorbbs.h"
 
extern jmp_buf disaster;      /* master error-recovery longjmp save block  */
 
main()
{
     BTVFILE *fp;
     char audrec[AUDSIZ];
     static char *filnam={"auditrai.dat"};
 
     if (setjmp(&disaster)) {
          exit();
     }
     fp=opnbtv(filnam,AUDSIZ);
     setbtv(fp);
     if (!qlobtv(0)) {
          catastro("file is empty!");
     }
     do {
          gcrbtv(audrec,0);
          fprintf(stdout,"%s\n",audrec);
     } while (qnxbtv());
     clsbtv(fp);
}
 
