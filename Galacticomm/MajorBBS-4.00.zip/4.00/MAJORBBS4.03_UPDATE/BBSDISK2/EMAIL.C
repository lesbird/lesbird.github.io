/***************************************************************************
 *                                                                         *
 *   EMAIL.C                                                               *
 *                                                                         *
 *   Copyright (C) 1987 GALACTICOMM, Inc.      All Rights Reserved.        *
 *                                                                         *
 *   This is the Major BBS electronic mail service handler.                *
 *                                                                         *
 *                                  - T. Stryker & S. Brinker 8/8/87       *
 *                                                                         *
 ***************************************************************************/
 
#include "stdio.h"
#include "ctype.h"
#include "majorbbs.h"
#include "usracc.h"
#include "btvstf.h"
#include "email.h"
 
int inieml(),ealert(),email(),dfsthn(),emlmcu(),emlhup(),dlaeml(),clseml();
 
#define EMLSTT      11        /* EMAIL state                          */
struct module module11={      /* module interface block               */
     'E',                     /*    main menu select character        */
     "Electronic Mail",       /*    description for main menu         */
     inieml,                  /*    system initialization routine     */
     ealert,                  /*    user logon supplemental routine   */
     email,                   /*    input routine if selected         */
     dfsthn,                  /*    status-input routine if selected  */
     emlhup,                  /*    hangup (lost carrier) routine     */
     emlmcu,                  /*    midnight cleanup routine          */
     dlaeml,                  /*    delete-account routine            */
     clseml                   /*    finish-up (sys shutdown) routine  */
};
 
static
FILE *emlmb;                  /* email named-message file block pointer    */
static
BTVFILE *emlbb,               /* email btrieve message file block pointer  */
        *sfsbb;               /* email "sofars" new-msg file block pointer */
 
#define TPCSIZ  41            /* email message maximum topic size          */
#define MAXVBT 927            /* maximum variable-length text size         */
#define EMLTCK  95            /* "ticks" (credits) eaten per message       */
#define MAXSUB  20            /* maximum number of sub-boards              */
#define MAXNCT   5            /* max number of commands concatted at once  */
 
struct emlstf {               /* email message record structure on disk    */
     long msgno;              /*   message number                          */
     char whofrm[UIDSIZ];     /*   user-id of creator                      */
     char whoto[UIDSIZ];      /*   user-id of recipient, or sub-board name */
     char topic[TPCSIZ];      /*   message topic                           */
     char credat[DATSIZ];     /*   message creation date                   */
     char vbltxt[MAXVBT];     /*   variable-length message text            */
};
static
struct emlusr {               /* email user data                           */
     long fpos;               /*   file position                           */
     int keynum;              /*   key number in use                       */
     int subbdn;              /*   sub-board # being scanned (-1 if none)  */
     int vtxlen;              /*   size of variable text area during build */
     int lineno;              /*   line number to be modified              */
     int flags;               /*   bit "flags"                             */
     long sofars[MAXSUB];     /*   highest msg#s seen so far, by sub-board */
     struct emlstf eblk;      /*   email message data block                */
} *emlusr,                    /* dynamically allocated emlusr array        */
  *emlptr;                    /* ptr to email data for current user        */
 
                              /* bit "flag" definitions                    */
#define INAUTO 1              /*   user is auto-replying to a message      */
#define CREATE 2              /*   SYSOP creating new sub-board            */
#define NEEDRF 4              /*   sub-board list needs refresh            */
#define NOTSAT 8              /*   "not satisfied"- no makeml til mod done */
#define GOTSFS 0x100          /*   got "sofars" already, ready to search   */
 
struct compos {               /* composite recipient/msg# for # searches   */
     char whoto[UIDSIZ];      /*   user-id of recipient, or sub-board name */
     long msgno;              /*   message number                          */
} compos;
 
struct newmrc {               /* new message locator database record format*/
     char userid[UIDSIZ];     /*   user-id                                 */
     long sofars[MAXSUB];     /*   highest msg#s seen so far, by sub-board */
     char spare[100-90];      /*   spare, decrease when adding more        */
} newmrc;
 
static
int newstt;                   /* new substate for this state               */
static
char *sublst;                 /* list of sub-boards and description (pool) */
static
char subid[MAXSUB][UIDSIZ];   /* names of sub-boards                       */
static
int numsbs;                   /* number of sub-boards currently active     */
static
char *cmscan;                 /* input command scanning pointer            */
static
int largv0;                   /* length of first arg                       */
 
extern
BTVFILE *accbb;               /* user account btrieve file block pointer   */
extern
struct usracc usracc[NTERMS], /* user accounting block array               */
              *usaptr;        /* user accounting block pointer for usrnum  */
extern
int usrnum;                   /* global user-number (channel) in effect    */
extern
struct user *usrptr,          /* global pointer to user data in effect     */
            user[NTERMS];     /* user volatile-data structure array        */
extern
char input[INPSIZ],           /* raw user input data buffer                */
     *margv[INPSIZ/2],        /* array of ptrs to word starts, a la argv[] */
     *margn[INPSIZ/2];        /* array of ptrs to word ends, for rstrin()  */
extern
int margc,                    /* number of words in margv[], a la argc     */
    inplen,                   /* overall raw input string length           */
    pfnlvl;                   /* profanity level of current input (0-3)    */
 
extern int othusn;            /* general purpose other-user channel number */
extern struct user *othusp;   /* gen purp other-user user structure ptr    */
extern struct usracc *othuap; /* gen purp other-user accounting data ptr   */
extern
struct sysvbl sv;             /* sys-variables record instance for updates */
extern
char prfbuf[];                /* 2K buffer used by prfutl, used for staging*/
 
long atol();
char *spr(),*startof();
FILE *opnmsg();
 
inieml()
{
     char *alcmem();
 
     emlusr=(struct emlusr *)alcmem(NTERMS*sizeof(struct emlusr));
     setmem(emlusr,NTERMS*sizeof(struct emlusr),0);
     emlmb=opnmsg("email.mcv");
     emlbb=opnbtv("email.dat",sizeof(struct emlstf));
     sfsbb=opnbtv("sofars.dat",sizeof(struct newmrc));
     emlptr=&(emlusr[0]);
     rfshsb();
}
 
ealert()
{
     setbtv(emlbb);
     if (qeqbtv(usaptr->userid,2)) {
          prf("\7There is E-MAIL waiting for you!\r");
     }
}
 
email()
{
     char *point1,*point2;
     int numcat;
 
     setmbk(emlmb);
     setbtv(emlbb);
     newstt=usrptr->substt;
     emlptr=&(emlusr[usrnum]);
     if (input[0] == '\0' ||
        (margc == 0 && newstt != CONTXT && newstt != MODLIN)) {
          rfrshs(newstt);
     }
     else if (margc == 1 && sameas(margv[0],"x")) {
          if (newstt == REPRMT) {
               prfmsg(MAINEX);
               return(0);
          }
          emlptr->flags&=~(INAUTO+CREATE+NOTSAT);
          prfmsg(EX2MAI);
          prfmsg(usrptr->substt=REPRMT);
          btumil(usrnum,DFTIMX);
     }
     else if (usrptr->pfnacc > MAXPFN) {
          btuinj(usrnum,RING);
          return(1);
     }
     else if (pfnlvl > 2) {
          errmsg(PFNMSG);
     }
     else if (pfnlvl == 2) {
          errmsg(RAUNCH);
     }
     else {
          for (numcat=0 ; numcat < MAXNCT ; numcat++) {
               cmscan=margv[0];
               clrprf();
               largv0=strlen(margv[0])-1;
               rstrin();
               setmbk(emlmb);
               setbtv(emlbb);
               switch (newstt) {
               case 0:
                    prfmsg(INTRO);
                    newstt=REPRMT;
                    loasfs();
                    break;
               case REPRMT:
                    sreprmt();
                    break;
               case REWHAT:
                    srewhat();
                    break;
               case SELSUB:
                    sselsub();
                    break;
               case SCOSCN:
               case SCFSCN:
                    sscoscn();
                    break;
               case PUBOPT:
                    spubopt();
                    break;
               case PRVOPT:
                    sprvopt();
                    break;
               case DELGUY:
                    sdelguy();
                    break;
               case WHOTO:
                    swhoto();
                    break;
               case GIVTOP:
                    sgivtop();
                    break;
               case CONTXT:
                    if (scontxt()) {
                         return(1);
                    }
                    break;
               case RUSAT:
                    srusat();
                    break;
               case MODWHT:
                    smodwht();
                    break;
               case RAFTLN:
                    sraftln();
                    break;
               case MODTPC:
                    smodtpc();
                    break;
               case MODLIN:
                    smodlin();
                    break;
               case DELMSN:
                    sdelmsn();
                    break;
               default:
                    catastro("EMAIL: usrptr->substt is %d for user %d",
                         usrptr->substt,usrnum);
               }
               usrptr->substt=newstt;
               cmscan+=1;
               movmem(cmscan,input,strlen(cmscan)+1);
               parsin();
               if (margc == 0) {
                    break;
               }
          }
     }
     outprf(usrnum);
     if (emlptr->flags&NEEDRF) {
          emlptr->flags&=~NEEDRF;
          rfshsb();
     }
     return(1);
}
 
loasfs()
{
     if (!(emlptr->flags&GOTSFS)) {
          setbtv(sfsbb);
          if (acqbtv(&newmrc,usaptr->userid,0)) {
               movmem(newmrc.sofars,emlptr->sofars,MAXSUB*sizeof(long));
          }
          else {
               movmem(usaptr->userid,newmrc.userid,UIDSIZ);
               insbtv(&newmrc);
          }
          emlptr->flags|=GOTSFS;
     }
}
 
sreprmt()
{
     switch (toupper(*margv[0])) {
     case 'G':
          errmsg(GENINF);
          break;
     case 'R':
          prfmsg(newstt=REWHAT);
          break;
     case 'W':
          if (usaptr->tckavl <= EMLTCK) {
               movmem("Sysop\0\0\0\0",emlptr->eblk.whoto,UIDSIZ);
               prfmsg(WSYSOP);
               prfmsg(newstt=GIVTOP,TPCSIZ-1);
               btumil(usrnum,TPCSIZ-1);
          }
          else {
               usaptr->tckavl-=EMLTCK;
               prfmsg(SUBAVL,sublst);
               prfmsg(newstt=WHOTO);
               btumil(usrnum,UIDSIZ-1);
          }
          break;
     case 'M':
          if (usrptr->class < PAYING) {
               blwoff(NOMOD);
          }
          else {
               prfmsg(newstt=MODWHT);
          }
          break;
     case 'D':
          prfmsg(newstt=DELMSN);
          break;
     case '?':
          prfmsg(INTRO);
          break;
     default:
          errmsg(CNOTIL);
     }
}
 
srewhat()
{
     if (isdigit(*margv[0])) {
          emlptr->eblk.msgno=atol(margv[0]);
          if (!acqbtv(&(emlptr->eblk),&(emlptr->eblk.msgno),0)) {
               errmsg(NSUCHN);
               return;
          }
          if (!(sameas(emlptr->eblk.whofrm,usaptr->userid)
             || sameas(emlptr->eblk.whoto ,usaptr->userid)
             || emlptr->eblk.whoto[0] == '@'
             || (usrptr->flags&ISYSOP))) {
               errmsg(NOREAD,spr("%lu",emlptr->eblk.msgno));
               return;
          }
          prf("\r");
          sumams();
          prf("%s\r",emlptr->eblk.vbltxt);
          prfmsg(newstt=REPRMT);
          cmscan+=largv0;
     }
     else {
          switch (toupper(*margv[0])) {
          case 'T':
               bgnrd(usaptr->userid,2,NOMSGT);
               break;
          case 'F':
               bgnrd(usaptr->userid,1,NOMSGF);
               break;
          case '@':
          case 'A':
               prfmsg(CHOSUB,sublst);
               prfmsg(newstt=SELSUB);
               break;
          default:
               errmsg(REWPLS);
          }
     }
}
 
sselsub()
{
     int i;
 
     if (sameto(margv[0],"?")) {
          prfmsg(CHOSUB,sublst);
          prfmsg(SELSUB);
     }
     else {
          if (*margv[0] != '@' && inplen < INPSIZ-1) {
               movmem(margv[0],margv[0]+1,strlen(margv[0])+1);
               *margv[0]='@';
               largv0+=1;
          }
          for (i=0 ; i < MAXSUB ; i++) {
               if (emlsto(margv[0],subid[i])) {
                    emlptr->keynum=2;
                    emlptr->subbdn=i;
                    movmem(subid[i],emlptr->eblk.whoto,UIDSIZ);
                    emlgo(emlptr->sofars[i]+1,NEWSTF,NEWSTF,NONEWS);
                    cmscan+=largv0;
                    return;
               }
          }
          errmsg(NOSUB,margv[0]);
     }
}
 
emlsto(shorts,longs)
char *shorts,*longs;
{
     while (*shorts != '\0' && *shorts != ' ') {
          if (tolower(*shorts) != tolower(*longs)) {
               return(0);
          }
          shorts+=1;
          longs+=1;
     }
     return(1);
}
 
sscoscn()
{
     long nxtnum;
     char *tpcdcd;
 
     estabc();
     switch (toupper(*margv[0])) {
     case '?':
          if (emlptr->keynum == 1) {
               prfmsg(SCFHLP);
               prfmsg(SCFSCN);
          }
          else {
               prfmsg(SCOHLP);
               prfmsg(SCOSCN);
          }
          break;
     case 'N':
          nxteml();
          break;
     case 'P':
          lsteml();
          break;
     case 'R':
          prf("%s\r",emlptr->eblk.vbltxt);
          updsof();
          if (sameas(usaptr->userid,emlptr->eblk.whofrm)) {
               prfmsg(newstt=DELGUY);
          }
          else if (sameas(usaptr->userid,emlptr->eblk.whoto)) {
               prfmsg(newstt=PRVOPT);
          }
          else {
               prfmsg(newstt=PUBOPT);
          }
          break;
     case '#':
          if (emlptr->keynum == 1) {
               errmsg(CNOTIL);
               break;
          }
          nxtnum=0;
          for (tpcdcd=emlptr->eblk.topic ; *tpcdcd != '\0' ; tpcdcd++) {
               if (isdigit(*tpcdcd)) {
                    nxtnum=nxtnum*10+*tpcdcd-'0';
               }
          }
          if (nxtnum == 0) {
               errmsg(RPNMNG);
          }
          else {
               emlgo(nxtnum,MISSHI,0,MISSLO);
          }
          break;
     default:
          if (emlptr->keynum == 1 || !isdigit(*margv[0])) {
               errmsg(CNOTIL);
          }
          else {
               cmscan+=largv0;
               emlgo(atol(margv[0]),MISSHI,0,MISSLO);
          }
     }
}
 
emlgo(nxtnum,msghi,msgeq,msglo)
long nxtnum;
int msghi,msgeq,msglo;
{
     movmem(emlptr->eblk.whoto,compos.whoto,UIDSIZ);
     compos.msgno=nxtnum;
     if (agebtv(&(emlptr->eblk),&compos,3)
      && sameas(emlptr->eblk.whoto,compos.whoto)) {
          if (emlptr->eblk.msgno != compos.msgno) {
               prfmsg(msghi);
          }
          else if (msgeq != 0) {
               prfmsg(msgeq);
          }
     }
     else if (altbtv(&(emlptr->eblk),&compos,3)
      && sameas(emlptr->eblk.whoto,compos.whoto)) {
          prfmsg(msglo);
     }
     else {
          catastro("EMLGO: NO MESSAGE FOUND");
     }
     sumams();
     prfsco();
}
 
spubopt()
{
     switch (toupper(*margv[0])) {
     case 'R':
          if (usaptr->tckavl > EMLTCK) {
               movmem(emlptr->eblk.whofrm,
                      emlptr->eblk.whoto,UIDSIZ);
               areply();
          }
          else {
               errmsg(LIVONL);
          }
          break;
     case 'P':
          if (usaptr->tckavl > EMLTCK) {
               areply();
          }
          else {
               errmsg(LIVONL);
          }
          break;
     case 'C':
          estabc();
          nxteml();
          break;
     default:
          errmsg(CNOTIL);
     }
}
 
sprvopt()
{
     switch (toupper(*margv[0])) {
     case 'R':
          if (usaptr->tckavl > EMLTCK) {
               movmem(emlptr->eblk.whofrm,
                      emlptr->eblk.whoto,UIDSIZ);
               areply();
          }
          else {
               errmsg(LIVONL);
          }
          break;
     case 'D':
          estabc();
          if (confli()) {
               prfmsg(USING);
               prfmsg(KEEPIN);
          }
          else {
               prfmsg(DELING);
               deleml();
          }
          nxteml();
          break;
     case 'K':
          estabc();
          nxteml();
          break;
     default:
          errmsg(CNOTIL);
     }
}
 
sdelguy()
{
     switch (toupper(*margv[0])) {
     case 'D':
          estabc();
          if (confli()) {
               prfmsg(USING);
               prfmsg(KEEPIN);
          }
          else {
               prfmsg(DELING);
               deleml();
          }
          nxteml();
          break;
     case 'K':
          estabc();
          nxteml();
          break;
     default:
          errmsg(CNOTIL);
     }
}
 
swhoto()
{
     int i;
 
     if (sameas(margv[0],"?")) {
          prfmsg(SUBAVL,sublst);
          prfmsg(WHOTO);
     }
     else if (*margv[0] == '@') {
          for (i=0 ; i < MAXSUB ; i++) {
               if (emlsto(margv[0],subid[i])) {
                    movmem(subid[i],emlptr->eblk.whoto,UIDSIZ);
                    prfmsg(newstt=GIVTOP,TPCSIZ-1);
                    btumil(usrnum,TPCSIZ-1);
                    cmscan+=(margn[0]-margv[0])-1;
                    break;
               }
          }
          if (i == MAXSUB) {
               if (usrptr->flags&ISYSOP) {
                    if (numsbs < MAXSUB) {
                         *margn[0]='\0';
                         addsub(margv[0]);
                         cmscan+=largv0;
                         rstrin();
                    }
                    else {
                         blwoff(NOROOM);
                    }
               }
               else {
                    errmsg(NOSUB);
               }
          }
     }
     else {
          *margn[0]='\0';
          strcpy(emlptr->eblk.whoto,margv[0]);
          zonkhl(emlptr->eblk.whoto);
          setbtv(accbb);
          if (qeqbtv(emlptr->eblk.whoto,0)) {
               prfmsg(newstt=GIVTOP,TPCSIZ-1);
               btumil(usrnum,TPCSIZ-1);
               cmscan+=largv0;
               rstrin();
          }
          else {
               errmsg(UIDNXI);
          }
     }
}
 
sgivtop()
{
     btumil(usrnum,DFTIMX);
     input[TPCSIZ-1]='\0';
     strcpy(emlptr->eblk.topic,margv[0]);
     prfmsg(ENTTXT,MAXVBT-1);
     newstt=CONTXT;
     emlptr->eblk.vbltxt[0]='\0';
     emlptr->vtxlen=0;
     zapcnc();
}
 
scontxt()
{
     int tl;
 
     if (!sameas(input,"OK")) {
          if (inplen > (tl=MAXVBT-(emlptr->vtxlen)-2)) {
               prfmsg(LLTRUN,MAXVBT-1);
               input[tl]='\0';
               ademln();
          }
          else if (inplen >= tl-5) {
               ademln();
          }
          else {
               btumil(usrnum,min(tl-inplen-1,DFTIMX));
               ademln();
               return(1);
          }
     }
     btumil(usrnum,DFTIMX);
     if (emlptr->flags&INAUTO) {
          emlptr->flags&=~INAUTO;
          if (emlptr->vtxlen != 0) {
               makeml();
               prfmsg(ACONFM,spr("%05lu",emlptr->eblk.msgno));
               estabc();
               if (emlptr->eblk.whoto[0] != '@') {
                    if (confli()) {
                         prfmsg(ARCONF);
                    }
                    else {
                         deleml();
                    }
               }
               nxteml();
               if (emlptr->eblk.msgno == sv.emltot) {
                    updsof();
                    clrprf();
                    nxteml();
               }
          }
          else {
               prfmsg(NORPYE);
               estabc();
               nxteml();
          }
     }
     else if (emlptr->vtxlen != 0) {
          prfmsg(newstt=RUSAT);
     }
     else {
          blwoff(NOMSGE);
     }
     zapcnc();
     return(0);
}
 
updsof()
{
     if (emlptr->subbdn >= 0
      && emlptr->eblk.msgno > emlptr->sofars[emlptr->subbdn]) {
          emlptr->sofars[emlptr->subbdn]=emlptr->eblk.msgno;
     }
}
 
srusat()
{
     switch (tolower(*margv[0])) {
     case 'y':
          makeml();
          wrtcnf();
          prfmsg(newstt=REPRMT);
          break;
     case 'n':
          movmem(usaptr->userid,emlptr->eblk.whofrm,UIDSIZ);
          dmsg4m();
          emlptr->flags|=NOTSAT;
          prfmsg(INDLCH);
          newstt=RAFTLN;
          break;
     default:
          errmsg(YORN);
     }
}
 
smodwht()
{
     emlptr->eblk.msgno=atol(margv[0]);
     if (!acqbtv(&(emlptr->eblk),&(emlptr->eblk.msgno),0)) {
          blwoff(NSUCHN);
          return;
     }
     if (!(sameas(emlptr->eblk.whofrm,usaptr->userid)
        || (usrptr->flags&ISYSOP))) {
          blwoff(UDONTO,spr("%05lu",emlptr->eblk.msgno));
          return;
     }
     cmscan+=largv0;
     dmsg4m();
     emlptr->fpos=absbtv();
     prfmsg(INDLCH);
     newstt=RAFTLN;
}
 
sraftln()
{
     int tl;
 
     switch (tolower(*margv[0])) {
     case 'r':
          dmsg4m();
          prfmsg(RAFTLN);
          break;
     case 'a':
          if (emlptr->flags&NOTSAT) {
               emlptr->flags&=~NOTSAT;
               makeml();
          }
          else {
               gabbtv(NULL,emlptr->fpos,0);
               updbtv(&emlptr->eblk);
          }
          wrtcnf();
          if ((usrptr->flags&ISYSOP) && emlptr->eblk.whoto[0] == '@') {
               emlptr->flags|=NEEDRF;
          }
          prfmsg(newstt=REPRMT);
          break;
     case 't':
          prfmsg(newstt=MODTPC);
          btumil(usrnum,TPCSIZ-1);
          break;
     default:
          if (isdigit(*margv[0])) {
               emlptr->lineno=atoi(margv[0]);
               if ((tl=nallow(emlptr->lineno)) > 1) {
                    prfmsg(newstt=MODLIN,emlptr->lineno,
                           (emlptr->vtxlen=tl));
                    btumil(usrnum,tl);
                    cmscan+=largv0;
               }
               else {
                    errmsg(NOTENS);
               }
          }
          else {
               errmsg(CNOTIL);
          }
     }
}
 
smodtpc()
{
     btumil(usrnum,DFTIMX);
     input[TPCSIZ-1]='\0';
     strcpy(emlptr->eblk.topic,margv[0]);
     prfmsg(newstt=RAFTLN);
     zapcnc();
}
 
smodlin()
{
     char *point1,*point2;
 
     btumil(usrnum,DFTIMX);
     if (inplen > emlptr->vtxlen) {
          input[inplen=emlptr->vtxlen]='\0';
          prfmsg(MODTOB);
     }
     point1=startof(emlptr->lineno);
     point2=startof(emlptr->lineno+1);
     movmem(point2,point1+inplen+1,strlen(point2)+1);
     *point1='\r';
     movmem(input,point1+1,inplen);
     prfmsg(newstt=RAFTLN);
     zapcnc();
}
 
sdelmsn()
{
     emlptr->eblk.msgno=atol(margv[0]);
     if (!acqbtv(&(emlptr->eblk),&(emlptr->eblk.msgno),0)) {
          blwoff(NSUCHN);
          return;
     }
     if (!(sameas(emlptr->eblk.whofrm,usaptr->userid)
        || sameas(emlptr->eblk.whoto ,usaptr->userid)
        || (usrptr->flags&ISYSOP))) {
          blwoff(UCANTD,spr("%05lu",emlptr->eblk.msgno));
          return;
     }
     if (confli()) {
          blwoff(USING);
          return;
     }
     cmscan+=largv0;
     prfmsg(OKGONE,spr("%05lu",emlptr->eblk.msgno));
     deleml();
     prfmsg(newstt=REPRMT);
}
 
wrtcnf()
{
     if (emlptr->flags&CREATE) {
          emlptr->flags&=~CREATE;
          prfmsg(NEWSUB);
          emlptr->flags|=NEEDRF;
     }
     prfmsg(WCONFM,spr("%05lu",emlptr->eblk.msgno));
}
 
addsub(subnam)
char *subnam;
{
     int i;
 
     for (i=0 ; i < MAXSUB ; i++) {
          if (subid[i][0] == '\0') {
               setmem(emlptr->eblk.whoto,UIDSIZ,0);
               strcpy(emlptr->eblk.whoto,subnam);
               emlptr->flags|=CREATE;
               prfmsg(newstt=GIVTOP,TPCSIZ-1);
               btumil(usrnum,TPCSIZ-1);
               emlptr->eblk.credat[DATSIZ-1]=(char)i;
               break;
          }
     }
     if (i == MAXSUB) {
          catastro("EMAIL: addsub() mismatch");
     }
}
 
areply()
{
     usaptr->tckavl-=EMLTCK;
     sprintf(emlptr->eblk.topic,"Reply to Message No. %s",
            spr("%05lu",emlptr->eblk.msgno));
     prfmsg(ENTREP,MAXVBT-1);
     newstt=CONTXT;
     emlptr->eblk.vbltxt[0]='\0';
     emlptr->vtxlen=0;
     emlptr->flags|=INAUTO;
}
 
rfshsb()
{
     char *alcmem();
 
     numsbs=0;
     setbtv(emlbb);
     if (sublst != NULL) {
          free(sublst);
          setmem(subid,sizeof(subid),0);
     }
     if (qgebtv("@",2)) {
          do {
               gcrbtv(&(emlptr->eblk),2);
               if (emlptr->eblk.whoto[0] != '@') {
                    break;
               }
               if (sameas(emlptr->eblk.whofrm,"Sysop")) {
                    movmem(emlptr->eblk.whoto,
                        subid[emlptr->eblk.credat[DATSIZ-1]],UIDSIZ);
                    prf("  %-9s ... %s\r",emlptr->eblk.whoto,
                        emlptr->eblk.topic);
                    numsbs+=1;
               }
               else {
                    do {
                         delbtv();
                    } while (qnxbtv() && sameas(emlbb->key,emlptr->eblk.whoto));
               }
          } while (qgtbtv(emlptr->eblk.whoto,2));
     }
     if (numsbs == 0) {
          prf("  <No public message bases installed>\r");
     }
     sublst=alcmem(strlen(prfbuf)+1);
     strcpy(sublst,prfbuf);
     clrprf();
}
 
bgnrd(keyval,keynum,nfndn)
char *keyval;
int keynum,nfndn;
{
     if (!acqbtv(&(emlptr->eblk),keyval,keynum)) {
          blwoff(nfndn);
     }
     else {
          emlptr->keynum=keynum;
          emlptr->subbdn=-1;
          sumams();
          prfsco();
     }
}
 
estabc()
{
     gabbtv(&(emlptr->eblk),emlptr->fpos,emlptr->keynum);
}
 
deleml()
{
     if ((usrptr->flags&ISYSOP) && emlptr->eblk.whoto[0] == '@') {
          emlptr->flags|=NEEDRF;
     }
     delbtv();
     sv.emlopn-=1;
}
 
nxteml()
{
     if (!aqnbtv(&(emlptr->eblk))) {
          blwoff(SCOEND);
     }
     else {
          sumams();
          prfsco();
     }
}
 
lsteml()
{
     if (!aqpbtv(&(emlptr->eblk))) {
          blwoff(SCOBGN);
     }
     else {
          sumams();
          prfsco();
     }
}
 
prfsco()
{
     prfmsg(newstt=(emlptr->keynum == 1 ? SCFSCN : SCOSCN));
}
 
sumams()
{
     char *spr();
 
     prf("#%05s %5.5s %-9s to %-9s RE: %s\n",
          spr("%lu",emlptr->eblk.msgno),emlptr->eblk.credat,
          emlptr->eblk.whofrm,emlptr->eblk.whoto,emlptr->eblk.topic);
     emlptr->fpos=absbtv();
}
 
ademln()
{
     emlptr->eblk.vbltxt[emlptr->vtxlen]='\r';
     strcpy(&emlptr->eblk.vbltxt[emlptr->vtxlen+1],input);
     emlptr->vtxlen+=1+inplen;
}
 
makeml()
{
     sv.emlopn+=1;
     emlptr->eblk.msgno=++sv.emltot;
     setbtv(emlbb);
     date(emlptr->eblk.credat,2);
     movmem(usaptr->userid,emlptr->eblk.whofrm,UIDSIZ);
     insbtv(&(emlptr->eblk));
     if (onsys(emlptr->eblk.whoto)) {
          prf("***\r\7%s has just written you some E-MAIL!\r",usaptr->userid);
          injoth();
          prf("\r%s is online, and has been notified.\r",emlptr->eblk.whoto);
     }
}
 
dmsg4m()
{
     char *msgptr,*linptr;
     char tmpchr;
     int lineno;
 
     prfmsg(MODCHC,emlptr->eblk.whofrm,emlptr->eblk.whoto,emlptr->eblk.topic);
     for (lineno=0,msgptr=emlptr->eblk.vbltxt ; *msgptr != '\0' ; ) {
          for (linptr=msgptr ; *linptr != '\r' && *linptr != '\0' ; linptr++) {
          }
          tmpchr=*linptr;
          *linptr='\0';
          prf("%2d. %s\r",lineno++,msgptr);
          if ((*linptr=tmpchr) == '\0') {
               break;
          }
          msgptr=linptr+1;
     }
     prf("%2d.\r",lineno);
}
 
nallow(lineno)
int lineno;
{
     int i,c,count;
     char *msgptr;
 
     for (i=0,msgptr=emlptr->eblk.vbltxt ; i < lineno ; i++) {
          while ((c=*msgptr++) != '\0' && c != '\r') {
          }
          if (c == '\0') {
               return(min(MAXVBT-(msgptr-(emlptr->eblk.vbltxt))-1,DFTIMX));
          }
     }
     for (count=0 ; (c=*msgptr++) != '\0' && c != '\r' ; count++) {
     }
     return(min(MAXVBT-strlen(emlptr->eblk.vbltxt)-2+count,DFTIMX));
}
 
char *startof(lineno)
int lineno;
{
     int i,c;
     char *msgptr;
 
     msgptr=emlptr->eblk.vbltxt;
     if (lineno < 2) {
          return(msgptr);
     }
     for (i=0 ; i < lineno ; i++) {
          while ((c=*msgptr++) != '\0' && c != '\r') {
          }
          if (c == '\0') {
               break;
          }
     }
     return(msgptr-1);
}
 
static
confli()
{
     long recpos;
 
     recpos=absbtv();
     for (othusn=0,othusp=user ; othusn < NTERMS ; othusn++,othusp++) {
          if (othusn != usrnum
           && othusp->class > SUPIPG
           && othusp->state == EMLSTT
           && othusp->substt != REPRMT
           && emlusr[othusn].fpos == recpos) {
               return(1);
          }
     }
     return(0);
}
 
static
errmsg(msgnum,parm)
int msgnum;
long parm;
{
     prfmsg(msgnum,parm);
     rfrshs(usrptr->substt);
     zapcnc();
}
 
rfrshs(state)
int state;
{
     switch (state) {
     case MODLIN:
          prfmsg(MODLIN,emlptr->lineno,emlptr->vtxlen);
          break;
     case GIVTOP:
          prfmsg(GIVTOP,TPCSIZ-1);
          break;
     default:
          prfmsg(state);
     }
}
 
static
blwoff(msgnum,parm)
int msgnum;
long parm;
{
     prfmsg(msgnum,parm);
     prfmsg(newstt=REPRMT);
     zapcnc();
}
 
zapcnc()
{
     input[1]='\0';
     cmscan=input;
}
 
emlmcu()
{
     char *curdat();
     int curmon,curday,admon,adday;
 
     sscanf(curdat(2),"%d/%d",&curmon,&curday);
     setbtv(emlbb);
     sv.emlopn=0;
     if (qlobtv(0)) {
          do {
               gcrbtv(&emlusr->eblk,0);
               admon=adday=0;
               sscanf(emlusr->eblk.credat,"%d/%d",&admon,&adday);
               if (((admon == curmon && adday < curday-14)
                 || (admon != curmon && adday < curday+31-14))
                 && !sameas(emlusr->eblk.whofrm,"Sysop")) {
                    delbtv();
               }
               else {
                    sv.emlopn+=1;
               }
          } while (qnxbtv());
     }
}
 
emlhup()
{
     if (emlusr[usrnum].flags&GOTSFS) {
          setbtv(sfsbb);
          geqbtv(&newmrc,usaptr->userid,0);
          movmem(emlusr[usrnum].sofars,newmrc.sofars,MAXSUB*sizeof(long));
          updbtv(&newmrc);
     }
     setmem(&emlusr[usrnum],sizeof(struct emlusr),0);
}
 
dlaeml(uid)
char *uid;
{
     setbtv(sfsbb);
     if (acqbtv(NULL,uid,0)) {
          delbtv();
     }
}
 
clseml()
{
     clsmsg(emlmb);
     clsbtv(emlbb);
     clsbtv(sfsbb);
}
