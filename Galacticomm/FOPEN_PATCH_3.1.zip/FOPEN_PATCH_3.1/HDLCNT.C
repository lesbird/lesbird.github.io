#include <stdio.h>

main(argc,argv)
int argc;
char *argv[];
{
     int n;

     if (argc == 1) {
          printf("\nFormat:  HDLCNT <testfile>\n");
          exit(1);
     }
     else {
          printf("Total number of files that can be fopen()'d at once:  ");
          for (n=5 ; fopen(argv[1],"r") != NULL ; n++) {
               printf("%3d\b\b\b",n+1);
          }
          printf("\n(this includes the 5 standard \"std\" devices)\n");
          exit(0);
     }
}
