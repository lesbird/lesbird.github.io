LEVITAR 3
=========

todo/wish list:

Super Shield		- deflects shots
Air Strike
Cloaking Device
Alien Ship Hack		- temporarily controls alien ship
Physics Puzzles		- requires use of tractor beam to move objects and open pathways
Moon Patrol levels	- land ship on vehicle and drive vehicle ala Moon Patrol (underground missions?)
Rail Drone			- flys around and rail gun's enemy


EFX FILE COMMANDS
=================
BUMPMAP=<bump file>,<bump scale>	- apply a scaled bump map to the object
ENVMAP=<environment map file>		- apply an environment map to the object
TEX0=<texture file>					- override default texture
XFORM<s>=<n>,<r>					- apply texture transform type <n> on stage <s> with rate <r>


OBJECT TAGS
===========
COLLECTEE	- Object is a collectee
COLLECTOR	- Object is a collector platform
LANDPAD		- Object is a landing pad
NOTRANS		- No camera collision translucency for this object
OBJECTIVE	- Object is a collectee and the mission objective (completes the mission when colleted)


CHEAT CODES
===========
ALLITEMS	- Get all inventory items
ABOMBS		- Add Sub-Atomic Bombs
BOMBS		- Add BFBs to inventory
CBOMBS		- Add Cluster Bombs to inventory
FREEAMMO	- Unlimited ammo
FREEFUEL	- Unlimited fuel
FREESHIP	- Add 100,000 points and gain a free ship
FUEL		- Refill ships fuel to 100%
NODAMAGE	- Toggle ship damage on/off
PLASMA		- Add plasma gun and ammo to inventory
RESEARCHALL - Research all items
SHIELDS		- Replenish shield energy
SBOMBS		- Add Smart Bombs
VBOMBS		- Add Vortex Bombs
UNLOCKALL	- Unlock all missions
WIN			- Complete the mission


FUNCTIONS
=========
GamePrintText(int x,int y,const char *fmt,...)
				<S> = small font
				<M> = medium font
				<L> = large font
				<CR>= color bright red
				<Cr>= color dark red
				<CG>= color bright green
				<Cg>= color dark green
				<CY>= color bright yellow
				<Cy>= color dark yellow
				<CB>= color bright blue
				<Cb>= color dark blue
				<CC>= color bright cyan
				<Cc>= color dark cyan
				<CP>= color bright purple
				<Cp>= color dark purple
				<CW>= color bright white
				<Cw>= color gray


LUA Script Commands
===================
lev.fireprojectile(proj_type,pos,vel,life_span,gobj)
								- Fires a projectile of type (proj_type) from (pos) with velocity (vel), life span and owner
lev.hitrayterrain(x,y,z,dirx,diry,dirz,len)
								- Casts a ray of length (len) from (x,y,z) in direction (dirx,diry,dirz)
								  returns hitposx,hitposy,hitposz,hitnorx,hitnory,hitnorz,hitlen
lev.platform(gobj,target_y,delta_time)
								- Operates platform if gobj is dead. Moves platform to target_y
lev.spawnexplosion(x,y,z,size,scale_rate,life_span,force,r,g,b,a,file_name,instigator)
								- Spawn an explosion with the passed-in parameters
lev.updatescrapingsound(gobj)	- Updates scraping sound for gobj
lev.ufo(gobj,delta_time)		- Moves ufo (gobj) to random altitude when activated


WEAPON LIST
===========
Particle Cannon

Static Gun
Chain Gun
Rail Gun
Plasma Gun

Big Bomb
ClusterBomb
Electro Magnetic Pulse
Vortex Bomb
Sub-Atomic Bomb

Rail Drone


Episode/Weapon list
===================

Moon "Io", volcanic, low gravity

E1M1		- New planet intro
E1M2		- Shields/Static Gun
E1M3		- Clusters/Plasma Gun
E1M4		- EMP/BFB/Rail Gun
E1M5
E1M6

Moon "Lunar", dusty, low gravity

E2M1		- New planet intro
E2M2		- Kill Sphere (through-out levels)
E2M3		- Vortex Bomb (impact, mini black hole)
E2M4
E2M5
E2M6

Planet "Pluto", icy, medium gravity

E3M1		- New planet intro
E3M2		- Concrete blocks (through-out levels)
E3M3		- Sub Atomic Bomb (impact, massive destruction)
E3M4
E3M5
E3M6

Planet "Venus", greenhouse, medium gravity

E4M1		- New planet intro
E4M2
E4M3
E4M4
E4M5
E4M6

Planet "Neptune", windy, strong gravity

E5M1		- New planet intro
E5M2
E5M3
E5M4
E5M5
E5M6

Planet "Jupiter", stormy, extreme gravity

E6M1		- New planet intro
E6M2
E6M3
E6M4
E6M5
E6M6
