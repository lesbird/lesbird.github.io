--	drop platform tower if dead

lev.platform(gobj,-24940,delta_time)
