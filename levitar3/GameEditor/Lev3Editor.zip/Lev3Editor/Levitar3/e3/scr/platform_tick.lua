--	drop platform tower if dead

function tick(gobj,delta_time)
	local param=obj.getvar(gobj,"comp")
	local tower_obj=gam.findobj(param)
	local target_y=-24940
	while (tower_obj ~= nil and gam.ptrisvalid(tower_obj)) do
		local buffer=obj.getptr(tower_obj,"sndb")
		if (obj.isalive(gobj)) then
			if (gam.ptrisnil(buffer)) then
				buffer=snd.precache("snd/lifloop2.wav")
				obj.setptr(tower_obj,"sndb",buffer)
			end
		else
			local x,y,z=obj.getpos(tower_obj)
			if (y > target_y) then
				if (not snd.isplaying(buffer)) then
					snd.play("snd/lifstrt2.wav")
					snd.loophandle(buffer,tower_obj)
					phy.enableall()
				end
				local mov_y=20*delta_time
				y=y-mov_y
				if (y <= target_y) then
					snd.play("snd/lifstop2.wav")
					snd.stop(buffer)
					y=target_y
				end
				obj.setpos(tower_obj,x,y,z)
			end
		end
		tower_obj=gam.findnextobj(param,tower_obj)
	end
	if (obj.isalive(gobj)) then
		local buffer=obj.getptr(gobj,"sndb")
		if (gam.ptrisvalid(buffer)) then
			if (not snd.isplaying(buffer)) then
				snd.loophandle(buffer,gobj)
			end
		end
	end
end

tick(gobj,delta_time)
