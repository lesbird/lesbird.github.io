--	drop platform tower if dead

lev.platform(gobj,-25180,delta_time*5)
