-- lava.lua

function tick(gobj,delta_time)
	x,y,z=obj.getrot(gobj)
	y=y-(delta_time*5)
	obj.setrot(gobj,x,y,z)
end

tick(gobj,delta_time)
