--	game init script

-- w,h=gam.getscreensize()

-- fov=45
-- aspect=w/h
-- gam.setprojection(fov,aspect,10,300000)
