--	game script for landing platform

function tick(gobj,delta_time)
	local game_time=gam.getgametime()
	local px,py,pz=obj.getpos(gobj)
	local m=obj.getworldmatrix(gobj)
	local spr1=obj.getptr(gobj,"lsp1")
	if (not gam.ptrisnil(spr1)) then
		local x1=-85
		local y1=925
		local z1=-90
		local x,y,z=vec.xform(x1,y1,z1,m)
		spr.setpos(spr1,px+x,py+y,pz+z)
		local a=math.abs(math.sin(game_time))
		spr.setcolor(spr1,1,1,1,a)
		spr.show(spr1)
	end
	local spr2=obj.getptr(gobj,"lsp2")
	if (not gam.ptrisnil(spr2)) then
		local x1=125
		local y1=0
		local z1=38
		local x,y,z=vec.xform(x1,y1,z1,m)
		spr.setpos(spr2,px+x,py+y,pz+z)
		spr.setrot(spr2,-25)
		local a=math.abs(math.sin(game_time+1))
		spr.setcolor(spr2,1,1,1,a)
		spr.show(spr2)
	end
	local spr3=obj.getptr(gobj,"lsp3")
	if (not gam.ptrisnil(spr3)) then
		local x1=125
		local y1=0
		local z1=0
		local x,y,z=vec.xform(x1,y1,z1,m)
		spr.setpos(spr3,px+x,py+y,pz+z)
		spr.setrot(spr3,0)
		local a=math.abs(math.sin(game_time+2))
		spr.setcolor(spr3,1,1,1,a)
		spr.show(spr3)
	end
	local spr4=obj.getptr(gobj,"lsp4")
	if (not gam.ptrisnil(spr4)) then
		local x1=125
		local y1=0
		local z1=-38
		local x,y,z=vec.xform(x1,y1,z1,m)
		spr.setpos(spr4,px+x,py+y,pz+z)
		spr.setrot(spr4,25)
		local a=math.abs(math.sin(game_time+3))
		spr.setcolor(spr4,1,1,1,a)
		spr.show(spr4)
	end
end

tick(gobj,delta_time)
