--	game script for collector platform

function tick(gobj,delta_time)
	if (math.random(100) > 50) then
		local emitter=par.findemitter("vortex")
		if (gam.ptrisvalid(emitter)) then
			local px,py,pz=obj.getpos(gobj)
			px=px+(math.random(280)-140)
			pz=pz+(math.random(280)-140)
			local ay=100+math.random(100)
			local argb=gam.makeargb(255,255,128,255)
			par.addparticle(emitter,px,py+75,pz,0,0,0,0,ay,0,2,argb)
		end
	end
end

tick(gobj,delta_time)
