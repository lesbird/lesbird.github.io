--	turn object on

local act_obj=gam.findobj(param)
while (act_obj ~= nil and gam.ptrisvalid(act_obj)) do
	obj.setbool(act_obj,"ison",true)
	act_obj=gam.findnextobj(param,act_obj)
end
