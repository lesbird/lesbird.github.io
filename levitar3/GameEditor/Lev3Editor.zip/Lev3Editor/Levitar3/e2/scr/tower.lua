--	spew out particles from top of towers

function tick(gobj,delta_time)
	local emitter=par.findemitter("particle")
	if (gam.ptrisvalid(emitter)) then
		local x,y,z=obj.getpos(gobj)
		local gx,gy,gz=phy.getgravity()
		local argb=gam.makeargb(255,255,128,128)
--		for i=1,5 do
			local vx=math.random(500)-250
			local vy=math.random(500)+250
			local vz=math.random(500)-250
			local ax=gx
			local ay=gy*100
			local az=gz
			par.addparticle(emitter,x,y+500,z,vx,vy,vz,ax,ay,az,10,argb)
--		end
	end
end

tick(gobj,delta_time)
