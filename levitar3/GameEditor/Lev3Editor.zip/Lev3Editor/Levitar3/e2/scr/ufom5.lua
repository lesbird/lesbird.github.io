--	ufo activation

lev.ufo(gobj,delta_time)
