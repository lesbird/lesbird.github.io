--	ufo activation

function tick(gobj,delta_time)
	if (obj.isalive(gobj)) then
		local vx,vy,vz=phy.getvelocity(gobj)
		local buffer=obj.getptr(gobj,"sndb")
		if (obj.getbool(gobj,"ison")) then
			local x,y,z=obj.getpos(gobj)
			if (not snd.isplaying(buffer)) then
				local a=y+(1500+math.random(1000))
				obj.setfloat(gobj,"alti",a)
				snd.loophandle(buffer,gobj)
			end
			local alt=obj.getfloat(gobj,"alti")
			if (y < alt) then
				phy.addforce(gobj,0,50,0)
			else
				obj.setbool(gobj,"iact",false)
			end
			phy.setvelocityang(gobj,0,5,0)
		else
			phy.addforce(gobj,-vx,0,0)
		end
--	hover object
		local gx,gy,gz=phy.getgravity()
		local fy=-vy-gy;
		phy.addforce(gobj,0,fy,0)
	end
end

tick(gobj,delta_time)
