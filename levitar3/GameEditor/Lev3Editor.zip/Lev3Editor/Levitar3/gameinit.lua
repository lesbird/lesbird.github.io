--	game init script

gam.loadfont(0,"courier new",10,2)
gam.loadfont(1,"courier new",16,2)
gam.loadfont(2,"courier new",24,2)
gam.loadfont(3,"courier new",8,0)
gam.loadfont(4,"symbol",10,1)
gam.loadfont(5,"symbol",16,1)
gam.loadfont(6,"symbol",24,1)
gam.loadfont(7,"symbol",8,0)
