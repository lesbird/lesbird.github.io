--	stop pump movement

local gobj=gam.findobj(param)
obj.kill(gobj)
