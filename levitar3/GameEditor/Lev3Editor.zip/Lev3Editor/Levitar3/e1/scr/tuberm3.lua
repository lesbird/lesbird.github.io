--	script to spawn particles in tubes

function tick(gobj,delta_time)
	local emitter=par.findemitter("vortex")
	if (gam.ptrisvalid(emitter)) then
		local x,y,z=obj.getpos(gobj)
		local gx,gy,gz=phy.getgravity()
		local argb=gam.makeargb(255,255,128,128)
		local vx=math.random(250)-125
		local vy=0
		local vz=math.random(250)-125
		local ax=gx
		local ay=gy*100
		local az=gz
		par.addparticle(emitter,x-125,y,z,vx,vy,vz,ax,ay,az,10,argb)
	end
end

tick(gobj,delta_time)
