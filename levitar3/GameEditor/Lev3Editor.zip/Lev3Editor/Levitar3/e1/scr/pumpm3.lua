--	script to move the pumps

function tick(gobj,delta_time)
	local x,y,z=obj.getrot(gobj)
	if (y == 0) then
		x=x+(100*delta_time)
	else
		x=x-(100*delta_time)
	end
	obj.setrot(gobj,x,y,z)
end

tick(gobj,delta_time)
