--	script to move the pumps

function tick(gobj,delta_time)
	local move_scale=obj.getfloat(gobj,"mscl")
	if (move_scale > 0) then
		local game_time=gam.getgametime()
		local obj_index=obj.getindex(gobj)
		local x,y,z=obj.getvec(gobj,"inip")
		y=y+((math.sin(game_time+obj_index)*move_scale)*300)
		obj.setpos(gobj,x,y,z)
		local buffer=obj.getptr(gobj,"sndb")
		if (obj.isalive(gobj)) then
			if (gam.ptrisnil(buffer)) then
				buffer=snd.precache("snd/miningmono.wav")
				obj.setptr(gobj,"sndb",buffer)
			else
				if (not snd.isplaying(buffer)) then
					snd.loophandle(buffer,gobj)
				end
			end					
		else
			if (not gam.ptrisnil(buffer)) then
				obj.setptr(gobj,"sndb",nil)
				snd.stop(buffer)
			end
			move_scale=move_scale-(delta_time*0.25)
			if (move_scale < 0) then
				move_scale=0
			end
			obj.setfloat(gobj,"mscl",move_scale)
		end
	end
end

tick(gobj,delta_time)
