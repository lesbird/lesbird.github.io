--	game script for proximity switches

lev.switch(gobj,delta_time)
